<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Job;
use App\Models\EcoTask;
use App\Models\Course;
use App\Models\Mentor;
use App\Models\News;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Admin foydalanuvchi
        User::create([
            'name' => 'Admin',
            'email' => 'admin@ambarella.uz',
            'password' => Hash::make('admin12345'),
            'role' => 'admin',
            'greencoin_balance' => 100,
        ]);

        // Test foydalanuvchi
        User::create([
            'name' => 'Test User',
            'email' => 'test@ambarella.uz',
            'password' => Hash::make('test12345'),
            'role' => 'user',
            'greencoin_balance' => 50,
        ]);

        // Ish e'lonlari
        $jobs = [
            ['title' => 'Frontend Developer', 'company' => 'TechCorp UZ', 'location' => 'Toshkent', 'type' => 'masofaviy', 'salary_min' => 5000000, 'salary_max' => 8000000, 'tags' => ['React', 'TypeScript', 'CSS'], 'description' => 'React va TypeScript bilan veb-ilovalar yaratish. 2+ yil tajriba talab qilinadi.', 'is_active' => true],
            ['title' => 'Backend Developer', 'company' => 'DataFlow', 'location' => 'Masofaviy', 'type' => 'masofaviy', 'salary_min' => 7000000, 'salary_max' => 12000000, 'tags' => ['PHP', 'Laravel', 'MySQL'], 'description' => 'Laravel framework bilan API va backend tizimlar yaratish.', 'is_active' => true],
            ['title' => 'UX/UI Dizayner', 'company' => 'GreenFuture', 'location' => 'Samarqand', 'type' => 'toliq', 'salary_min' => 4000000, 'salary_max' => 6000000, 'tags' => ['Figma', 'Adobe XD', 'Prototyping'], 'description' => 'Mobil va veb ilovalar uchun foydalanuvchi interfeyslari dizayni.', 'is_active' => true],
            ['title' => 'Marketing mutaxassisi', 'company' => 'StartupHub', 'location' => 'Toshkent', 'type' => 'toliq', 'salary_min' => 6000000, 'salary_max' => 9000000, 'tags' => ['SMM', 'SEO', 'Content'], 'description' => 'Ijtimoiy tarmoqlar va digital marketing strategiyalari.', 'is_active' => true],
            ['title' => 'Data Analyst', 'company' => 'FinTech UZ', 'location' => 'Masofaviy', 'type' => 'masofaviy', 'salary_min' => 8000000, 'salary_max' => 15000000, 'tags' => ['Python', 'SQL', 'PowerBI'], 'description' => 'Ma\'lumotlar tahlili va biznes-intellekt hisobotlari.', 'is_active' => true],
            ['title' => 'Mobile Developer', 'company' => 'AppFactory', 'location' => 'Toshkent', 'type' => 'toliq', 'salary_min' => 6000000, 'salary_max' => 10000000, 'tags' => ['Flutter', 'Dart', 'Firebase'], 'description' => 'Flutter bilan cross-platform mobil ilovalar yaratish.', 'is_active' => true],
        ];
        foreach ($jobs as $job) { Job::create($job); }

        // Ekologik vazifalar
        $ecoTasks = [
            ['title' => 'Plastik chiqindilarni ajratish', 'description' => 'Bugun uy chiqindilarini plastik, qog\'oz va organikga ajrating', 'reward' => 5, 'category' => 'Chiqindi', 'is_active' => true],
            ['title' => 'Velosipedda yurish', 'description' => 'Bugun transport o\'rniga velosiped yoki piyoda yuring', 'reward' => 10, 'category' => 'Transport', 'is_active' => true],
            ['title' => 'Chiroqlarni o\'chirish', 'description' => 'Ishlatilmayotgan xonalardagi chiroqlarni o\'chiring', 'reward' => 3, 'category' => 'Energiya', 'is_active' => true],
            ['title' => 'Daraxt ekish', 'description' => 'Bir tup ko\'chat eking yoki mavjud daraxtni parvarish qiling', 'reward' => 20, 'category' => 'Kundalik', 'is_active' => true],
            ['title' => 'Suv tejash', 'description' => 'Dush vaqtini 5 daqiqaga qisqartiring', 'reward' => 5, 'category' => 'Energiya', 'is_active' => true],
            ['title' => 'Qog\'oz ishlatmaslik', 'description' => 'Bugun hamma narsani raqamli formatda bajaring', 'reward' => 7, 'category' => 'Chiqindi', 'is_active' => true],
        ];
        foreach ($ecoTasks as $task) { EcoTask::create($task); }

        // Kurslar
        $courses = [
            ['title' => 'Python dasturlash asoslari', 'instructor' => 'Abdullo Rahimov', 'duration' => '3 oy', 'price' => 0, 'level' => 'Boshlang\'ich', 'rating' => 4.8, 'category' => 'Dasturlash', 'description' => 'Python tilini noldan o\'rganish. O\'zgaruvchilar, funksiyalar, OOP va loyiha yaratish.'],
            ['title' => 'Web Development (Full Stack)', 'instructor' => 'Sardor Karimov', 'duration' => '6 oy', 'price' => 500000, 'level' => 'O\'rta', 'rating' => 4.9, 'category' => 'Dasturlash', 'description' => 'HTML, CSS, JavaScript, React, Node.js va MongoDB bilan to\'liq stack.'],
            ['title' => 'Grafik Dizayn', 'instructor' => 'Nilufar Toshmatova', 'duration' => '2 oy', 'price' => 0, 'level' => 'Boshlang\'ich', 'rating' => 4.6, 'category' => 'Dizayn', 'description' => 'Adobe Photoshop, Illustrator va Figma bilan ishlash.'],
            ['title' => 'Digital Marketing', 'instructor' => 'Jasur Alimov', 'duration' => '2 oy', 'price' => 300000, 'level' => 'Boshlang\'ich', 'rating' => 4.5, 'category' => 'Marketing', 'description' => 'SMM, SEO, kontekst reklama va content marketing strategiyalari.'],
            ['title' => 'Data Science', 'instructor' => 'Firdavs Nazarov', 'duration' => '4 oy', 'price' => 800000, 'level' => 'Yuqori', 'rating' => 4.7, 'category' => 'Dasturlash', 'description' => 'Ma\'lumotlar tahlili, Machine Learning va sun\'iy intellekt asoslari.'],
        ];
        foreach ($courses as $course) { Course::create($course); }

        // Mentorlar
        $mentors = [
            ['name' => 'Aziz Sultonov', 'role' => 'Senior Frontend Developer', 'experience' => '7 yil', 'skills' => ['React', 'Vue.js', 'TypeScript', 'CSS'], 'rating' => 4.9, 'is_available' => true],
            ['name' => 'Malika Karimova', 'role' => 'Product Manager', 'experience' => '5 yil', 'skills' => ['Agile', 'Jira', 'Analytics', 'UX Research'], 'rating' => 4.8, 'is_available' => true],
            ['name' => 'Otabek Mirzayev', 'role' => 'DevOps Engineer', 'experience' => '6 yil', 'skills' => ['AWS', 'Docker', 'Kubernetes', 'CI/CD'], 'rating' => 4.7, 'is_available' => true],
            ['name' => 'Dildora Rahimova', 'role' => 'UX/UI Designer', 'experience' => '4 yil', 'skills' => ['Figma', 'Adobe XD', 'User Research', 'Prototyping'], 'rating' => 4.8, 'is_available' => true],
            ['name' => 'Rustam Toshmatov', 'role' => 'Backend Architect', 'experience' => '8 yil', 'skills' => ['PHP', 'Laravel', 'Go', 'PostgreSQL', 'Redis'], 'rating' => 4.9, 'is_available' => true],
        ];
        foreach ($mentors as $mentor) { Mentor::create($mentor); }

        // Yangiliklar
        $newsItems = [
            ['title' => 'AMBARELLA platformasi ishga tushdi!', 'content' => 'O\'zbekiston yoshlari uchun ko\'p funksiyali platforma rasman ishga tushdi. Bandlik, ekologiya, ta\'lim va mentorlik modullari mavjud.', 'author' => 'SADAF DEV', 'category' => 'Platforma'],
            ['title' => 'GreenCoin tizimi yangilandi', 'content' => 'Ekologik vazifalarni bajarish uchun yangi mukofotlar va imtiyozlar qo\'shildi. Yangi vazifalar kundalik ravishda yangilanadi.', 'author' => 'Eco Team', 'category' => 'Ekologiya'],
            ['title' => 'Yangi kurslar qo\'shildi', 'content' => 'Academy moduliga Data Science, Mobile Development va Digital Marketing kurslari qo\'shildi. Bepul va pullik variantlar mavjud.', 'author' => 'Academy', 'category' => 'Ta\'lim'],
            ['title' => '100+ ish e\'lonlari', 'content' => 'Platformada 100 dan ortiq faol ish e\'lonlari mavjud. IT, marketing, dizayn va boshqa sohalarda imkoniyatlar.', 'author' => 'Jobs Team', 'category' => 'Bandlik'],
        ];
        foreach ($newsItems as $item) { News::create($item); }
    }
}
