<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            if (!Schema::hasColumn('users', 'phone_normalized')) {
                $table->string('phone_normalized', 20)->nullable()->after('phone')->index();
            }
            if (!Schema::hasColumn('users', 'referral_rewarded')) {
                $table->boolean('referral_rewarded')->default(false)->after('referral_count');
            }
        });

        // Mavjud userlarning phone_normalized ni to'ldirish
        DB::statement("UPDATE users SET phone_normalized = REGEXP_REPLACE(phone, '[^0-9]', '') WHERE phone IS NOT NULL AND phone != ''");
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn(['phone_normalized', 'referral_rewarded']);
        });
    }
};
