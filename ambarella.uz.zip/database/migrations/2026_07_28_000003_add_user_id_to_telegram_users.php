<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('telegram_users', function (Blueprint $table) {
            if (!Schema::hasColumn('telegram_users', 'user_id')) {
                $table->unsignedBigInteger('user_id')->nullable()->after('chat_id');
                $table->foreign('user_id')->references('id')->on('users')->nullOnDelete();
            }
            if (!Schema::hasColumn('telegram_users', 'phone')) {
                $table->string('phone', 20)->nullable()->after('user_id');
            }
            if (!Schema::hasColumn('telegram_users', 'username')) {
                $table->string('username')->nullable()->after('phone');
            }
            if (!Schema::hasColumn('telegram_users', 'first_name')) {
                $table->string('first_name')->nullable()->after('username');
            }
        });
    }

    public function down(): void
    {
        Schema::table('telegram_users', function (Blueprint $table) {
            $table->dropForeign(['user_id']);
            $table->dropColumn(['user_id', 'phone', 'username', 'first_name']);
        });
    }
};
