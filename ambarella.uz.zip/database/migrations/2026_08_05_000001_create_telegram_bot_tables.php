<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            if (!Schema::hasColumn('users', 'referral_rewarded')) {
                $table->boolean('referral_rewarded')->default(false)->after('referral_count');
            }
        });

        if (Schema::hasTable('telegram_users') && !Schema::hasColumn('telegram_users', 'user_id')) {
            Schema::table('telegram_users', function (Blueprint $table) {
                $table->foreignId('user_id')->nullable()->after('phone')->constrained('users')->nullOnDelete();
            });
        }

        Schema::create('telegram_bot_tasks', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->text('description')->nullable();
            $table->string('task_type')->default('generic');
            $table->integer('reward')->default(0);
            $table->boolean('requires_approval')->default(true);
            $table->boolean('is_active')->default(true);
            $table->timestamp('start_at')->nullable();
            $table->timestamp('end_at')->nullable();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
        });

        Schema::create('telegram_bot_submissions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('task_id')->constrained('telegram_bot_tasks')->cascadeOnDelete();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->string('chat_id');
            $table->text('payload')->nullable();
            $table->string('media_type')->nullable();
            $table->enum('status', ['draft', 'pending', 'approved', 'rejected'])->default('draft');
            $table->foreignId('reviewed_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('reviewed_at')->nullable();
            $table->integer('reward_amount')->default(0);
            $table->text('notes')->nullable();
            $table->timestamps();
        });

        Schema::create('telegram_referrals', function (Blueprint $table) {
            $table->id();
            $table->foreignId('inviter_user_id')->constrained('users')->cascadeOnDelete();
            $table->string('invitee_phone')->nullable();
            $table->foreignId('invitee_user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('invite_code')->nullable();
            $table->enum('status', ['pending', 'completed', 'invalid'])->default('pending');
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            if (Schema::hasColumn('users', 'referral_rewarded')) {
                $table->dropColumn('referral_rewarded');
            }
        });

        if (Schema::hasTable('telegram_users') && Schema::hasColumn('telegram_users', 'user_id')) {
            Schema::table('telegram_users', function (Blueprint $table) {
                $table->dropForeign(['user_id']);
                $table->dropColumn('user_id');
            });
        }

        Schema::dropIfExists('telegram_bot_submissions');
        Schema::dropIfExists('telegram_bot_tasks');
        Schema::dropIfExists('telegram_referrals');
    }
};
