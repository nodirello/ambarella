<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Job listings indexes
        if (Schema::hasTable('job_listings')) {
            Schema::table('job_listings', function (Blueprint $table) {
                $table->index(['is_active', 'created_at']);
            });
        }

        // GreenCoin transactions indexes
        if (Schema::hasTable('green_coin_transactions')) {
            Schema::table('green_coin_transactions', function (Blueprint $table) {
                $table->index(['user_id', 'type']);
                $table->index(['user_id', 'created_at']);
            });
        }

        // Daily tasks indexes
        if (Schema::hasTable('daily_tasks')) {
            Schema::table('daily_tasks', function (Blueprint $table) {
                $table->index(['user_id', 'date']);
            });
        }

        // Habits indexes
        if (Schema::hasTable('habits')) {
            Schema::table('habits', function (Blueprint $table) {
                $table->index(['user_id', 'streak']);
            });
        }

        // Farm products indexes
        if (Schema::hasTable('farm_products')) {
            Schema::table('farm_products', function (Blueprint $table) {
                $table->index(['is_active', 'category']);
                $table->index(['user_id']);
            });
        }

        // Activity log indexes
        if (Schema::hasTable('activity_logs')) {
            Schema::table('activity_logs', function (Blueprint $table) {
                $table->index(['user_id', 'created_at']);
            });
        }
    }

    public function down(): void
    {
        // Laravel handles index drops automatically
    }
};
