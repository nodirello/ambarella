<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('courses', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->string('instructor');
            $table->string('duration');
            $table->integer('price')->default(0);
            $table->string('level');
            $table->decimal('rating', 2, 1)->default(0);
            $table->string('category');
            $table->text('description')->nullable();
            $table->string('image')->nullable();
            $table->timestamps();
        });

        Schema::create('course_user', function (Blueprint $table) {
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->foreignId('course_id')->constrained()->onDelete('cascade');
            $table->primary(['user_id', 'course_id']);
            $table->timestamps();
        });
    }

    public function down(): void { Schema::dropIfExists('course_user'); Schema::dropIfExists('courses'); }
};
