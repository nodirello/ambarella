<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('mentors', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('role');
            $table->string('experience');
            $table->json('skills')->nullable();
            $table->decimal('rating', 2, 1)->default(0);
            $table->boolean('is_available')->default(true);
            $table->timestamps();
        });

        Schema::create('mentor_requests', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->foreignId('mentor_id')->constrained()->onDelete('cascade');
            $table->enum('status', ['pending', 'accepted', 'rejected'])->default('pending');
            $table->timestamps();
        });
    }

    public function down(): void { Schema::dropIfExists('mentor_requests'); Schema::dropIfExists('mentors'); }
};
