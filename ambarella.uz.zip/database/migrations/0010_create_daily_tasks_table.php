<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Kundalik vazifalar
        Schema::create('daily_tasks', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('text');
            $table->boolean('is_done')->default(false);
            $table->date('date');
            $table->timestamps();
        });

        // Odatlar (habits)
        Schema::create('habits', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('name');
            $table->integer('streak')->default(0);
            $table->date('last_completed')->nullable();
            $table->timestamps();
        });

        // Ustoz-shogird bog'lanish
        Schema::create('mentorships', function (Blueprint $table) {
            $table->id();
            $table->foreignId('mentor_id')->constrained('users')->onDelete('cascade');
            $table->foreignId('student_id')->constrained('users')->onDelete('cascade');
            $table->enum('status', ['pending', 'active', 'completed'])->default('pending');
            $table->text('goal')->nullable();
            $table->timestamps();
        });

        // Ustoz vazifalari (shogirdga berilgan)
        Schema::create('mentor_tasks', function (Blueprint $table) {
            $table->id();
            $table->foreignId('mentorship_id')->constrained()->onDelete('cascade');
            $table->string('title');
            $table->text('description')->nullable();
            $table->boolean('is_done')->default(false);
            $table->date('deadline')->nullable();
            $table->timestamps();
        });

        // Qishloq — fermer mahsulotlari
        Schema::create('farm_products', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('name');
            $table->string('category');
            $table->integer('price');
            $table->string('unit')->default('kg');
            $table->string('region');
            $table->text('description')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('farm_products');
        Schema::dropIfExists('mentor_tasks');
        Schema::dropIfExists('mentorships');
        Schema::dropIfExists('habits');
        Schema::dropIfExists('daily_tasks');
    }
};
