<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Users jadvaliga telegram maydonlar qo'shish
        Schema::table('users', function (Blueprint $table) {
            $table->string('telegram_id')->nullable()->unique()->after('phone');
            $table->string('telegram_username')->nullable()->after('telegram_id');
        });

        // Telegram bot foydalanuvchilari (kod yuborish uchun)
        Schema::create('telegram_users', function (Blueprint $table) {
            $table->id();
            $table->string('chat_id')->unique();
            $table->string('phone')->nullable()->index();
            $table->string('username')->nullable();
            $table->string('first_name')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn(['telegram_id', 'telegram_username']);
        });
        Schema::dropIfExists('telegram_users');
    }
};
