<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->date('birth_date')->nullable()->after('phone');
            $table->enum('gender', ['male', 'female'])->nullable()->after('birth_date');
            $table->string('region', 100)->nullable()->after('gender');
            $table->text('bio')->nullable()->after('region');
            $table->json('interests')->nullable()->after('bio');
            $table->boolean('profile_completed')->default(false)->after('is_banned');
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn(['birth_date', 'gender', 'region', 'bio', 'interests', 'profile_completed']);
        });
    }
};
