-- ============================================
-- AMBARELLA.UZ DEMO MA'LUMOTLAR
-- MySQL orqali joylash uchun
-- ============================================

-- Admin foydalanuvchi (parol: admin12345)
INSERT INTO users (name, email, password, role, greencoin_balance, profile_completed, created_at, updated_at) VALUES
('Admin', 'admin@ambarella.uz', '$2y$12$LQv3YfOdOxyFk.gj1D6KEuVH7B6RUbSz7q2mJzXxFNlGN/7V6XWWK', 'admin', 100, 1, NOW(), NOW());

-- Test foydalanuvchi (parol: test12345)
INSERT INTO users (name, email, password, role, greencoin_balance, profile_completed, created_at, updated_at) VALUES
('Test User', 'test@ambarella.uz', '$2y$12$LQv3YfOdOxyFk.gj1D6KEuVH7B6RUbSz7q2mJzXxFNlGN/7V6XWWK', 'user', 50, 1, NOW(), NOW());

-- ============================================
-- ISH E'LONLARI
-- ============================================
INSERT INTO job_listings (title, company, location, type, salary_min, salary_max, tags, description, is_active, created_at, updated_at) VALUES
('Frontend Developer', 'TechCorp UZ', 'Toshkent', 'masofaviy', 5000000, 8000000, '["React","TypeScript","CSS"]', 'React va TypeScript bilan veb-ilovalar yaratish. 2+ yil tajriba talab qilinadi. Remote ishlash imkoniyati.', 1, NOW(), NOW()),
('Backend Developer', 'DataFlow', 'Masofaviy', 'masofaviy', 7000000, 12000000, '["PHP","Laravel","MySQL"]', 'Laravel framework bilan API va backend tizimlar yaratish. REST API, database optimization.', 1, NOW(), NOW()),
('UX/UI Dizayner', 'GreenFuture', 'Samarqand', 'toliq', 4000000, 6000000, '["Figma","Adobe XD","Prototyping"]', 'Mobil va veb ilovalar uchun foydalanuvchi interfeyslari dizayni. Portfolio talab qilinadi.', 1, NOW(), NOW()),
('Marketing mutaxassisi', 'StartupHub', 'Toshkent', 'toliq', 6000000, 9000000, '["SMM","SEO","Content"]', 'Ijtimoiy tarmoqlar va digital marketing strategiyalari. Instagram, Telegram, Facebook.', 1, NOW(), NOW()),
('Data Analyst', 'FinTech UZ', 'Masofaviy', 'masofaviy', 8000000, 15000000, '["Python","SQL","PowerBI"]', 'Ma''lumotlar tahlili va biznes-intellekt hisobotlari. Python, pandas, matplotlib.', 1, NOW(), NOW()),
('Mobile Developer', 'AppFactory', 'Toshkent', 'toliq', 6000000, 10000000, '["Flutter","Dart","Firebase"]', 'Flutter bilan cross-platform mobil ilovalar yaratish. iOS va Android.', 1, NOW(), NOW()),
('DevOps Engineer', 'CloudTech', 'Masofaviy', 'masofaviy', 10000000, 18000000, '["Docker","AWS","CI/CD"]', 'Infratuzilmani boshqarish, deployment avtomatlashtirish, monitoring.', 1, NOW(), NOW()),
('Project Manager', 'InnoLab', 'Toshkent', 'toliq', 8000000, 14000000, '["Agile","Jira","Scrum"]', 'IT loyihalarni boshqarish. 3+ yil PM tajriba. Agile/Scrum metodologiyasi.', 1, NOW(), NOW());

-- ============================================
-- EKO VAZIFALAR
-- ============================================
INSERT INTO eco_tasks (title, description, reward, category, is_active, created_at, updated_at) VALUES
('Plastik chiqindilarni ajratish', 'Bugun uy chiqindilarini plastik, qog''oz va organikga ajrating', 5, 'Chiqindi', 1, NOW(), NOW()),
('Velosipedda yurish', 'Bugun transport o''rniga velosiped yoki piyoda yuring', 10, 'Transport', 1, NOW(), NOW()),
('Chiroqlarni o''chirish', 'Ishlatilmayotgan xonalardagi chiroqlarni o''chiring', 3, 'Energiya', 1, NOW(), NOW()),
('Daraxt ekish', 'Bir tup ko''chat eking yoki mavjud daraxtni parvarish qiling', 20, 'Kundalik', 1, NOW(), NOW()),
('Suv tejash', 'Dush vaqtini 5 daqiqaga qisqartiring', 5, 'Energiya', 1, NOW(), NOW()),
('Qog''oz ishlatmaslik', 'Bugun hamma narsani raqamli formatda bajaring', 7, 'Chiqindi', 1, NOW(), NOW()),
('Jamoat transporti', 'Shaxsiy avtomobil o''rniga jamoat transportidan foydalaning', 8, 'Transport', 1, NOW(), NOW()),
('Ovqat isrof qilmaslik', 'Bugun ovqat qoldirmasdan iste''mol qiling', 5, 'Kundalik', 1, NOW(), NOW());

-- ============================================
-- KURSLAR
-- ============================================
INSERT INTO courses (title, instructor, duration, price, level, rating, category, description, created_at, updated_at) VALUES
('Python dasturlash asoslari', 'Abdullo Rahimov', '3 oy', 0, 'Boshlang''ich', 4.8, 'Dasturlash', 'Python tilini noldan o''rganish. O''zgaruvchilar, funksiyalar, OOP va loyiha yaratish.', NOW(), NOW()),
('Web Development (Full Stack)', 'Sardor Karimov', '6 oy', 500000, 'O''rta', 4.9, 'Dasturlash', 'HTML, CSS, JavaScript, React, Node.js va MongoDB bilan to''liq stack.', NOW(), NOW()),
('Grafik Dizayn', 'Nilufar Toshmatova', '2 oy', 0, 'Boshlang''ich', 4.6, 'Dizayn', 'Adobe Photoshop, Illustrator va Figma bilan ishlash asoslari.', NOW(), NOW()),
('Digital Marketing', 'Jasur Alimov', '2 oy', 300000, 'Boshlang''ich', 4.5, 'Marketing', 'SMM, SEO, kontekst reklama va content marketing strategiyalari.', NOW(), NOW()),
('Data Science', 'Firdavs Nazarov', '4 oy', 800000, 'Yuqori', 4.7, 'Dasturlash', 'Ma''lumotlar tahlili, Machine Learning va sun''iy intellekt asoslari.', NOW(), NOW()),
('Mobile App (Flutter)', 'Bekzod Tursunov', '4 oy', 400000, 'O''rta', 4.6, 'Dasturlash', 'Flutter va Dart bilan iOS va Android ilovalar yaratish.', NOW(), NOW()),
('Ingliz tili (IT uchun)', 'Madina Azimova', '3 oy', 0, 'Boshlang''ich', 4.4, 'Til', 'IT mutaxassislar uchun ingliz tili. Texnik leksika va muloqot.', NOW(), NOW());

-- ============================================
-- MENTORLAR
-- ============================================
INSERT INTO mentors (name, role, experience, skills, rating, is_available, created_at, updated_at) VALUES
('Aziz Sultonov', 'Senior Frontend Developer', '7 yil', '["React","Vue.js","TypeScript","CSS"]', 4.9, 1, NOW(), NOW()),
('Malika Karimova', 'Product Manager', '5 yil', '["Agile","Jira","Analytics","UX Research"]', 4.8, 1, NOW(), NOW()),
('Otabek Mirzayev', 'DevOps Engineer', '6 yil', '["AWS","Docker","Kubernetes","CI/CD"]', 4.7, 1, NOW(), NOW()),
('Dildora Rahimova', 'UX/UI Designer', '4 yil', '["Figma","Adobe XD","User Research","Prototyping"]', 4.8, 1, NOW(), NOW()),
('Rustam Toshmatov', 'Backend Architect', '8 yil', '["PHP","Laravel","Go","PostgreSQL","Redis"]', 4.9, 1, NOW(), NOW()),
('Nodira Xasanova', 'Data Scientist', '5 yil', '["Python","TensorFlow","SQL","Tableau"]', 4.7, 1, NOW(), NOW());

-- ============================================
-- YANGILIKLAR
-- ============================================
INSERT INTO news (title, content, author, category, created_at, updated_at) VALUES
('AMBARELLA platformasi ishga tushdi!', 'O''zbekiston yoshlari uchun ko''p funksiyali platforma rasman ishga tushdi. Bandlik, ekologiya, ta''lim va mentorlik modullari mavjud. Platformada 20+ modul bitta joyda jamlangan.', 'SADAF DEV', 'Platforma', NOW(), NOW()),
('GreenCoin tizimi yangilandi', 'Ekologik vazifalarni bajarish uchun yangi mukofotlar va imtiyozlar qo''shildi. Kundalik vazifalar soni 8 taga yetkazildi. Yangi vazifalar har hafta qo''shiladi.', 'Eco Team', 'Ekologiya', NOW(), NOW()),
('Yangi kurslar qo''shildi', 'Academy moduliga Data Science, Mobile Development va Digital Marketing kurslari qo''shildi. Bepul va pullik variantlar mavjud. 7 ta yangi kurs!', 'Academy', 'Ta''lim', NOW(), NOW()),
('Biznes panel ishga tushdi', 'Endi kompaniyalar o''z ish e''lonlarini to''g''ridan-to''g''ri platformaga joylashtirishlari mumkin. Analitika, arizalarni boshqarish va ko''p boshqa funksiyalar.', 'SADAF DEV', 'Platforma', NOW(), NOW()),
('Mentorlik dasturi kengaydi', '6 ta yangi mentor qo''shildi. Frontend, Backend, DevOps, Dizayn, Data Science va Product Management yo''nalishlari mavjud.', 'Mentor Team', 'Mentorlik', NOW(), NOW());

-- ============================================
-- E'LONLAR (ANNOUNCEMENT)
-- ============================================
INSERT INTO announcements (message, type, is_active, created_at, updated_at) VALUES
('Platformaga xush kelibsiz! Ro''yxatdan o''ting va 50 GreenCoin bonus oling.', 'info', 1, NOW(), NOW());

-- ============================================
-- TAYYOR!
-- ============================================
