<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Database\Eloquent\Model;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        // N+1 query detection (faqat development'da)
        if (config('app.env') === 'local') {
            Model::preventLazyLoading();
        }

        // Production'da lazy loading'ga ruxsat, lekin log yozish
        if (config('app.env') === 'production') {
            Model::preventLazyLoading(false);
        }
    }
}
