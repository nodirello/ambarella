<?php

namespace App\Traits;

trait TracksViews
{
    protected function trackView(string $type, int $id, string $title, string $url): void
    {
        $viewed = session()->get('last_viewed', []);
        // Remove if already exists
        $viewed = array_filter($viewed, fn($v) => !($v['type'] === $type && $v['id'] === $id));
        // Add to front
        array_unshift($viewed, [
            'type' => $type,
            'id' => $id,
            'title' => $title,
            'url' => $url,
            'time' => now()->toDateTimeString()
        ]);
        // Keep only 10
        session()->put('last_viewed', array_slice($viewed, 0, 10));
    }
}
