<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MentorRequest extends Model
{
    protected $fillable = ['user_id', 'mentor_id', 'status'];
}
