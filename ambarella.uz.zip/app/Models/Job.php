<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Job extends Model
{
    protected $table = 'job_listings';
    protected $fillable = ['title', 'company', 'company_logo', 'location', 'type', 'salary_min', 'salary_max', 'tags', 'description', 'requirements', 'benefits', 'is_active', 'views_count', 'deadline'];
    protected $casts = ['tags' => 'array', 'is_active' => 'boolean', 'deadline' => 'date'];

    public function applications() { return $this->hasMany(JobApplication::class, 'job_id'); }

    public function isApplied(): bool
    {
        if (!auth()->check()) return false;
        return $this->applications()->where('user_id', auth()->id())->exists();
    }

    public function getTypeColorAttribute(): string
    {
        return match($this->type) {
            'masofaviy' => '#22d3ee',
            'yarim' => '#fbbf24',
            default => '#4ade80',
        };
    }
}
