<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ForumTopic extends Model
{
    protected $fillable = ['user_id', 'title', 'body', 'category', 'views_count', 'is_solved'];

    protected $casts = [
        'is_solved' => 'boolean',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function replies()
    {
        return $this->hasMany(ForumReply::class, 'topic_id');
    }

    public function getRepliesCountAttribute()
    {
        return $this->replies()->count();
    }
}
