<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DailyTask extends Model
{
    protected $fillable = ['user_id', 'text', 'is_done', 'date'];
    protected $casts = ['is_done' => 'boolean', 'date' => 'date'];

    public function user() { return $this->belongsTo(User::class); }
}
