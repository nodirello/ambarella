<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TelegramBotSubmission extends Model
{
    protected $table = 'telegram_bot_submissions';
    protected $fillable = ['task_id', 'user_id', 'chat_id', 'payload', 'media_type', 'status', 'reviewed_by', 'reviewed_at', 'reward_amount', 'notes'];
    protected $casts = [
        'payload' => 'array',
        'reviewed_at' => 'datetime',
    ];

    public function task()
    {
        return $this->belongsTo(TelegramBotTask::class, 'task_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function reviewer()
    {
        return $this->belongsTo(User::class, 'reviewed_by');
    }
}
