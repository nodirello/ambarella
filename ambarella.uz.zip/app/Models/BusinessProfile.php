<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BusinessProfile extends Model
{
    protected $fillable = [
        'user_id', 'company_name', 'company_type', 'logo', 'description',
        'website', 'phone', 'email', 'region', 'is_verified', 'is_active',
        'plan', 'plan_expires_at',
    ];

    protected $casts = [
        'is_verified' => 'boolean',
        'is_active' => 'boolean',
        'plan_expires_at' => 'date',
    ];

    public function user() { return $this->belongsTo(User::class); }
}
