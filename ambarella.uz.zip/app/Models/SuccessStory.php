<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SuccessStory extends Model
{
    protected $fillable = [
        'user_name', 'user_role', 'story', 'avatar_url', 'is_featured',
    ];

    protected $casts = [
        'is_featured' => 'boolean',
    ];
}
