<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\User;

class TelegramUser extends Model
{
    protected $table = 'telegram_users';
    protected $fillable = ['chat_id', 'phone', 'username', 'first_name', 'user_id'];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
