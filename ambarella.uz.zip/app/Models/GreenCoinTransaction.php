<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GreenCoinTransaction extends Model
{
    protected $table = 'greencoin_transactions';
    protected $fillable = ['user_id', 'amount', 'type', 'description'];

    public function user() { return $this->belongsTo(User::class); }
}
