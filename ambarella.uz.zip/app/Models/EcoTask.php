<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EcoTask extends Model
{
    protected $fillable = ['title', 'description', 'reward', 'category', 'is_active', 'icon', 'difficulty', 'co2_saved'];
    protected $casts = ['is_active' => 'boolean'];

    public function getCategoryColorAttribute(): string
    {
        return match($this->category) {
            'daraxt'    => '#16a34a',
            'suv'       => '#0891b2',
            'chiqindi'  => '#f59e0b',
            'transport' => '#8b5cf6',
            'energiya'  => '#ec4899',
            default     => '#4ade80',
        };
    }

    public function getCategoryIconAttribute(): string
    {
        return match($this->category) {
            'daraxt'    => '<path d="M12 22c4-2.5 7-6 7-10a7 7 0 00-14 0c0 4 3 7.5 7 10z"/>',
            'suv'       => '<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z"/>',
            'chiqindi'  => '<polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a1 1 0 011-1h4a1 1 0 011 1v2"/>',
            'transport' => '<circle cx="12" cy="12" r="10"/><path d="M8 12h8M12 8v8"/>',
            default     => '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
        };
    }
}
