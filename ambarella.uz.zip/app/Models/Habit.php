<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Habit extends Model
{
    protected $fillable = ['user_id', 'name', 'streak', 'last_completed'];
    protected $casts = ['last_completed' => 'date'];

    public function user() { return $this->belongsTo(User::class); }
}
