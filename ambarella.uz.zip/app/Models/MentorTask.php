<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MentorTask extends Model
{
    protected $fillable = ['mentorship_id', 'title', 'description', 'is_done', 'deadline'];
    protected $casts = ['is_done' => 'boolean', 'deadline' => 'date'];

    public function mentorship() { return $this->belongsTo(Mentorship::class); }
}
