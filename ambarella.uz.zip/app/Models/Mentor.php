<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Mentor extends Model
{
    protected $fillable = ['name', 'role', 'experience', 'skills', 'rating', 'bio', 'avatar', 'company', 'linkedin', 'sessions_count', 'is_available'];
    protected $casts = ['skills' => 'array', 'is_available' => 'boolean'];

    public function requests() { return $this->hasMany(MentorRequest::class); }

    public function getInitialsAttribute(): string
    {
        $words = explode(' ', $this->name);
        return strtoupper(implode('', array_map(fn($w) => $w[0] ?? '', array_slice($words, 0, 2))));
    }
}
