<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Poll extends Model
{
    protected $fillable = ['question', 'is_active', 'ends_at'];

    protected $casts = [
        'is_active' => 'boolean',
        'ends_at' => 'date',
    ];

    public function options(): HasMany
    {
        return $this->hasMany(PollOption::class);
    }

    public function votes(): HasMany
    {
        return $this->hasMany(PollVote::class);
    }

    public function hasVoted($userId): bool
    {
        return $this->votes()->where('user_id', $userId)->exists();
    }

    public function totalVotes(): int
    {
        return $this->options()->sum('votes_count');
    }
}
