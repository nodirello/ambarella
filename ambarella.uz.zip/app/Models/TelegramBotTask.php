<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TelegramBotTask extends Model
{
    protected $table = 'telegram_bot_tasks';
    protected $fillable = ['title', 'description', 'task_type', 'reward', 'requires_approval', 'is_active', 'start_at', 'end_at', 'created_by'];
    protected $casts = [
        'requires_approval' => 'boolean',
        'is_active' => 'boolean',
        'start_at' => 'datetime',
        'end_at' => 'datetime',
    ];

    public function submissions()
    {
        return $this->hasMany(TelegramBotSubmission::class, 'task_id');
    }

    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}
