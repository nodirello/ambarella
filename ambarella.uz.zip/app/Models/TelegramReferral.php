<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TelegramReferral extends Model
{
    protected $table = 'telegram_referrals';
    protected $fillable = ['inviter_user_id', 'invitee_phone', 'invitee_user_id', 'invite_code', 'status', 'completed_at'];
    protected $casts = [
        'completed_at' => 'datetime',
    ];

    public function inviter()
    {
        return $this->belongsTo(User::class, 'inviter_user_id');
    }

    public function invitee()
    {
        return $this->belongsTo(User::class, 'invitee_user_id');
    }
}
