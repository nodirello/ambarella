<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Course extends Model
{
    protected $fillable = ['title', 'instructor', 'duration', 'price', 'level', 'rating', 'category', 'description', 'image'];

    public function users() { return $this->belongsToMany(User::class, 'course_user'); }
}
