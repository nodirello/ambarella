<?php

namespace App\Models;

use App\Models\GreenCoinTransaction;
use App\Models\TelegramReferral;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable implements MustVerifyEmail
{
    use Notifiable;

    protected $fillable = ['name', 'email', 'phone', 'phone_normalized', 'password', 'greencoin_balance', 'avatar', 'telegram_id', 'telegram_username', 'birth_date', 'gender', 'region', 'bio', 'interests', 'profile_completed', 'referral_code', 'referred_by', 'referral_count', 'referral_rewarded', 'login_streak', 'last_login_date', 'two_factor_enabled'];

    /**
     * Mass assignment himoyasi: role va is_banned faqat admin tomonidan o'zgartiriladi
     */
    protected $guarded = ['role', 'is_banned'];
    protected $hidden = ['password', 'remember_token'];
    protected $casts = ['is_banned' => 'boolean', 'profile_completed' => 'boolean', 'two_factor_enabled' => 'boolean', 'interests' => 'array', 'birth_date' => 'date', 'last_login_date' => 'date', 'email_verified_at' => 'datetime', 'referral_rewarded' => 'boolean', 'referral_count' => 'integer', 'greencoin_balance' => 'integer'];

    public function setPhoneAttribute(?string $value): void
    {
        $this->attributes['phone']            = $value;
        $this->attributes['phone_normalized'] = $value ? preg_replace('/[^0-9]/', '', $value) : null;
    }

    public function isAdmin(): bool { return $this->role === 'admin'; }

    /**
     * Referral mukofotini berish (agar hali berilmagan bo'lsa)
     */
    public function rewardReferralIfEligible(): void
    {
        if (!$this->referred_by || !empty($this->referral_rewarded)) {
            return;
        }

        $referrer = self::find($this->referred_by);
        if (!$referrer) return;

        // Shogirdga bonus
        $this->increment('greencoin_balance', 50);
        \App\Models\GreenCoinTransaction::create([
            'user_id'     => $this->id,
            'amount'      => 50,
            'type'        => 'earned',
            'description' => 'Taklif bonusi (referral)',
        ]);

        // Taklif qiluvchiga bonus
        $referrer->increment('greencoin_balance', 50);
        $referrer->increment('referral_count');
        \App\Models\GreenCoinTransaction::create([
            'user_id'     => $referrer->id,
            'amount'      => 50,
            'type'        => 'earned',
            'description' => 'Referral bonus: ' . $this->name,
        ]);

        // Telegram orqali xabar
        if ($referrer->telegram_id) {
            $token = config('services.telegram.bot_token');
            if ($token) {
                \Illuminate\Support\Facades\Http::post("https://api.telegram.org/bot{$token}/sendMessage", [
                    'chat_id'    => $referrer->telegram_id,
                    'text'       => "🎉 Tabriklaymiz! {$this->name} sizning referal havolangiz orqali ro'yxatdan o'tdi va profilini to'ldirdi.\n\n+50 GreenCoin hisobingizga qo'shildi!",
                    'parse_mode' => 'Markdown',
                ]);
            }
        }

        $this->update(['referral_rewarded' => true]);
    }

    public function transactions() { return $this->hasMany(GreenCoinTransaction::class); }
    public function applications() { return $this->hasMany(JobApplication::class); }
    public function courses() { return $this->belongsToMany(Course::class, 'course_user'); }
    public function dailyTasks() { return $this->hasMany(DailyTask::class); }
    public function telegramUser() { return $this->hasOne(TelegramUser::class, 'user_id'); }
    public function telegramSubmissions() { return $this->hasMany(TelegramBotSubmission::class, 'user_id'); }
    public function referralsSent() { return $this->hasMany(TelegramReferral::class, 'inviter_user_id'); }
    public function referralsReceived() { return $this->hasMany(TelegramReferral::class, 'invitee_user_id'); }
    public function habits() { return $this->hasMany(Habit::class); }
    public function farmProducts() { return $this->hasMany(FarmProduct::class); }
    public function mentorshipsAsMentor() { return $this->hasMany(Mentorship::class, 'mentor_id'); }
    public function mentorshipsAsStudent() { return $this->hasMany(Mentorship::class, 'student_id'); }
    public function businessProfile() { return $this->hasOne(BusinessProfile::class); }
    public function favorites() { return $this->hasMany(Favorite::class); }
    public function achievements() { return $this->hasMany(UserAchievement::class); }
    public function blogPosts() { return $this->hasMany(BlogPost::class); }
    public function referrer() { return $this->belongsTo(User::class, 'referred_by'); }

    public function notes() { return $this->hasMany(Note::class); }
    public function forumTopics() { return $this->hasMany(ForumTopic::class); }
}
