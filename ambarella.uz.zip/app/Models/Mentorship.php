<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Mentorship extends Model
{
    protected $fillable = ['mentor_id', 'student_id', 'status', 'goal'];

    public function mentor() { return $this->belongsTo(User::class, 'mentor_id'); }
    public function student() { return $this->belongsTo(User::class, 'student_id'); }
    public function tasks() { return $this->hasMany(MentorTask::class); }
}
