<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Notifications\Messages\MailMessage;

class NewJobPosted extends Notification
{
    use Queueable;

    private string $jobTitle;
    private string $company;
    private int $jobId;

    public function __construct(string $jobTitle, string $company, int $jobId)
    {
        $this->jobTitle = $jobTitle;
        $this->company = $company;
        $this->jobId = $jobId;
    }

    public function via(object $notifiable): array
    {
        return ['mail', 'database'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)
            ->subject('Yangi ish: ' . $this->jobTitle)
            ->greeting('Salom, ' . $notifiable->name . '!')
            ->line("Yangi ish e'loni chiqdi: {$this->jobTitle} — {$this->company}")
            ->action('Ko\'rish', url('/jobs/' . $this->jobId))
            ->line('AMBARELLA — O\'zbekiston yoshlari platformasi');
    }

    public function toArray(object $notifiable): array
    {
        return [
            'type' => 'new_job',
            'title' => $this->jobTitle,
            'company' => $this->company,
            'job_id' => $this->jobId,
            'message' => "Yangi ish: {$this->jobTitle} — {$this->company}",
        ];
    }
}
