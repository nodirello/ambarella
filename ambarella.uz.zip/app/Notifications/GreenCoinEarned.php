<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;

class GreenCoinEarned extends Notification
{
    use Queueable;

    private int $amount;
    private string $reason;

    public function __construct(int $amount, string $reason)
    {
        $this->amount = $amount;
        $this->reason = $reason;
    }

    public function via(object $notifiable): array
    {
        return ['database'];
    }

    public function toArray(object $notifiable): array
    {
        return [
            'type' => 'greencoin_earned',
            'amount' => $this->amount,
            'reason' => $this->reason,
            'message' => "+{$this->amount} GreenCoin: {$this->reason}",
        ];
    }
}
