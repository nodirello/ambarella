<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\User;
use App\Models\Job;
use App\Models\News;
use Illuminate\Support\Facades\Mail;

class WeeklyDigest extends Command
{
    protected $signature = 'app:weekly-digest';
    protected $description = 'Haftalik yangiliklar digestini foydalanuvchilarga yuborish';

    public function handle(): int
    {
        $this->info('Haftalik digest yuborilmoqda...');

        $newJobs = Job::where('is_active', true)
            ->where('created_at', '>=', now()->subWeek())
            ->take(5)
            ->get();

        $latestNews = News::where('created_at', '>=', now()->subWeek())
            ->take(3)
            ->get();

        $newUsersCount = User::where('created_at', '>=', now()->subWeek())->count();

        if ($newJobs->isEmpty() && $latestNews->isEmpty()) {
            $this->info('Yangilik yo\'q — digest yuborilmadi.');
            return Command::SUCCESS;
        }

        $users = User::where('is_banned', false)
            ->whereNotNull('email')
            ->cursor();

        $sent = 0;
        foreach ($users as $user) {
            try {
                $jobsList = $newJobs->map(fn($j) => "- {$j->title} ({$j->company})")->implode("\n");
                $newsList = $latestNews->map(fn($n) => "- {$n->title}")->implode("\n");

                $body = "Salom, {$user->name}!\n\n";
                $body .= "Bu hafta AMBARELLA'da:\n\n";

                if ($newJobs->isNotEmpty()) {
                    $body .= "Yangi ish e'lonlari:\n{$jobsList}\n\n";
                }
                if ($latestNews->isNotEmpty()) {
                    $body .= "Yangiliklar:\n{$newsList}\n\n";
                }

                $body .= "Yangi foydalanuvchilar: +{$newUsersCount}\n\n";
                $body .= "Platformaga o'tish: " . url('/dashboard') . "\n\n";
                $body .= "— AMBARELLA jamoasi";

                Mail::raw($body, function ($message) use ($user) {
                    $message->to($user->email)
                        ->subject('AMBARELLA — Haftalik digest');
                });

                $sent++;
            } catch (\Exception $e) {
                continue;
            }
        }

        $this->info("{$sent} ta foydalanuvchiga digest yuborildi.");
        return Command::SUCCESS;
    }
}
