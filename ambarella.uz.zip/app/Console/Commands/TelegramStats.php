<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\TelegramUser;
use App\Models\TelegramBotSubmission;
use App\Models\TelegramBotTask;
use Illuminate\Support\Facades\Http;

class TelegramStats extends Command
{
    protected $signature   = 'telegram:stats';
    protected $description = 'Telegram bot statistikasi';

    public function handle(): int
    {
        $token = config('services.telegram.bot_token');

        $this->info('');
        $this->info('  ╔══════════════════════════════════════╗');
        $this->info('  ║     Telegram Bot Statistika          ║');
        $this->info('  ╚══════════════════════════════════════╝');
        $this->info('');

        // Telegram users
        $total    = TelegramUser::count();
        $linked   = TelegramUser::whereNotNull('user_id')->count();
        $unlinked = $total - $linked;

        $this->info('  👥 Foydalanuvchilar:');
        $this->line("  ├─ Jami bot users:  {$total}");
        $this->line("  ├─ Platforma bilan bog'langan: {$linked}");
        $this->line("  └─ Bog'lanmagan:     {$unlinked}");

        // Submissions
        $pending  = TelegramBotSubmission::where('status', 'pending')->count();
        $approved = TelegramBotSubmission::where('status', 'approved')->count();
        $rejected = TelegramBotSubmission::where('status', 'rejected')->count();
        $totalGC  = TelegramBotSubmission::where('status', 'approved')->sum('reward_amount');

        $this->info('');
        $this->info('  📋 Topshiriqlar:');
        $this->line("  ├─ Kutilmoqda:   {$pending}");
        $this->line("  ├─ Tasdiqlangan: {$approved}");
        $this->line("  ├─ Rad etilgan:  {$rejected}");
        $this->line("  └─ Berilgan GC:  " . number_format($totalGC));

        // Tasks
        $activeTasks = TelegramBotTask::where('is_active', true)->count();
        $this->info('');
        $this->info('  ⚙️  Vazifalar:');
        $this->line("  └─ Faol vazifalar: {$activeTasks}");

        // Webhook info
        if ($token) {
            $response = Http::get("https://api.telegram.org/bot{$token}/getWebhookInfo");
            $info = $response->json('result', []);
            $this->info('');
            $this->info('  🔗 Webhook:');
            $this->line("  ├─ URL:     " . ($info['url'] ?? 'O\'rnatilmagan'));
            $this->line("  ├─ Pending: " . ($info['pending_update_count'] ?? 0));
            $this->line("  └─ Xato:    " . ($info['last_error_message'] ?? 'Yo\'q'));
        }

        $this->info('');
        return Command::SUCCESS;
    }
}
