<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Http;

/**
 * Telegram bot'ga buyruqlar ro'yxatini o'rnatish
 * BotFather'ga avtomatik ravishda yuboriladi
 */
class TelegramSetCommands extends Command
{
    protected $signature   = 'telegram:set-commands';
    protected $description = 'Telegram bot buyruqlar menyusini o\'rnatish';

    public function handle(): int
    {
        $token = config('services.telegram.bot_token');
        if (!$token) {
            $this->error('TELEGRAM_BOT_TOKEN topilmadi!');
            return Command::FAILURE;
        }

        $commands = [
            ['command' => 'start',   'description' => '🏠 Bosh menyu'],
            ['command' => 'tasks',   'description' => '🌿 Eco vazifalar (+GreenCoin)'],
            ['command' => 'balance', 'description' => '💰 GreenCoin balansi'],
            ['command' => 'jobs',    'description' => '💼 Yangi ish e\'lonlari'],
            ['command' => 'refer',   'description' => '🔗 Referal havola (do\'stlarni taklif)'],
            ['command' => 'webapp',  'description' => '🌐 Platforma (Telegram ichida)'],
            ['command' => 'status',  'description' => '📊 Topshiriqlar holati'],
            ['command' => 'help',    'description' => '❓ Yordam va buyruqlar'],
        ];

        $response = Http::post(
            "https://api.telegram.org/bot{$token}/setMyCommands",
            ['commands' => $commands]
        );

        if ($response->json('ok')) {
            $this->info('✅ Bot buyruqlari muvaffaqiyatli o\'rnatildi!');
            $this->table(
                ['Buyruq', 'Tavsif'],
                collect($commands)->map(fn($c) => ['/' . $c['command'], $c['description']])->toArray()
            );
            return Command::SUCCESS;
        }

        $this->error('❌ Xatolik: ' . $response->json('description'));
        return Command::FAILURE;
    }
}
