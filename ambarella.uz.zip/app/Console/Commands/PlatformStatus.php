<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\User;
use App\Models\Job;
use App\Models\GreenCoinTransaction;
use Illuminate\Support\Facades\DB;

class PlatformStatus extends Command
{
    protected $signature = 'app:status';
    protected $description = 'AMBARELLA platforma holati';

    public function handle(): int
    {
        $this->info('');
        $this->info('  ╔══════════════════════════════════════╗');
        $this->info('  ║     AMBARELLA Platform Status        ║');
        $this->info('  ╚══════════════════════════════════════╝');
        $this->info('');

        // Database
        try {
            DB::connection()->getPdo();
            $this->line('  ✅ Database: Connected');
        } catch (\Exception $e) {
            $this->error('  ❌ Database: ' . $e->getMessage());
        }

        // Stats
        $this->info('');
        $this->info('  📊 Statistika:');
        $this->line('  ├─ Users: ' . number_format(User::count()));
        $this->line('  ├─ Today new: ' . User::whereDate('created_at', today())->count());
        $this->line('  ├─ Active jobs: ' . Job::where('is_active', true)->count());
        $this->line('  ├─ GreenCoin total: ' . number_format(GreenCoinTransaction::where('type', 'earned')->sum('amount')));
        $this->line('  └─ Banned users: ' . User::where('is_banned', true)->count());

        // System
        $this->info('');
        $this->info('  🖥️  System:');
        $this->line('  ├─ PHP: ' . PHP_VERSION);
        $this->line('  ├─ Laravel: ' . app()->version());
        $this->line('  ├─ Environment: ' . config('app.env'));
        $this->line('  ├─ Debug: ' . (config('app.debug') ? '⚠️  ON' : '✅ OFF'));
        $this->line('  └─ Memory: ' . round(memory_get_usage(true) / 1048576, 1) . ' MB');

        $this->info('');
        return Command::SUCCESS;
    }
}
