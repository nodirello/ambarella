<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Http;

class TelegramSetWebhook extends Command
{
    protected $signature   = 'telegram:set-webhook {--delete : Webhookni o\'chirish}';
    protected $description = 'Telegram bot webhook URL ni o\'rnatish yoki o\'chirish';

    public function handle(): int
    {
        $token  = config('services.telegram.bot_token');
        $secret = config('services.telegram.webhook_secret');

        if (!$token) {
            $this->error('TELEGRAM_BOT_TOKEN .env da yo\'q!');
            return Command::FAILURE;
        }

        if ($this->option('delete')) {
            $response = Http::post("https://api.telegram.org/bot{$token}/deleteWebhook");
            if ($response->json('ok')) {
                $this->info('Webhook o\'chirildi.');
                return Command::SUCCESS;
            }
            $this->error('Xatolik: ' . $response->json('description'));
            return Command::FAILURE;
        }

        $webhookUrl = url('/webhook/telegram');

        $payload = [
            'url'             => $webhookUrl,
            'allowed_updates' => ['message', 'callback_query', 'my_chat_member'],
            'drop_pending_updates' => true,
        ];

        if ($secret) {
            $payload['secret_token'] = $secret;
        }

        $response = Http::post(
            "https://api.telegram.org/bot{$token}/setWebhook",
            $payload
        );

        $result = $response->json();

        if ($result['ok'] ?? false) {
            $this->info('✅ Webhook muvaffaqiyatli o\'rnatildi!');
            $this->line("   URL: {$webhookUrl}");
            return Command::SUCCESS;
        }

        $this->error('❌ Xatolik: ' . ($result['description'] ?? 'Noma\'lum'));
        return Command::FAILURE;
    }
}
