<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\TelegramUser;
use App\Models\TelegramBotTask;
use App\Models\GreenCoinTransaction;
use Illuminate\Support\Facades\Http;

/**
 * Kundalik push xabar — har kuni ertalab bot foydalanuvchilarga
 * bugungi eco vazifalarni va GreenCoin balansini eslatadi.
 */
class TelegramDailyPush extends Command
{
    protected $signature = 'telegram:daily-push
                            {--dry-run : Haqiqatan yubormasdan test qilish}
                            {--chat= : Faqat bitta chat_id ga yuborish (test uchun)}';

    protected $description = 'Bog\'langan Telegram foydalanuvchilarga kundalik eco eslatma yuborish';

    public function handle(): int
    {
        $token = config('services.telegram.bot_token');
        if (!$token) {
            $this->error('TELEGRAM_BOT_TOKEN topilmadi!');
            return Command::FAILURE;
        }

        // Faol eco vazifalar
        $tasks = TelegramBotTask::where('is_active', true)
            ->where(fn($q) => $q->whereNull('start_at')->orWhere('start_at', '<=', now()))
            ->where(fn($q) => $q->whereNull('end_at')->orWhere('end_at', '>=', now()))
            ->where('task_type', 'action')
            ->get();

        if ($tasks->isEmpty()) {
            $this->warn('Yuborilayotgan faol eco vazifa yo\'q.');
            return Command::SUCCESS;
        }

        // Bitta chat_id uchun test
        if ($testChat = $this->option('chat')) {
            $this->sendPush($token, $testChat, $tasks, true);
            $this->info("Test xabari yuborildi: {$testChat}");
            return Command::SUCCESS;
        }

        // Platforma bilan bog'langan va profili to'liq foydalanuvchilar
        $users = TelegramUser::whereNotNull('user_id')
            ->whereHas('user', fn($q) => $q->where('profile_completed', true)->where('is_banned', false))
            ->with('user')
            ->get();

        $sent = 0;
        $skipped = 0;
        $failed = 0;

        $bar = $this->output->createProgressBar($users->count());
        $bar->start();

        foreach ($users as $tgUser) {
            $user = $tgUser->user;

            // Bugun allaqachon eco harakat qilganmi?
            $todayActions = GreenCoinTransaction::where('user_id', $user->id)
                ->whereDate('created_at', today())
                ->where('type', 'earned')
                ->count();

            if ($todayActions > 0) {
                $skipped++;
                $bar->advance();
                continue; // Bugun allaqachon aktiv — eslatma keraksiz
            }

            if (!$this->option('dry-run')) {
                $success = $this->sendPush($token, $tgUser->chat_id, $tasks);
                if ($success) {
                    $sent++;
                } else {
                    $failed++;
                }
                usleep(35000); // ~29 msg/sec — Telegram limit
            } else {
                $sent++;
            }

            $bar->advance();
        }

        $bar->finish();
        $this->newLine(2);

        $this->info("✅ Natija:");
        $this->line("   Yuborildi: {$sent}");
        $this->line("   O'tkazildi (bugun aktiv): {$skipped}");
        $this->line("   Xatolik: {$failed}");

        return Command::SUCCESS;
    }

    private function sendPush(string $token, string $chatId, $tasks, bool $isTest = false): bool
    {
        // Tasodifiy bitta vazifani tanlash
        $task = $tasks->random();

        $greeting = $this->morningGreeting();
        $testLabel = $isTest ? "[TEST] " : "";

        $text = "{$testLabel}{$greeting}\n\n"
            . "🌿 *Bugungi eco vazifa:*\n"
            . "*{$task->title}*\n"
            . ($task->description ? "{$task->description}\n" : "")
            . "\n💰 Mukofot: *+{$task->reward} GreenCoin*\n\n"
            . "Bajarish uchun rasm yuboring yoki:\n"
            . "`/submit eco " . mb_strtolower($task->title) . "`";

        $keyboard = [
            [
                ['text' => '📋 Barcha vazifalar', 'callback_data' => 'show_tasks'],
                ['text' => '💰 Balansim', 'callback_data' => 'show_balance'],
            ],
        ];

        $response = Http::timeout(5)->post(
            "https://api.telegram.org/bot{$token}/sendMessage",
            [
                'chat_id'      => $chatId,
                'text'         => $text,
                'parse_mode'   => 'Markdown',
                'reply_markup' => json_encode(['inline_keyboard' => $keyboard]),
            ]
        );

        return $response->successful() && ($response->json('ok') === true);
    }

    private function morningGreeting(): string
    {
        $hour = (int)now('Asia/Tashkent')->format('H');

        return match(true) {
            $hour >= 5 && $hour < 12  => "☀️ *Xayrli tong!*",
            $hour >= 12 && $hour < 17 => "🌤️ *Xayrli kun!*",
            $hour >= 17 && $hour < 21 => "🌆 *Xayrli kech!*",
            default                   => "🌙 *Salom!*",
        };
    }
}
