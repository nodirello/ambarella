<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\TelegramUser;
use App\Models\GreenCoinTransaction;
use Illuminate\Support\Facades\Http;

/**
 * Haftalik GreenCoin hisobot — har dushanba foydalanuvchilarga
 * o'tgan hafta statistikasi va yangi hafta uchun motivatsiya.
 */
class TelegramWeeklyReport extends Command
{
    protected $signature = 'telegram:weekly-report
                            {--dry-run : Test rejimi}
                            {--chat= : Bitta chat_id ga yuborish}';

    protected $description = 'Haftalik GreenCoin statistikasi va motivatsiya xabari';

    public function handle(): int
    {
        $token = config('services.telegram.bot_token');
        if (!$token) {
            $this->error('TELEGRAM_BOT_TOKEN topilmadi!');
            return Command::FAILURE;
        }

        if ($testChat = $this->option('chat')) {
            $tgUser = TelegramUser::where('chat_id', $testChat)->with('user')->first();
            $user = $tgUser?->user;
            $this->sendWeeklyReport($token, $testChat, $user, true);
            $this->info("Test hisobot yuborildi.");
            return Command::SUCCESS;
        }

        $users = TelegramUser::whereNotNull('user_id')
            ->whereHas('user', fn($q) => $q->where('profile_completed', true)->where('is_banned', false))
            ->with('user')
            ->get();

        $sent = 0;
        $this->info("Hisobotlar yuborilmoqda ({$users->count()} foydalanuvchi)...");

        foreach ($users as $tgUser) {
            if (!$this->option('dry-run')) {
                $this->sendWeeklyReport($token, $tgUser->chat_id, $tgUser->user);
                $sent++;
                usleep(35000);
            } else {
                $sent++;
            }
        }

        $this->info("✅ {$sent} ta foydalanuvchiga haftalik hisobot yuborildi.");
        return Command::SUCCESS;
    }

    private function sendWeeklyReport(string $token, string $chatId, $user, bool $isTest = false): void
    {
        $testLabel = $isTest ? "[TEST] " : "";

        if (!$user) {
            // Bog'lanmagan user uchun oddiy motivatsiya
            $text = "{$testLabel}🗓️ *Yangi hafta boshlandi!*\n\n"
                . "Platformaga ulanib GreenCoin ishlashni boshlang.\n"
                . "Eco vazifalar, challenge va mentorlik sizni kutmoqda!";

            Http::post("https://api.telegram.org/bot{$token}/sendMessage", [
                'chat_id'    => $chatId,
                'text'       => $text,
                'parse_mode' => 'Markdown',
                'reply_markup' => json_encode(['inline_keyboard' => [
                    [['text' => '🌐 Saytga o\'tish', 'url' => url('/register')]],
                ]]),
            ]);
            return;
        }

        // O'tgan hafta statistikasi
        $lastWeekEarned = GreenCoinTransaction::where('user_id', $user->id)
            ->where('type', 'earned')
            ->whereBetween('created_at', [now()->subWeek()->startOfWeek(), now()->subWeek()->endOfWeek()])
            ->sum('amount');

        $lastWeekActions = GreenCoinTransaction::where('user_id', $user->id)
            ->where('type', 'earned')
            ->whereBetween('created_at', [now()->subWeek()->startOfWeek(), now()->subWeek()->endOfWeek()])
            ->count();

        // Daraja
        $level = match(true) {
            $user->greencoin_balance >= 5000 => '👑 Platinum',
            $user->greencoin_balance >= 1000 => '🥇 Gold',
            $user->greencoin_balance >= 500  => '🥈 Silver',
            $user->greencoin_balance >= 100  => '🥉 Bronze',
            default                          => '🌱 Starter',
        };

        // Motivatsiya xabari
        $motivation = $lastWeekEarned > 0
            ? "💪 Zo'r! O'tgan hafta {$lastWeekActions} ta harakat bajardingiz."
            : "🎯 Bu hafta birinchi eco harakatni bajaring va GreenCoin ishlang!";

        $text = "{$testLabel}🗓️ *Haftalik hisobot*\n\n"
            . "👤 {$user->name}\n"
            . "💎 Joriy balans: *{$user->greencoin_balance} GC*\n"
            . "🏆 Daraja: *{$level}*\n"
            . "📈 O'tgan hafta: *+{$lastWeekEarned} GC* ({$lastWeekActions} harakat)\n\n"
            . "{$motivation}\n\n"
            . "Bu haftaning maqsadi: *+100 GC* ishlash 🌿";

        Http::post("https://api.telegram.org/bot{$token}/sendMessage", [
            'chat_id'      => $chatId,
            'text'         => $text,
            'parse_mode'   => 'Markdown',
            'reply_markup' => json_encode(['inline_keyboard' => [
                [
                    ['text' => '🌿 Eco vazifalar', 'callback_data' => 'show_tasks'],
                    ['text' => '💰 Balans', 'callback_data' => 'show_balance'],
                ],
            ]]),
        ]);
    }
}
