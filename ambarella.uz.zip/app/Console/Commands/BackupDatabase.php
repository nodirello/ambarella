<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;

class BackupDatabase extends Command
{
    protected $signature = 'app:backup {--type=db : Backup type (db or full)}';
    protected $description = 'AMBARELLA database backup yaratish';

    public function handle(): int
    {
        $this->info('Backup boshlanmoqda...');

        $dbName = config('database.connections.mysql.database');
        $dbUser = config('database.connections.mysql.username');
        $dbPass = config('database.connections.mysql.password');
        $dbHost = config('database.connections.mysql.host');

        $filename = 'backup_' . $dbName . '_' . date('Y-m-d_H-i-s') . '.sql';
        $backupPath = storage_path('app/backups');

        // Papka yaratish
        if (!is_dir($backupPath)) {
            mkdir($backupPath, 0755, true);
        }

        $fullPath = $backupPath . '/' . $filename;

        // mysqldump command
        $passwordPart = $dbPass ? "-p\"{$dbPass}\"" : '';
        $command = "mysqldump -h {$dbHost} -u {$dbUser} {$passwordPart} {$dbName} > \"{$fullPath}\"";

        exec($command, $output, $returnCode);

        if ($returnCode === 0 && file_exists($fullPath) && filesize($fullPath) > 0) {
            $size = round(filesize($fullPath) / 1024, 1);
            $this->info("Backup muvaffaqiyatli yaratildi: {$filename} ({$size} KB)");

            // Eski backuplarni o'chirish (7 kundan eski)
            $this->cleanOldBackups($backupPath);

            return Command::SUCCESS;
        }

        $this->error('Backup yaratishda xatolik yuz berdi.');
        return Command::FAILURE;
    }

    private function cleanOldBackups(string $path): void
    {
        $files = glob($path . '/backup_*.sql');
        $maxAge = 7 * 24 * 60 * 60; // 7 kun

        foreach ($files as $file) {
            if (time() - filemtime($file) > $maxAge) {
                unlink($file);
                $this->line("Eski backup o'chirildi: " . basename($file));
            }
        }
    }
}
