<?php

namespace App\Helpers;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;

class ImageHelper
{
    /**
     * Rasmni yuklash va optimize qilish
     */
    public static function upload(UploadedFile $file, string $folder = 'uploads', int $maxWidth = 1200): string
    {
        // Fayl nomini yaratish
        $filename = uniqid() . '_' . time() . '.' . $file->getClientOriginalExtension();

        // GD extension bilan resize qilish (agar mavjud bo'lsa)
        if (extension_loaded('gd') && in_array($file->getMimeType(), ['image/jpeg', 'image/png', 'image/webp'])) {
            $image = self::createImage($file);
            if ($image) {
                $width = imagesx($image);
                $height = imagesy($image);

                // Faqat katta rasmlarni kichraytirish
                if ($width > $maxWidth) {
                    $newHeight = intval($height * ($maxWidth / $width));
                    $resized = imagecreatetruecolor($maxWidth, $newHeight);

                    // PNG transparency
                    if ($file->getMimeType() === 'image/png') {
                        imagealphablending($resized, false);
                        imagesavealpha($resized, true);
                    }

                    imagecopyresampled($resized, $image, 0, 0, 0, 0, $maxWidth, $newHeight, $width, $height);

                    $path = $folder . '/' . $filename;
                    $fullPath = storage_path('app/public/' . $path);

                    // Papka yaratish
                    if (!is_dir(dirname($fullPath))) {
                        mkdir(dirname($fullPath), 0755, true);
                    }

                    // Saqlash
                    match ($file->getMimeType()) {
                        'image/jpeg' => imagejpeg($resized, $fullPath, 85),
                        'image/png' => imagepng($resized, $fullPath, 8),
                        'image/webp' => imagewebp($resized, $fullPath, 85),
                        default => null,
                    };

                    imagedestroy($image);
                    imagedestroy($resized);

                    return $path;
                }

                imagedestroy($image);
            }
        }

        // GD yo'q bo'lsa oddiy yuklash
        return $file->store($folder, 'public');
    }

    /**
     * GD image resource yaratish
     */
    private static function createImage(UploadedFile $file)
    {
        return match ($file->getMimeType()) {
            'image/jpeg' => imagecreatefromjpeg($file->getPathname()),
            'image/png' => imagecreatefrompng($file->getPathname()),
            'image/webp' => imagecreatefromwebp($file->getPathname()),
            default => null,
        };
    }

    /**
     * Eski rasmni o'chirish
     */
    public static function delete(?string $path): void
    {
        if ($path && Storage::disk('public')->exists($path)) {
            Storage::disk('public')->delete($path);
        }
    }
}
