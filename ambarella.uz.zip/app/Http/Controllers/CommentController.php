<?php

namespace App\Http\Controllers;

use App\Models\Comment;
use Illuminate\Http\Request;

class CommentController extends Controller
{
    public function store(Request $request)
    {
        $request->validate([
            'body' => 'required|string|min:2|max:1000',
            'commentable_type' => 'required|string|in:news,blog,forum_topic',
            'commentable_id' => 'required|integer|min:1',
        ]);

        // Ruxsat etilgan model typelarni map qilish (xavfsizlik)
        $allowedTypes = [
            'news' => \App\Models\News::class,
            'blog' => \App\Models\BlogPost::class,
            'forum_topic' => \App\Models\ForumTopic::class,
        ];

        $type = $allowedTypes[$request->commentable_type] ?? null;
        if (!$type) {
            return back()->withErrors(['commentable_type' => 'Noto\'g\'ri tur.']);
        }

        Comment::create([
            'user_id' => auth()->id(),
            'commentable_type' => $type,
            'commentable_id' => $request->commentable_id,
            'body' => strip_tags($request->body),
        ]);

        return back()->with('success', 'Izoh muvaffaqiyatli qo\'shildi!');
    }
}
