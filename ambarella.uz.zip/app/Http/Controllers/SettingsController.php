<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class SettingsController extends Controller
{
    public function index()
    {
        $user = auth()->user();
        return view('settings.index', compact('user'));
    }

    public function updateProfile(Request $request)
    {
        $user = auth()->user();

        $request->validate([
            'name' => 'required|string|max:255',
            'bio' => 'nullable|string|max:500',
            'region' => 'nullable|string|max:100',
            'gender' => 'nullable|string|in:male,female,other',
            'birth_date' => 'nullable|date|before:today',
        ]);

        $user->update([
            'name' => strip_tags($request->name),
            'bio' => strip_tags($request->bio),
            'region' => $request->region,
            'gender' => $request->gender,
            'birth_date' => $request->birth_date,
        ]);

        return back()->with('success', 'Profil yangilandi!');
    }

    public function updatePassword(Request $request)
    {
        $request->validate([
            'current_password' => 'required',
            'password' => ['required', 'min:8', 'max:128', 'confirmed', 'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/'],
        ], [
            'password.regex' => 'Parol kamida 1 katta harf, 1 kichik harf va 1 raqam bo\'lishi kerak.',
        ]);

        $user = auth()->user();

        if (!Hash::check($request->current_password, $user->password)) {
            return back()->withErrors(['current_password' => 'Joriy parol noto\'g\'ri.']);
        }

        $user->update(['password' => Hash::make($request->password)]);

        // Activity log
        \App\Models\ActivityLog::create([
            'user_id' => $user->id,
            'action' => 'password_change',
            'description' => 'Parol o\'zgartirildi',
            'ip_address' => $request->ip(),
        ]);

        return back()->with('success', 'Parol o\'zgartirildi!');
    }

    public function toggle2FA(Request $request)
    {
        $request->validate(['password' => 'required']);

        $user = auth()->user();

        if (!Hash::check($request->password, $user->password)) {
            return back()->withErrors(['password' => 'Parol noto\'g\'ri.']);
        }

        $user->two_factor_enabled = !$user->two_factor_enabled;
        $user->save();

        $status = $user->two_factor_enabled ? 'yoqildi' : 'o\'chirildi';

        \App\Models\ActivityLog::create([
            'user_id' => $user->id,
            'action' => '2fa_toggle',
            'description' => "2FA {$status}",
            'ip_address' => $request->ip(),
        ]);

        return back()->with('success', "Ikki faktorli autentifikatsiya {$status}!");
    }

    public function deleteAccount(Request $request)
    {
        $request->validate(['password' => 'required']);

        $user = auth()->user();

        if (!Hash::check($request->password, $user->password)) {
            return back()->withErrors(['password' => 'Parol noto\'g\'ri.']);
        }

        // Activity log before delete
        \App\Models\ActivityLog::create([
            'user_id' => $user->id,
            'action' => 'account_deleted',
            'description' => 'Hisob o\'chirildi: ' . $user->email,
            'ip_address' => $request->ip(),
        ]);

        Auth::logout();
        $user->delete();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('/')->with('success', 'Hisobingiz o\'chirildi.');
    }

    public function exportData()
    {
        $user = auth()->user();

        $data = [
            'profil' => [
                'ism' => $user->name,
                'email' => $user->email,
                'telefon' => $user->phone,
                'region' => $user->region,
                'bio' => $user->bio,
                'greencoin' => $user->greencoin_balance,
                'ro\'yxatdan_o\'tgan' => $user->created_at->format('d.m.Y'),
            ],
            'statistika' => [
                'login_streak' => $user->login_streak,
                'arizalar_soni' => $user->applications()->count(),
                'eco_harakatlar' => $user->transactions()->where('type', 'earned')->count(),
            ],
        ];

        return response()->json($data, 200, [
            'Content-Disposition' => 'attachment; filename="my_data_' . date('Y-m-d') . '.json"',
            'Content-Type' => 'application/json',
        ]);
    }
}
