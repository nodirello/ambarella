<?php

namespace App\Http\Controllers;

use App\Models\Poll;
use App\Models\PollOption;
use Illuminate\Http\Request;

class PollController extends Controller
{
    public function show(Poll $poll)
    {
        $poll->load('options');
        $hasVoted = $poll->hasVoted(auth()->id());
        $totalVotes = $poll->totalVotes();

        return view('polls.show', compact('poll', 'hasVoted', 'totalVotes'));
    }

    public function vote(Request $request, Poll $poll)
    {
        $request->validate([
            'option_id' => 'required|exists:poll_options,id',
        ]);

        // Tekshirish: allaqachon ovoz berganmi
        if ($poll->hasVoted(auth()->id())) {
            return back()->with('error', 'Siz allaqachon ovoz bergansiz!');
        }

        // Tekshirish: poll faolmi
        if (!$poll->is_active) {
            return back()->with('error', 'Bu so\'rovnoma yakunlangan.');
        }

        // Tekshirish: muddati o'tganmi
        if ($poll->ends_at && $poll->ends_at->isPast()) {
            return back()->with('error', 'Bu so\'rovnoma muddati tugagan.');
        }

        // Ovoz berish
        $poll->votes()->create([
            'user_id' => auth()->id(),
            'option_id' => $request->option_id,
        ]);

        // Ovoz sonini oshirish
        PollOption::where('id', $request->option_id)->increment('votes_count');

        return back()->with('success', 'Ovozingiz qabul qilindi!');
    }
}
