<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\UserAchievement;
use App\Models\GreenCoinTransaction;
use App\Models\BlogPost;

class UserProfileController extends Controller
{
    public function show(User $user)
    {
        // Banned user'ni ko'rsatmaslik
        if ($user->is_banned) {
            abort(404);
        }

        $achievementsCount = UserAchievement::where('user_id', $user->id)->count();
        $postsCount = BlogPost::where('user_id', $user->id)->where('is_published', true)->count();
        $ecoActions = GreenCoinTransaction::where('user_id', $user->id)->where('type', 'earned')->count();

        // Calculate level
        $balance = $user->greencoin_balance;
        if ($balance >= 5000) {
            $level = ['name' => 'Lider', 'color' => '#f59e0b', 'icon' => 'crown'];
        } elseif ($balance >= 2000) {
            $level = ['name' => 'Ekspert', 'color' => '#8b5cf6', 'icon' => 'star'];
        } elseif ($balance >= 500) {
            $level = ['name' => 'Pro', 'color' => '#3b82f6', 'icon' => 'zap'];
        } elseif ($balance >= 100) {
            $level = ['name' => 'Faol', 'color' => '#10b981', 'icon' => 'check'];
        } else {
            $level = ['name' => 'Yangi', 'color' => '#64748b', 'icon' => 'user'];
        }

        // Stats
        $stats = [
            'greencoin' => $user->greencoin_balance,
            'achievements' => $achievementsCount,
            'eco_actions' => $ecoActions,
            'posts' => $postsCount,
            'login_streak' => $user->login_streak ?? 0,
            'member_since' => $user->created_at->diffForHumans(),
        ];

        return view('user-profile.show', compact('user', 'achievementsCount', 'level', 'stats'));
    }
}
