<?php

namespace App\Http\Controllers;

use App\Models\Reaction;
use Illuminate\Http\Request;

class ReactionController extends Controller
{
    public function toggle(Request $request)
    {
        $request->validate([
            'reactable_type' => 'required|string|in:App\\Models\\BlogPost,App\\Models\\News,App\\Models\\Course',
            'reactable_id' => 'required|integer',
            'type' => 'required|in:like,dislike',
        ]);

        $user = auth()->user();
        $existing = Reaction::where('user_id', $user->id)
            ->where('reactable_type', $request->reactable_type)
            ->where('reactable_id', $request->reactable_id)
            ->first();

        if ($existing) {
            if ($existing->type === $request->type) {
                // Same reaction — remove it (toggle off)
                $existing->delete();
            } else {
                // Different reaction — switch it
                $existing->update(['type' => $request->type]);
            }
        } else {
            // New reaction
            Reaction::create([
                'user_id' => $user->id,
                'reactable_type' => $request->reactable_type,
                'reactable_id' => $request->reactable_id,
                'type' => $request->type,
            ]);
        }

        // Return updated counts
        $likes = Reaction::where('reactable_type', $request->reactable_type)
            ->where('reactable_id', $request->reactable_id)
            ->where('type', 'like')
            ->count();

        $dislikes = Reaction::where('reactable_type', $request->reactable_type)
            ->where('reactable_id', $request->reactable_id)
            ->where('type', 'dislike')
            ->count();

        $userReaction = Reaction::where('user_id', $user->id)
            ->where('reactable_type', $request->reactable_type)
            ->where('reactable_id', $request->reactable_id)
            ->value('type');

        return response()->json([
            'likes' => $likes,
            'dislikes' => $dislikes,
            'user_reaction' => $userReaction,
        ]);
    }
}
