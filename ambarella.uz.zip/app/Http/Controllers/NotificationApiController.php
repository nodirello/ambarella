<?php

namespace App\Http\Controllers;

use App\Models\GreenCoinTransaction;

class NotificationApiController extends Controller
{
    public function unreadCount()
    {
        $count = 0;

        if (auth()->check()) {
            // Count recent greencoin transactions as "notifications"
            $count = GreenCoinTransaction::where('user_id', auth()->id())
                ->where('created_at', '>=', now()->subDay())
                ->count();
        }

        return response()->json(['count' => $count]);
    }
}
