<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LastViewedController extends Controller
{
    public function index()
    {
        $items = session()->get('last_viewed', []);
        return view('last-viewed.index', compact('items'));
    }
}
