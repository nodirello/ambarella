<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function loginForm()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:8',
        ]);

        if (Auth::attempt($request->only('email', 'password'), $request->boolean('remember'))) {
            $request->session()->regenerate();

            // Login streak tracking
            $user = auth()->user();
            $today = now()->toDateString();
            if ($user->last_login_date) {
                $lastLogin = \Carbon\Carbon::parse($user->last_login_date);
                if ($lastLogin->isYesterday()) {
                    $user->login_streak = ($user->login_streak ?? 0) + 1;
                } elseif (!$lastLogin->isToday()) {
                    $user->login_streak = 1;
                }
            } else {
                $user->login_streak = 1;
            }
            $user->last_login_date = $today;
            $user->save();

            // Activity log
            \App\Models\ActivityLog::create([
                'user_id' => $user->id,
                'action' => 'login',
                'description' => 'Tizimga kirdi',
                'ip_address' => $request->ip(),
            ]);

            return redirect()->intended('/dashboard');
        }

        // Failed login attempt log
        \App\Models\ActivityLog::create([
            'user_id' => null,
            'action' => 'login_failed',
            'description' => 'Muvaffaqiyatsiz kirish: ' . $request->email,
            'ip_address' => $request->ip(),
        ]);

        // IP blocking
        \App\Http\Middleware\BlockSuspiciousIPs::recordFailedLogin($request->ip());

        return back()->withErrors(['email' => 'Email yoki parol noto\'g\'ri.']);
    }

    public function registerForm()
    {
        // Referral kodni saqlash
        if (request('ref')) {
            session(['referral_code' => request('ref')]);
        }
        return view('auth.register');
    }

    public function register(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255|regex:/^[\p{L}\s\-\.]+$/u',
            'email' => 'required|email:rfc,dns|unique:users|max:255',
            'phone' => 'nullable|string|max:20|regex:/^[\+0-9\s\-\(\)]+$/',
            'password' => ['required', 'min:8', 'max:128', 'confirmed', 'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/'],
        ], [
            'password.regex' => 'Parol kamida 1 katta harf, 1 kichik harf va 1 raqam bo\'lishi kerak.',
        ]);

        $user = User::create([
            'name' => strip_tags($request->name),
            'email' => strtolower(trim($request->email)),
            'phone' => $request->phone ? preg_replace('/[^\+0-9]/', '', $request->phone) : null,
            'password' => Hash::make($request->password),
            'greencoin_balance' => 0,
        ]);

        // Referral tizimi — faqat to'liq profil to'ldirilganda sovrin beriladi
        if ($request->has('ref') || session('referral_code')) {
            $refCode = $request->ref ?? session('referral_code');
            $referrer = User::where('referral_code', $refCode)->first();
            if ($referrer && $referrer->id !== $user->id) {
                $user->referred_by = $referrer->id;
                $user->save();
            }
        }

        Auth::login($user);

        // Activity log
        \App\Models\ActivityLog::create([
            'user_id' => $user->id,
            'action' => 'register',
            'description' => 'Yangi foydalanuvchi ro\'yxatdan o\'tdi: ' . $user->email,
            'ip_address' => $request->ip(),
        ]);

        // Admin notification
        \App\Http\Controllers\Admin\AdminNotificationService::notifyNewUser($user);

        // Welcome message via Telegram
        if ($user->phone && config('services.telegram.bot_token')) {
            $chatId = \DB::table('telegram_users')->where('phone', preg_replace('/[^0-9]/', '', $user->phone))->value('chat_id');
            if ($chatId) {
                \Http::post("https://api.telegram.org/bot" . config('services.telegram.bot_token') . "/sendMessage", [
                    'chat_id' => $chatId,
                    'text' => "🎉 Tabriklaymiz, {$user->name}!\n\nAMBARELLA platformasiga xush kelibsiz!\n\n✅ Profilingizni to'ldiring\n✅ Ish e'lonlarini ko'ring\n✅ GreenCoin ishlang\n\n🌐 ambarella.uz/dashboard",
                    'parse_mode' => 'Markdown',
                ]);
            }
        }

        return redirect('/onboarding');
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('/');
    }
}
