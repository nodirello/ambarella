<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\GreenCoinTransaction;

class ChallengeController extends Controller
{
    public function index()
    {
        $challenges = DB::table('challenges')
            ->where('is_active', true)
            ->orderByDesc('created_at')
            ->paginate(12);

        $userParticipations = [];
        if (auth()->check()) {
            $userParticipations = DB::table('challenge_participants')
                ->where('user_id', auth()->id())
                ->pluck('challenge_id')
                ->toArray();
        }

        return view('challenges.index', compact('challenges', 'userParticipations'));
    }

    public function join(int $challengeId)
    {
        $challenge = DB::table('challenges')->find($challengeId);
        if (!$challenge || !$challenge->is_active) {
            return back()->withErrors(['challenge' => 'Bu musobaqa mavjud emas yoki tugagan.']);
        }

        $alreadyJoined = DB::table('challenge_participants')
            ->where('challenge_id', $challengeId)
            ->where('user_id', auth()->id())
            ->exists();

        if ($alreadyJoined) {
            return back()->withErrors(['challenge' => 'Siz allaqachon qatnashmoqdasiz.']);
        }

        DB::table('challenge_participants')->insert([
            'challenge_id' => $challengeId,
            'user_id' => auth()->id(),
            'status' => 'active',
            'created_at' => now(),
        ]);

        // GreenCoin bonus for joining
        $user = auth()->user();
        $user->increment('greencoin_balance', 10);
        GreenCoinTransaction::create([
            'user_id' => $user->id,
            'amount' => 10,
            'type' => 'earned',
            'description' => 'Challenge qatnashish bonusi: ' . $challenge->title,
        ]);

        return back()->with('success', 'Musobaqaga qo\'shildingiz! +10 GreenCoin');
    }
}
