<?php

namespace App\Http\Controllers;

use App\Models\Note;
use Illuminate\Http\Request;

class NoteController extends Controller
{
    public function index()
    {
        $notes = Note::where('user_id', auth()->id())
            ->orderByDesc('is_pinned')
            ->latest()
            ->get();

        return view('notes.index', compact('notes'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'nullable|string|max:255',
            'content' => 'required|string',
            'color' => 'required|string|in:blue,green,yellow,purple,pink',
        ]);

        Note::create([
            'user_id' => auth()->id(),
            'title' => $request->title,
            'content' => $request->content,
            'color' => $request->color,
        ]);

        return redirect()->route('notes')->with('success', 'Eslatma yaratildi!');
    }

    public function update(Request $request, Note $note)
    {
        if ($note->user_id !== auth()->id()) {
            abort(403);
        }

        $request->validate([
            'title' => 'nullable|string|max:255',
            'content' => 'required|string',
            'color' => 'required|string|in:blue,green,yellow,purple,pink',
        ]);

        $note->update($request->only('title', 'content', 'color'));

        return redirect()->route('notes')->with('success', 'Eslatma yangilandi!');
    }

    public function destroy(Note $note)
    {
        if ($note->user_id !== auth()->id()) {
            abort(403);
        }

        $note->delete();

        return redirect()->route('notes')->with('success', 'Eslatma o\'chirildi!');
    }

    public function togglePin(Note $note)
    {
        if ($note->user_id !== auth()->id()) {
            abort(403);
        }

        $note->update(['is_pinned' => !$note->is_pinned]);

        return redirect()->route('notes')->with('success', $note->is_pinned ? 'Eslatma qadaldi!' : 'Eslatma qadalmadi!');
    }
}
