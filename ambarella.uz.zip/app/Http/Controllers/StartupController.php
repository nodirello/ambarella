<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StartupController extends Controller
{
    public function index()
    {
        $startups = DB::table('startups')
            ->orderByDesc('votes')
            ->paginate(12);

        return view('startup.index', compact('startups'));
    }

    public function show(int $id)
    {
        $startup = DB::table('startups')->find($id);
        if (!$startup) abort(404);

        return view('startup.show', compact('startup'));
    }

    public function create()
    {
        return view('startup.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string|min:50|max:2000',
            'category' => 'required|string|max:100',
            'stage' => 'required|string|in:idea,mvp,growth,scale',
            'team_size' => 'required|integer|min:1|max:100',
            'looking_for' => 'nullable|string|max:500',
        ]);

        DB::table('startups')->insert([
            'user_id' => auth()->id(),
            'name' => strip_tags($request->name),
            'description' => strip_tags($request->description),
            'category' => $request->category,
            'stage' => $request->stage,
            'team_size' => $request->team_size,
            'looking_for' => strip_tags($request->looking_for),
            'votes' => 0,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return redirect('/startup')->with('success', 'Startup loyihangiz joylashtirildi!');
    }

    public function vote(int $id)
    {
        $startup = DB::table('startups')->find($id);
        if (!$startup) abort(404);

        // Foydalanuvchi allaqachon ovoz berganmi
        $alreadyVoted = DB::table('startup_votes')
            ->where('startup_id', $id)
            ->where('user_id', auth()->id())
            ->exists();

        if ($alreadyVoted) {
            return back()->withErrors(['vote' => 'Siz allaqachon ovoz bergansiz.']);
        }

        DB::table('startups')->where('id', $id)->increment('votes');
        DB::table('startup_votes')->insert([
            'startup_id' => $id,
            'user_id' => auth()->id(),
            'created_at' => now(),
        ]);

        return back()->with('success', 'Ovoz berildi!');
    }
}
