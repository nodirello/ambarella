<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Support\Facades\Cache;

class LeaderboardController extends Controller
{
    public function index()
    {
        $leaders = Cache::remember('leaderboard', 300, function () {
            return User::where('greencoin_balance', '>', 0)
                ->where('is_banned', false)
                ->orderByDesc('greencoin_balance')
                ->take(50)
                ->get(['id', 'name', 'avatar', 'greencoin_balance', 'region', 'login_streak']);
        });

        // Joriy user'ning o'rni
        $userRank = null;
        if (auth()->check()) {
            $userRank = User::where('greencoin_balance', '>', auth()->user()->greencoin_balance)
                ->where('is_banned', false)
                ->count() + 1;
        }

        return view('greencoin.leaderboard', compact('leaders', 'userRank'));
    }
}
