<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

class TelegramAuthController extends Controller
{
    /**
     * Variant A: Telegram Login Widget callback
     * Telegram widget orqali kirish
     */
    public function telegramCallback(Request $request)
    {
        // Telegram dan kelgan ma'lumotlarni tekshirish
        $data = $request->all();
        
        if (!$this->verifyTelegramData($data)) {
            return redirect('/login')->withErrors(['telegram' => 'Telegram tasdiqlash xatosi.']);
        }

        // Foydalanuvchini topish yoki yaratish
        $user = User::where('telegram_id', $data['id'])->first();

        if (!$user) {
            $user = User::create([
                'name' => $data['first_name'] . ' ' . ($data['last_name'] ?? ''),
                'email' => 'tg_' . $data['id'] . '@ambarella.uz',
                'telegram_id' => $data['id'],
                'telegram_username' => $data['username'] ?? null,
                'avatar' => $data['photo_url'] ?? null,
                'password' => Hash::make(Str::random(32)),
                'greencoin_balance' => 0,
            ]);
        }

        Auth::login($user, true);
        return redirect('/dashboard');
    }

    /**
     * Variant B: Telegramga kod yuborish
     * 1-qadam: telefon raqam qabul qilish va kod yuborish
     */
    public function sendCode(Request $request)
    {
        $request->validate([
            'phone' => 'required|string|min:9|max:20',
        ]);

        $phone = $this->normalizePhoneNumber($request->phone);
        
        // Telefon raqam bo'yicha chat_id topish
        $chatId = $this->getChatIdByPhone($phone);

        if (!$chatId) {
            return response()->json([
                'success' => false,
                'message' => 'Avval @Ambarella_IDBot ga Telegramda /start yozing va telefon raqamingizni yuboring.',
            ], 422);
        }

        // Rate limiting: 60 soniyada 1 marta kod yuborish mumkin
        $rateLimitKey = 'tg_code_sent_' . $phone;
        if (cache()->has($rateLimitKey)) {
            return response()->json([
                'success' => false,
                'message' => 'Kod allaqachon yuborilgan. 60 soniya kuting.',
            ], 429);
        }

        // 6 xonali kod generatsiya
        $code = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
        
        // Kodni bazaga saqlash (5 daqiqa amal qiladi)
        cache()->put('tg_code_' . $phone, $code, now()->addMinutes(5));
        cache()->put($rateLimitKey, true, now()->addSeconds(60));

        // Telegram bot orqali kod yuborish
        $this->sendTelegramCode($phone, $code);

        return response()->json([
            'success' => true,
            'message' => 'Kod Telegram orqali yuborildi.',
        ]);
    }

    /**
     * Variant B: Kodni tekshirish va kirish
     */
    public function verifyCode(Request $request)
    {
        $request->validate([
            'phone' => 'required|string',
            'code' => 'required|string|size:6',
        ]);

        $phone = $this->normalizePhoneNumber($request->phone);
        $savedCode = cache()->get('tg_code_' . $phone);

        if (!$savedCode || $savedCode !== $request->code) {
            return response()->json([
                'success' => false,
                'message' => 'Kod noto\'g\'ri yoki muddati o\'tgan.',
            ], 422);
        }

        // Kodni o'chirish
        cache()->forget('tg_code_' . $phone);

        // Foydalanuvchini topish yoki yaratish
        $user = User::where('phone', $phone)->first();

        if (!$user) {
            $user = User::create([
                'name' => 'Foydalanuvchi',
                'email' => 'phone_' . $phone . '@ambarella.uz',
                'phone' => $phone,
                'password' => Hash::make(Str::random(32)),
                'greencoin_balance' => 0,
            ]);
        }

        Auth::login($user, true);

        return response()->json([
            'success' => true,
            'redirect' => '/dashboard',
        ]);
    }

    /**
     * Telegram widget ma'lumotlarini tekshirish
     */
    private function verifyTelegramData(array $data): bool
    {
        $botToken = config('services.telegram.bot_token');
        $checkHash = $data['hash'] ?? '';
        unset($data['hash']);

        ksort($data);
        $dataCheckString = collect($data)
            ->map(fn($v, $k) => "$k=$v")
            ->implode("\n");

        $secretKey = hash('sha256', $botToken, true);
        $hash = hash_hmac('sha256', $dataCheckString, $secretKey);

        return hash_equals($hash, $checkHash);
    }

    /**
     * Telegram bot orqali kod yuborish
     */
    private function sendTelegramCode(string $phone, string $code): void
    {
        $botToken = config('services.telegram.bot_token');
        $chatId = $this->getChatIdByPhone($phone);

        if ($chatId) {
            Http::post("https://api.telegram.org/bot{$botToken}/sendMessage", [
                'chat_id' => $chatId,
                'text' => "🔐 AMBARELLA tasdiqlash kodi: *{$code}*\n\nKod 5 daqiqa amal qiladi.\nAgar siz so'ramagan bo'lsangiz, e'tiborsiz qoldiring.",
                'parse_mode' => 'Markdown',
            ]);
        }
    }

    /**
     * Telefon raqam bo'yicha Telegram chat_id topish
     * (Foydalanuvchi avval @AmbarellaBot ga /start bergan bo'lishi kerak)
     */
    private function getChatIdByPhone(string $phone): ?string
    {
        // telegram_users jadvalidan qidirish
        $normalizedPhone = $this->normalizePhoneNumber($phone);
        $tgUser = \DB::table('telegram_users')
            ->where('phone', $normalizedPhone)
            ->first();

        return $tgUser?->chat_id;
    }

    /**
     * Telefon raqamini standart formatga o'tkazish
     */
    private function normalizePhoneNumber(string $phone): string
    {
        // Barcha raqam bo'lmagan belgilarni olib tashlash
        return preg_replace('/[^0-9]/', '', $phone);
    }
}
