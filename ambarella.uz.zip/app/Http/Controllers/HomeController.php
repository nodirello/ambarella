<?php

namespace App\Http\Controllers;

use App\Models\Job;
use App\Models\News;
use App\Models\User;
use App\Models\GreenCoinTransaction;
use App\Models\Course;
use Illuminate\Support\Facades\Cache;

class HomeController extends Controller
{
    public function index()
    {
        try {
            $jobs = Job::where('is_active', true)->latest()->take(4)->get();
            $news = News::latest()->take(3)->get();

            $stats = Cache::remember('home_stats', 300, function () {
                return [
                    'users' => User::count(),
                    'jobs' => Job::where('is_active', true)->count(),
                    'courses' => Course::count(),
                    'eco_actions' => GreenCoinTransaction::where('type', 'earned')->count(),
                    'total_coins' => GreenCoinTransaction::where('type', 'earned')->sum('amount'),
                ];
            });
        } catch (\Exception $e) {
            $jobs = collect();
            $news = collect();
            $stats = ['users' => 0, 'jobs' => 0, 'courses' => 0, 'eco_actions' => 0, 'total_coins' => 0];
        }

        return view('home', compact('jobs', 'news', 'stats'));
    }
}
