<?php

namespace App\Http\Controllers;

use App\Models\GreenCoinTransaction;
use Illuminate\Http\Request;

class GreenCoinShopController extends Controller
{
    /**
     * GreenCoin do'koni — coinlarni sarflash mumkin bo'lgan narsalar
     */
    public function index()
    {
        $user = auth()->user();
        $items = $this->getShopItems();

        return view('greencoin.shop', compact('user', 'items'));
    }

    /**
     * Xarid qilish
     */
    public function purchase(Request $request)
    {
        $request->validate([
            'item_id' => 'required|string',
        ]);

        $user = auth()->user();
        $items = $this->getShopItems();
        $item = collect($items)->firstWhere('id', $request->item_id);

        if (!$item) {
            return back()->withErrors(['item' => 'Bunday mahsulot topilmadi.']);
        }

        if ($user->greencoin_balance < $item['price']) {
            return back()->withErrors(['item' => 'Yetarli GreenCoin yo\'q. Kerak: ' . $item['price'] . ' GC']);
        }

        // GreenCoin yechib olish
        $user->decrement('greencoin_balance', $item['price']);

        GreenCoinTransaction::create([
            'user_id' => $user->id,
            'amount' => $item['price'],
            'type' => 'spent',
            'description' => 'Do\'kon: ' . $item['name'],
        ]);

        // Activity log
        \App\Models\ActivityLog::create([
            'user_id' => $user->id,
            'action' => 'shop_purchase',
            'description' => $item['name'] . ' — ' . $item['price'] . ' GC',
            'ip_address' => $request->ip(),
        ]);

        return back()->with('success', "'{$item['name']}' xarid qilindi! -{$item['price']} GC");
    }

    /**
     * Do'kon mahsulotlari
     */
    private function getShopItems(): array
    {
        return [
            ['id' => 'premium_course', 'name' => 'Premium kurs kirish', 'price' => 500, 'icon' => 'book', 'description' => '1 ta pullik kursga bepul kirish'],
            ['id' => 'mentor_session', 'name' => 'Mentor sessiya', 'price' => 300, 'icon' => 'users', 'description' => '30 daqiqa individual mentorlik'],
            ['id' => 'certificate_boost', 'name' => 'Sertifikat dizayni', 'price' => 100, 'icon' => 'award', 'description' => 'Premium sertifikat dizayni'],
            ['id' => 'profile_badge', 'name' => 'Maxsus badge', 'price' => 200, 'icon' => 'star', 'description' => 'Profilga maxsus badge qo\'shish'],
            ['id' => 'priority_job', 'name' => 'Ariza prioriteti', 'price' => 150, 'icon' => 'zap', 'description' => 'Ish arizangiz birinchi ko\'rinadi'],
            ['id' => 'eco_tree', 'name' => 'Real daraxt ekish', 'price' => 1000, 'icon' => 'tree', 'description' => 'Sizning nomingizda daraxt ekiladi'],
        ];
    }
}
