<?php

namespace App\Http\Controllers;

use App\Models\Mentorship;
use App\Models\MentorTask;
use App\Models\User;
use Illuminate\Http\Request;

class MentorshipController extends Controller
{
    public function index()
    {
        $user = auth()->user();

        // Foydalanuvchi ustoz sifatida
        $asmentor = Mentorship::where('mentor_id', $user->id)
            ->with(['student', 'tasks'])
            ->latest()
            ->get();

        // Foydalanuvchi shogird sifatida
        $asstudent = Mentorship::where('student_id', $user->id)
            ->with(['mentor', 'tasks'])
            ->latest()
            ->get();

        return view('mentorship.index', compact('asmentor', 'asstudent'));
    }

    public function create()
    {
        // Ustoz bo'lish uchun ariza
        return view('mentorship.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'student_email' => 'required|email|exists:users,email',
            'goal' => 'required|string|max:500',
        ]);

        $student = User::where('email', $request->student_email)->first();

        if ($student->id === auth()->id()) {
            return back()->withErrors(['student_email' => 'O\'zingizni shogird qilib bo\'lmaydi!']);
        }

        // Mavjud aktiv mentorship bormi?
        $exists = Mentorship::where('mentor_id', auth()->id())
            ->where('student_id', $student->id)
            ->whereIn('status', ['pending', 'active'])
            ->exists();

        if ($exists) {
            return back()->withErrors(['student_email' => 'Bu shogird bilan allaqachon bog\'lanishingiz bor!']);
        }

        Mentorship::create([
            'mentor_id' => auth()->id(),
            'student_id' => $student->id,
            'goal' => $request->goal,
            'status' => 'pending',
        ]);

        return redirect('/mentorship')->with('success', 'Shogirdga taklif yuborildi!');
    }

    public function accept(Mentorship $mentorship)
    {
        if ($mentorship->student_id !== auth()->id()) {
            abort(403);
        }

        $mentorship->update(['status' => 'active']);
        return back()->with('success', 'Mentorlik qabul qilindi!');
    }

    public function reject(Mentorship $mentorship)
    {
        if ($mentorship->student_id !== auth()->id()) {
            abort(403);
        }

        $mentorship->update(['status' => 'completed']);
        return back()->with('success', 'Mentorlik rad etildi.');
    }

    public function addTask(Request $request, Mentorship $mentorship)
    {
        if ($mentorship->mentor_id !== auth()->id()) {
            abort(403);
        }

        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string|max:1000',
            'deadline' => 'nullable|date|after:today',
        ]);

        $mentorship->tasks()->create($request->only(['title', 'description', 'deadline']));

        return back()->with('success', 'Vazifa qo\'shildi!');
    }

    public function completeTask(MentorTask $task)
    {
        $mentorship = $task->mentorship;

        if ($mentorship->student_id !== auth()->id()) {
            abort(403);
        }

        $task->update(['is_done' => true]);
        return back()->with('success', 'Vazifa bajarildi!');
    }
}
