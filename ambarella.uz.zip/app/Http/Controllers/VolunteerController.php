<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class VolunteerController extends Controller
{
    public function index()
    {
        $projects = DB::table('volunteer_projects')
            ->where('is_active', true)
            ->orderByDesc('created_at')
            ->paginate(12);

        $stats = [
            'total_projects' => DB::table('volunteer_projects')->where('is_active', true)->count(),
            'total_volunteers' => DB::table('volunteer_applications')->count(),
            'total_hours' => DB::table('volunteer_applications')->where('status', 'completed')->sum('hours'),
        ];

        return view('volunteer.index', compact('projects', 'stats'));
    }

    public function apply(Request $request, int $projectId)
    {
        $request->validate([
            'message' => 'nullable|string|max:500',
        ]);

        // Tekshirish
        $alreadyApplied = DB::table('volunteer_applications')
            ->where('project_id', $projectId)
            ->where('user_id', auth()->id())
            ->exists();

        if ($alreadyApplied) {
            return back()->withErrors(['project' => 'Siz bu loyihaga allaqachon ariza topshirgansiz.']);
        }

        DB::table('volunteer_applications')->insert([
            'project_id' => $projectId,
            'user_id' => auth()->id(),
            'message' => strip_tags($request->message),
            'status' => 'pending',
            'hours' => 0,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return back()->with('success', 'Volontyorlik arizangiz topshirildi!');
    }
}
