<?php

namespace App\Http\Controllers;

use App\Models\UserAchievement;

class AchievementController extends Controller
{
    public function index()
    {
        $user = auth()->user();

        // Calculate level
        $balance = $user->greencoin_balance;
        if ($balance >= 5000) {
            $level = ['name' => 'Lider', 'min' => 5000, 'max' => 10000, 'color' => '#f59e0b'];
        } elseif ($balance >= 2000) {
            $level = ['name' => 'Ekspert', 'min' => 2000, 'max' => 5000, 'color' => '#8b5cf6'];
        } elseif ($balance >= 500) {
            $level = ['name' => 'Pro', 'min' => 500, 'max' => 2000, 'color' => '#3b82f6'];
        } elseif ($balance >= 100) {
            $level = ['name' => 'Faol', 'min' => 100, 'max' => 500, 'color' => '#10b981'];
        } else {
            $level = ['name' => 'Yangi', 'min' => 0, 'max' => 100, 'color' => '#64748b'];
        }

        $progress = min(100, (($balance - $level['min']) / max(1, $level['max'] - $level['min'])) * 100);

        // Check and award new badges
        $this->checkBadges($user);

        // Get earned badges
        $earnedBadges = UserAchievement::where('user_id', $user->id)->pluck('badge')->toArray();

        // All available badges
        $allBadges = [
            'first_login' => ['name' => 'Birinchi kirish', 'icon' => '🎉', 'description' => 'Platformaga birinchi marta kirdingiz'],
            'first_job_apply' => ['name' => 'Birinchi ariza', 'icon' => '📝', 'description' => 'Birinchi ish arizasi topshirdingiz'],
            'eco_starter' => ['name' => 'Eko boshlovchi', 'icon' => '🌱', 'description' => '5 ta eko vazifa bajardingiz'],
            'streak_7' => ['name' => '7 kunlik streak', 'icon' => '🔥', 'description' => '7 kun ketma-ket faol bo\'ldingiz'],
            'streak_30' => ['name' => '30 kunlik streak', 'icon' => '💎', 'description' => '30 kun ketma-ket faol bo\'ldingiz'],
            'green_100' => ['name' => '100 GC', 'icon' => '🪙', 'description' => '100+ GreenCoin to\'pladingiz'],
            'green_1000' => ['name' => '1000 GC', 'icon' => '💰', 'description' => '1000+ GreenCoin to\'pladingiz'],
            'referral_5' => ['name' => '5 ta referal', 'icon' => '👥', 'description' => '5 ta do\'stingizni taklif qildingiz'],
        ];

        return view('achievements.index', compact('level', 'progress', 'earnedBadges', 'allBadges', 'balance'));
    }

    private function checkBadges($user): void
    {
        $badges = [];

        // first_login - always earned
        $badges[] = 'first_login';

        // first_job_apply
        if ($user->applications()->count() > 0) {
            $badges[] = 'first_job_apply';
        }

        // eco_starter (5 eco tasks)
        $ecoCount = \App\Models\GreenCoinTransaction::where('user_id', $user->id)
            ->where('description', 'like', '%eco%')
            ->count();
        if ($ecoCount >= 5) {
            $badges[] = 'eco_starter';
        }

        // streak_7 and streak_30
        $habits = $user->habits;
        $maxStreak = $habits->max('streak') ?? 0;
        if ($maxStreak >= 7) $badges[] = 'streak_7';
        if ($maxStreak >= 30) $badges[] = 'streak_30';

        // green_100 and green_1000
        if ($user->greencoin_balance >= 100) $badges[] = 'green_100';
        if ($user->greencoin_balance >= 1000) $badges[] = 'green_1000';

        // referral_5
        if ($user->referral_count >= 5) $badges[] = 'referral_5';

        // Award new badges
        foreach ($badges as $badge) {
            UserAchievement::firstOrCreate(
                ['user_id' => $user->id, 'badge' => $badge],
                ['earned_at' => now()]
            );
        }
    }
}
