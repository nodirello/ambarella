<?php

namespace App\Http\Controllers;

use Illuminate\Support\Str;

class ReferralController extends Controller
{
    public function index()
    {
        $user = auth()->user();

        if (!$user->referral_code) {
            $user->referral_code = Str::random(8);
            $user->save();
        }

        $code = $user->referral_code;
        $link = url('/register?ref=' . $code);
        $count = $user->referral_count;

        return view('referral.index', compact('code', 'link', 'count'));
    }
}
