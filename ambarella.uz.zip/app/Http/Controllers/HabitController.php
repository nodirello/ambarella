<?php

namespace App\Http\Controllers;

use App\Models\Habit;
use Illuminate\Http\Request;

class HabitController extends Controller
{
    public function index()
    {
        $habits = Habit::where('user_id', auth()->id())
            ->orderBy('streak', 'desc')
            ->get();

        return view('habits.index', compact('habits'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
        ]);

        Habit::create([
            'user_id' => auth()->id(),
            'name' => $request->name,
        ]);

        return back()->with('success', 'Odat qo\'shildi!');
    }

    public function complete(Habit $habit)
    {
        if ($habit->user_id !== auth()->id()) {
            abort(403);
        }

        // Bugun allaqachon bajarilganmi?
        if ($habit->last_completed && $habit->last_completed->isToday()) {
            return back()->withErrors(['habit' => 'Bugun allaqachon bajarilgan!']);
        }

        // Streak hisoblash
        $yesterday = now()->subDay()->toDateString();
        if ($habit->last_completed && $habit->last_completed->toDateString() === $yesterday) {
            $habit->streak += 1;
        } elseif (!$habit->last_completed || !$habit->last_completed->isToday()) {
            $habit->streak = 1;
        }

        $habit->last_completed = now();
        $habit->save();

        return back()->with('success', "'{$habit->name}' bajarildi! Streak: {$habit->streak} kun");
    }

    public function destroy(Habit $habit)
    {
        if ($habit->user_id !== auth()->id()) {
            abort(403);
        }

        $habit->delete();
        return back()->with('success', 'Odat o\'chirildi!');
    }
}
