<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PsychologyController extends Controller
{
    public function index()
    {
        $tests = $this->getAvailableTests();
        return view('psychology.index', compact('tests'));
    }

    public function test(string $slug)
    {
        $tests = $this->getAvailableTests();
        $test = collect($tests)->firstWhere('slug', $slug);

        if (!$test) abort(404);

        return view('psychology.test', compact('test'));
    }

    public function submit(Request $request, string $slug)
    {
        $request->validate([
            'answers' => 'required|array',
            'answers.*' => 'required|integer|min:1|max:5',
        ]);

        $score = array_sum($request->answers);
        $maxScore = count($request->answers) * 5;
        $percentage = round(($score / $maxScore) * 100);

        // Natija darajasi
        if ($percentage >= 80) {
            $result = ['level' => 'A\'lo', 'color' => '#4ade80', 'message' => 'Siz juda yaxshi holatdasiz!'];
        } elseif ($percentage >= 60) {
            $result = ['level' => 'Yaxshi', 'color' => '#60a5fa', 'message' => 'Umumiy holatingiz yaxshi.'];
        } elseif ($percentage >= 40) {
            $result = ['level' => 'O\'rtacha', 'color' => '#fbbf24', 'message' => 'Ba\'zi sohalarda e\'tibor kerak.'];
        } else {
            $result = ['level' => 'Diqqat', 'color' => '#f87171', 'message' => 'Professional yordam tavsiya etiladi.'];
        }

        $result['score'] = $score;
        $result['max_score'] = $maxScore;
        $result['percentage'] = $percentage;

        return view('psychology.result', compact('result', 'slug'));
    }

    private function getAvailableTests(): array
    {
        return [
            [
                'slug' => 'stress',
                'title' => 'Stress darajasi',
                'description' => 'Kundalik hayotingizdagi stress darajasini aniqlang',
                'questions_count' => 10,
                'duration' => '5 daqiqa',
                'icon' => 'activity',
            ],
            [
                'slug' => 'motivation',
                'title' => 'Motivatsiya testi',
                'description' => 'Ichki motivatsiyangiz qanchalik kuchli ekanligini bilib oling',
                'questions_count' => 8,
                'duration' => '4 daqiqa',
                'icon' => 'zap',
            ],
            [
                'slug' => 'burnout',
                'title' => 'Burnout (kuyish)',
                'description' => 'Professional kuyish belgilari bormi tekshiring',
                'questions_count' => 12,
                'duration' => '6 daqiqa',
                'icon' => 'alert-triangle',
            ],
            [
                'slug' => 'self-esteem',
                'title' => 'O\'ziga ishonch',
                'description' => 'O\'z-o\'ziga baho berish va ishonch darajasi',
                'questions_count' => 10,
                'duration' => '5 daqiqa',
                'icon' => 'heart',
            ],
            [
                'slug' => 'anxiety',
                'title' => 'Tashvish (anksiozlik)',
                'description' => 'Umumiy tashvish darajangizni aniqlang',
                'questions_count' => 7,
                'duration' => '3 daqiqa',
                'icon' => 'cloud',
            ],
        ];
    }
}
