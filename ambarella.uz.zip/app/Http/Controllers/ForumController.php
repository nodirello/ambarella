<?php

namespace App\Http\Controllers;

use App\Models\ForumTopic;
use App\Models\ForumReply;
use Illuminate\Http\Request;

class ForumController extends Controller
{
    public function index(Request $request)
    {
        $query = ForumTopic::with('user')->withCount('replies');

        if ($request->has('category') && $request->category !== 'all') {
            $query->where('category', $request->category);
        }

        $topics = $query->latest()->paginate(15);

        return view('forum.index', compact('topics'));
    }

    public function show(ForumTopic $topic)
    {
        $topic->increment('views_count');
        $topic->load(['user', 'replies.user']);

        return view('forum.show', compact('topic'));
    }

    public function create()
    {
        return view('forum.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'body' => 'required|string|min:10|max:10000',
            'category' => 'required|string|in:Dasturlash,Dizayn,Biznes,Boshqa',
        ]);

        $topic = ForumTopic::create([
            'user_id' => auth()->id(),
            'title' => strip_tags($request->title),
            'body' => strip_tags($request->body, '<p><br><strong><em><ul><ol><li><code><pre><blockquote>'),
            'category' => $request->category,
        ]);

        return redirect()->route('forum.show', $topic)->with('success', 'Savol muvaffaqiyatli yaratildi!');
    }

    public function reply(Request $request, ForumTopic $topic)
    {
        $request->validate([
            'body' => 'required|string|min:3|max:5000',
        ]);

        ForumReply::create([
            'topic_id' => $topic->id,
            'user_id' => auth()->id(),
            'body' => strip_tags($request->body, '<p><br><strong><em><code><pre>'),
        ]);

        return redirect()->route('forum.show', $topic)->with('success', 'Javob qo\'shildi!');
    }

    public function markBest(ForumReply $reply)
    {
        $topic = $reply->topic;

        // Faqat savol muallifi belgilashi mumkin
        if ($topic->user_id !== auth()->id()) {
            return back()->with('error', 'Faqat savol muallifi eng yaxshi javobni belgilashi mumkin.');
        }

        // Avvalgi best answer ni olib tashlash
        $topic->replies()->update(['is_best_answer' => false]);

        // Yangi best answer
        $reply->update(['is_best_answer' => true]);
        $topic->update(['is_solved' => true]);

        return back()->with('success', 'Eng yaxshi javob belgilandi!');
    }
}
