<?php

namespace App\Http\Controllers;

use App\Models\Mentor;

class MentorController extends Controller
{
    public function index()
    {
        $query = Mentor::where('is_available', true);

        if (request()->filled('search')) {
            $s = strip_tags(request('search'));
            $query->where(function($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('role', 'like', "%{$s}%")
                  ->orWhere('skills', 'like', "%{$s}%");
            });
        }

        if (request('available') == '1') {
            $query->where('is_available', true);
        }

        $sort = request('sort', 'rating');
        $query->orderByDesc($sort === 'sessions' ? 'sessions_count' : 'rating');

        $mentors = $query->paginate(12)->withQueryString();
        return view('mentor.index', compact('mentors'));
    }

    public function request(Mentor $mentor)
    {
        $user = auth()->user();

        // Tekshirish: allaqachon so'rov yuborganmi?
        $alreadyRequested = $mentor->requests()
            ->where('user_id', $user->id)
            ->whereIn('status', ['pending', 'accepted'])
            ->exists();

        if ($alreadyRequested) {
            return back()->withErrors(['mentor' => 'Siz bu mentorga allaqachon so\'rov yuborgansiz.']);
        }

        $mentor->requests()->create([
            'user_id' => $user->id,
            'status' => 'pending',
        ]);

        return back()->with('success', 'So\'rov yuborildi!');
    }
}
