<?php

namespace App\Http\Controllers;

use App\Models\BlogPost;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class BlogController extends Controller
{
    public function index(Request $request)
    {
        $query = BlogPost::where('is_published', true)->with('user');

        if ($request->filled('category')) {
            $query->where('category', $request->category);
        }

        if ($request->filled('search')) {
            $s = strip_tags($request->search);
            $query->where(function ($q) use ($s) {
                $q->where('title', 'like', "%{$s}%")
                  ->orWhere('content', 'like', "%{$s}%");
            });
        }

        $posts = $query->latest()->paginate(12);
        $categories = BlogPost::where('is_published', true)->distinct()->pluck('category')->filter();

        return view('blog.index', compact('posts', 'categories'));
    }

    public function show(string $slug)
    {
        $post = BlogPost::where('slug', $slug)->with('user')->firstOrFail();
        $post->increment('views_count');

        // Related posts
        $related = BlogPost::where('is_published', true)
            ->where('id', '!=', $post->id)
            ->where('category', $post->category)
            ->latest()
            ->take(3)
            ->get();

        return view('blog.show', compact('post', 'related'));
    }

    public function create()
    {
        return view('blog.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'content' => 'required|string|min:50',
            'excerpt' => 'nullable|string|max:500',
            'category' => 'required|string|max:100|in:Texnologiya,Ekologiya,Biznes,Hayot,Boshqa',
            'image' => 'nullable|url|max:500',
        ]);

        $validated['user_id'] = auth()->id();
        $validated['slug'] = Str::slug($validated['title']) . '-' . Str::random(5);
        $validated['published_at'] = now();
        $validated['title'] = strip_tags($validated['title']);
        $validated['content'] = strip_tags($validated['content'], '<p><br><strong><em><ul><ol><li><h2><h3><code><pre><blockquote><a>');

        BlogPost::create($validated);

        return redirect()->route('blog')->with('success', 'Blog post muvaffaqiyatli yaratildi!');
    }
}
