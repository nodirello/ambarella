<?php

namespace App\Http\Controllers;

use App\Models\TelegramUser;
use App\Models\User;
use App\Models\EcoTask;
use App\Models\GreenCoinTransaction;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class TelegramWebAppController extends Controller
{
    /**
     * Telegram initData ni tekshirish va user topish
     * Development'da ham ishlaydi
     */
    private function getUserFromInitData(Request $request): ?User
    {
        $initData = $request->header('X-Telegram-Init-Data')
            ?? $request->input('init_data')
            ?? '';

        if (empty($initData)) return null;

        // initData ni parse qilish
        $params = [];
        parse_str($initData, $params);
        $hash = $params['hash'] ?? '';
        if (!$hash) return null;

        unset($params['hash']);

        // HMAC tekshirish
        $token = config('services.telegram.bot_token');
        if (!$token) return null;

        // Satrlarni tartibda yig'ish
        ksort($params);
        $dataCheckString = collect($params)
            ->map(fn($v, $k) => "{$k}={$v}")
            ->implode("\n");

        $secretKey    = hash_hmac('sha256', 'WebAppData', $token, true);
        $computedHash = hash_hmac('sha256', $dataCheckString, $secretKey);

        if (!hash_equals($computedHash, $hash)) return null;

        // user JSON dan chat_id
        $userData = json_decode($params['user'] ?? '{}', true);
        $chatId   = (string)($userData['id'] ?? '');
        if (!$chatId) return null;

        $tgUser = TelegramUser::where('chat_id', $chatId)->with('user')->first();
        return $tgUser?->user;
    }

    /** Web App HTML sahifasi */
    public function index()
    {
        return view('tg-app.index');
    }

    /** Joriy user ma'lumoti — Web App uchun */
    public function me(Request $request): JsonResponse
    {
        $user = $this->getUserFromInitData($request);

        if (!$user) {
            return response()->json([
                'success' => false,
                'message' => 'Telegram orqali kirish kerak',
                'need_link' => true,
            ], 401);
        }

        $ecoActions   = GreenCoinTransaction::where('user_id', $user->id)->where('type', 'earned')->count();
        $todayActions = GreenCoinTransaction::where('user_id', $user->id)
            ->whereDate('created_at', today())->where('type', 'earned')->count();
        $todayGC      = GreenCoinTransaction::where('user_id', $user->id)
            ->whereDate('created_at', today())->where('type', 'earned')->sum('amount');

        return response()->json([
            'success' => true,
            'user'    => [
                'id'               => $user->id,
                'name'             => $user->name,
                'greencoin_balance' => $user->greencoin_balance,
                'login_streak'     => $user->login_streak ?? 0,
                'eco_actions'      => $ecoActions,
                'today_actions'    => $todayActions,
                'today_gc'         => $todayGC,
                'applications'     => $user->applications()->count(),
                'referral_count'   => $user->referral_count ?? 0,
                'level'            => $this->getLevel($user->greencoin_balance),
                'level_icon'       => $this->getLevelIcon($user->greencoin_balance),
                'profile_completed' => $user->profile_completed,
                'referral_link'    => url('/register?ref=' . ($user->referral_code ?? '')),
            ],
        ]);
    }

    /** Eco vazifalar */
    public function ecoTasks(): JsonResponse
    {
        $tasks = EcoTask::where('is_active', true)->get();

        return response()->json([
            'success' => true,
            'tasks'   => $tasks->map(fn($t) => [
                'id'          => $t->id,
                'title'       => $t->title,
                'description' => $t->description,
                'reward'      => $t->reward,
                'category'    => $t->category,
            ]),
        ]);
    }

    /** Eco statistika */
    public function ecoStats(Request $request): JsonResponse
    {
        $user = $this->getUserFromInitData($request);

        $q = GreenCoinTransaction::where('type', 'earned');
        if ($user) $q->where('user_id', $user->id);

        $totalActions = (clone $q)->count();
        $todayActions = (clone $q)->whereDate('created_at', today())->count();
        $totalGC      = (clone $q)->sum('amount');

        return response()->json([
            'success'       => true,
            'total_actions' => $totalActions,
            'today_actions' => $todayActions,
            'total_gc'      => $totalGC,
        ]);
    }

    private function getLevel(int $balance): string
    {
        return match(true) {
            $balance >= 5000 => 'Platinum',
            $balance >= 1000 => 'Gold',
            $balance >= 500  => 'Silver',
            $balance >= 100  => 'Bronze',
            default          => 'Starter',
        };
    }

    private function getLevelIcon(int $balance): string
    {
        return match(true) {
            $balance >= 5000 => '👑',
            $balance >= 1000 => '🥇',
            $balance >= 500  => '🥈',
            $balance >= 100  => '🥉',
            default          => '🌱',
        };
    }
}
