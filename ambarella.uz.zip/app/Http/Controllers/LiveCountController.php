<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;

class LiveCountController extends Controller
{
    public function count()
    {
        // Approximate by counting sessions modified in last 5 minutes
        $count = DB::table('sessions')
            ->where('last_activity', '>=', now()->subMinutes(5)->timestamp)
            ->count();

        return response()->json(['online' => max($count, 1)]);
    }
}
