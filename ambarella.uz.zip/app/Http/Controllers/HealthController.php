<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;

class HealthController extends Controller
{
    public function check()
    {
        $checks = [
            'status' => 'ok',
            'timestamp' => now()->toIso8601String(),
            'app' => config('app.name'),
            'environment' => config('app.env'),
            'php_version' => PHP_VERSION,
            'laravel_version' => app()->version(),
        ];

        // Database check
        try {
            DB::connection()->getPdo();
            $checks['database'] = 'connected';
        } catch (\Exception $e) {
            $checks['database'] = 'error';
            $checks['status'] = 'degraded';
        }

        // Cache check
        try {
            Cache::put('health_check', true, 10);
            $checks['cache'] = Cache::get('health_check') ? 'working' : 'error';
        } catch (\Exception $e) {
            $checks['cache'] = 'error';
        }

        // Disk space
        $freeSpace = disk_free_space('/');
        $totalSpace = disk_total_space('/');
        if ($freeSpace && $totalSpace) {
            $checks['disk_free_gb'] = round($freeSpace / 1073741824, 2);
            $checks['disk_usage_percent'] = round((1 - $freeSpace / $totalSpace) * 100, 1);
        }

        // Memory
        $checks['memory_usage_mb'] = round(memory_get_usage(true) / 1048576, 2);

        $statusCode = $checks['status'] === 'ok' ? 200 : 503;

        return response()->json($checks, $statusCode);
    }
}
