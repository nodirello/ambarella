<?php

namespace App\Http\Controllers;

use App\Models\EcoTask;
use App\Models\GreenCoinTransaction;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

class EcoController extends Controller
{
    public function index()
    {
        $tasks = EcoTask::where('is_active', true)->get();
        $categories = $tasks->pluck('category')->unique()->filter()->values();

        // User'ning bugun bajargan vazifalari
        $completedToday = [];
        $userStats = null;

        if (auth()->check()) {
            $completedToday = GreenCoinTransaction::where('user_id', auth()->id())
                ->whereDate('created_at', today())
                ->where('type', 'earned')
                ->pluck('description')
                ->toArray();

            $tasks->each(function ($task) use ($completedToday) {
                $task->completed_today = in_array($task->title . ' bajarildi', $completedToday);
            });

            $userStats = [
                'total_earned'  => GreenCoinTransaction::where('user_id', auth()->id())->where('type', 'earned')->sum('amount'),
                'tasks_done'    => GreenCoinTransaction::where('user_id', auth()->id())->where('type', 'earned')->count(),
                'today_earned'  => GreenCoinTransaction::where('user_id', auth()->id())->whereDate('created_at', today())->where('type', 'earned')->sum('amount'),
                'balance'       => auth()->user()->greencoin_balance,
            ];
        }

        // Global stats
        $stats = Cache::remember('eco_stats', 300, fn() => [
            'total_actions' => GreenCoinTransaction::where('type', 'earned')->count(),
            'total_co2'     => GreenCoinTransaction::where('type', 'earned')->sum('amount') * 2,
            'total_coins'   => GreenCoinTransaction::where('type', 'earned')->sum('amount'),
            'total_users'   => GreenCoinTransaction::where('type', 'earned')->distinct('user_id')->count('user_id'),
        ]);

        // Leaderboard (top 10)
        $leaderboard = Cache::remember('eco_leaderboard', 300, fn() =>
            User::where('greencoin_balance', '>', 0)
                ->where('is_banned', false)
                ->orderByDesc('greencoin_balance')
                ->take(10)
                ->get(['id', 'name', 'greencoin_balance', 'avatar'])
        );

        return view('eco.index', compact('tasks', 'categories', 'stats', 'userStats', 'leaderboard', 'completedToday'));
    }

    public function complete(EcoTask $task)
    {
        if (!$task->is_active) {
            return back()->withErrors(['task' => 'Bu vazifa faol emas.']);
        }

        $user = auth()->user();

        $alreadyDone = GreenCoinTransaction::where('user_id', $user->id)
            ->where('description', $task->title . ' bajarildi')
            ->whereDate('created_at', today())
            ->exists();

        if ($alreadyDone) {
            return back()->withErrors(['task' => 'Siz bu vazifani bugun allaqachon bajargansiz. Ertaga qayta urinib ko\'ring.']);
        }

        // GreenCoin berish
        GreenCoinTransaction::create([
            'user_id'     => $user->id,
            'amount'      => $task->reward,
            'type'        => 'earned',
            'description' => $task->title . ' bajarildi',
        ]);

        $user->increment('greencoin_balance', $task->reward);

        // Activity log
        \App\Models\ActivityLog::create([
            'user_id'     => $user->id,
            'action'      => 'eco_task_complete',
            'description' => $task->title . ' (+' . $task->reward . ' GC)',
            'ip_address'  => request()->ip(),
        ]);

        // Cache tozalash
        Cache::forget('eco_stats');
        Cache::forget('eco_leaderboard');
        Cache::forget('home_stats');

        return back()->with('success', "Vazifa bajarildi! <strong>+{$task->reward} GreenCoin</strong> qo'shildi 🎉");
    }
}
