<?php

namespace App\Http\Controllers;

use App\Models\GreenCoinTransaction;
use App\Models\User;
use Illuminate\Http\Request;

class GreenCoinController extends Controller
{
    public function index()
    {
        $user = auth()->user();
        $transactions = GreenCoinTransaction::where('user_id', $user->id)
            ->latest()
            ->paginate(20);

        $stats = [
            'balance' => $user->greencoin_balance,
            'earned' => GreenCoinTransaction::where('user_id', $user->id)->where('type', 'earned')->sum('amount'),
            'spent' => GreenCoinTransaction::where('user_id', $user->id)->where('type', 'spent')->sum('amount'),
            'rank' => User::where('greencoin_balance', '>', $user->greencoin_balance)->where('is_banned', false)->count() + 1,
        ];

        return view('greencoin.index', compact('transactions', 'stats'));
    }

    /**
     * GreenCoin transfer qilish
     */
    public function transfer(Request $request)
    {
        $request->validate([
            'recipient_email' => 'required|email|exists:users,email',
            'amount' => 'required|integer|min:10|max:5000',
            'message' => 'nullable|string|max:255',
        ]);

        $sender = auth()->user();
        $recipient = User::where('email', $request->recipient_email)->first();

        // O'ziga transfer qilish mumkin emas
        if ($recipient->id === $sender->id) {
            return back()->withErrors(['recipient_email' => 'O\'zingizga transfer qilib bo\'lmaydi.']);
        }

        // Yetarli balans
        if ($sender->greencoin_balance < $request->amount) {
            return back()->withErrors(['amount' => 'Yetarli GreenCoin yo\'q.']);
        }

        // Transfer
        $sender->decrement('greencoin_balance', $request->amount);
        $recipient->increment('greencoin_balance', $request->amount);

        // Tranzaksiyalar
        GreenCoinTransaction::create([
            'user_id' => $sender->id,
            'amount' => $request->amount,
            'type' => 'spent',
            'description' => 'Transfer: ' . $recipient->name . ($request->message ? ' — ' . $request->message : ''),
        ]);

        GreenCoinTransaction::create([
            'user_id' => $recipient->id,
            'amount' => $request->amount,
            'type' => 'earned',
            'description' => 'Transfer olindi: ' . $sender->name . ($request->message ? ' — ' . $request->message : ''),
        ]);

        return back()->with('success', "{$request->amount} GC {$recipient->name} ga yuborildi!");
    }
}
