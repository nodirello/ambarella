<?php

namespace App\Http\Controllers;

use App\Models\Favorite;
use App\Models\Job;
use App\Models\Course;
use App\Models\Mentor;
use Illuminate\Http\Request;

class FavoriteController extends Controller
{
    public function toggle(Request $request)
    {
        $request->validate([
            'type' => 'required|in:job,course,mentor',
            'id' => 'required|integer',
        ]);

        $typeMap = [
            'job' => Job::class,
            'course' => Course::class,
            'mentor' => Mentor::class,
        ];

        $favoritableType = $typeMap[$request->type];
        $user = auth()->user();

        $existing = Favorite::where('user_id', $user->id)
            ->where('favoritable_id', $request->id)
            ->where('favoritable_type', $favoritableType)
            ->first();

        if ($existing) {
            $existing->delete();
            return back()->with('success', 'Sevimlilardan olib tashlandi.');
        }

        Favorite::create([
            'user_id' => $user->id,
            'favoritable_id' => $request->id,
            'favoritable_type' => $favoritableType,
        ]);

        return back()->with('success', 'Sevimlilarga qo\'shildi!');
    }

    public function index()
    {
        $user = auth()->user();

        $jobFavorites = Favorite::where('user_id', $user->id)
            ->where('favoritable_type', Job::class)
            ->with('favoritable')
            ->get()
            ->pluck('favoritable')
            ->filter();

        $courseFavorites = Favorite::where('user_id', $user->id)
            ->where('favoritable_type', Course::class)
            ->with('favoritable')
            ->get()
            ->pluck('favoritable')
            ->filter();

        $mentorFavorites = Favorite::where('user_id', $user->id)
            ->where('favoritable_type', Mentor::class)
            ->with('favoritable')
            ->get()
            ->pluck('favoritable')
            ->filter();

        return view('favorites.index', compact('jobFavorites', 'courseFavorites', 'mentorFavorites'));
    }
}
