<?php

namespace App\Http\Controllers;

use App\Models\Course;
use Illuminate\Http\Request;

class CertificateController extends Controller
{
    public function generate(Course $course)
    {
        $user = auth()->user();

        // Check if user enrolled
        if (!$user->courses()->where('course_id', $course->id)->exists()) {
            return back()->withErrors(['certificate' => 'Siz bu kursga yozilmagansiz.']);
        }

        $data = [
            'user_name' => $user->name,
            'course_title' => $course->title,
            'instructor' => $course->instructor,
            'date' => now()->format('d.m.Y'),
            'certificate_id' => 'AMB-' . str_pad($user->id, 4, '0', STR_PAD_LEFT) . '-' . str_pad($course->id, 4, '0', STR_PAD_LEFT),
        ];

        return view('certificate.pdf', $data);
    }

    public function verify($id)
    {
        // Parse certificate ID: AMB-0001-0002
        $parts = explode('-', $id);
        if (count($parts) !== 3 || $parts[0] !== 'AMB') {
            return view('certificate.invalid');
        }

        $userId = (int)$parts[1];
        $courseId = (int)$parts[2];

        $user = \App\Models\User::find($userId);
        $course = Course::find($courseId);

        if (!$user || !$course) {
            return view('certificate.invalid');
        }

        return view('certificate.verify', compact('user', 'course', 'id'));
    }
}
