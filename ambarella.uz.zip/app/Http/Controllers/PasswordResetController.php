<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

class PasswordResetController extends Controller
{
    /**
     * Parolni tiklash so'rovi — kod yuborish
     */
    public function requestReset(Request $request)
    {
        $request->validate(['email' => 'required|email']);

        $user = User::where('email', $request->email)->first();
        if (!$user) {
            return back()->withErrors(['email' => 'Bu email ro\'yxatdan o\'tmagan.']);
        }

        $code = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
        Cache::put('password_reset_' . $user->email, $code, now()->addMinutes(10));

        $sent = false;

        // 1-usul: Telegram orqali kod yuborish (agar ulangan bo'lsa)
        if ($user->telegram_id) {
            $token = config('services.telegram.bot_token');
            Http::post("https://api.telegram.org/bot{$token}/sendMessage", [
                'chat_id' => $user->telegram_id,
                'text' => "🔐 AMBARELLA parol tiklash kodi: *{$code}*\n10 daqiqa amal qiladi.",
                'parse_mode' => 'Markdown',
            ]);
            $sent = true;
        }

        // 2-usul: Email orqali kod yuborish
        if (!$sent && config('mail.mailer') !== 'log') {
            try {
                Mail::raw("AMBARELLA parol tiklash kodi: {$code}\n\nKod 10 daqiqa amal qiladi.\nAgar siz so'ramagan bo'lsangiz, e'tiborsiz qoldiring.", function ($message) use ($user) {
                    $message->to($user->email)
                            ->subject('AMBARELLA — Parol tiklash kodi');
                });
                $sent = true;
            } catch (\Exception $e) {
                // Email yuborib bo'lmasa, keyingi usulga o'tamiz
            }
        }

        if (!$sent) {
            return back()->withErrors(['email' => 'Kod yuborib bo\'lmadi. Telegram botga ulanib ko\'ring yoki admin bilan bog\'laning.']);
        }

        return view('auth.reset-code', ['email' => $user->email]);
    }

    /**
     * Kodni tekshirish va yangi parol o'rnatish
     */
    public function resetPassword(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'code' => 'required|string|size:6',
            'password' => 'required|min:8|confirmed',
        ]);

        $savedCode = Cache::get('password_reset_' . $request->email);

        if (!$savedCode || $savedCode !== $request->code) {
            return back()->withErrors(['code' => 'Kod noto\'g\'ri yoki muddati o\'tgan.']);
        }

        $user = User::where('email', $request->email)->first();
        if (!$user) {
            return back()->withErrors(['email' => 'Foydalanuvchi topilmadi.']);
        }

        $user->password = Hash::make($request->password);
        $user->save();

        Cache::forget('password_reset_' . $request->email);

        return redirect('/login')->with('success', 'Parol yangilandi! Endi kiring.');
    }

    public function showForm()
    {
        return view('auth.forgot-password');
    }
}
