<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class OnboardingController extends Controller
{
    public function show()
    {
        if (auth()->user()->profile_completed) {
            return redirect('/dashboard');
        }
        return view('onboarding.index');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'phone' => 'required|string|max:20',
            'birth_date' => 'required|date|before:today',
            'gender' => 'required|in:male,female',
            'region' => 'required|string|max:100',
            'bio' => 'nullable|string|max:500',
            'interests' => 'required|array|min:1|max:5',
            'interests.*' => 'string|max:50',
            'avatar' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
        ]);

        $user = auth()->user();
        $user->name = $request->name;
        $user->phone = $request->phone;
        $user->birth_date = $request->birth_date;
        $user->gender = $request->gender;
        $user->region = $request->region;
        $user->bio = $request->bio;
        $user->interests = $request->interests;
        $user->profile_completed = true;

        if ($request->hasFile('avatar')) {
            $user->avatar = $request->file('avatar')->store('avatars', 'public');
        }

        $user->save();
        $user->rewardReferralIfEligible();

        return redirect('/dashboard')->with('success', 'Tabriklaymiz! Profilingiz tayyor. Platformadan foydalanishingiz mumkin.');
    }
}
