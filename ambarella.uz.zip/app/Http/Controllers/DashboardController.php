<?php

namespace App\Http\Controllers;

use App\Models\DailyTask;
use App\Models\Habit;
use App\Models\Mentorship;
use App\Models\Course;

class DashboardController extends Controller
{
    public function index()
    {
        $user = auth()->user();
        $today = now()->toDateString();

        $data = [
            'greencoin' => $user->greencoin_balance,
            'tasks_done' => $user->transactions()->where('type', 'earned')->count(),
            'applications' => $user->applications()->count(),
            'login_streak' => $user->login_streak ?? 0,
            'courses_enrolled' => $user->courses()->count(),
        ];

        // Kundalik vazifalar
        $dailyTasks = DailyTask::where('user_id', $user->id)
            ->where('date', $today)
            ->latest()
            ->take(5)
            ->get();

        // Odatlar
        $habits = Habit::where('user_id', $user->id)
            ->orderBy('streak', 'desc')
            ->take(5)
            ->get();

        // Mentorliklar
        $mentorships = Mentorship::where(function ($q) use ($user) {
                $q->where('student_id', $user->id)
                  ->orWhere('mentor_id', $user->id);
            })
            ->where('status', 'active')
            ->with(['mentor', 'student'])
            ->take(3)
            ->get();

        return view('dashboard', compact('data', 'dailyTasks', 'habits', 'mentorships'));
    }
}
