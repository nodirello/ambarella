<?php

namespace App\Http\Controllers;

use App\Models\Job;
use App\Models\Course;
use App\Models\News;

class SitemapController extends Controller
{
    public function index()
    {
        $staticRoutes = [
            ['url' => '/', 'priority' => '1.0', 'freq' => 'daily'],
            ['url' => '/jobs', 'priority' => '0.9', 'freq' => 'daily'],
            ['url' => '/eco', 'priority' => '0.8', 'freq' => 'weekly'],
            ['url' => '/academy', 'priority' => '0.9', 'freq' => 'weekly'],
            ['url' => '/mentor', 'priority' => '0.8', 'freq' => 'weekly'],
            ['url' => '/farm', 'priority' => '0.8', 'freq' => 'daily'],
            ['url' => '/news', 'priority' => '0.8', 'freq' => 'daily'],
            ['url' => '/startup', 'priority' => '0.7', 'freq' => 'monthly'],
            ['url' => '/volunteer', 'priority' => '0.7', 'freq' => 'monthly'],
            ['url' => '/events', 'priority' => '0.7', 'freq' => 'weekly'],
            ['url' => '/challenges', 'priority' => '0.7', 'freq' => 'weekly'],
            ['url' => '/psychology', 'priority' => '0.7', 'freq' => 'monthly'],
            ['url' => '/about', 'priority' => '0.6', 'freq' => 'monthly'],
            ['url' => '/contact', 'priority' => '0.6', 'freq' => 'monthly'],
            ['url' => '/modules', 'priority' => '0.7', 'freq' => 'monthly'],
            ['url' => '/blog', 'priority' => '0.8', 'freq' => 'daily'],
        ];

        $jobs = Job::where('is_active', true)->select('id', 'updated_at')->get();
        $courses = Course::select('id', 'updated_at')->get();
        $news = News::select('id', 'updated_at')->get();

        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

        foreach ($staticRoutes as $route) {
            $xml .= '  <url>' . "\n";
            $xml .= '    <loc>' . url($route['url']) . '</loc>' . "\n";
            $xml .= '    <changefreq>' . $route['freq'] . '</changefreq>' . "\n";
            $xml .= '    <priority>' . $route['priority'] . '</priority>' . "\n";
            $xml .= '  </url>' . "\n";
        }

        foreach ($jobs as $job) {
            $xml .= '  <url>' . "\n";
            $xml .= '    <loc>' . url('/jobs/' . $job->id) . '</loc>' . "\n";
            $xml .= '    <lastmod>' . $job->updated_at->toW3cString() . '</lastmod>' . "\n";
            $xml .= '    <changefreq>daily</changefreq>' . "\n";
            $xml .= '    <priority>0.7</priority>' . "\n";
            $xml .= '  </url>' . "\n";
        }

        foreach ($courses as $course) {
            $xml .= '  <url>' . "\n";
            $xml .= '    <loc>' . url('/academy/' . $course->id) . '</loc>' . "\n";
            $xml .= '    <lastmod>' . $course->updated_at->toW3cString() . '</lastmod>' . "\n";
            $xml .= '    <changefreq>weekly</changefreq>' . "\n";
            $xml .= '    <priority>0.7</priority>' . "\n";
            $xml .= '  </url>' . "\n";
        }

        foreach ($news as $item) {
            $xml .= '  <url>' . "\n";
            $xml .= '    <loc>' . url('/news/' . $item->id) . '</loc>' . "\n";
            $xml .= '    <lastmod>' . $item->updated_at->toW3cString() . '</lastmod>' . "\n";
            $xml .= '    <changefreq>daily</changefreq>' . "\n";
            $xml .= '    <priority>0.6</priority>' . "\n";
            $xml .= '  </url>' . "\n";
        }

        $xml .= '</urlset>';

        return response($xml, 200)->header('Content-Type', 'text/xml');
    }
}
