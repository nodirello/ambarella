<?php

namespace App\Http\Controllers\Business;

use App\Http\Controllers\Controller;
use App\Models\Job;
use App\Models\JobApplication;
use App\Models\FarmProduct;
use Illuminate\Support\Facades\DB;

class BusinessAnalyticsController extends Controller
{
    public function index()
    {
        $business = auth()->user()->businessProfile;
        if (!$business) return redirect('/business/register');

        $stats = [
            'total_jobs' => Job::where('company', $business->company_name)->count(),
            'active_jobs' => Job::where('company', $business->company_name)->where('is_active', true)->count(),
            'total_applications' => JobApplication::whereHas('job', fn($q) => $q->where('company', $business->company_name))->count(),
            'pending_applications' => JobApplication::whereHas('job', fn($q) => $q->where('company', $business->company_name))->where('status', 'pending')->count(),
            'total_products' => FarmProduct::where('user_id', auth()->id())->count(),
            'active_products' => FarmProduct::where('user_id', auth()->id())->where('is_active', true)->count(),
        ];

        // Haftalik arizalar
        $weeklyApps = JobApplication::whereHas('job', fn($q) => $q->where('company', $business->company_name))
            ->where('created_at', '>=', now()->subDays(7))
            ->select(DB::raw('DATE(created_at) as date'), DB::raw('COUNT(*) as count'))
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        // Eng ko'p ariza kelgan ish e'lonlari
        $topJobs = Job::where('company', $business->company_name)
            ->withCount('applications')
            ->orderByDesc('applications_count')
            ->take(5)
            ->get();

        return view('business.analytics', compact('business', 'stats', 'weeklyApps', 'topJobs'));
    }
}
