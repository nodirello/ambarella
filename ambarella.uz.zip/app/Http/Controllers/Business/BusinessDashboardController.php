<?php

namespace App\Http\Controllers\Business;

use App\Http\Controllers\Controller;
use App\Models\Job;
use App\Models\FarmProduct;
use App\Models\JobApplication;
use Illuminate\Http\Request;

class BusinessDashboardController extends Controller
{
    public function index()
    {
        $business = auth()->user()->businessProfile;

        if (!$business) {
            return redirect('/business/register');
        }

        $myJobsCount = Job::where('company', $business->company_name)->count();
        $myProductsCount = FarmProduct::where('user_id', auth()->id())->count();
        $applicationsCount = JobApplication::whereHas('job', function ($q) use ($business) {
            $q->where('company', $business->company_name);
        })->count();

        return view('business.dashboard', compact('business', 'myJobsCount', 'myProductsCount', 'applicationsCount'));
    }
}
