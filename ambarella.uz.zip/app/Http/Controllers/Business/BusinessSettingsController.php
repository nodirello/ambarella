<?php

namespace App\Http\Controllers\Business;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class BusinessSettingsController extends Controller
{
    public function index()
    {
        $business = auth()->user()->businessProfile;
        if (!$business) return redirect('/business/register');

        return view('business.settings', compact('business'));
    }

    public function update(Request $request)
    {
        $business = auth()->user()->businessProfile;
        if (!$business) return redirect('/business/register');

        $request->validate([
            'company_name' => 'required|string|max:255',
            'description' => 'nullable|string|max:1000',
            'website' => 'nullable|url|max:255',
            'phone' => 'required|string|max:20',
            'email' => 'required|email|max:255',
            'region' => 'nullable|string|max:100',
            'logo' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
        ]);

        $business->company_name = $request->company_name;
        $business->description = $request->description;
        $business->website = $request->website;
        $business->phone = $request->phone;
        $business->email = $request->email;
        $business->region = $request->region;

        if ($request->hasFile('logo')) {
            if ($business->logo) {
                Storage::disk('public')->delete($business->logo);
            }
            $business->logo = $request->file('logo')->store('business-logos', 'public');
        }

        $business->save();

        return back()->with('success', 'Biznes profil yangilandi!');
    }
}
