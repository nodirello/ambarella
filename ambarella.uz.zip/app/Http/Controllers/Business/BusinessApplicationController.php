<?php

namespace App\Http\Controllers\Business;

use App\Http\Controllers\Controller;
use App\Models\Job;
use App\Models\JobApplication;
use Illuminate\Http\Request;

class BusinessApplicationController extends Controller
{
    public function index()
    {
        $business = auth()->user()->businessProfile;
        if (!$business) return redirect('/business/register');

        $applications = JobApplication::whereHas('job', function ($q) use ($business) {
            $q->where('company', $business->company_name);
        })->with(['user', 'job'])->latest()->paginate(20);

        $stats = [
            'total' => (clone $applications->getCollection())->count(),
            'pending' => JobApplication::whereHas('job', fn($q) => $q->where('company', $business->company_name))->where('status', 'pending')->count(),
            'accepted' => JobApplication::whereHas('job', fn($q) => $q->where('company', $business->company_name))->where('status', 'accepted')->count(),
            'rejected' => JobApplication::whereHas('job', fn($q) => $q->where('company', $business->company_name))->where('status', 'rejected')->count(),
        ];

        return view('business.applications.index', compact('applications', 'stats', 'business'));
    }

    public function updateStatus(Request $request, JobApplication $application)
    {
        $business = auth()->user()->businessProfile;
        if (!$business || $application->job->company !== $business->company_name) {
            abort(403);
        }

        $request->validate(['status' => 'required|in:pending,accepted,rejected']);
        $application->update(['status' => $request->status]);

        return back()->with('success', 'Ariza holati yangilandi!');
    }
}
