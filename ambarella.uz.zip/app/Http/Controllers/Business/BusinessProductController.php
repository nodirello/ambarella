<?php

namespace App\Http\Controllers\Business;

use App\Http\Controllers\Controller;
use App\Models\FarmProduct;
use Illuminate\Http\Request;

class BusinessProductController extends Controller
{
    public function index()
    {
        $products = FarmProduct::where('user_id', auth()->id())->latest()->paginate(15);
        return view('business.products.index', compact('products'));
    }
}
