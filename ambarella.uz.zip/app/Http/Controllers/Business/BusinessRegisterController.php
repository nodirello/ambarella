<?php

namespace App\Http\Controllers\Business;

use App\Http\Controllers\Controller;
use App\Models\BusinessProfile;
use Illuminate\Http\Request;

class BusinessRegisterController extends Controller
{
    public function show()
    {
        return view('business.register');
    }

    public function store(Request $request)
    {
        $request->validate([
            'company_name' => 'required|string|max:255',
            'company_type' => 'required|in:employer,seller,startup',
            'description' => 'nullable|string|max:1000',
            'website' => 'nullable|url|max:255',
            'phone' => 'required|string|max:20',
            'email' => 'required|email|max:255',
            'region' => 'nullable|string|max:100',
        ]);

        BusinessProfile::create([
            'user_id' => auth()->id(),
            'company_name' => $request->company_name,
            'company_type' => $request->company_type,
            'description' => $request->description,
            'website' => $request->website,
            'phone' => $request->phone,
            'email' => $request->email,
            'region' => $request->region,
        ]);

        return redirect('/business')->with('success', 'Biznes profil muvaffaqiyatli yaratildi!');
    }
}
