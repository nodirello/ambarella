<?php

namespace App\Http\Controllers\Business;

use App\Http\Controllers\Controller;
use App\Models\Job;
use Illuminate\Http\Request;

class BusinessJobController extends Controller
{
    public function index()
    {
        $business = auth()->user()->businessProfile;
        $jobs = Job::where('company', $business->company_name ?? '')->latest()->paginate(10);

        return view('business.jobs.index', compact('jobs', 'business'));
    }

    public function create()
    {
        return view('business.jobs.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'location' => 'required|string|max:255',
            'type' => 'required|string|max:50',
            'salary_min' => 'nullable|numeric',
            'salary_max' => 'nullable|numeric',
            'description' => 'required|string',
            'tags' => 'nullable|string',
        ]);

        $business = auth()->user()->businessProfile;

        Job::create([
            'title' => $request->title,
            'company' => $business->company_name,
            'location' => $request->location,
            'type' => $request->type,
            'salary_min' => $request->salary_min,
            'salary_max' => $request->salary_max,
            'description' => $request->description,
            'tags' => $request->tags ? explode(',', $request->tags) : [],
            'is_active' => true,
        ]);

        return redirect('/business/jobs')->with('success', 'Ish e\'loni muvaffaqiyatli yaratildi!');
    }

    public function toggle(Job $job)
    {
        $business = auth()->user()->businessProfile;
        if (!$business || $job->company !== $business->company_name) {
            abort(403);
        }
        $job->update(['is_active' => !$job->is_active]);
        return back()->with('success', $job->is_active ? 'Faollashtirildi!' : 'To\'xtatildi!');
    }
}
