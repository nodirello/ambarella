<?php

namespace App\Http\Controllers;

use App\Models\Job;
use App\Models\JobApplication;
use App\Models\GreenCoinTransaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

class JobController extends Controller
{
    public function index(Request $request)
    {
        $query = Job::where('is_active', true);

        if ($request->filled('search')) {
            $s = strip_tags($request->search);
            $query->where(function ($q) use ($s) {
                $q->where('title', 'like', "%{$s}%")
                  ->orWhere('company', 'like', "%{$s}%")
                  ->orWhere('tags', 'like', "%{$s}%");
            });
        }

        if ($request->filled('type')) {
            $query->where('type', $request->type);
        }

        if ($request->filled('location')) {
            $query->where('location', $request->location);
        }

        if ($request->filled('salary_min')) {
            $query->where('salary_min', '>=', (int)$request->salary_min * 1000000);
        }

        $sortBy = $request->get('sort', 'latest');
        match($sortBy) {
            'salary_high' => $query->orderByDesc('salary_max'),
            'salary_low'  => $query->orderBy('salary_min'),
            'popular'     => $query->orderByDesc('views_count'),
            default       => $query->latest(),
        };

        $jobs = $query->paginate(12)->withQueryString();

        // Stats
        $stats = Cache::remember('jobs_stats', 300, fn() => [
            'total'   => Job::where('is_active', true)->count(),
            'remote'  => Job::where('is_active', true)->where('type', 'masofaviy')->count(),
            'new'     => Job::where('is_active', true)->where('created_at', '>=', now()->subDays(7))->count(),
        ]);

        // Locations for filter
        $locations = Cache::remember('job_locations', 600, fn() =>
            Job::where('is_active', true)->whereNotNull('location')->distinct()->pluck('location')
        );

        return view('jobs.index', compact('jobs', 'stats', 'locations'));
    }

    public function show(Job $job)
    {
        if (!$job->is_active) abort(404);

        // Views counter
        $job->increment('views_count');

        // Related jobs
        $related = Job::where('is_active', true)
            ->where('id', '!=', $job->id)
            ->where(function($q) use ($job) {
                $q->where('location', $job->location)
                  ->orWhere('type', $job->type);
            })
            ->latest()->take(4)->get();

        $isApplied = auth()->check()
            ? $job->applications()->where('user_id', auth()->id())->exists()
            : false;

        $applicationsCount = $job->applications()->count();

        return view('jobs.show', compact('job', 'related', 'isApplied', 'applicationsCount'));
    }

    public function apply(Job $job, Request $request)
    {
        if (!$job->is_active) {
            return back()->withErrors(['job' => 'Bu vakansiya yopilgan.']);
        }

        $request->validate([
            'cover_letter' => 'nullable|string|max:1000',
            'phone'        => 'nullable|string|max:20',
        ]);

        $user = auth()->user();

        $alreadyApplied = $job->applications()->where('user_id', $user->id)->exists();
        if ($alreadyApplied) {
            return back()->withErrors(['job' => 'Siz bu vakansiyaga allaqachon ariza topshirgansiz.']);
        }

        $job->applications()->create([
            'user_id'      => $user->id,
            'status'       => 'pending',
            'cover_letter' => strip_tags($request->cover_letter ?? ''),
            'phone'        => $request->phone ?? $user->phone,
        ]);

        // +5 GreenCoin — ariza topshirgani uchun
        $user->increment('greencoin_balance', 5);
        GreenCoinTransaction::create([
            'user_id'     => $user->id,
            'amount'      => 5,
            'type'        => 'earned',
            'description' => 'Ish arizasi topshirildi: ' . $job->title,
        ]);

        // Admin notification
        \App\Http\Controllers\Admin\AdminNotificationService::notifyNewApplication($user, $job->title);

        // Activity log
        \App\Models\ActivityLog::create([
            'user_id'     => $user->id,
            'action'      => 'job_apply',
            'description' => 'Ariza: ' . $job->title . ' — ' . $job->company,
            'ip_address'  => $request->ip(),
        ]);

        return back()->with('success', 'Arizangiz muvaffaqiyatli topshirildi! +5 GreenCoin');
    }

    public function saveJob(Job $job)
    {
        $user = auth()->user();
        $existing = \App\Models\Favorite::where('user_id', $user->id)
            ->where('favorable_type', Job::class)
            ->where('favorable_id', $job->id)
            ->first();

        if ($existing) {
            $existing->delete();
            return back()->with('success', 'Sevimlilardan olib tashlandi.');
        }

        \App\Models\Favorite::create([
            'user_id'        => $user->id,
            'favorable_type' => Job::class,
            'favorable_id'   => $job->id,
        ]);

        return back()->with('success', 'Sevimlilaringizga qo\'shildi!');
    }
}
