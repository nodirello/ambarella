<?php

namespace App\Http\Controllers;

use App\Models\Course;
use App\Models\GreenCoinTransaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

class CourseController extends Controller
{
    public function index(Request $request)
    {
        $query = Course::query();

        if ($request->filled('search')) {
            $s = strip_tags($request->search);
            $query->where(function($q) use ($s) {
                $q->where('title', 'like', "%{$s}%")
                  ->orWhere('instructor', 'like', "%{$s}%")
                  ->orWhere('category', 'like', "%{$s}%");
            });
        }

        if ($request->filled('level')) {
            $query->where('level', $request->level);
        }

        if ($request->filled('category')) {
            $query->where('category', $request->category);
        }

        if ($request->get('free')) {
            $query->where('price', 0);
        }

        $courses = $query->latest()->paginate(12)->withQueryString();

        $stats = Cache::remember('academy_stats', 300, fn() => [
            'total'      => Course::count(),
            'free'       => Course::where('price', 0)->count(),
            'enrolled'   => \Illuminate\Support\Facades\DB::table('course_user')->count(),
        ]);

        $categories = Cache::remember('course_categories', 600, fn() =>
            Course::whereNotNull('category')->distinct()->pluck('category')
        );

        return view('academy.index', compact('courses', 'stats', 'categories'));
    }

    public function show(Course $course)
    {
        $isEnrolled = auth()->check()
            ? auth()->user()->courses()->where('course_id', $course->id)->exists()
            : false;

        $studentsCount = $course->users()->count();

        $related = Course::where('category', $course->category)
            ->where('id', '!=', $course->id)
            ->take(3)->get();

        return view('academy.show', compact('course', 'isEnrolled', 'studentsCount', 'related'));
    }

    public function enroll(Course $course)
    {
        $user = auth()->user();

        $alreadyEnrolled = $user->courses()->where('course_id', $course->id)->exists();
        if ($alreadyEnrolled) {
            return back()->with('success', 'Siz allaqachon bu kursga yozilgansiz!');
        }

        $user->courses()->attach($course->id);

        // +10 GreenCoin kursga yozilgani uchun
        $user->increment('greencoin_balance', 10);
        GreenCoinTransaction::create([
            'user_id'     => $user->id,
            'amount'      => 10,
            'type'        => 'earned',
            'description' => 'Kursga yozildi: ' . $course->title,
        ]);

        \App\Models\ActivityLog::create([
            'user_id'     => $user->id,
            'action'      => 'course_enroll',
            'description' => $course->title,
            'ip_address'  => request()->ip(),
        ]);

        return back()->with('success', 'Kursga muvaffaqiyatli yozildingiz! +10 GreenCoin');
    }
}
