<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Job;
use App\Models\Course;
use App\Models\News;
use App\Models\GreenCoinTransaction;
use Illuminate\Support\Facades\Cache;

class AdminDashboardController extends Controller
{
    public function index()
    {
        $stats = Cache::remember('admin_stats', 120, function () {
            return [
                'users' => User::count(),
                'jobs' => Job::count(),
                'courses' => Course::count(),
                'coins_total' => GreenCoinTransaction::where('type', 'earned')->sum('amount'),
                'today_users' => User::whereDate('created_at', today())->count(),
                'active_jobs' => Job::where('is_active', true)->count(),
                'news_count' => News::count(),
                'banned_users' => User::where('is_banned', true)->count(),
            ];
        });

        $recentUsers = User::latest()->take(10)->get();

        return view('admin.dashboard', compact('stats', 'recentUsers'));
    }
}
