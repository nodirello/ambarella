<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\FarmProduct;
use App\Models\BlogPost;
use App\Models\Comment;

class AdminModerationController extends Controller
{
    public function index()
    {
        // Get recent items needing moderation
        $pendingComments = Comment::where('is_approved', false)->with('user')->latest()->take(20)->get();
        $recentProducts = FarmProduct::where('is_active', true)->latest()->take(10)->get();
        $recentPosts = BlogPost::where('is_published', true)->latest()->take(10)->get();

        return view('admin.moderation.index', compact('pendingComments', 'recentProducts', 'recentPosts'));
    }

    public function approveComment(Comment $comment)
    {
        $comment->update(['is_approved' => true]);
        return back()->with('success', 'Izoh tasdiqlandi!');
    }

    public function rejectComment(Comment $comment)
    {
        $comment->delete();
        return back()->with('success', 'Izoh o\'chirildi!');
    }
}
