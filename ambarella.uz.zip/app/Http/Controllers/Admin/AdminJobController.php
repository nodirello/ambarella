<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Job;
use Illuminate\Http\Request;

class AdminJobController extends Controller
{
    public function index()
    {
        $jobs = Job::latest()->paginate(20);
        return view('admin.jobs.index', compact('jobs'));
    }

    public function create()
    {
        return view('admin.jobs.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'company' => 'required|string|max:255',
            'location' => 'required|string|max:100',
            'type' => 'required|in:toliq,yarim,masofaviy',
            'salary_min' => 'required|integer|min:0',
            'salary_max' => 'required|integer|min:0|gte:salary_min',
            'description' => 'nullable|string|max:5000',
            'tags' => 'nullable|string|max:500',
        ]);

        $data = $request->only(['title', 'company', 'location', 'type', 'salary_min', 'salary_max', 'description']);
        $data['tags'] = array_filter(array_map('trim', explode(',', $request->input('tags', ''))));
        $data['is_active'] = true;

        Job::create($data);

        return redirect('/admin/jobs')->with('success', 'Ish e\'loni qo\'shildi!');
    }

    public function edit(Job $job)
    {
        return view('admin.jobs.edit', compact('job'));
    }

    public function update(Request $request, Job $job)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'company' => 'required|string|max:255',
            'location' => 'required|string|max:100',
            'type' => 'required|in:toliq,yarim,masofaviy',
            'salary_min' => 'required|integer|min:0',
            'salary_max' => 'required|integer|min:0|gte:salary_min',
            'description' => 'nullable|string|max:5000',
            'tags' => 'nullable|string|max:500',
        ]);

        $data = $request->only(['title', 'company', 'location', 'type', 'salary_min', 'salary_max', 'description']);
        $data['tags'] = array_filter(array_map('trim', explode(',', $request->input('tags', ''))));

        $job->update($data);

        return redirect('/admin/jobs')->with('success', 'Yangilandi!');
    }

    public function destroy(Job $job)
    {
        $job->delete();
        return back()->with('success', 'O\'chirildi!');
    }

    public function toggleActive(Job $job)
    {
        $job->is_active = !$job->is_active;
        $job->save();

        return back()->with('success', $job->is_active ? 'Faollashtirildi.' : 'O\'chirildi.');
    }
}
