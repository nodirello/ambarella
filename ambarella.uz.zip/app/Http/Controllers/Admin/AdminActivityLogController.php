<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ActivityLog;

class AdminActivityLogController extends Controller
{
    public function index()
    {
        $query = ActivityLog::with('user')->latest();

        if (request('action')) {
            $query->where('action', request('action'));
        }

        if (request('user')) {
            $query->whereHas('user', function ($q) {
                $q->where('name', 'like', '%' . request('user') . '%');
            });
        }

        $logs = $query->paginate(50);
        $actions = ActivityLog::select('action')->distinct()->pluck('action');

        return view('admin.activity-log.index', compact('logs', 'actions'));
    }
}
