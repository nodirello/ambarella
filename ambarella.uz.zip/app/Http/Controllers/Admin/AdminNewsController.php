<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\News;
use Illuminate\Http\Request;

class AdminNewsController extends Controller
{
    public function index()
    {
        $news = News::latest()->paginate(20);
        return view('admin.news.index', compact('news'));
    }

    public function create()
    {
        return view('admin.news.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'content' => 'required|string|max:10000',
            'author' => 'required|string|max:100',
            'category' => 'required|string|max:50',
            'image' => 'nullable|string|max:500',
        ]);

        News::create($request->only(['title', 'content', 'author', 'category', 'image']));

        return redirect('/admin/news')->with('success', 'Yangilik qo\'shildi!');
    }

    public function edit(News $news)
    {
        return view('admin.news.edit', compact('news'));
    }

    public function update(Request $request, News $news)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'content' => 'required|string|max:10000',
            'author' => 'nullable|string|max:100',
            'category' => 'nullable|string|max:50',
            'image' => 'nullable|string|max:500',
        ]);

        $news->update($request->only(['title', 'content', 'author', 'category', 'image']));

        return redirect('/admin/news')->with('success', 'Yangilandi!');
    }

    public function destroy(News $news)
    {
        $news->delete();
        return back()->with('success', 'O\'chirildi!');
    }
}
