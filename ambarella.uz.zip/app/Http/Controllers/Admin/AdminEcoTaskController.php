<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\EcoTask;
use Illuminate\Http\Request;

class AdminEcoTaskController extends Controller
{
    public function index()
    {
        $tasks = EcoTask::latest()->paginate(20);
        return view('admin.eco-tasks.index', compact('tasks'));
    }

    public function create()
    {
        return view('admin.eco-tasks.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string|max:500',
            'reward' => 'required|integer|min:1|max:100',
            'category' => 'required|string|max:50',
        ]);

        EcoTask::create([
            ...$request->only(['title', 'description', 'reward', 'category']),
            'is_active' => true,
        ]);

        return redirect('/admin/eco-tasks')->with('success', 'Eko vazifa qo\'shildi!');
    }

    public function edit(EcoTask $task)
    {
        return view('admin.eco-tasks.edit', compact('task'));
    }

    public function update(Request $request, EcoTask $task)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string|max:500',
            'reward' => 'required|integer|min:1|max:100',
            'category' => 'required|string|max:50',
        ]);

        $task->update($request->only(['title', 'description', 'reward', 'category']));

        return redirect('/admin/eco-tasks')->with('success', 'Yangilandi!');
    }

    public function destroy(EcoTask $task)
    {
        $task->delete();
        return back()->with('success', 'O\'chirildi!');
    }

    public function toggle(EcoTask $task)
    {
        $task->update(['is_active' => !$task->is_active]);
        return back()->with('success', $task->is_active ? 'Faollashtirildi!' : 'O\'chirildi!');
    }
}
