<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Job;
use App\Models\Course;
use App\Models\News;
use App\Models\EcoTask;
use App\Models\Mentor;
use App\Models\FarmProduct;
use App\Models\GreenCoinTransaction;
use App\Models\JobApplication;
use App\Models\DailyTask;
use App\Models\Habit;
use App\Models\Mentorship;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;

class AdminStatsController extends Controller
{
    public function index()
    {
        $stats = Cache::remember('admin_full_stats', 180, function () {
            return [
                'users' => User::count(),
                'users_today' => User::whereDate('created_at', today())->count(),
                'users_week' => User::where('created_at', '>=', now()->subWeek())->count(),
                'users_month' => User::where('created_at', '>=', now()->subMonth())->count(),
                'banned_users' => User::where('is_banned', true)->count(),
                'jobs' => Job::count(),
                'jobs_active' => Job::where('is_active', true)->count(),
                'applications' => JobApplication::count(),
                'applications_pending' => JobApplication::where('status', 'pending')->count(),
                'applications_accepted' => JobApplication::where('status', 'accepted')->count(),
                'courses' => Course::count(),
                'mentors' => Mentor::count(),
                'news' => News::count(),
                'eco_tasks' => EcoTask::where('is_active', true)->count(),
                'greencoin_total' => GreenCoinTransaction::where('type', 'earned')->sum('amount'),
                'greencoin_spent' => GreenCoinTransaction::where('type', 'spent')->sum('amount'),
                'greencoin_transactions' => GreenCoinTransaction::count(),
                'farm_products' => FarmProduct::count(),
                'farm_active' => FarmProduct::where('is_active', true)->count(),
                'daily_tasks_today' => DailyTask::whereDate('date', today())->count(),
                'habits_total' => Habit::count(),
                'mentorships_active' => Mentorship::where('status', 'active')->count(),
            ];
        });

        // Oxirgi 30 kun ro'yxatga olish (chart uchun)
        $registrations = User::select(DB::raw('DATE(created_at) as date'), DB::raw('COUNT(*) as count'))
            ->where('created_at', '>=', now()->subDays(30))
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        // Oxirgi 30 kun GreenCoin (chart uchun)
        $greenCoinDaily = GreenCoinTransaction::select(
                DB::raw('DATE(created_at) as date'),
                DB::raw('SUM(amount) as total')
            )
            ->where('type', 'earned')
            ->where('created_at', '>=', now()->subDays(30))
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        // Arizalar haftalik (chart uchun)
        $applicationsWeekly = JobApplication::select(
                DB::raw('DATE(created_at) as date'),
                DB::raw('COUNT(*) as count')
            )
            ->where('created_at', '>=', now()->subDays(30))
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        // Top foydalanuvchilar (GreenCoin bo'yicha)
        $topUsers = User::orderBy('greencoin_balance', 'desc')->take(10)->get();

        // Top regionlar
        $topRegions = User::select('region', DB::raw('COUNT(*) as count'))
            ->whereNotNull('region')
            ->where('region', '!=', '')
            ->groupBy('region')
            ->orderByDesc('count')
            ->take(10)
            ->get();

        return view('admin.stats.index', compact('stats', 'registrations', 'greenCoinDaily', 'applicationsWeekly', 'topUsers', 'topRegions'));
    }
}
