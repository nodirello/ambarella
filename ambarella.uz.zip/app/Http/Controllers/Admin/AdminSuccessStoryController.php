<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SuccessStory;
use Illuminate\Http\Request;

class AdminSuccessStoryController extends Controller
{
    public function index()
    {
        $stories = SuccessStory::latest()->paginate(20);
        return view('admin.stories.index', compact('stories'));
    }

    public function create()
    {
        return view('admin.stories.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'user_name' => 'required|string|max:255',
            'user_role' => 'required|string|max:255',
            'story' => 'required|string|max:5000',
            'avatar_url' => 'nullable|string|max:500',
            'is_featured' => 'nullable|boolean',
        ]);

        SuccessStory::create([
            'user_name' => $request->user_name,
            'user_role' => $request->user_role,
            'story' => $request->story,
            'avatar_url' => $request->avatar_url,
            'is_featured' => $request->boolean('is_featured', false),
        ]);

        return redirect('/admin/stories')->with('success', 'Muvaffaqiyat hikoyasi qo\'shildi!');
    }

    public function destroy(SuccessStory $story)
    {
        $story->delete();
        return back()->with('success', 'Hikoya o\'chirildi!');
    }
}
