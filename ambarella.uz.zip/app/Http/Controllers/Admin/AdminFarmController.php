<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\FarmProduct;

class AdminFarmController extends Controller
{
    public function index()
    {
        $products = FarmProduct::with('user')->latest()->paginate(20);
        return view('admin.farm.index', compact('products'));
    }

    public function toggleActive(FarmProduct $product)
    {
        $product->update(['is_active' => !$product->is_active]);
        return back()->with('success', $product->is_active ? 'Faollashtirildi!' : 'O\'chirildi!');
    }

    public function destroy(FarmProduct $product)
    {
        $product->delete();
        return back()->with('success', 'Mahsulot o\'chirildi!');
    }
}
