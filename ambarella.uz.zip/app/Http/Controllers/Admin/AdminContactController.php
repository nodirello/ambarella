<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ContactMessage;
use Illuminate\Http\Request;

class AdminContactController extends Controller
{
    public function index()
    {
        $messages = ContactMessage::latest()->paginate(20);
        $unread = ContactMessage::where('status', 'new')->count();
        return view('admin.contacts.index', compact('messages', 'unread'));
    }

    public function show(ContactMessage $message)
    {
        if ($message->status === 'new') {
            $message->update(['status' => 'read']);
        }
        return view('admin.contacts.show', compact('message'));
    }

    public function reply(Request $request, ContactMessage $message)
    {
        $request->validate(['admin_reply' => 'required|string|max:2000']);
        $message->update([
            'admin_reply' => $request->admin_reply,
            'status' => 'replied',
        ]);
        return back()->with('success', 'Javob saqlandi!');
    }

    public function destroy(ContactMessage $message)
    {
        $message->delete();
        return redirect('/admin/contacts')->with('success', 'O\'chirildi!');
    }
}
