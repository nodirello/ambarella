<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Banner;
use Illuminate\Http\Request;

class AdminBannerController extends Controller
{
    public function index()
    {
        $banners = Banner::orderBy('sort_order')->get();
        return view('admin.banners.index', compact('banners'));
    }

    public function create()
    {
        return view('admin.banners.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'subtitle' => 'nullable|string|max:255',
            'image_url' => 'required|url|max:500',
            'link_url' => 'nullable|url|max:500',
            'button_text' => 'nullable|string|max:100',
            'sort_order' => 'integer|min:0',
        ]);

        Banner::create($validated);

        return redirect()->route('admin.banners')->with('success', 'Banner qo\'shildi!');
    }

    public function edit(Banner $banner)
    {
        return view('admin.banners.edit', compact('banner'));
    }

    public function update(Request $request, Banner $banner)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'subtitle' => 'nullable|string|max:255',
            'image_url' => 'required|url|max:500',
            'link_url' => 'nullable|url|max:500',
            'button_text' => 'nullable|string|max:100',
            'sort_order' => 'integer|min:0',
        ]);

        $banner->update($validated);

        return redirect()->route('admin.banners')->with('success', 'Banner yangilandi!');
    }

    public function destroy(Banner $banner)
    {
        $banner->delete();
        return redirect()->route('admin.banners')->with('success', 'Banner o\'chirildi!');
    }

    public function toggle(Banner $banner)
    {
        $banner->update(['is_active' => !$banner->is_active]);
        return back()->with('success', 'Banner holati o\'zgartirildi!');
    }
}
