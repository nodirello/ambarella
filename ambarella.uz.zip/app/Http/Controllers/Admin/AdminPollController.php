<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Poll;
use App\Models\PollOption;
use Illuminate\Http\Request;

class AdminPollController extends Controller
{
    public function index()
    {
        $polls = Poll::withCount('votes')->with('options')->latest()->get();
        return view('admin.polls.index', compact('polls'));
    }

    public function create()
    {
        return view('admin.polls.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'question' => 'required|string|max:500',
            'options' => 'required|array|min:2',
            'options.*' => 'required|string|max:255',
            'ends_at' => 'nullable|date|after:today',
        ]);

        $poll = Poll::create([
            'question' => $request->question,
            'is_active' => true,
            'ends_at' => $request->ends_at,
        ]);

        foreach ($request->options as $optionText) {
            if (trim($optionText)) {
                $poll->options()->create(['text' => trim($optionText)]);
            }
        }

        return redirect()->route('admin.polls')->with('success', 'So\'rovnoma yaratildi!');
    }

    public function destroy(Poll $poll)
    {
        $poll->delete();
        return redirect()->route('admin.polls')->with('success', 'So\'rovnoma o\'chirildi!');
    }
}
