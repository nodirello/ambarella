<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdminEventController extends Controller
{
    public function index()
    {
        $events = DB::table('events')->latest()->paginate(20);
        return view('admin.events.index', compact('events'));
    }

    public function create()
    {
        return view('admin.events.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string|max:2000',
            'type' => 'required|in:hackathon,webinar,meetup,conference',
            'date' => 'required|date|after:today',
            'location' => 'required|string|max:255',
            'is_active' => 'boolean',
        ]);

        DB::table('events')->insert([
            'title' => $request->title,
            'description' => $request->description,
            'type' => $request->type,
            'date' => $request->date,
            'location' => $request->location,
            'is_active' => $request->has('is_active'),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return redirect('/admin/events')->with('success', 'Tadbir qo\'shildi!');
    }

    public function edit($id)
    {
        $event = DB::table('events')->find($id);
        abort_unless($event, 404);
        return view('admin.events.edit', compact('event'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string|max:2000',
            'type' => 'required|in:hackathon,webinar,meetup,conference',
            'date' => 'required|date',
            'location' => 'required|string|max:255',
        ]);

        DB::table('events')->where('id', $id)->update([
            'title' => $request->title,
            'description' => $request->description,
            'type' => $request->type,
            'date' => $request->date,
            'location' => $request->location,
            'is_active' => $request->has('is_active'),
            'updated_at' => now(),
        ]);

        return redirect('/admin/events')->with('success', 'Yangilandi!');
    }

    public function destroy($id)
    {
        DB::table('events')->where('id', $id)->delete();
        return back()->with('success', 'O\'chirildi!');
    }
}
