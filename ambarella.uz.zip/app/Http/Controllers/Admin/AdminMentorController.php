<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Mentor;
use Illuminate\Http\Request;

class AdminMentorController extends Controller
{
    public function index()
    {
        $mentors = Mentor::latest()->paginate(20);
        return view('admin.mentors.index', compact('mentors'));
    }

    public function create()
    {
        return view('admin.mentors.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'role' => 'required|string|max:100',
            'experience' => 'required|string|max:100',
            'skills' => 'required|string|max:500',
            'rating' => 'required|numeric|min:1|max:5',
        ]);

        Mentor::create([
            'name' => $request->name,
            'role' => $request->role,
            'experience' => $request->experience,
            'skills' => explode(',', $request->skills),
            'rating' => $request->rating,
            'is_available' => true,
        ]);

        return redirect('/admin/mentors')->with('success', 'Mentor qo\'shildi!');
    }

    public function edit(Mentor $mentor)
    {
        return view('admin.mentors.edit', compact('mentor'));
    }

    public function update(Request $request, Mentor $mentor)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'role' => 'required|string|max:100',
            'experience' => 'required|string|max:100',
            'skills' => 'required|string|max:500',
            'rating' => 'required|numeric|min:1|max:5',
        ]);

        $mentor->update([
            'name' => $request->name,
            'role' => $request->role,
            'experience' => $request->experience,
            'skills' => explode(',', $request->skills),
            'rating' => $request->rating,
        ]);

        return redirect('/admin/mentors')->with('success', 'Yangilandi!');
    }

    public function destroy(Mentor $mentor)
    {
        $mentor->delete();
        return back()->with('success', 'O\'chirildi!');
    }
}
