<?php

namespace App\Http\Controllers\Admin;

use App\Models\User;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Http;

class AdminNotificationService
{
    /**
     * Adminlarga yangi user haqida xabar berish
     */
    public static function notifyNewUser(User $user): void
    {
        $admins = User::where('role', 'admin')->get();

        foreach ($admins as $admin) {
            // Email notification
            try {
                Mail::raw(
                    "Yangi foydalanuvchi ro'yxatdan o'tdi!\n\n" .
                    "Ism: {$user->name}\n" .
                    "Email: {$user->email}\n" .
                    "Telefon: {$user->phone}\n" .
                    "Sana: " . now()->format('d.m.Y H:i') . "\n\n" .
                    "Admin panel: " . url('/admin/users'),
                    function ($message) use ($admin) {
                        $message->to($admin->email)
                            ->subject('AMBARELLA — Yangi foydalanuvchi');
                    }
                );
            } catch (\Exception $e) {
                // Silent fail
            }

            // Telegram notification (agar bot token mavjud bo'lsa)
            self::sendTelegramToAdmin($admin, "👤 Yangi user: {$user->name}\n📧 {$user->email}\n📅 " . now()->format('d.m.Y H:i'));
        }
    }

    /**
     * Adminlarga yangi ariza haqida xabar
     */
    public static function notifyNewApplication(User $user, string $jobTitle): void
    {
        $admins = User::where('role', 'admin')->get();

        foreach ($admins as $admin) {
            self::sendTelegramToAdmin($admin, "📋 Yangi ariza!\n👤 {$user->name}\n💼 {$jobTitle}\n📅 " . now()->format('d.m.Y H:i'));
        }
    }

    /**
     * Adminlarga yangi xabar (contact) haqida xabar
     */
    public static function notifyNewContact(string $name, string $subject): void
    {
        $admins = User::where('role', 'admin')->get();

        foreach ($admins as $admin) {
            self::sendTelegramToAdmin($admin, "✉️ Yangi xabar!\n👤 {$name}\n📝 {$subject}\n📅 " . now()->format('d.m.Y H:i'));
        }
    }

    /**
     * Telegram orqali admin'ga xabar yuborish
     */
    private static function sendTelegramToAdmin(User $admin, string $text): void
    {
        $botToken = config('services.telegram.bot_token');
        if (!$botToken || !$admin->telegram_id) return;

        try {
            Http::post("https://api.telegram.org/bot{$botToken}/sendMessage", [
                'chat_id' => $admin->telegram_id,
                'text' => $text,
                'parse_mode' => 'HTML',
            ]);
        } catch (\Exception $e) {
            // Silent fail
        }
    }
}
