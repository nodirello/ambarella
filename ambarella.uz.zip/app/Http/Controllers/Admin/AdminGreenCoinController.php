<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\GreenCoinTransaction;
use App\Models\User;
use Illuminate\Http\Request;

class AdminGreenCoinController extends Controller
{
    public function index()
    {
        $transactions = GreenCoinTransaction::with('user')
            ->latest()
            ->paginate(30);

        $stats = [
            'total_earned' => GreenCoinTransaction::where('type', 'earned')->sum('amount'),
            'total_spent' => GreenCoinTransaction::where('type', 'spent')->sum('amount'),
            'total_transactions' => GreenCoinTransaction::count(),
        ];

        return view('admin.greencoin.index', compact('transactions', 'stats'));
    }

    public function adjustBalance(Request $request, User $user)
    {
        $request->validate([
            'amount' => 'required|integer|min:1|max:10000',
            'type' => 'required|in:earned,spent',
            'description' => 'required|string|max:255',
        ]);

        GreenCoinTransaction::create([
            'user_id' => $user->id,
            'amount' => $request->amount,
            'type' => $request->type,
            'description' => '[Admin] ' . $request->description,
        ]);

        if ($request->type === 'earned') {
            $user->increment('greencoin_balance', $request->amount);
        } else {
            $user->decrement('greencoin_balance', $request->amount);
        }

        return back()->with('success', "Balans yangilandi! ({$request->type}: {$request->amount} GC)");
    }
}
