<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\TelegramBotTask;
use App\Models\TelegramBotSubmission;
use App\Models\TelegramUser;
use App\Models\GreenCoinTransaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class AdminTelegramController extends Controller
{
    // ── Dashboard ──
    public function index()
    {
        $stats = [
            'total_users'    => TelegramUser::count(),
            'linked_users'   => TelegramUser::whereNotNull('user_id')->count(),
            'pending'        => TelegramBotSubmission::where('status', 'pending')->count(),
            'approved_today' => TelegramBotSubmission::where('status', 'approved')
                ->whereDate('reviewed_at', today())->count(),
            'total_gc_given' => TelegramBotSubmission::where('status', 'approved')->sum('reward_amount'),
            'active_tasks'   => TelegramBotTask::where('is_active', true)->count(),
        ];

        $pendingSubmissions = TelegramBotSubmission::with(['user', 'task'])
            ->where('status', 'pending')
            ->latest()
            ->take(10)
            ->get();

        $recentUsers = TelegramUser::with('user')
            ->latest()
            ->take(10)
            ->get();

        return view('admin.telegram.index', compact('stats', 'pendingSubmissions', 'recentUsers'));
    }

    // ── Submissions list ──
    public function submissions(Request $request)
    {
        $query = TelegramBotSubmission::with(['user', 'task', 'reviewer']);

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('search')) {
            $s = strip_tags($request->search);
            $query->whereHas('user', fn($q) => $q->where('name', 'like', "%{$s}%"));
        }

        $submissions = $query->latest()->paginate(20);

        return view('admin.telegram.submissions', compact('submissions'));
    }

    // ── Tasdiqlash ──
    public function approve(Request $request, TelegramBotSubmission $submission)
    {
        if ($submission->status !== 'pending') {
            return back()->withErrors(['submission' => 'Allaqachon ko\'rib chiqilgan.']);
        }

        $submission->update([
            'status'      => 'approved',
            'reviewed_by' => auth()->id(),
            'reviewed_at' => now(),
            'notes'       => strip_tags($request->notes ?? ''),
        ]);

        $user = $submission->user;
        if ($user) {
            $user->increment('greencoin_balance', $submission->reward_amount);

            GreenCoinTransaction::create([
                'user_id'     => $user->id,
                'amount'      => $submission->reward_amount,
                'type'        => 'earned',
                'description' => 'Telegram submission tasdiqlandi: #' . $submission->id,
            ]);

            // Foydalanuvchiga Telegram xabar
            $this->notifyUser($user->telegram_id,
                "✅ *Topshirig'ingiz tasdiqlandi!*\n\n" .
                "*+{$submission->reward_amount} GC* hisobingizga o'tkazildi 🎉"
            );
        }

        \App\Models\ActivityLog::create([
            'user_id'     => auth()->id(),
            'action'      => 'telegram_submission_approve',
            'description' => "Submission #{$submission->id} tasdiqlandi",
            'ip_address'  => $request->ip(),
        ]);

        return back()->with('success', "Submission #{$submission->id} tasdiqlandi! +{$submission->reward_amount} GC berildi.");
    }

    // ── Rad etish ──
    public function reject(Request $request, TelegramBotSubmission $submission)
    {
        if ($submission->status !== 'pending') {
            return back()->withErrors(['submission' => 'Allaqachon ko\'rib chiqilgan.']);
        }

        $submission->update([
            'status'      => 'rejected',
            'reviewed_by' => auth()->id(),
            'reviewed_at' => now(),
            'notes'       => strip_tags($request->notes ?? ''),
        ]);

        $user = $submission->user;
        if ($user?->telegram_id) {
            $this->notifyUser($user->telegram_id,
                "❌ *Topshirig'ingiz rad etildi.*\n\n" .
                ($request->notes ? "Sabab: " . $request->notes . "\n\n" : '') .
                "Qaytadan urinib ko'ring: /tasks"
            );
        }

        \App\Models\ActivityLog::create([
            'user_id'     => auth()->id(),
            'action'      => 'telegram_submission_reject',
            'description' => "Submission #{$submission->id} rad etildi",
            'ip_address'  => $request->ip(),
        ]);

        return back()->with('success', "Submission #{$submission->id} rad etildi.");
    }

    // ── Vazifalar (Tasks) ──
    public function tasks()
    {
        $tasks = TelegramBotTask::with('creator')->latest()->get();
        return view('admin.telegram.tasks', compact('tasks'));
    }

    public function createTask()
    {
        return view('admin.telegram.task-form');
    }

    public function storeTask(Request $request)
    {
        $request->validate([
            'title'             => 'required|string|max:255',
            'description'       => 'nullable|string|max:1000',
            'task_type'         => 'required|in:action,referral,subscription,custom',
            'reward'            => 'required|integer|min:1|max:1000',
            'requires_approval' => 'boolean',
            'start_at'          => 'nullable|date',
            'end_at'            => 'nullable|date|after:start_at',
        ]);

        TelegramBotTask::create([
            'title'             => strip_tags($request->title),
            'description'       => strip_tags($request->description),
            'task_type'         => $request->task_type,
            'reward'            => $request->reward,
            'requires_approval' => $request->boolean('requires_approval', true),
            'is_active'         => true,
            'start_at'          => $request->start_at,
            'end_at'            => $request->end_at,
            'created_by'        => auth()->id(),
        ]);

        return redirect('/admin/telegram/tasks')->with('success', 'Vazifa yaratildi!');
    }

    public function toggleTask(TelegramBotTask $task)
    {
        $task->update(['is_active' => !$task->is_active]);
        return back()->with('success', $task->is_active ? 'Faollashtirildi' : 'O\'chirildi');
    }

    public function destroyTask(TelegramBotTask $task)
    {
        $task->delete();
        return back()->with('success', 'Vazifa o\'chirildi.');
    }

    // ── Broadcast xabar ──
    public function broadcast(Request $request)
    {
        $request->validate([
            'message'   => 'required|string|max:4096',
            'target'    => 'required|in:all,linked,unlinked',
        ]);

        $query = TelegramUser::query();

        if ($request->target === 'linked') {
            $query->whereNotNull('user_id');
        } elseif ($request->target === 'unlinked') {
            $query->whereNull('user_id');
        }

        $users  = $query->whereNotNull('chat_id')->get();
        $sent   = 0;
        $failed = 0;

        foreach ($users as $tgUser) {
            try {
                $this->notifyUser($tgUser->chat_id, $request->message);
                $sent++;
                usleep(50000); // 50ms — rate limit
            } catch (\Exception $e) {
                $failed++;
            }
        }

        \App\Models\ActivityLog::create([
            'user_id'     => auth()->id(),
            'action'      => 'telegram_broadcast',
            'description' => "Broadcast: {$sent} ta yuborildi, {$failed} ta xatolik",
            'ip_address'  => $request->ip(),
        ]);

        return back()->with('success', "Xabar {$sent} ta foydalanuvchiga yuborildi. Xatolik: {$failed}");
    }

    // ── Webhook sozlash ──
    public function setWebhook()
    {
        $token      = config('services.telegram.bot_token');
        $secret     = config('services.telegram.webhook_secret');
        $webhookUrl = url('/webhook/telegram');

        if (!$token) {
            return back()->withErrors(['telegram' => 'Bot token sozlanmagan.']);
        }

        $payload = [
            'url'             => $webhookUrl,
            'allowed_updates' => ['message', 'callback_query'],
            'drop_pending_updates' => true,
        ];

        if ($secret) $payload['secret_token'] = $secret;

        $response = Http::post("https://api.telegram.org/bot{$token}/setWebhook", $payload);

        if ($response->json('ok')) {
            return back()->with('success', "Webhook o'rnatildi: {$webhookUrl}");
        }

        return back()->withErrors(['telegram' => 'Xatolik: ' . $response->json('description')]);
    }

    private function notifyUser(?string $chatId, string $text): void
    {
        if (!$chatId) return;
        $token = config('services.telegram.bot_token');
        if (!$token) return;

        Http::post("https://api.telegram.org/bot{$token}/sendMessage", [
            'chat_id'    => $chatId,
            'text'       => $text,
            'parse_mode' => 'Markdown',
        ]);
    }
}
