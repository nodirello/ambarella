<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Course;
use Illuminate\Http\Request;

class AdminCourseController extends Controller
{
    public function index()
    {
        $courses = Course::latest()->paginate(20);
        return view('admin.courses.index', compact('courses'));
    }

    public function create()
    {
        return view('admin.courses.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'instructor' => 'required|string|max:100',
            'duration' => 'required|string|max:50',
            'price' => 'required|integer|min:0',
            'level' => 'required|in:Boshlang\'ich,O\'rta,Yuqori',
            'category' => 'required|string|max:50',
            'description' => 'nullable|string|max:2000',
            'image' => 'nullable|string|max:500',
        ]);

        Course::create($request->only(['title', 'instructor', 'duration', 'price', 'level', 'category', 'description', 'image']));

        return redirect('/admin/courses')->with('success', 'Kurs qo\'shildi!');
    }

    public function edit(Course $course)
    {
        return view('admin.courses.edit', compact('course'));
    }

    public function update(Request $request, Course $course)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'instructor' => 'required|string|max:100',
            'duration' => 'required|string|max:50',
            'price' => 'required|integer|min:0',
            'level' => 'required|in:Boshlang\'ich,O\'rta,Yuqori',
            'category' => 'required|string|max:50',
            'description' => 'nullable|string|max:2000',
            'image' => 'nullable|string|max:500',
        ]);

        $course->update($request->only(['title', 'instructor', 'duration', 'price', 'level', 'category', 'description', 'image']));

        return redirect('/admin/courses')->with('success', 'Yangilandi!');
    }

    public function destroy(Course $course)
    {
        $course->delete();
        return back()->with('success', 'O\'chirildi!');
    }
}
