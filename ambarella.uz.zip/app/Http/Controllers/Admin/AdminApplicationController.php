<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\JobApplication;
use Illuminate\Http\Request;

class AdminApplicationController extends Controller
{
    public function index()
    {
        $applications = JobApplication::with(['user', 'job'])
            ->latest()
            ->paginate(20);

        return view('admin.applications.index', compact('applications'));
    }

    public function updateStatus(Request $request, JobApplication $application)
    {
        $request->validate(['status' => 'required|in:pending,accepted,rejected']);
        $application->update(['status' => $request->status]);
        return back()->with('success', 'Ariza holati yangilandi!');
    }
}
