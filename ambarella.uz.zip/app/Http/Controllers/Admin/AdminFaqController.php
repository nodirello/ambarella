<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Faq;
use Illuminate\Http\Request;

class AdminFaqController extends Controller
{
    public function index()
    {
        $faqs = Faq::orderBy('sort_order')->paginate(20);
        return view('admin.faq.index', compact('faqs'));
    }

    public function create()
    {
        return view('admin.faq.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'question_uz' => 'required|string|max:500',
            'answer_uz' => 'required|string|max:5000',
            'question_ru' => 'nullable|string|max:500',
            'answer_ru' => 'nullable|string|max:5000',
            'question_en' => 'nullable|string|max:500',
            'answer_en' => 'nullable|string|max:5000',
            'sort_order' => 'nullable|integer|min:0',
            'is_active' => 'nullable|boolean',
        ]);

        Faq::create([
            'question_uz' => $request->question_uz,
            'answer_uz' => $request->answer_uz,
            'question_ru' => $request->question_ru,
            'answer_ru' => $request->answer_ru,
            'question_en' => $request->question_en,
            'answer_en' => $request->answer_en,
            'sort_order' => $request->sort_order ?? 0,
            'is_active' => $request->boolean('is_active', true),
        ]);

        return redirect('/admin/faq')->with('success', 'FAQ qo\'shildi!');
    }

    public function edit(Faq $faq)
    {
        return view('admin.faq.edit', compact('faq'));
    }

    public function update(Request $request, Faq $faq)
    {
        $request->validate([
            'question_uz' => 'required|string|max:500',
            'answer_uz' => 'required|string|max:5000',
            'question_ru' => 'nullable|string|max:500',
            'answer_ru' => 'nullable|string|max:5000',
            'question_en' => 'nullable|string|max:500',
            'answer_en' => 'nullable|string|max:5000',
            'sort_order' => 'nullable|integer|min:0',
            'is_active' => 'nullable|boolean',
        ]);

        $faq->update([
            'question_uz' => $request->question_uz,
            'answer_uz' => $request->answer_uz,
            'question_ru' => $request->question_ru,
            'answer_ru' => $request->answer_ru,
            'question_en' => $request->question_en,
            'answer_en' => $request->answer_en,
            'sort_order' => $request->sort_order ?? 0,
            'is_active' => $request->boolean('is_active', true),
        ]);

        return redirect('/admin/faq')->with('success', 'FAQ yangilandi!');
    }

    public function destroy(Faq $faq)
    {
        $faq->delete();
        return back()->with('success', 'FAQ o\'chirildi!');
    }
}
