<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Traits\LogsActivity;
use Illuminate\Http\Request;

class AdminUserController extends Controller
{
    use LogsActivity;
    public function index(Request $request)
    {
        $query = User::query();

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('email', 'like', "%{$s}%")
                  ->orWhere('phone', 'like', "%{$s}%");
            });
        }

        $users = $query->latest()->paginate(20);
        return view('admin.users.index', compact('users'));
    }

    public function toggleBan(User $user)
    {
        if ($user->id === auth()->id()) {
            return back()->withErrors(['user' => 'O\'zingizni bloklash mumkin emas.']);
        }

        $user->is_banned = !$user->is_banned;
        $user->save();

        $this->logActivity('user_ban', ($user->is_banned ? 'Bloklandi' : 'Blok olib tashlandi') . ': ' . $user->email);

        return back()->with('success', $user->is_banned ? 'Foydalanuvchi bloklandi.' : 'Blok olib tashlandi.');
    }

    public function makeAdmin(User $user)
    {
        $user->role = 'admin';
        $user->save();

        $this->logActivity('user_make_admin', 'Admin qilindi: ' . $user->email);

        return back()->with('success', $user->name . ' admin qilindi.');
    }

    public function removeAdmin(User $user)
    {
        if ($user->id === auth()->id()) {
            return back()->withErrors(['user' => 'O\'zingizdan admin huquqini olib tashlash mumkin emas.']);
        }

        $user->role = 'user';
        $user->save();

        $this->logActivity('user_remove_admin', 'Admin huquqi olib tashlandi: ' . $user->email);

        return back()->with('success', $user->name . ' admin huquqi olib tashlandi.');
    }
}
