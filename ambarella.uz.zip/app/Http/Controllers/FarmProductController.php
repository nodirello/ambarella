<?php

namespace App\Http\Controllers;

use App\Models\FarmProduct;
use Illuminate\Http\Request;

class FarmProductController extends Controller
{
    public function index(Request $request)
    {
        $query = FarmProduct::where('is_active', true);

        if ($request->filled('category')) {
            $query->where('category', $request->category);
        }
        if ($request->filled('region')) {
            $query->where('region', $request->region);
        }
        if ($request->filled('search')) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }

        $products = $query->with('user')->latest()->paginate(12);

        $categories = FarmProduct::where('is_active', true)->distinct()->pluck('category');
        $regions = FarmProduct::where('is_active', true)->distinct()->pluck('region');

        return view('farm.index', compact('products', 'categories', 'regions'));
    }

    public function create()
    {
        return view('farm.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'category' => 'required|string|max:100',
            'price' => 'required|integer|min:100',
            'unit' => 'required|string|max:20',
            'region' => 'required|string|max:100',
            'description' => 'nullable|string|max:1000',
        ]);

        FarmProduct::create([
            'user_id' => auth()->id(),
            ...$request->only(['name', 'category', 'price', 'unit', 'region', 'description']),
        ]);

        return redirect('/farm')->with('success', 'Mahsulot qo\'shildi!');
    }

    public function show(FarmProduct $product)
    {
        $product->load('user');
        $similar = FarmProduct::where('category', $product->category)
            ->where('id', '!=', $product->id)
            ->where('is_active', true)
            ->take(4)
            ->get();

        return view('farm.show', compact('product', 'similar'));
    }

    public function myProducts()
    {
        $products = FarmProduct::where('user_id', auth()->id())->latest()->get();
        return view('farm.my-products', compact('products'));
    }

    public function edit(FarmProduct $product)
    {
        if ($product->user_id !== auth()->id()) {
            abort(403);
        }
        return view('farm.edit', compact('product'));
    }

    public function update(Request $request, FarmProduct $product)
    {
        if ($product->user_id !== auth()->id()) {
            abort(403);
        }

        $request->validate([
            'name' => 'required|string|max:255',
            'category' => 'required|string|max:100',
            'price' => 'required|integer|min:100',
            'unit' => 'required|string|max:20',
            'region' => 'required|string|max:100',
            'description' => 'nullable|string|max:1000',
        ]);

        $product->update($request->only(['name', 'category', 'price', 'unit', 'region', 'description']));

        return redirect('/farm/my-products')->with('success', 'Mahsulot yangilandi!');
    }

    public function destroy(FarmProduct $product)
    {
        if ($product->user_id !== auth()->id()) {
            abort(403);
        }

        $product->delete();
        return back()->with('success', 'Mahsulot o\'chirildi!');
    }

    public function toggleActive(FarmProduct $product)
    {
        if ($product->user_id !== auth()->id()) {
            abort(403);
        }

        $product->update(['is_active' => !$product->is_active]);
        return back()->with('success', $product->is_active ? 'Faollashtirildi!' : 'O\'chirildi!');
    }
}
