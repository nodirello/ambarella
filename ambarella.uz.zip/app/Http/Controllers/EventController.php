<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;

class EventController extends Controller
{
    public function index()
    {
        $events = DB::table('events')
            ->where('is_active', true)
            ->orderBy('date', 'asc')
            ->paginate(12);

        return view('events.index', compact('events'));
    }
}
