<?php

namespace App\Http\Controllers;

use App\Models\GreenCoinTransaction;
use App\Models\TelegramBotSubmission;
use App\Models\TelegramBotTask;
use App\Models\TelegramReferral;
use App\Models\TelegramUser;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * AMBARELLA Telegram Bot — yagona controller
 *
 * Buyruqlar: /start /help /tasks /balance /refer /status /submit
 * Xususiyatlar: inline keyboard, rasm topshirish, kanal a'zolik tekshiruvi,
 *               referal, admin approve/reject, GreenCoin mukofot
 */
class TelegramBotController extends Controller
{
    // ═══════════════════════════════════════
    // WEBHOOK ENTRY POINT
    // ═══════════════════════════════════════
    public function webhook(Request $request)
    {
        $secret = config('services.telegram.webhook_secret');
        if ($secret && $request->header('X-Telegram-Bot-Api-Secret-Token') !== $secret) {
            abort(403);
        }

        $update = $request->json()->all();
        if (empty($update)) {
            $update = $request->all();
        }

        try {
            if (isset($update['callback_query'])) {
                $this->handleCallbackQuery($update['callback_query']);
            } elseif (isset($update['message'])) {
                $this->handleMessage($update['message']);
            } elseif (isset($update['my_chat_member'])) {
                // Bot kanalga qo'shildi/chiqarildi — ignore
            }
        } catch (\Throwable $e) {
            \Log::error('TelegramBot error: ' . $e->getMessage(), ['update' => $update]);
        }

        return response('ok');
    }

    // ═══════════════════════════════════════
    // MESSAGE HANDLER
    // ═══════════════════════════════════════
    private function handleMessage(array $message): void
    {
        $chatId = (string)$message['chat']['id'];
        $from   = $message['from'] ?? [];
        $text   = trim($message['text'] ?? '');

        $telegramUser = TelegramUser::firstOrCreate(
            ['chat_id' => $chatId],
            ['username' => $from['username'] ?? null, 'first_name' => $from['first_name'] ?? null]
        );

        // 1. Buyruqlar (/ bilan boshlangan)
        if (str_starts_with($text, '/')) {
            $this->handleCommand($chatId, $telegramUser, $text);
            return;
        }

        // 2. Kontakt (telefon tugmasi bosilganda)
        if (isset($message['contact']['phone_number'])) {
            $this->handleContact($chatId, $telegramUser, $message['contact']['phone_number']);
            return;
        }

        // 3. Rasm (eco proof)
        if (isset($message['photo'])) {
            $this->handlePhoto($chatId, $telegramUser, $message['photo'], trim($message['caption'] ?? ''));
            return;
        }

        // 4. Conversation state — foydalanuvchi matn kiritishi kerak bo'lsa
        $state = cache()->get("tg_state_{$chatId}");
        if ($state) {
            $this->handleConversationInput($chatId, $telegramUser, $text, $state);
            return;
        }

        // 5. Telefon raqam ko'rinishida matn
        if ($this->looksLikePhone($text)) {
            $this->handleContact($chatId, $telegramUser, $text);
            return;
        }

        // 6. Boshqa — bosh menyuni ko'rsat
        $this->cmdStart($chatId, $telegramUser);
    }

    // ═══════════════════════════════════════
    // CONVERSATION STATE HANDLER
    // Foydalanuvchi oldin tugma bosgan va matn kiritishi kutilmoqda
    // ═══════════════════════════════════════
    private function handleConversationInput(string $chatId, TelegramUser $tu, string $text, array $state): void
    {
        // Stateni o'chirish
        cache()->forget("tg_state_{$chatId}");

        $user = $tu->user;
        if (!$user) { $this->cmdStart($chatId, $tu); return; }

        match($state['action']) {
            // Eco matn topshirish
            'eco_submit' => $this->submitEco($chatId, $user, $text),

            // Muayyan vazifa uchun matn topshirish
            'task_submit' => $this->submitTask($chatId, $user, $state['task_id'], $text),

            // Boshqa holat
            default => $this->cmdStart($chatId, $tu),
        };
    }

    // ═══════════════════════════════════════
    // COMMAND ROUTER
    // ═══════════════════════════════════════
    private function handleCommand(string $chatId, TelegramUser $tu, string $text): void
    {
        match(true) {
            $text === '/start'                => $this->cmdStart($chatId, $tu),
            $text === '/help'                 => $this->cmdHelp($chatId),
            $text === '/balance'              => $this->cmdBalance($chatId, $tu),
            $text === '/tasks'                => $this->cmdTasks($chatId, $tu),
            $text === '/refer'                => $this->cmdRefer($chatId, $tu),
            $text === '/status'               => $this->cmdStatus($chatId, $tu),
            $text === '/webapp'               => $this->cmdWebApp($chatId, $tu),
            $text === '/jobs'                 => $this->cmdJobs($chatId, $tu),
            str_starts_with($text, '/submit') => $this->cmdSubmit($chatId, $tu, $text),
            default                           => $this->msg($chatId, "Noma'lum buyruq. /help yozing."),
        };
    }

    // ═══════════════════════════════════════
    // CALLBACK QUERY
    // ═══════════════════════════════════════
    private function handleCallbackQuery(array $cq): void
    {
        $chatId    = (string)$cq['message']['chat']['id'];
        $data      = $cq['data'] ?? '';
        $msgId     = $cq['message']['message_id'] ?? null;
        $token     = config('services.telegram.bot_token');

        if ($token) {
            Http::post("https://api.telegram.org/bot{$token}/answerCallbackQuery", [
                'callback_query_id' => $cq['id'],
            ]);
        }

        $tu = TelegramUser::where('chat_id', $chatId)->first();

        match(true) {
            $data === 'show_balance'              => $this->cmdBalance($chatId, $tu),
            $data === 'show_tasks'                => $this->cmdTasks($chatId, $tu),
            $data === 'show_refer'                => $this->cmdRefer($chatId, $tu),
            $data === 'show_status'               => $this->cmdStatus($chatId, $tu),
            $data === 'show_webapp'               => $this->cmdWebApp($chatId, $tu),
            $data === 'show_jobs'                 => $this->cmdJobs($chatId, $tu),
            $data === 'show_main'                 => $this->cmdMainMenu($chatId, $tu),
            // Vazifa detail
            str_starts_with($data, 'task_')       => $this->showTaskDetail($chatId, (int)substr($data, 5)),
            // Vazifani tugma orqali topshirish (matn so'rash)
            str_starts_with($data, 'do_task_')    => $this->askTaskInput($chatId, $tu, (int)substr($data, 8)),
            // Eco tugma orqali (matn so'rash)
            $data === 'do_eco'                    => $this->askEcoInput($chatId, $tu),
            // Rasm yuborish yo'riqnomasi
            str_starts_with($data, 'photo_task_') => $this->askPhotoInput($chatId, (int)substr($data, 11)),
            // Admin
            str_starts_with($data, 'approve_')    => $this->adminApprove($chatId, $msgId, (int)substr($data, 8)),
            str_starts_with($data, 'reject_')     => $this->adminReject($chatId, $msgId, (int)substr($data, 7)),
            default                               => null,
        };
    }

    // ═══════════════════════════════════════
    // /start — YAXSHILANGAN
    // ═══════════════════════════════════════
    private function cmdStart(string $chatId, TelegramUser $tu): void
    {
        $user = $tu->user;

        if ($user) {
            // Bugungi statistika
            $todayGC = \App\Models\GreenCoinTransaction::where('user_id', $user->id)
                ->whereDate('created_at', today())->where('type', 'earned')->sum('amount');

            $level = match(true) {
                $user->greencoin_balance >= 5000 => '👑',
                $user->greencoin_balance >= 1000 => '🥇',
                $user->greencoin_balance >= 500  => '🥈',
                $user->greencoin_balance >= 100  => '🥉',
                default                          => '🌱',
            };

            $todayLine = $todayGC > 0
                ? "\n✅ Bugun: *+{$todayGC} GC* ishlandi"
                : "\n💡 Bugun hali GC ishlmadingiz";

            $this->msgInline($chatId,
                "👋 Xush kelibsiz, *{$user->name}*! {$level}\n\n"
                . "💎 Balans: *{$user->greencoin_balance} GC*"
                . "{$todayLine}\n\n"
                . "Nima qilamiz?",
                [
                    [
                        ['text' => '🌿 Eco vazifalar', 'callback_data' => 'show_tasks'],
                        ['text' => '💰 Balans', 'callback_data' => 'show_balance'],
                    ],
                    [
                        ['text' => '💼 Ish e\'lonlari', 'callback_data' => 'show_jobs'],
                        ['text' => '🔗 Referal', 'callback_data' => 'show_refer'],
                    ],
                    [
                        ['text' => '🌐 Platforma', 'web_app' => ['url' => url('/tg-app')]],
                    ],
                ]
            );
        } else {
            // Yangi foydalanuvchi — onboarding funnel
            $this->msgContact($chatId,
                "👋 *Assalomu alaykum!*\n\n"
                . "Men *AMBARELLA* — O'zbekiston yoshlari platformasi botiman 🇺🇿\n\n"
                . "📌 Nima qilish mumkin:\n"
                . "✅ Ish e'lonlarini ko'rish\n"
                . "🌿 Eco vazifalar → GreenCoin ishlash\n"
                . "🎓 Kurslar va mentorlik\n"
                . "🚀 Startup va musobaqalar\n\n"
                . "━━━━━━━━━━━━━━━━━━━━\n"
                . "Boshlash uchun *telefon raqamingizni* yuboring 👇"
            );
        }
    }

    // ═══════════════════════════════════════
    // /help — YANGILANGAN
    // ═══════════════════════════════════════
    private function cmdHelp(string $chatId): void
    {
        $this->msgInline($chatId,
            "📖 *Bot imkoniyatlari:*\n\n"
            . "🌿 */tasks* — Eco vazifalar (+GC)\n"
            . "💰 */balance* — GreenCoin balansi\n"
            . "🔗 */refer* — Referal dasturi\n"
            . "📊 */status* — Topshiriqlar holati\n"
            . "💼 */jobs* — So'nggi ish e'lonlari\n"
            . "🌐 */webapp* — Platforma (Telegram ichida)\n\n"
            . "*Topshirish:*\n"
            . "📸 Rasm yuboring — eco proof\n"
            . "`/submit eco daraxt ekdim`\n"
            . "`/submit task <id> <matn>`\n\n"
            . "🌐 ambarella.uz",
            [
                [
                    ['text' => '🌿 Vazifalar', 'callback_data' => 'show_tasks'],
                    ['text' => '💼 Ishlar', 'callback_data' => 'show_jobs'],
                ],
                [
                    ['text' => '🌐 Platforma', 'web_app' => ['url' => url('/tg-app')]],
                ],
            ]
        );
    }

    // ═══════════════════════════════════════
    // /webapp — Telegram Web App
    // ═══════════════════════════════════════
    private function cmdWebApp(string $chatId, TelegramUser $tu): void
    {
        $user = $tu->user;

        if (!$user) {
            $this->msgInline($chatId,
                "⚠️ Avval platformaga ulaning:",
                [[['text' => '🌐 Ro\'yxatdan o\'tish', 'url' => url('/register')]]]
            );
            return;
        }

        $this->msgInline($chatId,
            "🌐 *AMBARELLA Platformasi*\n\n"
            . "Dashboard, kurslar, ish e'lonlari, eco vazifalar va ko'plab imkoniyatlar Telegram ichida:",
            [
                [['text' => '🚀 Platformani ochish', 'web_app' => ['url' => url('/tg-app')]]],
                [['text' => '🌍 Brauzerda ochish', 'url' => url('/dashboard')]],
            ]
        );
    }

    // ═══════════════════════════════════════
    // /jobs — So'nggi ish e'lonlari
    // ═══════════════════════════════════════
    private function cmdJobs(string $chatId, TelegramUser $tu): void
    {
        $jobs = \App\Models\Job::where('is_active', true)
            ->latest()
            ->take(5)
            ->get();

        if ($jobs->isEmpty()) {
            $this->msg($chatId, "Hozircha faol ish e'lonlari yo'q.");
            return;
        }

        $text = "💼 *So'nggi ish e'lonlari:*\n\n";
        $kbd  = [];

        foreach ($jobs as $job) {
            $salary = $job->salary_min
                ? number_format($job->salary_min / 1000000, 0) . '–' . number_format($job->salary_max / 1000000, 0) . 'M'
                : 'Kelishiladi';

            $text .= "🏢 *{$job->title}*\n";
            $text .= "   {$job->company} · {$job->location} · {$salary} so'm\n\n";

            $kbd[] = [['text' => "💼 {$job->title}", 'url' => url('/jobs/' . $job->id)]];
        }

        $kbd[] = [['text' => '🔍 Barcha ishlar', 'url' => url('/jobs')]];
        $kbd[] = [['text' => '⬅️ Bosh menyu', 'callback_data' => 'show_main']];

        $this->msgInline($chatId, $text, $kbd);
    }

    // ═══════════════════════════════════════
    // Bosh menyu (callback uchun)
    // ═══════════════════════════════════════
    private function cmdMainMenu(string $chatId, TelegramUser $tu): void
    {
        $user = $tu->user;
        if ($user) {
            $todayGC = \App\Models\GreenCoinTransaction::where('user_id', $user->id)
                ->whereDate('created_at', today())->where('type', 'earned')->sum('amount');

            $level = match(true) {
                $user->greencoin_balance >= 5000 => '👑',
                $user->greencoin_balance >= 1000 => '🥇',
                $user->greencoin_balance >= 500  => '🥈',
                $user->greencoin_balance >= 100  => '🥉',
                default                          => '🌱',
            };

            $todayLine = $todayGC > 0
                ? "\n✅ Bugun: *+{$todayGC} GC* ishlandi"
                : "\n💡 Bugun hali GC ishlmadingiz";

            $this->msgInline($chatId,
                "👋 {$level} *{$user->name}*\n\n"
                . "💎 Balans: *{$user->greencoin_balance} GC*"
                . "{$todayLine}\n\nNima qilamiz?",
                [
                    [
                        ['text' => '🌿 Eco vazifalar', 'callback_data' => 'show_tasks'],
                        ['text' => '💼 Ish e\'lonlari', 'callback_data' => 'show_jobs'],
                    ],
                    [
                        ['text' => '💰 Balans', 'callback_data' => 'show_balance'],
                        ['text' => '🔗 Referal', 'callback_data' => 'show_refer'],
                    ],
                    [
                        ['text' => '🌐 Platforma', 'web_app' => ['url' => url('/tg-app')]],
                    ],
                ]
            );
        } else {
            $this->cmdStart($chatId, $tu);
        }
    }

    // ═══════════════════════════════════════
    // CONTACT / PHONE
    // ═══════════════════════════════════════
    private function handleContact(string $chatId, TelegramUser $tu, string $phoneRaw): void
    {
        $phone = $this->normalizePhone($phoneRaw);
        $tu->update(['phone' => $phone]);

        $user = $this->findUserByPhone($phone);
        if (!$user) {
            $this->msgInline($chatId,
                "⚠️ Bu raqam platformada topilmadi.\n\nAvval *ambarella.uz* da ro'yxatdan o'ting:",
                [[['text' => '🌐 Ro\'yxatdan o\'tish', 'url' => url('/register')]]]
            );
            return;
        }

        $user->update(['telegram_id' => $chatId, 'telegram_username' => $tu->username]);
        $tu->update(['user_id' => $user->id]);

        if (!$user->profile_completed) {
            $this->msgInline($chatId,
                "✅ Hisobingiz bog'landi!\n\n⚠️ Profilingizni to'ldiring:",
                [[['text' => '📝 Profilni to\'ldirish', 'url' => url('/onboarding')]]]
            );
            return;
        }

        if ($user->referred_by && empty($user->referral_rewarded)) {
            $user->rewardReferralIfEligible();
        }

        $this->msgInline($chatId,
            "✅ *Muvaffaqiyatli bog'landi!*\n\n👤 {$user->name}\n💰 {$user->greencoin_balance} GC",
            [[
                ['text' => '📋 Vazifalar', 'callback_data' => 'show_tasks'],
                ['text' => '💰 Balans', 'callback_data' => 'show_balance'],
            ],[
                ['text' => '🌐 Sayt', 'url' => url('/dashboard')],
                ['text' => '🔗 Referal', 'callback_data' => 'show_refer'],
            ]]
        );
    }

    // ═══════════════════════════════════════
    // KANAL A'ZOLIK TEKSHIRUVI
    // ═══════════════════════════════════════
    private function isChannelMember(string $chatId): bool
    {
        $channelId = config('services.telegram.required_channel');
        if (!$channelId) return true; // Kanal sozlanmagan — tekshirmaslik

        $token = config('services.telegram.bot_token');
        if (!$token) return true;

        try {
            $res = Http::get("https://api.telegram.org/bot{$token}/getChatMember", [
                'chat_id' => $channelId,
                'user_id' => $chatId,
            ]);

            $status = $res->json('result.status', 'left');
            return in_array($status, ['member', 'administrator', 'creator']);
        } catch (\Throwable $e) {
            return true; // Xatolikda ruxsat berish
        }
    }

    private function requireChannel(string $chatId): bool
    {
        if ($this->isChannelMember($chatId)) return true;

        $channelId  = config('services.telegram.required_channel');
        $channelUrl = config('services.telegram.channel_url', 'https://t.me/' . ltrim($channelId, '@'));

        $this->msgInline($chatId,
            "⚠️ *Kanalga a'zo bo'lish shart!*\n\nVazifalardan foydalanish va GreenCoin ishlash uchun kanalga obuna bo'ling, so'ng qayta yuboring.",
            [[
                ['text' => '📢 Kanalga o\'tish', 'url' => $channelUrl],
            ],[
                ['text' => '✅ A\'bo bo\'ldim', 'callback_data' => 'show_tasks'],
            ]]
        );
        return false;
    }

    // ═══════════════════════════════════════
    // /balance
    // ═══════════════════════════════════════
    private function cmdBalance(string $chatId, ?TelegramUser $tu): void
    {
        $user = $tu?->user;
        if (!$user) { $this->msg($chatId, "⚠️ Avval telefon raqamingizni yuboring."); return; }

        $level = match(true) {
            $user->greencoin_balance >= 5000 => '👑 Platinum',
            $user->greencoin_balance >= 1000 => '🥇 Gold',
            $user->greencoin_balance >= 500  => '🥈 Silver',
            $user->greencoin_balance >= 100  => '🥉 Bronze',
            default                          => '🌱 Starter',
        };

        $this->msgInline($chatId,
            "💰 *GreenCoin Hamyon*\n\n👤 {$user->name}\n💎 Balans: *{$user->greencoin_balance} GC*\n" .
            "🏆 Daraja: *{$level}*\n🔗 Referallar: {$user->referral_count}\n🔥 Streak: {$user->login_streak} kun",
            [[['text' => '📋 Vazifalar', 'callback_data' => 'show_tasks'], ['text' => '🔗 Referal', 'callback_data' => 'show_refer']]]
        );
    }

    // ═══════════════════════════════════════
    // /tasks — TUGMA-ASOSLI
    // ═══════════════════════════════════════
    private function cmdTasks(string $chatId, ?TelegramUser $tu): void
    {
        $user = $tu?->user;
        if (!$user) { $this->msg($chatId, "⚠️ Avval telefon raqamingizni yuboring."); return; }
        if (!$user->profile_completed) {
            $this->msgInline($chatId, "⚠️ Profilingizni to'ldiring:", [[['text' => '📝 To\'ldirish', 'url' => url('/onboarding')]]]);
            return;
        }
        if (!$this->requireChannel($chatId)) return;

        $tasks = TelegramBotTask::where('is_active', true)
            ->where(fn($q) => $q->whereNull('start_at')->orWhere('start_at', '<=', now()))
            ->where(fn($q) => $q->whereNull('end_at')->orWhere('end_at', '>=', now()))
            ->get();

        if ($tasks->isEmpty()) {
            $this->msgInline($chatId,
                "📋 Hozircha vazifalar yo'q.\n\nTez orada yangi vazifalar qo'shiladi!",
                [[['text' => '⬅️ Bosh menyu', 'callback_data' => 'show_main']]]
            );
            return;
        }

        // Bugungi eco harakatni ham qo'shamiz
        $text  = "📋 *Bugungi vazifalar:*\n\n";
        $text .= "Har bir vazifani bajarib GreenCoin ishlang 🌿\n\n";
        $kbd   = [];

        foreach ($tasks as $t) {
            $icon  = $t->requires_approval ? '⏳' : '⚡';
            $text .= "{$icon} *{$t->title}* — *+{$t->reward} GC*\n";
            if ($t->description) $text .= "   _{$t->description}_\n";
            $text .= "\n";

            $kbd[] = [
                ['text' => "📋 {$t->title}", 'callback_data' => "task_{$t->id}"],
            ];
        }

        // Eco tugma ham qo'shamiz
        $kbd[] = [['text' => '🌿 Eco harakat bajarish', 'callback_data' => 'do_eco']];
        $kbd[] = [['text' => '⬅️ Bosh menyu', 'callback_data' => 'show_main']];

        $this->msgInline($chatId, $text, $kbd);
    }

    private function showTaskDetail(string $chatId, int $taskId): void
    {
        $t = TelegramBotTask::find($taskId);
        if (!$t) { $this->msg($chatId, "Vazifa topilmadi."); return; }

        $text  = "📋 *{$t->title}*\n\n";
        $text .= $t->description ? "{$t->description}\n\n" : '';
        $text .= "💰 Mukofot: *+{$t->reward} GC*\n";
        $text .= $t->requires_approval ? "⏳ Moderator ko'rib chiqadi\n" : "✅ Avtomatik tasdiqlanadi\n";
        $text .= "\nQanday topshirasiz?";

        $this->msgInline($chatId, $text, [
            [
                ['text' => '✍️ Matn yozish',  'callback_data' => "do_task_{$t->id}"],
                ['text' => '📸 Rasm yuborish', 'callback_data' => "photo_task_{$t->id}"],
            ],
            [['text' => '⬅️ Orqaga', 'callback_data' => 'show_tasks']],
        ]);
    }

    // ── Matn topshirish uchun so'rov ──
    private function askTaskInput(string $chatId, TelegramUser $tu, int $taskId): void
    {
        $task = TelegramBotTask::find($taskId);
        if (!$task) return;

        $user = $tu->user;
        if (!$user) { $this->cmdStart($chatId, $tu); return; }

        // State saqlaymiz — keyingi matn shu vazifa uchun
        cache()->put("tg_state_{$chatId}", ['action' => 'task_submit', 'task_id' => $taskId], 600);

        $this->msg($chatId,
            "✍️ *{$task->title}*\n\n"
            . "Bajarganingizni tasvirlab yozing:\n"
            . "_Masalan: \"Bugun mahallam yaqinida 2 ta chiqindi qopini yig'dim\"_\n\n"
            . "💡 Bekor qilish uchun /start bosing"
        );
    }

    // ── Eco matn topshirish uchun so'rov ──
    private function askEcoInput(string $chatId, TelegramUser $tu): void
    {
        $user = $tu->user;
        if (!$user) { $this->cmdStart($chatId, $tu); return; }

        cache()->put("tg_state_{$chatId}", ['action' => 'eco_submit'], 600);

        $this->msg($chatId,
            "🌿 *Eco harakat*\n\n"
            . "Bugun qanday ekologik harakat qildingiz?\n"
            . "_Masalan: \"Daraxt ekdim\", \"Chiqindi ajratdim\", \"Piyoda yurdim\"_\n\n"
            . "💡 Bekor qilish uchun /start bosing"
        );
    }

    // ── Rasm yuborish yo'riqnomasi ──
    private function askPhotoInput(string $chatId, int $taskId): void
    {
        $this->msg($chatId,
            "📸 *Rasm bilan tasdiqlash*\n\n"
            . "Bajargan harakatingizning rasmini yuboring.\n"
            . "Rasmni yuborishdan oldin caption'ga `#{$taskId}` yozing.\n\n"
            . "_Masalan: caption'da \"#{$taskId} daraxt ekdim\" deb yozing_"
        );
    }

    // ═══════════════════════════════════════
    // /refer
    // ═══════════════════════════════════════
    private function cmdRefer(string $chatId, ?TelegramUser $tu): void
    {
        $user = $tu?->user;
        if (!$user) { $this->msg($chatId, "⚠️ Avval telefon raqamingizni yuboring."); return; }

        if (!$user->referral_code) {
            $user->update(['referral_code' => \Illuminate\Support\Str::random(8)]);
        }

        $link = url('/register?ref=' . $user->referral_code);
        $this->msgInline($chatId,
            "🔗 *Referal dasturi*\n\nHavolangiz:\n`{$link}`\n\n" .
            "👥 Taklif qilganlar: *{$user->referral_count}*\n" .
            "💰 Har bir taklif uchun: *+50 GC* (siz)\n🎁 Do'stingiz ham: *+50 GC*",
            [[['text' => '📤 Ulashish', 'url' => "https://t.me/share/url?url={$link}&text=AMBARELLA - O'zbekiston yoshlari platformasi!"]]]
        );
    }

    // ═══════════════════════════════════════
    // /status
    // ═══════════════════════════════════════
    private function cmdStatus(string $chatId, ?TelegramUser $tu): void
    {
        $user = $tu?->user;
        if (!$user) { $this->msg($chatId, "⚠️ Avval telefon raqamingizni yuboring."); return; }

        $p  = TelegramBotSubmission::where('user_id', $user->id)->where('status', 'pending')->count();
        $a  = TelegramBotSubmission::where('user_id', $user->id)->where('status', 'approved')->count();
        $r  = TelegramBotSubmission::where('user_id', $user->id)->where('status', 'rejected')->count();
        $gc = TelegramBotSubmission::where('user_id', $user->id)->where('status', 'approved')->sum('reward_amount');

        $this->msg($chatId, "📊 *Topshiriqlar holati*\n\n⏳ Kutilmoqda: *{$p}*\n✅ Tasdiqlangan: *{$a}*\n❌ Rad etilgan: *{$r}*\n\n💰 Bot orqali ishlangan: *{$gc} GC*");
    }

    // ═══════════════════════════════════════
    // /submit
    // ═══════════════════════════════════════
    private function cmdSubmit(string $chatId, TelegramUser $tu, string $text): void
    {
        $user = $tu->user;
        if (!$user) { $this->msg($chatId, "⚠️ Avval telefon raqamingizni yuboring."); return; }
        if (!$user->profile_completed) {
            $this->msgInline($chatId, "⚠️ Profilingizni to'ldiring:", [[['text' => '📝 To\'ldirish', 'url' => url('/onboarding')]]]); return;
        }
        if (!$this->requireChannel($chatId)) return;

        if (preg_match('/^\/submit\s+referral\s+(\+?\d[\d\s\-\(\)]{7,})/i', $text, $m)) {
            $this->submitReferral($chatId, $user, $this->normalizePhone($m[1])); return;
        }
        if (preg_match('/^\/submit\s+eco\s+(.+)/is', $text, $m)) {
            $this->submitEco($chatId, $user, trim($m[1])); return;
        }
        if (preg_match('/^\/submit\s+task\s+(\d+)\s+(.+)/is', $text, $m)) {
            $this->submitTask($chatId, $user, (int)$m[1], trim($m[2])); return;
        }

        $this->msg($chatId,
            "❌ Format noto'g'ri:\n" .
            "`/submit task <id> <matn>`\n" .
            "`/submit eco <ta'rif>`\n" .
            "`/submit referral +998...`"
        );
    }

    // ═══════════════════════════════════════
    // PHOTO
    // ═══════════════════════════════════════
    private function handlePhoto(string $chatId, TelegramUser $tu, array $photo, string $caption): void
    {
        $user = $tu->user;
        if (!$user) { $this->msg($chatId, "⚠️ Avval telefon raqamingizni yuboring."); return; }
        if (!$user->profile_completed) { $this->msg($chatId, "⚠️ Profilingizni to'ldiring: " . url('/onboarding')); return; }
        if (!$this->requireChannel($chatId)) return;

        // Caption'da task ID bor bo'lsa (#5 yoki 5)
        $taskId = null;
        if (preg_match('/#?(\d+)/', $caption, $m)) $taskId = (int)$m[1];

        $task = $taskId
            ? TelegramBotTask::where('id', $taskId)->where('is_active', true)->first()
            : TelegramBotTask::where('task_type', 'action')->where('is_active', true)->first();

        if (!$task) { $this->msg($chatId, "Hozircha foto talab qiladigan vazifa yo'q."); return; }

        $fileId = end($photo)['file_id'];

        $sub = TelegramBotSubmission::create([
            'task_id'       => $task->id,
            'user_id'       => $user->id,
            'chat_id'       => $chatId,
            'payload'       => ['file_id' => $fileId, 'caption' => $caption],
            'media_type'    => 'photo',
            'status'        => 'pending',
            'reward_amount' => $task->reward,
        ]);

        $this->notifyAdmin($sub);
        $this->msg($chatId, "📸 *Rasm qabul qilindi!*\n\nVazifa: *{$task->title}*\nModerator ko'rib chiqadi — tasdiqlansa *+{$task->reward} GC* beriladi.\n\nHolat: /status");
    }

    // ═══════════════════════════════════════
    // SUBMIT HANDLERS
    // ═══════════════════════════════════════
    private function submitReferral(string $chatId, User $user, string $phone): void
    {
        if ($phone === $this->normalizePhone($user->phone ?? '')) {
            $this->msg($chatId, "❌ O'zingizni taklif qila olmaysiz."); return;
        }

        $invitee = $this->findUserByPhone($phone);
        if (!$invitee) {
            $this->msg($chatId, "Do'stingiz hali platformada yo'q.\nReferal havolangiz: " . url('/register?ref=' . $user->referral_code)); return;
        }
        if ($invitee->id === $user->id) { $this->msg($chatId, "❌ O'zingizni taklif qila olmaysiz."); return; }
        if ($invitee->referred_by && $invitee->referred_by !== $user->id) {
            $this->msg($chatId, "⚠️ Bu foydalanuvchi allaqachon boshqa kishi tomonidan taklif qilingan."); return;
        }

        $invitee->update(['referred_by' => $user->id]);
        TelegramReferral::firstOrCreate(
            ['inviter_user_id' => $user->id, 'invitee_user_id' => $invitee->id],
            ['invitee_phone' => $phone, 'invite_code' => $user->referral_code, 'status' => 'pending']
        );

        if ($invitee->profile_completed) {
            $invitee->rewardReferralIfEligible();
            $this->msg($chatId, "✅ Do'stingiz profilini to'ldirgan! Mukofot berildi."); return;
        }
        $this->msg($chatId, "✅ Do'stingiz platformada bor. Profil to'ldirgach ikkalangizga +50 GC beriladi.");
    }

    private function submitEco(string $chatId, User $user, string $payload): void
    {
        $task = TelegramBotTask::where('task_type', 'action')->where('is_active', true)->first();
        if (!$task) { $this->msg($chatId, "Hozircha eco vazifa yo'q."); return; }

        $sub = TelegramBotSubmission::create([
            'task_id' => $task->id, 'user_id' => $user->id, 'chat_id' => $chatId,
            'payload' => ['text' => $payload], 'media_type' => 'text',
            'status' => 'pending', 'reward_amount' => $task->reward,
        ]);
        $this->notifyAdmin($sub);
        $this->msg($chatId, "✅ Eco topshirig'ingiz qabul qilindi!\nTasdiqlansa *+{$task->reward} GC* beriladi.");
    }

    private function submitTask(string $chatId, User $user, int $taskId, string $payload): void
    {
        $task = TelegramBotTask::find($taskId);
        if (!$task || !$task->is_active) { $this->msg($chatId, "❌ Vazifa topilmadi yoki faol emas."); return; }

        $sub = TelegramBotSubmission::create([
            'task_id' => $task->id, 'user_id' => $user->id, 'chat_id' => $chatId,
            'payload' => ['text' => $payload], 'media_type' => 'text',
            'status' => $task->requires_approval ? 'pending' : 'approved',
            'reward_amount' => $task->reward,
        ]);

        if ($task->requires_approval) {
            $this->notifyAdmin($sub);
            $this->msg($chatId, "✅ Topshiriq yuborildi. Moderator ko'rib chiqadi."); return;
        }

        $this->grantReward($user, $task->reward, "Telegram: {$task->title}");
        $this->msg($chatId, "✅ Bajarildi! *+{$task->reward} GC* hisobingizga o'tkazildi 🎉");
    }

    // ═══════════════════════════════════════
    // ADMIN APPROVE / REJECT (Telegram callback orqali)
    // ═══════════════════════════════════════
    private function adminApprove(string $chatId, ?int $msgId, int $subId): void
    {
        $sub = TelegramBotSubmission::find($subId);
        if (!$sub || $sub->status !== 'pending') {
            $this->msg($chatId, "⚠️ Allaqachon ko'rib chiqilgan yoki topilmadi."); return;
        }

        $sub->update(['status' => 'approved', 'reviewed_at' => now()]);
        $user = $sub->user;

        if ($user) {
            $this->grantReward($user, $sub->reward_amount, "Telegram submission tasdiqlandi");
            if ($user->telegram_id) {
                $this->msg((string)$user->telegram_id,
                    "✅ *Topshirig'ingiz tasdiqlandi!*\n*+{$sub->reward_amount} GC* berildi 🎉\nBalans: *{$user->fresh()->greencoin_balance} GC*"
                );
            }
        }

        if ($msgId) {
            $this->editMsg($chatId, $msgId, "✅ *TASDIQLANDI* #{$subId} → {$user?->name} (+{$sub->reward_amount} GC)");
        }
    }

    private function adminReject(string $chatId, ?int $msgId, int $subId): void
    {
        $sub = TelegramBotSubmission::find($subId);
        if (!$sub || $sub->status !== 'pending') {
            $this->msg($chatId, "⚠️ Allaqachon ko'rib chiqilgan yoki topilmadi."); return;
        }

        $sub->update(['status' => 'rejected', 'reviewed_at' => now()]);
        $user = $sub->user;

        if ($user?->telegram_id) {
            $this->msg((string)$user->telegram_id,
                "❌ *Topshirig'ingiz rad etildi.*\nQaytadan urinib ko'ring: /tasks"
            );
        }

        if ($msgId) {
            $this->editMsg($chatId, $msgId, "❌ *RAD ETILDI* #{$subId} → {$user?->name}");
        }
    }

    // ═══════════════════════════════════════
    // UTILITY
    // ═══════════════════════════════════════
    private function grantReward(User $user, int $amount, string $desc): void
    {
        $user->increment('greencoin_balance', $amount);
        GreenCoinTransaction::create(['user_id' => $user->id, 'amount' => $amount, 'type' => 'earned', 'description' => $desc]);
    }

    private function notifyAdmin(TelegramBotSubmission $sub): void
    {
        $token   = config('services.telegram.bot_token');
        $adminId = config('services.telegram.admin_chat_id');
        if (!$token || !$adminId) return;

        $user = $sub->user;
        $task = $sub->task;
        $kbd  = [[
            ['text' => '✅ Tasdiqlash', 'callback_data' => "approve_{$sub->id}"],
            ['text' => '❌ Rad etish',  'callback_data' => "reject_{$sub->id}"],
        ]];
        $text = "📩 *Yangi topshiriq* #{$sub->id}\n👤 {$user?->name}\n📋 " .
            ($task?->title ?? 'Eco action') . "\n💰 +{$sub->reward_amount} GC\n📎 {$sub->media_type}";

        $payload = ['chat_id' => $adminId, 'parse_mode' => 'Markdown', 'reply_markup' => json_encode(['inline_keyboard' => $kbd])];

        if ($sub->media_type === 'photo' && isset($sub->payload['file_id'])) {
            Http::post("https://api.telegram.org/bot{$token}/sendPhoto", array_merge($payload, [
                'photo' => $sub->payload['file_id'],
                'caption' => $text . "\n" . ($sub->payload['caption'] ?? ''),
            ]));
        } else {
            Http::post("https://api.telegram.org/bot{$token}/sendMessage", array_merge($payload, [
                'text' => $text . "\n📝 " . ($sub->payload['text'] ?? ''),
            ]));
        }
    }

    /** Oddiy xabar — inline keyboard yo'q */
    private function msg(string $chatId, string $text): void
    {
        $token = config('services.telegram.bot_token');
        if (!$token) return;
        Http::post("https://api.telegram.org/bot{$token}/sendMessage", [
            'chat_id' => $chatId, 'text' => $text, 'parse_mode' => 'Markdown',
        ]);
    }

    /** Inline keyboard bilan xabar */
    private function msgInline(string $chatId, string $text, array $keyboard): void
    {
        $token = config('services.telegram.bot_token');
        if (!$token) return;
        Http::post("https://api.telegram.org/bot{$token}/sendMessage", [
            'chat_id'      => $chatId,
            'text'         => $text,
            'parse_mode'   => 'Markdown',
            'reply_markup' => json_encode(['inline_keyboard' => $keyboard]),
        ]);
    }

    /** Reply keyboard (contact button) bilan xabar */
    private function msgContact(string $chatId, string $text): void
    {
        $token = config('services.telegram.bot_token');
        if (!$token) return;
        Http::post("https://api.telegram.org/bot{$token}/sendMessage", [
            'chat_id'      => $chatId,
            'text'         => $text,
            'parse_mode'   => 'Markdown',
            'reply_markup' => json_encode([
                'keyboard'          => [[['text' => '📱 Telefon raqamni ulash', 'request_contact' => true]]],
                'resize_keyboard'   => true,
                'one_time_keyboard' => true,
            ]),
        ]);
    }

    /** Xabarni tahrirlash */
    private function editMsg(string $chatId, int $msgId, string $text): void
    {
        $token = config('services.telegram.bot_token');
        if (!$token) return;
        Http::post("https://api.telegram.org/bot{$token}/editMessageText", [
            'chat_id'      => $chatId, 'message_id' => $msgId,
            'text'         => $text, 'parse_mode' => 'Markdown',
            'reply_markup' => json_encode(['inline_keyboard' => []]),
        ]);
    }

    private function normalizePhone(string $phone): string
    {
        return preg_replace('/[^0-9]/', '', $phone);
    }

    private function looksLikePhone(string $text): bool
    {
        $p = $this->normalizePhone($text);
        return strlen($p) >= 9 && strlen($p) <= 15;
    }

    private function findUserByPhone(string $phone): ?User
    {
        $n = $this->normalizePhone($phone);
        // phone_normalized ustuni mavjud bo'lsa (indeksli, tez)
        $user = User::where('phone_normalized', $n)->first();
        if ($user) return $user;
        // Fallback — REPLACE bilan
        return User::whereRaw("REPLACE(REPLACE(REPLACE(phone,'+',''),' ',''),'-','') = ?", [$n])->first();
    }
}
