<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class TwoFactorController extends Controller
{
    /**
     * 2FA sahifasini ko'rsatish
     */
    public function showVerify()
    {
        if (!auth()->user()->two_factor_enabled) {
            return redirect('/dashboard');
        }

        // 6 raqamli kod yaratib email/telegram orqali yuborish
        if (!session('2fa_code_sent')) {
            $this->sendCode();
        }

        return view('auth.two-factor');
    }

    /**
     * 2FA kodni tekshirish
     */
    public function verify(Request $request)
    {
        $request->validate([
            'code' => 'required|string|size:6',
        ]);

        $storedCode = session('2fa_code');
        $expiresAt = session('2fa_code_expires');

        if (!$storedCode || now()->isAfter($expiresAt)) {
            return back()->withErrors(['code' => 'Kod muddati tugagan. Qayta yuboring.']);
        }

        if ($request->code !== $storedCode) {
            return back()->withErrors(['code' => 'Kod noto\'g\'ri.']);
        }

        session(['2fa_verified' => true]);
        session()->forget(['2fa_code', '2fa_code_expires', '2fa_code_sent']);

        return redirect('/dashboard')->with('success', '2FA tasdiqlandi!');
    }

    /**
     * 2FA kodni qayta yuborish
     */
    public function resend()
    {
        $this->sendCode();
        return back()->with('success', 'Yangi kod yuborildi!');
    }

    /**
     * 2FA sozlamalar
     */
    public function settings()
    {
        return view('settings.two-factor');
    }

    /**
     * 2FA yoqish/o'chirish
     */
    public function toggle(Request $request)
    {
        $user = auth()->user();

        $request->validate([
            'password' => 'required|string',
        ]);

        if (!Hash::check($request->password, $user->password)) {
            return back()->withErrors(['password' => 'Parol noto\'g\'ri.']);
        }

        $user->two_factor_enabled = !$user->two_factor_enabled;
        $user->save();

        $status = $user->two_factor_enabled ? 'yoqildi' : 'o\'chirildi';
        return back()->with('success', "Ikki faktorli autentifikatsiya {$status}.");
    }

    /**
     * Kod yaratish va yuborish
     */
    private function sendCode(): void
    {
        $code = (string) random_int(100000, 999999);
        session([
            '2fa_code' => $code,
            '2fa_code_expires' => now()->addMinutes(5),
            '2fa_code_sent' => true,
        ]);

        $user = auth()->user();

        // Email orqali yuborish
        try {
            \Illuminate\Support\Facades\Mail::raw(
                "AMBARELLA 2FA tasdiqlash kodi: {$code}\n\nBu kod 5 daqiqa amal qiladi.",
                function ($message) use ($user) {
                    $message->to($user->email)
                        ->subject('AMBARELLA - 2FA Tasdiqlash Kodi');
                }
            );
        } catch (\Exception $e) {
            // Email yuborilmasa, session'dagi kod orqali davom etish
        }
    }
}
