<?php

namespace App\Http\Controllers;

class MyCoursesController extends Controller
{
    public function index()
    {
        $courses = auth()->user()->courses()->get();
        return view('my-courses.index', compact('courses'));
    }
}
