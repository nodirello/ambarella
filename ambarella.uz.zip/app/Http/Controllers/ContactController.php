<?php

namespace App\Http\Controllers;

use App\Models\ContactMessage;
use Illuminate\Http\Request;

class ContactController extends Controller
{
    public function store(Request $request)
    {
        // Honeypot spam check
        if ($request->filled('website_url')) {
            // Bot detected — silently reject
            return back()->with('success', 'Xabaringiz yuborildi!');
        }

        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email:rfc|max:255',
            'phone' => 'nullable|string|max:20',
            'subject' => 'required|string|max:255',
            'message' => 'required|string|min:10|max:2000',
        ]);

        ContactMessage::create([
            'name' => strip_tags($request->name),
            'email' => strtolower(trim($request->email)),
            'phone' => $request->phone,
            'subject' => strip_tags($request->subject),
            'message' => strip_tags($request->message),
        ]);

        // Admin notification
        \App\Http\Controllers\Admin\AdminNotificationService::notifyNewContact($request->name, $request->subject);

        return back()->with('success', 'Xabaringiz yuborildi! Tez orada javob beramiz.');
    }
}
