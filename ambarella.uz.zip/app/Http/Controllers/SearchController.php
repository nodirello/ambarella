<?php

namespace App\Http\Controllers;

use App\Models\Job;
use App\Models\Course;
use App\Models\Mentor;
use App\Models\News;
use App\Models\FarmProduct;
use Illuminate\Http\Request;

class SearchController extends Controller
{
    public function index(Request $request)
    {
        $q = htmlspecialchars($request->input('q', ''), ENT_QUOTES, 'UTF-8');
        $q = mb_substr($q, 0, 100); // max 100 belgi

        $jobs = collect();
        $courses = collect();
        $mentors = collect();
        $news = collect();
        $products = collect();

        if (strlen($q) >= 2) {
            $jobs = Job::where('is_active', true)
                ->where(function ($query) use ($q) {
                    $query->where('title', 'like', "%{$q}%")
                          ->orWhere('company', 'like', "%{$q}%");
                })->limit(5)->get();

            $courses = Course::where('title', 'like', "%{$q}%")
                ->orWhere('instructor', 'like', "%{$q}%")
                ->limit(5)->get();

            $mentors = Mentor::where('name', 'like', "%{$q}%")
                ->orWhere('role', 'like', "%{$q}%")
                ->limit(5)->get();

            $news = News::where('title', 'like', "%{$q}%")
                ->limit(5)->get();

            $products = FarmProduct::where('is_active', true)
                ->where('name', 'like', "%{$q}%")
                ->limit(5)->get();
        }

        return view('search.index', compact('q', 'jobs', 'courses', 'mentors', 'news', 'products'));
    }
}
