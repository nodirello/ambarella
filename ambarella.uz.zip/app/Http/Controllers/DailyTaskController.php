<?php

namespace App\Http\Controllers;

use App\Models\DailyTask;
use Illuminate\Http\Request;

class DailyTaskController extends Controller
{
    public function index()
    {
        $user = auth()->user();
        $today = now()->toDateString();

        $tasks = DailyTask::where('user_id', $user->id)
            ->where('date', $today)
            ->orderBy('created_at', 'desc')
            ->get();

        $stats = [
            'total_today' => $tasks->count(),
            'done_today' => $tasks->where('is_done', true)->count(),
            'streak' => $this->calculateStreak($user->id),
        ];

        return view('daily-tasks.index', compact('tasks', 'stats'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'text' => 'required|string|max:255',
        ]);

        DailyTask::create([
            'user_id' => auth()->id(),
            'text' => $request->text,
            'date' => now()->toDateString(),
        ]);

        return back()->with('success', 'Vazifa qo\'shildi!');
    }

    public function toggle(DailyTask $task)
    {
        if ($task->user_id !== auth()->id()) {
            abort(403);
        }

        $task->update(['is_done' => !$task->is_done]);

        return back()->with('success', $task->is_done ? 'Bajarildi!' : 'Bekor qilindi');
    }

    public function destroy(DailyTask $task)
    {
        if ($task->user_id !== auth()->id()) {
            abort(403);
        }

        $task->delete();
        return back()->with('success', 'O\'chirildi!');
    }

    private function calculateStreak(int $userId): int
    {
        $streak = 0;
        $date = now()->subDay();

        while (true) {
            $hasTasks = DailyTask::where('user_id', $userId)
                ->where('date', $date->toDateString())
                ->where('is_done', true)
                ->exists();

            if (!$hasTasks) break;
            $streak++;
            $date->subDay();
        }

        // Bugungi ham bajarilgan bo'lsa
        $todayDone = DailyTask::where('user_id', $userId)
            ->where('date', now()->toDateString())
            ->where('is_done', true)
            ->exists();

        if ($todayDone) $streak++;

        return $streak;
    }
}
