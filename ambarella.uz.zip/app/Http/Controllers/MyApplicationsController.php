<?php

namespace App\Http\Controllers;

use App\Models\JobApplication;

class MyApplicationsController extends Controller
{
    public function index()
    {
        $applications = JobApplication::where('user_id', auth()->id())
            ->with('job')
            ->latest()
            ->paginate(15);

        return view('my-applications.index', compact('applications'));
    }
}
