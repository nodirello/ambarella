<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Carbon\Carbon;

class StreakController extends Controller
{
    public function check(Request $request)
    {
        $user = auth()->user();
        $today = Carbon::today();
        $lastLogin = $user->last_login_date ? Carbon::parse($user->last_login_date) : null;

        // If already logged in today, just return info
        if ($lastLogin && $lastLogin->isSameDay($today)) {
            return response()->json([
                'streak' => $user->login_streak,
                'reward' => null,
                'message' => 'Bugun allaqachon kirgansiz!'
            ]);
        }

        // Check if consecutive
        if ($lastLogin && $lastLogin->isSameDay($today->copy()->subDay())) {
            $user->login_streak += 1;
        } else {
            // Streak broken, reset
            $user->login_streak = 1;
        }

        $user->last_login_date = $today;

        // Check rewards
        $reward = 0;
        $streak = $user->login_streak;

        if ($streak === 7) {
            $reward = 25;
        } elseif ($streak === 14) {
            $reward = 50;
        } elseif ($streak === 30) {
            $reward = 100;
        }

        if ($reward > 0) {
            $user->greencoin_balance += $reward;
        }

        $user->save();

        return response()->json([
            'streak' => $user->login_streak,
            'reward' => $reward > 0 ? $reward : null,
            'message' => $reward > 0
                ? "Tabriklaymiz! {$streak} kunlik streak uchun +{$reward} GreenCoin!"
                : "{$streak} kun ketma-ket kiryapsiz!"
        ]);
    }
}
