<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class SetLocale
{
    private const SUPPORTED_LOCALES = ['uz', 'ru', 'en'];

    public function handle(Request $request, Closure $next)
    {
        $locale = $request->cookie('locale')
            ?? $request->header('Accept-Language', 'uz');

        // Faqat dastlabki 2 belgi
        $locale = substr($locale, 0, 2);

        if (!in_array($locale, self::SUPPORTED_LOCALES)) {
            $locale = 'uz';
        }

        app()->setLocale($locale);

        return $next($request);
    }
}
