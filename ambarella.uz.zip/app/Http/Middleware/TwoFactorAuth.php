<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class TwoFactorAuth
{
    public function handle(Request $request, Closure $next)
    {
        $user = auth()->user();

        // Agar 2FA yoqilgan bo'lsa va hali tasdiqlangan bo'lmasa
        if ($user && $user->two_factor_enabled && !session('2fa_verified')) {
            // 2FA sahifasiga yo'naltirish
            if (!$request->is('2fa*') && !$request->is('logout')) {
                return redirect('/2fa/verify');
            }
        }

        return $next($request);
    }
}
