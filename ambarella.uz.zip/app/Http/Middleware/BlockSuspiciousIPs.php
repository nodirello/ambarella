<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

class BlockSuspiciousIPs
{
    /**
     * Shubhali IP manzillarni bloklash
     * 10+ failed login 5 daqiqa ichida = 30 daqiqalik block
     */
    public function handle(Request $request, Closure $next)
    {
        $ip = $request->ip();
        $blockKey = "blocked_ip:{$ip}";

        // Bloklangan IP
        if (Cache::has($blockKey)) {
            abort(429, 'Sizning IP manzilingiz vaqtincha bloklangan.');
        }

        return $next($request);
    }

    /**
     * Failed login qayd etish
     */
    public static function recordFailedLogin(string $ip): void
    {
        $key = "failed_login:{$ip}";
        $attempts = Cache::get($key, 0) + 1;
        Cache::put($key, $attempts, 300); // 5 daqiqa

        // 10+ failed attempt = block
        if ($attempts >= 10) {
            Cache::put("blocked_ip:{$ip}", true, 1800); // 30 daqiqa
            Cache::forget($key);
        }
    }
}
