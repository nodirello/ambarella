<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class CheckProfileComplete
{
    public function handle(Request $request, Closure $next)
    {
        if (auth()->check() && !auth()->user()->profile_completed) {
            // Profil sahifasiga o'tishga ruxsat berish
            if (!$request->is('onboarding*') && !$request->is('logout')) {
                return redirect('/onboarding');
            }
        }

        return $next($request);
    }
}
