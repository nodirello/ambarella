// tests/storage.property.test.js
import { describe, it, expect, beforeEach } from 'vitest';
import fc from 'fast-check';
import { saveItem, getItem } from '../assets/js/storage.js';

/**
 * Feature: ambarella-html-mvp
 * Property 5: localStorage saqlash round-trip
 * Validates: Requirements MOD-001.5, MOD-011.4
 */
describe('localStorage round-trip xususiyatlari', () => {
  beforeEach(() => localStorage.clear());

  it('PROP-5: For any key and serializable value, save then get returns same value', () => {
    fc.assert(fc.property(
      fc.string({ minLength: 1, maxLength: 50 }),
      fc.oneof(fc.string(), fc.array(fc.string()), fc.boolean(), fc.integer()),
      (key, value) => {
        saveItem(key, value);
        const retrieved = getItem(key);
        expect(retrieved).toEqual(value);
      }
    ), { numRuns: 100 });
  });

  it('PROP-5b: Storage operations fail silently (no exception thrown)', () => {
    // localStorage mock — quota exceeded simulation
    const originalSetItem = Storage.prototype.setItem;
    Storage.prototype.setItem = () => { throw new Error('QuotaExceededError'); };

    expect(() => saveItem('test', 'value')).not.toThrow();
    expect(getItem('test')).toBeNull();

    Storage.prototype.setItem = originalSetItem;
  });
});
