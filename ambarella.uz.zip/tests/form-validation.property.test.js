/**
 * Feature: ambarella-html-mvp
 * Property 6: Forma validatsiya to'g'riligi
 * **Validates: Requirements AUTH-001.5, AUTH-001.6**
 */
import { describe, it, expect } from 'vitest';
import fc from 'fast-check';
import { validateEmail, validatePassword } from '../assets/js/form-validation.js';

describe('Forma validatsiya xususiyatlari (Property 6)', () => {

  it('PROP-6a: Valid email format (user@domain.tld) passes validation', () => {
    // Generate valid emails: alphanumeric user, alphanumeric domain, 2-4 alpha tld
    const validEmailArb = fc.tuple(
      fc.stringMatching(/^[a-zA-Z0-9]+$/).filter(s => s.length >= 1),
      fc.stringMatching(/^[a-zA-Z0-9]+$/).filter(s => s.length >= 1),
      fc.stringMatching(/^[a-zA-Z]{2,4}$/)
    ).map(([user, domain, tld]) => `${user}@${domain}.${tld}`);

    fc.assert(fc.property(validEmailArb, (email) => {
      expect(validateEmail(email)).toBe(true);
    }), { numRuns: 100 });
  });

  it('PROP-6b: Strings missing @ always fail email validation', () => {
    const noAtStrings = fc.string({ minLength: 0, maxLength: 50 })
      .filter(s => !s.includes('@'));

    fc.assert(fc.property(noAtStrings, (str) => {
      expect(validateEmail(str)).toBe(false);
    }), { numRuns: 100 });
  });

  it('PROP-6c: Strings missing . after @ always fail email validation', () => {
    // Strings with @ but no . after the @
    const noDotAfterAt = fc.tuple(
      fc.stringMatching(/^[a-zA-Z0-9]+$/),
      fc.stringMatching(/^[a-zA-Z0-9]+$/)
    ).map(([left, right]) => `${left}@${right}`)
     .filter(s => {
       const afterAt = s.split('@')[1];
       return afterAt && !afterAt.includes('.');
     });

    fc.assert(fc.property(noDotAfterAt, (str) => {
      expect(validateEmail(str)).toBe(false);
    }), { numRuns: 100 });
  });

  it('PROP-6d: Passwords with length >= 8 pass validation', () => {
    const longPasswords = fc.string({ minLength: 8, maxLength: 100 });

    fc.assert(fc.property(longPasswords, (password) => {
      expect(validatePassword(password)).toBe(true);
    }), { numRuns: 100 });
  });

  it('PROP-6e: Passwords with length < 8 fail validation', () => {
    const shortPasswords = fc.string({ minLength: 0, maxLength: 7 });

    fc.assert(fc.property(shortPasswords, (password) => {
      expect(validatePassword(password)).toBe(false);
    }), { numRuns: 100 });
  });
});
