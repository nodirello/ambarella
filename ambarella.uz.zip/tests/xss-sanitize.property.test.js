/**
 * Feature: ambarella-html-mvp
 * Property 3: XSS sanitizatsiya round-trip xavfsizligi
 * 
 * sanitizeInput(s) natijasida '<' va '>' bo'lmasligi,
 * xavfsiz satrlar o'zgarmasdan o'tishi kerak
 * 
 * **Validates: Requirements SEC-001.1**
 */
import { describe, it, expect } from 'vitest';
import fc from 'fast-check';
import { sanitizeInput } from '../assets/js/form-validation.js';

describe('XSS sanitizatsiya xususiyatlari (Property 3)', () => {
  it('PROP-3a: sanitizeInput(s) natijasida raw "<" va ">" belgilari bo\'lmasligi kerak', () => {
    fc.assert(
      fc.property(
        fc.string(), // ixtiyoriy satr
        (input) => {
          const sanitized = sanitizeInput(input);
          // Sanitized natijada raw < va > bo'lmasligi kerak
          expect(sanitized).not.toContain('<');
          expect(sanitized).not.toContain('>');
        }
      ),
      { numRuns: 200 }
    );
  });

  it('PROP-3b: Xavfsiz satrlar (faqat [a-zA-Z0-9 ]) o\'zgarmasdan o\'tishi kerak', () => {
    fc.assert(
      fc.property(
        fc.stringMatching(/^[a-zA-Z0-9 ]*$/), // faqat xavfsiz belgilar
        (input) => {
          const sanitized = sanitizeInput(input);
          // Xavfsiz satrlar aynan o'zgarishsiz qaytishi kerak
          expect(sanitized).toBe(input);
        }
      ),
      { numRuns: 200 }
    );
  });
});
