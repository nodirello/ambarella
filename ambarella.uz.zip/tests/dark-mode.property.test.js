import { describe, it, expect, beforeEach } from 'vitest';
import fc from 'fast-check';
import { applyTheme, saveToStorage } from '../assets/js/dark-mode.js';

/**
 * Feature: ambarella-html-mvp
 * Property 4: Dark Mode localStorage round-trip
 * 
 * **Validates: Requirements UI-001.2, UI-001.3, UI-001.4**
 */
describe('Dark mode xususiyatlari', () => {
  beforeEach(() => {
    document.documentElement.removeAttribute('data-theme');
    localStorage.clear();
  });

  it('PROP-4: For any theme value, applyTheme + saveToStorage should produce consistent data-theme attribute and localStorage', () => {
    fc.assert(fc.property(
      fc.oneof(fc.constant('light'), fc.constant('dark')),
      (theme) => {
        // Tema qo'llash va saqlash
        applyTheme(theme);
        saveToStorage(theme);

        // Tekshirish: data-theme atributi mos
        const applied = document.documentElement.getAttribute('data-theme');
        expect(applied).toBe(theme);

        // Tekshirish: localStorage mos
        const saved = localStorage.getItem('ambarella-theme');
        expect(saved).toBe(theme);

        // Tekshirish: ikkalasi bir xil
        expect(saved).toBe(applied);
      }
    ), { numRuns: 100 });
  });
});
