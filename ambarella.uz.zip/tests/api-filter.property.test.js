/**
 * Property-Based Test: Filtrlash mantiqining to'g'riligi
 *
 * Feature: ambarella-html-mvp
 * Property 2: Filtrlash mantiqining to'g'riligi
 *
 * filterJobs(L, F) natijalar faqat L to'plamidan bo'lishi,
 * F filtrlariga mos kelishi va takrorlanmasligi kerak
 *
 * **Validates: Requirements MOD-001.3, MOD-011.2, MOD-018.2**
 */

import { describe, it, expect } from 'vitest';
import fc from 'fast-check';
import { filterJobs } from '../assets/js/api.js';

// Job object uchun arbitrary generator
const jobArb = fc.record({
  id: fc.string({ minLength: 1, maxLength: 20 }),
  type: fc.oneof(
    fc.constant('full-time'),
    fc.constant('part-time'),
    fc.constant('remote')
  ),
  category: fc.oneof(
    fc.constant('IT'),
    fc.constant('Marketing'),
    fc.constant('Finance'),
    fc.constant('Education'),
    fc.constant('Design')
  ),
  location: fc.record({
    city: fc.oneof(
      fc.constant('Toshkent'),
      fc.constant('Samarqand'),
      fc.constant('Buxoro'),
      fc.constant('Farg\'ona'),
      fc.constant('Namangan')
    )
  }),
  experience: fc.oneof(
    fc.constant('junior'),
    fc.constant('middle'),
    fc.constant('senior')
  ),
  salary: fc.integer({ min: 0, max: 50000000 })
});

// Filtr object uchun arbitrary generator
const filterArb = fc.record({
  type: fc.option(
    fc.oneof(fc.constant('full-time'), fc.constant('part-time'), fc.constant('remote')),
    { nil: undefined }
  ),
  category: fc.option(
    fc.oneof(fc.constant('IT'), fc.constant('Marketing'), fc.constant('Finance'), fc.constant('Education'), fc.constant('Design')),
    { nil: undefined }
  ),
  location: fc.option(
    fc.oneof(fc.constant('Toshkent'), fc.constant('Samarqand'), fc.constant('Buxoro'), fc.constant('Farg\'ona'), fc.constant('Namangan')),
    { nil: undefined }
  ),
  experience: fc.option(
    fc.oneof(fc.constant('junior'), fc.constant('middle'), fc.constant('senior')),
    { nil: undefined }
  ),
  salary: fc.option(
    fc.record({
      min: fc.option(fc.integer({ min: 0, max: 25000000 }), { nil: undefined }),
      max: fc.option(fc.integer({ min: 25000000, max: 50000000 }), { nil: undefined })
    }),
    { nil: undefined }
  )
});

describe('Job filter xususiyatlari (Property 2)', () => {
  it('PROP-2a: Natijalar faqat asl ro\'yxatdan bo\'lishi kerak (subset property)', () => {
    fc.assert(fc.property(
      fc.array(jobArb, { minLength: 0, maxLength: 50 }),
      filterArb,
      (jobs, filters) => {
        const result = filterJobs(jobs, filters);

        // Har bir natija asl ro'yxatdan bo'lishi kerak
        result.forEach(item => {
          expect(jobs).toContain(item);
        });
      }
    ), { numRuns: 200 });
  });

  it('PROP-2b: Natijalar barcha filtr shartlariga mos kelishi kerak', () => {
    fc.assert(fc.property(
      fc.array(jobArb, { minLength: 0, maxLength: 50 }),
      filterArb,
      (jobs, filters) => {
        const result = filterJobs(jobs, filters);

        result.forEach(job => {
          // type filtri
          if (filters.type !== undefined) {
            expect(job.type).toBe(filters.type);
          }

          // category filtri
          if (filters.category !== undefined) {
            expect(job.category).toBe(filters.category);
          }

          // location filtri
          if (filters.location !== undefined) {
            const jobCity = job.location && typeof job.location === 'object'
              ? job.location.city
              : job.location;
            expect(jobCity).toBe(filters.location);
          }

          // experience filtri
          if (filters.experience !== undefined) {
            expect(job.experience).toBe(filters.experience);
          }

          // salary filtri
          if (filters.salary !== undefined) {
            const jobSalary = typeof job.salary === 'number' ? job.salary : 0;
            if (filters.salary.min !== undefined) {
              expect(jobSalary).toBeGreaterThanOrEqual(filters.salary.min);
            }
            if (filters.salary.max !== undefined) {
              expect(jobSalary).toBeLessThanOrEqual(filters.salary.max);
            }
          }
        });
      }
    ), { numRuns: 200 });
  });

  it('PROP-2c: Natijada takrorlanuvchi elementlar bo\'lmasligi kerak', () => {
    fc.assert(fc.property(
      fc.array(jobArb, { minLength: 0, maxLength: 50 }),
      filterArb,
      (jobs, filters) => {
        const result = filterJobs(jobs, filters);

        // ID bo'yicha takrorlanish yo'q
        const ids = result.map(r => r.id);
        expect(new Set(ids).size).toBe(ids.length);
      }
    ), { numRuns: 200 });
  });
});
