/**
 * Feature: ambarella-html-mvp
 * Property 7: WCAG kontrast nisbati
 *
 * Dizayn tizimidagi asosiy rang juftliklari (--color-text/--color-bg)
 * normal matn uchun ≥ 4.5:1, katta matn uchun ≥ 3.0:1 kontrast nisbatini
 * ta'minlashi kerak (light va dark rejim ikkalasida)
 *
 * **Validates: Requirements A11Y-001.3**
 */
import { describe, it, expect } from 'vitest';
import fc from 'fast-check';

// --- Contrast ratio hisoblash funksiyalari (WCAG 2.1 algoritmiga mos) ---

/**
 * sRGB kanalini relative luminance uchun linearizatsiya qilish
 * @param {number} channel - 0-255 oralig'idagi rang kanali
 * @returns {number} - linearizatsiya qilingan qiymat
 */
function linearize(channel) {
  const sRGB = channel / 255;
  return sRGB <= 0.03928
    ? sRGB / 12.92
    : Math.pow((sRGB + 0.055) / 1.055, 2.4);
}

/**
 * Relative luminance hisoblash (WCAG 2.1)
 * @param {number} r - 0-255
 * @param {number} g - 0-255
 * @param {number} b - 0-255
 * @returns {number} - 0 dan 1 gacha luminance
 */
function relativeLuminance(r, g, b) {
  return 0.2126 * linearize(r) + 0.7152 * linearize(g) + 0.0722 * linearize(b);
}

/**
 * Ikki rang o'rtasidagi kontrast nisbatini hisoblash
 * @param {{r:number,g:number,b:number}} fg - foreground rang
 * @param {{r:number,g:number,b:number}} bg - background rang
 * @returns {number} - kontrast nisbati (1:1 dan 21:1 gacha)
 */
function getContrastRatio(fg, bg) {
  const L1 = relativeLuminance(fg.r, fg.g, fg.b);
  const L2 = relativeLuminance(bg.r, bg.g, bg.b);
  const lighter = Math.max(L1, L2);
  const darker = Math.min(L1, L2);
  return (lighter + 0.05) / (darker + 0.05);
}

/**
 * HEX rangni RGB ga aylantirish
 * @param {string} hex - "#RRGGBB" formatdagi rang
 * @returns {{r:number,g:number,b:number}}
 */
function hexToRgb(hex) {
  const clean = hex.replace('#', '');
  return {
    r: parseInt(clean.substring(0, 2), 16),
    g: parseInt(clean.substring(2, 4), 16),
    b: parseInt(clean.substring(4, 6), 16),
  };
}

// --- Dizayn tizimidagi ranglar (base.css dan olingan) ---

const lightTheme = {
  'color-primary': '#2563EB',
  'color-success': '#16A34A',
  'color-warning': '#F59E0B',
  'color-danger': '#DC2626',
  'color-bg': '#FFFFFF',
  'color-text': '#1E293B',
  'color-text-muted': '#64748B',
};

const darkTheme = {
  'color-primary': '#2563EB',
  'color-success': '#16A34A',
  'color-warning': '#F59E0B',
  'color-danger': '#DC2626',
  'color-bg': '#0F172A',
  'color-text': '#E2E8F0',
  'color-text-muted': '#94A3B8',
};

// Asosiy matn rang juftliklari — WCAG AA normal matn: ≥ 4.5:1
const normalTextPairs = [
  { name: 'Light: text on bg', fg: 'color-text', bg: 'color-bg', theme: 'light' },
  { name: 'Dark: text on bg', fg: 'color-text', bg: 'color-bg', theme: 'dark' },
  { name: 'Light: muted text on bg', fg: 'color-text-muted', bg: 'color-bg', theme: 'light' },
  { name: 'Dark: muted text on bg', fg: 'color-text-muted', bg: 'color-bg', theme: 'dark' },
];

// UI element rang juftliklari — WCAG AA katta matn / UI: ≥ 3.0:1
const largeTextPairs = [
  { name: 'Light: primary on bg', fg: 'color-primary', bg: 'color-bg', theme: 'light' },
  { name: 'Dark: primary on bg', fg: 'color-primary', bg: 'color-bg', theme: 'dark' },
  { name: 'Light: success on bg', fg: 'color-success', bg: 'color-bg', theme: 'light' },
  { name: 'Light: danger on bg', fg: 'color-danger', bg: 'color-bg', theme: 'light' },
];

describe('WCAG Kontrast Nisbati Xususiyatlari (Property 7)', () => {
  it('PROP-7a: Normal matn rang juftliklari ≥ 4.5:1 kontrast nisbatiga ega bo\'lishi kerak', () => {
    fc.assert(
      fc.property(
        fc.constantFrom(...normalTextPairs),
        (pair) => {
          const theme = pair.theme === 'light' ? lightTheme : darkTheme;
          const fg = hexToRgb(theme[pair.fg]);
          const bg = hexToRgb(theme[pair.bg]);
          const ratio = getContrastRatio(fg, bg);
          expect(ratio).toBeGreaterThanOrEqual(4.5);
        }
      ),
      { numRuns: 100 }
    );
  });

  it('PROP-7b: Katta matn va UI element rang juftliklari ≥ 3.0:1 kontrast nisbatiga ega bo\'lishi kerak', () => {
    fc.assert(
      fc.property(
        fc.constantFrom(...largeTextPairs),
        (pair) => {
          const theme = pair.theme === 'light' ? lightTheme : darkTheme;
          const fg = hexToRgb(theme[pair.fg]);
          const bg = hexToRgb(theme[pair.bg]);
          const ratio = getContrastRatio(fg, bg);
          expect(ratio).toBeGreaterThanOrEqual(3.0);
        }
      ),
      { numRuns: 100 }
    );
  });

  it('PROP-7c: Ixtiyoriy RGB rang juftligi uchun kontast hisoblash 1 dan 21 gacha bo\'lishi kerak', () => {
    fc.assert(
      fc.property(
        fc.record({
          r: fc.integer({ min: 0, max: 255 }),
          g: fc.integer({ min: 0, max: 255 }),
          b: fc.integer({ min: 0, max: 255 }),
        }),
        fc.record({
          r: fc.integer({ min: 0, max: 255 }),
          g: fc.integer({ min: 0, max: 255 }),
          b: fc.integer({ min: 0, max: 255 }),
        }),
        (fg, bg) => {
          const ratio = getContrastRatio(fg, bg);
          // Kontrast nisbati doimo 1:1 dan 21:1 gacha bo'lishi kerak
          expect(ratio).toBeGreaterThanOrEqual(1);
          expect(ratio).toBeLessThanOrEqual(21);
        }
      ),
      { numRuns: 200 }
    );
  });
});
