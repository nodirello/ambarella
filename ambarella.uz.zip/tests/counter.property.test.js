// tests/counter.property.test.js
import { describe, it, expect } from 'vitest';
import fc from 'fast-check';
import { calculateCounterValue } from '../assets/js/counter.js';

/**
 * Feature: ambarella-html-mvp
 * Property 1: Counter animatsiya to'g'riligi
 * Validates: Requirements HOME-001.7, MOD-002.4
 */
describe('Counter animatsiya xususiyatlari', () => {
  it('PROP-1a: calculateCounterValue(0, target) === 0 (noldan boshlanadi)', () => {
    fc.assert(fc.property(
      fc.integer({ min: 1, max: 10_000_000 }),
      (target) => {
        const value = calculateCounterValue(0, target);
        expect(value).toBe(0);
      }
    ), { numRuns: 100 });
  });

  it('PROP-1b: calculateCounterValue(1, target) === target (maqsadga etadi)', () => {
    fc.assert(fc.property(
      fc.integer({ min: 0, max: 10_000_000 }),
      (target) => {
        const value = calculateCounterValue(1, target);
        expect(value).toBe(target);
      }
    ), { numRuns: 100 });
  });

  it('PROP-1c: For any progress in [0,1], value is in range [0, target]', () => {
    fc.assert(fc.property(
      fc.integer({ min: 1, max: 10_000_000 }),
      fc.double({ min: 0, max: 1, noNaN: true }),
      (target, progress) => {
        const value = calculateCounterValue(progress, target);
        expect(value).toBeGreaterThanOrEqual(0);
        expect(value).toBeLessThanOrEqual(target);
      }
    ), { numRuns: 100 });
  });
});
