// ============================================
// AMBARELLA — Global Effects & Animations
// ============================================

// 1. KONFETTI ANIMATSIYA
function showConfetti() {
  const colors = ['#3b82f6','#10b981','#f59e0b','#8b5cf6','#ec4899','#06b6d4'];
  const container = document.createElement('div');
  container.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:99999;overflow:hidden';
  document.body.appendChild(container);
  
  for(let i = 0; i < 80; i++) {
    const piece = document.createElement('div');
    const color = colors[Math.floor(Math.random()*colors.length)];
    const left = Math.random()*100;
    const delay = Math.random()*0.5;
    const size = Math.random()*8+4;
    const rotation = Math.random()*360;
    piece.style.cssText = `position:absolute;top:-20px;left:${left}%;width:${size}px;height:${size*0.6}px;background:${color};border-radius:2px;transform:rotate(${rotation}deg);animation:confettiFall ${2+Math.random()}s ease-in ${delay}s forwards;opacity:0.9`;
    container.appendChild(piece);
  }
  setTimeout(() => container.remove(), 3000);
}

// 2. LOADING SKELETON
function showSkeleton(element) {
  element.classList.add('skeleton-loading');
}
function hideSkeleton(element) {
  element.classList.remove('skeleton-loading');
}

// 3. SUCCESS TOAST WITH ANIMATION
function showToast(message, type = 'success') {
  const existing = document.querySelector('.toast-notification');
  if(existing) existing.remove();
  
  const toast = document.createElement('div');
  toast.className = 'toast-notification toast-' + type;
  const icons = {success:'✓',error:'✕',info:'ℹ',warning:'⚠'};
  toast.innerHTML = `<span class="toast-icon">${icons[type]||'✓'}</span><span>${message}</span>`;
  document.body.appendChild(toast);
  setTimeout(() => toast.classList.add('show'), 10);
  setTimeout(() => {toast.classList.remove('show');setTimeout(()=>toast.remove(),300)}, 3500);
}

// 4. ANIMATED COUNTER
function animateCounter(element, target, duration = 1500) {
  let start = 0;
  const step = target / (duration / 16);
  const timer = setInterval(() => {
    start += step;
    if(start >= target) { start = target; clearInterval(timer); }
    element.textContent = Math.floor(start).toLocaleString();
  }, 16);
}

// 5. TYPEWRITER EFFECT
function typeWriter(element, text, speed = 50) {
  let i = 0;
  element.textContent = '';
  const timer = setInterval(() => {
    element.textContent += text.charAt(i);
    i++;
    if(i >= text.length) clearInterval(timer);
  }, speed);
}

// 6. PROGRESS RING
function drawProgressRing(canvas, percent, color = '#3b82f6') {
  const ctx = canvas.getContext('2d');
  const size = canvas.width;
  const center = size / 2;
  const radius = center - 8;
  const startAngle = -Math.PI / 2;
  const endAngle = startAngle + (2 * Math.PI * percent / 100);
  
  ctx.clearRect(0, 0, size, size);
  // Background circle
  ctx.beginPath();
  ctx.arc(center, center, radius, 0, 2 * Math.PI);
  ctx.strokeStyle = 'rgba(255,255,255,0.06)';
  ctx.lineWidth = 6;
  ctx.stroke();
  // Progress arc
  ctx.beginPath();
  ctx.arc(center, center, radius, startAngle, endAngle);
  ctx.strokeStyle = color;
  ctx.lineWidth = 6;
  ctx.lineCap = 'round';
  ctx.stroke();
  // Center text
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 16px Inter';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(percent + '%', center, center);
}

// 7. INTERSECTION OBSERVER - STAGGERED REVEAL
function initStaggerReveal() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry, index) => {
      if(entry.isIntersecting) {
        setTimeout(() => {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
        }, index * 80);
        observer.unobserve(entry.target);
      }
    });
  }, {threshold: 0.1});
  
  document.querySelectorAll('[data-stagger]').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity .5s ease, transform .5s ease';
    observer.observe(el);
  });
}

// 8. SMOOTH NUMBER INCREMENT ON SCROLL
function initCounterAnimation() {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if(entry.isIntersecting) {
        const el = entry.target;
        const target = parseInt(el.dataset.count || el.textContent.replace(/\D/g,''));
        if(target) animateCounter(el, target);
        observer.unobserve(el);
      }
    });
  });
  document.querySelectorAll('[data-count]').forEach(el => observer.observe(el));
}

// 9. RIPPLE EFFECT ON BUTTONS
function initRipple() {
  document.querySelectorAll('.btn').forEach(btn => {
    btn.addEventListener('click', function(e) {
      const ripple = document.createElement('span');
      const rect = this.getBoundingClientRect();
      ripple.style.cssText = `position:absolute;border-radius:50%;background:rgba(255,255,255,.3);width:0;height:0;left:${e.clientX-rect.left}px;top:${e.clientY-rect.top}px;transform:translate(-50%,-50%);animation:rippleAnim .6s ease-out;pointer-events:none`;
      this.style.position = 'relative';
      this.style.overflow = 'hidden';
      this.appendChild(ripple);
      setTimeout(() => ripple.remove(), 600);
    });
  });
}

// 10. AUTO INIT
document.addEventListener('DOMContentLoaded', () => {
  initStaggerReveal();
  initCounterAnimation();
  initRipple();
  
  // Auto-show confetti on success messages
  const successAlert = document.querySelector('.alert-success');
  if(successAlert && (successAlert.textContent.includes('Bajarildi') || successAlert.textContent.includes('GreenCoin') || successAlert.textContent.includes('Tabriklaymiz'))) {
    setTimeout(showConfetti, 300);
  }
});

// 11. 3D CARD TILT
function init3DTilt() {
  document.querySelectorAll('.tilt-card').forEach(card => {
    card.addEventListener('mousemove', e => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      const rotateX = (y - centerY) / 20;
      const rotateY = (centerX - x) / 20;
      card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-4px)`;
    });
    card.addEventListener('mouseleave', () => {
      card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) translateY(0)';
    });
  });
}

// 12. SOCIAL SHARE
function shareToTelegram(text, url) {
  window.open(`https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`, '_blank');
}
function shareToTwitter(text, url) {
  window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`, '_blank');
}
function copyLink(url) {
  navigator.clipboard.writeText(url || window.location.href).then(() => showToast('Havola nusxalandi!', 'success'));
}

// 13. PARALLAX ON SCROLL
function initParallax() {
  const els = document.querySelectorAll('[data-parallax]');
  if(!els.length) return;
  window.addEventListener('scroll', () => {
    const scrollY = window.scrollY;
    els.forEach(el => {
      const speed = parseFloat(el.dataset.parallax) || 0.3;
      el.style.transform = `translateY(${scrollY * speed}px)`;
    });
  });
}

// 14. CURSOR GLOW (desktop only)
function initCursorGlow() {
  if(window.innerWidth < 768) return;
  const glow = document.createElement('div');
  glow.style.cssText = 'position:fixed;width:200px;height:200px;border-radius:50%;background:radial-gradient(circle,rgba(59,130,246,.06) 0%,transparent 70%);pointer-events:none;z-index:0;transition:transform .1s ease;transform:translate(-50%,-50%)';
  document.body.appendChild(glow);
  document.addEventListener('mousemove', e => {
    glow.style.left = e.clientX + 'px';
    glow.style.top = e.clientY + 'px';
  });
}

// Update AUTO INIT
document.addEventListener('DOMContentLoaded', () => {
  init3DTilt();
  initParallax();
  initCursorGlow();
});

// 15. THEME TOGGLE
function toggleTheme() {
  const current = localStorage.getItem('theme') || 'dark';
  const newTheme = current === 'dark' ? 'light' : 'dark';
  localStorage.setItem('theme', newTheme);
  applyTheme(newTheme);
}

function applyTheme(theme) {
  if(theme === 'light') {
    document.documentElement.style.setProperty('--dark', '#ffffff');
    document.body.style.background = '#f8fafc';
    document.body.style.color = '#1e293b';
    document.documentElement.classList.add('light-mode');
  } else {
    document.documentElement.style.setProperty('--dark', '#0f172a');
    document.body.style.background = '#0f172a';
    document.body.style.color = '#e2e8f0';
    document.documentElement.classList.remove('light-mode');
  }
}

// Apply on load
document.addEventListener('DOMContentLoaded', () => {
  applyTheme(localStorage.getItem('theme') || 'dark');
});

// 16. NOTIFICATION SOUND
function playNotificationSound() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.frequency.value = 800;
    gain.gain.value = 0.1;
    osc.start();
    setTimeout(() => { gain.gain.value = 0; osc.stop(); ctx.close(); }, 150);
  } catch(e) {}
}

// Play on new success toast
const origShowToast = showToast;
showToast = function(message, type) {
  origShowToast(message, type);
  if(type === 'success') playNotificationSound();
};


// 17. NOTIFICATION BADGE
function updateNotificationBadge() {
  const badge = document.getElementById('notifBadge');
  if (!badge) return;
  
  fetch('/api/notifications/unread-count')
    .then(r => r.json())
    .then(data => {
      if (data.count > 0) {
        badge.textContent = data.count > 9 ? '9+' : data.count;
        badge.style.display = 'flex';
      } else {
        badge.style.display = 'none';
      }
    })
    .catch(() => {});
}

// Check every 30 seconds
setInterval(updateNotificationBadge, 30000);
document.addEventListener('DOMContentLoaded', updateNotificationBadge);

// 18. ONLINE USERS COUNTER
function updateOnlineCount() {
  const el = document.getElementById('onlineCount');
  if (!el) return;
  
  fetch('/api/online-count')
    .then(r => r.json())
    .then(data => {
      el.textContent = data.online;
    })
    .catch(() => {});
}

setInterval(updateOnlineCount, 60000);
document.addEventListener('DOMContentLoaded', updateOnlineCount);

// 19. SMOOTH IMAGE LOADING
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('img').forEach(img => {
    if(img.complete) {
      img.classList.add('loaded');
    } else {
      img.addEventListener('load', () => img.classList.add('loaded'));
      img.addEventListener('error', () => img.style.opacity = '0.3');
    }
  });
});

// 20. BACK TO TOP BUTTON
(function(){
  const btn = document.createElement('button');
  btn.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 15l-6-6-6 6"/></svg>';
  btn.style.cssText = 'position:fixed;bottom:140px;right:20px;width:44px;height:44px;border-radius:50%;background:rgba(15,23,42,.9);border:1px solid rgba(255,255,255,.08);color:#94a3b8;display:none;align-items:center;justify-content:center;cursor:pointer;z-index:89;transition:all .3s;backdrop-filter:blur(8px)';
  btn.onmouseover = () => { btn.style.color='#3b82f6'; btn.style.borderColor='rgba(59,130,246,.3)'; btn.style.transform='translateY(-2px)'; };
  btn.onmouseout = () => { btn.style.color='#94a3b8'; btn.style.borderColor='rgba(255,255,255,.08)'; btn.style.transform='translateY(0)'; };
  btn.onclick = () => window.scrollTo({top:0,behavior:'smooth'});
  document.body.appendChild(btn);
  
  window.addEventListener('scroll', () => {
    btn.style.display = window.scrollY > 400 ? 'flex' : 'none';
  });
})();

// 21. COPY TO CLIPBOARD UTILITY
function copyToClipboard(text) {
  navigator.clipboard.writeText(text).then(() => {
    showToast('Nusxalandi!', 'success');
  }).catch(() => {
    // Fallback
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    showToast('Nusxalandi!', 'success');
  });
}

// 22. AUTO-RESIZE TEXTAREA
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('textarea[data-autoresize]').forEach(ta => {
    ta.style.overflow = 'hidden';
    function resize(){ ta.style.height='auto'; ta.style.height=ta.scrollHeight+'px'; }
    ta.addEventListener('input', resize);
    resize();
  });
});

// 23. KEYBOARD SHORTCUTS
document.addEventListener('keydown', (e) => {
  // Ctrl+K = Search
  if((e.ctrlKey || e.metaKey) && e.key === 'k') {
    e.preventDefault();
    window.location.href = '/search';
  }
  // Escape = Close AI chat
  if(e.key === 'Escape') {
    const chatBox = document.getElementById('aiChatBox');
    if(chatBox && chatBox.classList.contains('open')) {
      toggleAiChat();
    }
  }
});

// 24. LAZY LOAD IMAGES
if('IntersectionObserver' in window) {
  const imgObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if(entry.isIntersecting) {
        const img = entry.target;
        if(img.dataset.src) {
          img.src = img.dataset.src;
          img.removeAttribute('data-src');
        }
        imgObserver.unobserve(img);
      }
    });
  });
  document.querySelectorAll('img[data-src]').forEach(img => imgObserver.observe(img));
}
