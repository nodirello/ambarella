// AMBARELLA Multi-language System (UZ/RU/EN)
const T = {
  uz: {
    'nav.home':'Bosh sahifa','nav.jobs':'Bandlik','nav.eco':'Ekologiya','nav.academy':'Academy',
    'nav.mentor':'Mentorlik','nav.farm':'Qishloq','nav.news':'Yangiliklar',
    'nav.login':'Kirish','nav.register':"Ro'yxatdan o'tish",'nav.dashboard':'Dashboard','nav.logout':'Chiqish',
    'bottom.home':'Bosh','bottom.jobs':'Ish','bottom.eco':'Eco','bottom.panel':'Panel',
    'bottom.more':"Ko'proq",'bottom.login':'Kirish',
    'ai.title':'AI Yordamchi','ai.placeholder':'Savolingizni yozing...',
    'ai.greeting':"Salom! Men AMBARELLA AI yordamchisiman. Platforma haqida savollaringiz bo'lsa yozing.",
    'search.placeholder':'Qidirish...','search.btn':'Qidirish',
    'fav.title':'Sevimlilar','fav.empty':"Hali sevimlilar yo'q",
    'business.title':'Biznes panel','business.register':"Biznesni ro'yxatdan o'tkazish",
    'footer.rights':'Barcha huquqlar himoyalangan',
  },
  ru: {
    'nav.home':'Главная','nav.jobs':'Работа','nav.eco':'Экология','nav.academy':'Академия',
    'nav.mentor':'Менторство','nav.farm':'Фермер','nav.news':'Новости',
    'nav.login':'Войти','nav.register':'Регистрация','nav.dashboard':'Панель','nav.logout':'Выйти',
    'bottom.home':'Главная','bottom.jobs':'Работа','bottom.eco':'Эко','bottom.panel':'Панель',
    'bottom.more':'Ещё','bottom.login':'Войти',
    'ai.title':'AI Помощник','ai.placeholder':'Задайте вопрос...',
    'ai.greeting':'Привет! Я AI помощник AMBARELLA. Спросите о платформе.',
    'search.placeholder':'Поиск...','search.btn':'Найти',
    'fav.title':'Избранное','fav.empty':'Пока нет избранного',
    'business.title':'Бизнес панель','business.register':'Зарегистрировать бизнес',
    'footer.rights':'Все права защищены',
  },
  en: {
    'nav.home':'Home','nav.jobs':'Jobs','nav.eco':'Ecology','nav.academy':'Academy',
    'nav.mentor':'Mentoring','nav.farm':'Farm','nav.news':'News',
    'nav.login':'Login','nav.register':'Register','nav.dashboard':'Dashboard','nav.logout':'Logout',
    'bottom.home':'Home','bottom.jobs':'Jobs','bottom.eco':'Eco','bottom.panel':'Panel',
    'bottom.more':'More','bottom.login':'Login',
    'ai.title':'AI Assistant','ai.placeholder':'Type your question...',
    'ai.greeting':"Hi! I'm AMBARELLA AI assistant. Ask me anything about the platform.",
    'search.placeholder':'Search...','search.btn':'Search',
    'fav.title':'Favorites','fav.empty':'No favorites yet',
    'business.title':'Business Panel','business.register':'Register Business',
    'footer.rights':'All rights reserved',
  }
};

function getLang(){return localStorage.getItem('ambarella_lang')||'uz'}
function setLang(lang){
  localStorage.setItem('ambarella_lang',lang);
  applyLang(lang);
  document.querySelectorAll('.lang-btn').forEach(b=>b.classList.toggle('active',b.dataset.lang===lang));
}
function applyLang(lang){
  const t=T[lang]||T.uz;
  document.querySelectorAll('[data-i18n]').forEach(el=>{const k=el.dataset.i18n;if(t[k])el.textContent=t[k]});
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el=>{const k=el.dataset.i18nPlaceholder;if(t[k])el.placeholder=t[k]});
}
document.addEventListener('DOMContentLoaded',()=>applyLang(getLang()));
