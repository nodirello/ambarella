const CACHE_NAME = 'ambarella-v1';
const OFFLINE_URL = '/offline';

// Keshlanadigan asosiy resurslar
const PRECACHE_URLS = [
  '/',
  '/offline',
  '/assets/icons/favicon.svg',
  '/assets/icons/icon-192.png',
  '/assets/icons/icon-512.png',
];

// O'rnatish
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(PRECACHE_URLS))
  );
  self.skipWaiting();
});

// Faollashtirish — eski keshlarni o'chirish
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => 
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// So'rovlarni boshqarish — Network First strategiyasi
self.addEventListener('fetch', event => {
  // Faqat GET so'rovlar
  if (event.request.method !== 'GET') return;

  // API va auth so'rovlarini keshlamaymiz
  const url = new URL(event.request.url);
  if (url.pathname.startsWith('/admin') || 
      url.pathname.startsWith('/login') || 
      url.pathname.startsWith('/register') ||
      url.pathname.startsWith('/webhook')) return;

  event.respondWith(
    fetch(event.request)
      .then(response => {
        // Muvaffaqiyatli javobni keshlash
        if (response.status === 200) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
        }
        return response;
      })
      .catch(() => {
        // Offline — keshdan qaytarish
        return caches.match(event.request).then(cached => {
          if (cached) return cached;
          // Navigatsiya so'rovi bo'lsa offline sahifa
          if (event.request.mode === 'navigate') {
            return caches.match('/offline');
          }
        });
      })
  );
});

// Push notification qabul qilish
self.addEventListener('push', event => {
  const data = event.data ? event.data.json() : {};
  const title = data.title || 'AMBARELLA';
  const options = {
    body: data.body || 'Yangi xabar bor!',
    icon: '/assets/icons/icon-192.png',
    badge: '/assets/icons/favicon-32.png',
    vibrate: [100, 50, 100],
    data: { url: data.url || '/' },
    actions: [
      { action: 'open', title: 'Ochish' },
      { action: 'close', title: 'Yopish' }
    ]
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

// Notification bosilganda
self.addEventListener('notificationclick', event => {
  event.notification.close();
  const url = event.notification.data?.url || '/';
  event.waitUntil(
    clients.matchAll({ type: 'window' }).then(windowClients => {
      // Ochiq oyna bormi?
      for (const client of windowClients) {
        if (client.url.includes(url) && 'focus' in client) return client.focus();
      }
      return clients.openWindow(url);
    })
  );
});
