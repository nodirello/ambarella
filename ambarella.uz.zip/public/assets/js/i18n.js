/**
 * AMBARELLA — Ko'p tilli tizim (UZ/RU/EN)
 * Foydalanish: HTML elementlarga data-i18n="key" qo'shing
 * Til tanlash: setLang('uz') | setLang('ru') | setLang('en')
 */

const translations = {
  uz: {
    // Header & Nav
    "nav.home": "Bosh sahifa",
    "nav.jobs": "Bandlik",
    "nav.eco": "Ekologiya",
    "nav.academy": "Academy",
    "nav.mentor": "Mentorlik",
    "nav.news": "Yangiliklar",
    "nav.login": "Kirish",
    "nav.register": "Ro'yxatdan o'tish",
    "nav.dashboard": "Dashboard",
    "nav.profile": "Profil",
    "nav.logout": "Chiqish",
    "nav.admin": "Admin",

    // Hero
    "hero.badge": "O'zbekiston yoshlari uchun",
    "hero.title": "Kelajagingizni",
    "hero.title.brand": "AMBARELLA",
    "hero.title.end": "bilan quring",
    "hero.desc": "Bandlik, ekologiya, ta'lim, mentorlik va AI yordamchi — barcha imkoniyatlar bitta platformada.",
    "hero.cta": "Platformaga kirish",
    "hero.cta2": "Modullarni ko'rish",
    "hero.stat.users": "Foydalanuvchilar",
    "hero.stat.jobs": "Ish o'rinlari",
    "hero.stat.modules": "Modullar",

    // How it works
    "how.title": "Qanday ishlaydi?",
    "how.desc": "Uch oddiy qadamda platformadan foydalanishni boshlang",
    "how.step1.title": "Ro'yxatdan o'ting",
    "how.step1.desc": "Email yoki Telegram orqali 1 daqiqada hisob yarating",
    "how.step2.title": "Modulni tanlang",
    "how.step2.desc": "28 moduldan sizga keraklisini tanlang",
    "how.step3.title": "Natijaga erishing",
    "how.step3.desc": "Ish toping, kurs tamomlag, GreenCoin yig'ing",

    // Modules
    "modules.title": "Platformaning asosiy modullari",
    "modules.desc": "28 ta modul yagona ekotizimda",

    // Features
    "features.title": "Nima uchun AMBARELLA?",
    "features.desc": "O'zbekiston yoshlari uchun maxsus ishlab chiqilgan",
    "features.free.title": "Bepul va xavfsiz",
    "features.free.desc": "Barcha xizmatlar bepul. Ma'lumotlar shifrlangan.",
    "features.lang.title": "O'zbek tilida",
    "features.lang.desc": "To'liq o'zbek tilida. UZ/RU/EN qo'llab-quvvatlanadi.",
    "features.ai.title": "AI yordamchi",
    "features.ai.desc": "Sun'iy intellekt orqali shaxsiy tavsiyalar.",
    "features.gc.title": "GreenCoin tizimi",
    "features.gc.desc": "Ekologik faoliyat uchun raqamli mukofotlar.",
    "features.mobile.title": "Mobil qulay",
    "features.mobile.desc": "Har qanday qurilmada mukammal ishlaydi.",
    "features.mentor.title": "Mentorlik",
    "features.mentor.desc": "Soha mutaxassislaridan karyera maslahatlari.",

    // Eco
    "eco.title": "Yashil kelajak — birga quramiz",
    "eco.desc": "Ekologik faoliyat orqali GreenCoin yig'ing",
    "eco.stat1": "Eko-harakatlar",
    "eco.stat2": "Tejilgan CO₂",
    "eco.stat3": "GreenCoin",
    "eco.cta": "Ekologiya moduli",

    // Jobs
    "jobs.title": "So'nggi ish e'lonlari",
    "jobs.desc": "Eng yangi ish imkoniyatlari",
    "jobs.all": "Barcha ish e'lonlari",

    // FAQ
    "faq.title": "Ko'p beriladigan savollar",
    "faq.desc": "Platforma haqida savollar va javoblar",
    "faq.q1": "AMBARELLA platformasi nima?",
    "faq.a1": "O'zbekiston yoshlari uchun bandlik, ekologiya, ta'lim, mentorlik va AI yordamchi xizmatlarni yagona interfeys orqali taqdim etuvchi raqamli ekotizim. 28 modul bitta joyda.",
    "faq.q2": "GreenCoin nima?",
    "faq.a2": "Ekologik faoliyat uchun beriladigan raqamli mukofot tokeni. Vazifalarni bajaring — coin yig'ing — imtiyozlarga aylantiring.",
    "faq.q3": "Platformada ish topish mumkinmi?",
    "faq.a3": "Ha! 1200+ ish e'lonlari. Ish turi, joylashuv, maosh bo'yicha filtr. AI sizga mos ish tavsiya qiladi.",
    "faq.q4": "Platforma bepulmi?",
    "faq.a4": "Ha, barcha asosiy xizmatlar bepul. Yashirin to'lovlar yo'q.",

    // Footer
    "footer.platform": "Platforma",
    "footer.resources": "Resurslar",
    "footer.contact": "Aloqa",
    "footer.copy": "© 2026 SADAF DEV | AMBARELLA | Barcha huquqlar himoyalangan"
  },

  ru: {
    "nav.home": "Главная",
    "nav.jobs": "Работа",
    "nav.eco": "Экология",
    "nav.academy": "Академия",
    "nav.mentor": "Менторство",
    "nav.news": "Новости",
    "nav.login": "Войти",
    "nav.register": "Регистрация",
    "nav.dashboard": "Панель",
    "nav.profile": "Профиль",
    "nav.logout": "Выйти",
    "nav.admin": "Админ",

    "hero.badge": "Для молодёжи Узбекистана",
    "hero.title": "Постройте будущее с",
    "hero.title.brand": "AMBARELLA",
    "hero.title.end": "",
    "hero.desc": "Трудоустройство, экология, образование, менторство и AI-помощник — все возможности на одной платформе.",
    "hero.cta": "Войти на платформу",
    "hero.cta2": "Смотреть модули",
    "hero.stat.users": "Пользователей",
    "hero.stat.jobs": "Вакансий",
    "hero.stat.modules": "Модулей",

    "how.title": "Как это работает?",
    "how.desc": "Начните пользоваться платформой за три простых шага",
    "how.step1.title": "Зарегистрируйтесь",
    "how.step1.desc": "Создайте аккаунт через Email или Telegram за 1 минуту",
    "how.step2.title": "Выберите модуль",
    "how.step2.desc": "Выберите нужный из 28 модулей",
    "how.step3.title": "Достигайте результатов",
    "how.step3.desc": "Найдите работу, закончите курс, копите GreenCoin",

    "modules.title": "Основные модули платформы",
    "modules.desc": "28 модулей в единой экосистеме",

    "features.title": "Почему AMBARELLA?",
    "features.desc": "Специально разработано для молодёжи Узбекистана",
    "features.free.title": "Бесплатно и безопасно",
    "features.free.desc": "Все услуги бесплатны. Данные зашифрованы.",
    "features.lang.title": "На узбекском языке",
    "features.lang.desc": "Полностью на узбекском. Поддержка UZ/RU/EN.",
    "features.ai.title": "AI-помощник",
    "features.ai.desc": "Персональные рекомендации через искусственный интеллект.",
    "features.gc.title": "Система GreenCoin",
    "features.gc.desc": "Цифровые награды за экологическую активность.",
    "features.mobile.title": "Удобно на мобильных",
    "features.mobile.desc": "Отлично работает на любом устройстве.",
    "features.mentor.title": "Менторство",
    "features.mentor.desc": "Карьерные советы от экспертов отрасли.",

    "eco.title": "Зелёное будущее — строим вместе",
    "eco.desc": "Копите GreenCoin через экологическую активность",
    "eco.stat1": "Эко-действий",
    "eco.stat2": "Сэкономлено CO₂",
    "eco.stat3": "GreenCoin",
    "eco.cta": "Модуль экологии",

    "jobs.title": "Последние вакансии",
    "jobs.desc": "Новейшие возможности трудоустройства",
    "jobs.all": "Все вакансии",

    "faq.title": "Часто задаваемые вопросы",
    "faq.desc": "Вопросы и ответы о платформе",
    "faq.q1": "Что такое платформа AMBARELLA?",
    "faq.a1": "Цифровая экосистема, предоставляющая услуги трудоустройства, экологии, образования, менторства и AI-помощника через единый интерфейс для молодёжи Узбекистана. 28 модулей в одном месте.",
    "faq.q2": "Что такое GreenCoin?",
    "faq.a2": "Цифровой токен вознаграждения за экологическую активность. Выполняйте задания — копите коины — обменивайте на привилегии.",
    "faq.q3": "Можно ли найти работу на платформе?",
    "faq.a3": "Да! 1200+ вакансий. Фильтры по типу, расположению, зарплате. AI рекомендует подходящие вакансии.",
    "faq.q4": "Платформа бесплатная?",
    "faq.a4": "Да, все основные услуги бесплатны. Скрытых платежей нет.",

    "footer.platform": "Платформа",
    "footer.resources": "Ресурсы",
    "footer.contact": "Контакты",
    "footer.copy": "© 2026 SADAF DEV | AMBARELLA | Все права защищены"
  },

  en: {
    "nav.home": "Home",
    "nav.jobs": "Jobs",
    "nav.eco": "Ecology",
    "nav.academy": "Academy",
    "nav.mentor": "Mentorship",
    "nav.news": "News",
    "nav.login": "Login",
    "nav.register": "Sign Up",
    "nav.dashboard": "Dashboard",
    "nav.profile": "Profile",
    "nav.logout": "Logout",
    "nav.admin": "Admin",

    "hero.badge": "For Uzbekistan's Youth",
    "hero.title": "Build your future with",
    "hero.title.brand": "AMBARELLA",
    "hero.title.end": "",
    "hero.desc": "Employment, ecology, education, mentorship and AI assistant — all opportunities on one platform.",
    "hero.cta": "Enter Platform",
    "hero.cta2": "View Modules",
    "hero.stat.users": "Users",
    "hero.stat.jobs": "Job Listings",
    "hero.stat.modules": "Modules",

    "how.title": "How does it work?",
    "how.desc": "Start using the platform in three simple steps",
    "how.step1.title": "Sign Up",
    "how.step1.desc": "Create an account via Email or Telegram in 1 minute",
    "how.step2.title": "Choose a Module",
    "how.step2.desc": "Select what you need from 28 modules",
    "how.step3.title": "Achieve Results",
    "how.step3.desc": "Find a job, complete a course, earn GreenCoin",

    "modules.title": "Platform's Core Modules",
    "modules.desc": "28 modules in a unified ecosystem",

    "features.title": "Why AMBARELLA?",
    "features.desc": "Specifically designed for Uzbekistan's youth",
    "features.free.title": "Free & Secure",
    "features.free.desc": "All services are free. Data is encrypted.",
    "features.lang.title": "In Uzbek Language",
    "features.lang.desc": "Fully in Uzbek. UZ/RU/EN supported.",
    "features.ai.title": "AI Assistant",
    "features.ai.desc": "Personalized recommendations through artificial intelligence.",
    "features.gc.title": "GreenCoin System",
    "features.gc.desc": "Digital rewards for ecological activity.",
    "features.mobile.title": "Mobile Friendly",
    "features.mobile.desc": "Works perfectly on any device.",
    "features.mentor.title": "Mentorship",
    "features.mentor.desc": "Career advice from industry experts.",

    "eco.title": "Green Future — Building Together",
    "eco.desc": "Earn GreenCoin through ecological activity",
    "eco.stat1": "Eco-Actions",
    "eco.stat2": "CO₂ Saved",
    "eco.stat3": "GreenCoin",
    "eco.cta": "Ecology Module",

    "jobs.title": "Latest Job Listings",
    "jobs.desc": "Newest employment opportunities",
    "jobs.all": "All Job Listings",

    "faq.title": "Frequently Asked Questions",
    "faq.desc": "Questions and answers about the platform",
    "faq.q1": "What is the AMBARELLA platform?",
    "faq.a1": "A digital ecosystem providing employment, ecology, education, mentorship and AI assistant services through a unified interface for Uzbekistan's youth. 28 modules in one place.",
    "faq.q2": "What is GreenCoin?",
    "faq.a2": "A digital reward token for ecological activity. Complete tasks — earn coins — exchange for privileges.",
    "faq.q3": "Can I find a job on the platform?",
    "faq.a3": "Yes! 1200+ job listings. Filter by type, location, salary. AI recommends suitable vacancies.",
    "faq.q4": "Is the platform free?",
    "faq.a4": "Yes, all core services are free. No hidden fees.",

    "footer.platform": "Platform",
    "footer.resources": "Resources",
    "footer.contact": "Contact",
    "footer.copy": "© 2026 SADAF DEV | AMBARELLA | All rights reserved"
  }
};

// Current language
let currentLang = localStorage.getItem('ambarella_lang') || 'uz';

/**
 * Set language and update all elements with data-i18n
 */
function setLang(lang) {
  if (!translations[lang]) return;
  currentLang = lang;
  localStorage.setItem('ambarella_lang', lang);
  document.documentElement.lang = lang;

  // Update all elements with data-i18n attribute
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    const text = translations[lang][key];
    if (text) {
      if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
        el.placeholder = text;
      } else {
        el.textContent = text;
      }
    }
  });

  // Update lang button text
  const langBtns = document.querySelectorAll('.lang-switcher .lang-opt');
  langBtns.forEach(btn => {
    const isActive = btn.dataset.lang === lang;
    btn.classList.toggle('active', isActive);
    btn.style.background = isActive ? 'rgba(37,99,235,.15)' : 'rgba(255,255,255,.03)';
    btn.style.color = isActive ? '#93c5fd' : '#64748b';
    btn.style.borderColor = isActive ? 'rgba(37,99,235,.3)' : 'rgba(255,255,255,.08)';
  });

  // Update active lang display
  const langDisplay = document.querySelector('.lang-current');
  if (langDisplay) langDisplay.textContent = lang.toUpperCase();
}

/**
 * Get translation by key
 */
function t(key) {
  return translations[currentLang]?.[key] || translations['uz'][key] || key;
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
  setLang(currentLang);
});
