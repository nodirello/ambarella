# Performance Optimallashtirish Tekshiruv Ro'yxati — AMBARELLA HTML MVP

> **Sana:** 2026-01-30
> **Versiya:** 1.0.0
> **Maqsad:** Lighthouse Performance Score ≥ 90

---

## Tekshiruv Xulosasi

| Mezon | Holat | Izoh |
|-------|-------|------|
| Lazy loading (rasmlar) | ✅ Qo'llanilgan | Hero dan tashqari barcha `<img>` |
| Script `defer` / `type="module"` | ✅ Qo'llanilgan | Barcha JS fayllar |
| `<link rel="preload">` | ✅ Qo'llanilgan | Font va hero rasm |
| WebP format havola | ✅ Qo'llanilgan | Barcha rasm manbalar |
| Critical CSS inline | ✅ Qo'llanilgan | `<style>` tegida hero/above-fold |
| Service Worker caching | ✅ Qo'llanilgan | Cache-first strategiya |
| CDN `integrity` + `crossorigin` | ✅ Qo'llanilgan | Bootstrap, AOS, Swiper |
| SVG sprite (HTTP so'rovlar kamayishi) | ✅ Qo'llanilgan | `assets/icons/sprite.svg` |

---

## 1. Rasm Optimallashtirish

### Lazy Loading
```html
<!-- Hero rasmi — preload (above-fold) -->
<link rel="preload" as="image" href="/assets/images/hero.webp" fetchpriority="high">

<!-- Boshqa rasmlar — lazy loading -->
<img src="/assets/images/card.webp" loading="lazy" alt="..." width="400" height="300">
```

**Qoidalar:**
- ✅ Hero seksiyasidagi rasm: `fetchpriority="high"` + preload
- ✅ Below-fold barcha rasmlar: `loading="lazy"`
- ✅ Barcha rasmlarda `width` va `height` atributlari (CLS oldini olish)
- ✅ WebP format havola (fallback uchun SVG/PNG)

### Rasm Formati
| Format | Ishlatilish joyi | Siqilish |
|--------|-----------------|----------|
| WebP | Fotosuratlar, thumbnaillar | Lossy 80% |
| SVG | Ikonkalar, logolar, illustratsiyalar | Vektorli |
| PNG | Favicon, app ikonkalar | Lossless |

---

## 2. JavaScript Optimallashtirish

### Defer va Module
```html
<!-- Barcha skriptlar defer yoki module bilan -->
<script src="/assets/js/main.js" type="module" defer></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        defer integrity="sha384-..." crossorigin="anonymous"></script>
```

**Qoidalar:**
- ✅ Hech bir `<script>` render-blocking emas
- ✅ `type="module"` — o'z JS fayllari uchun
- ✅ `defer` — tashqi kutubxonalar uchun
- ✅ `async` ishlatilmaydi (tartib muhim)

### AbortController (API Timeout)
```javascript
// api.js da 10s timeout
const controller = new AbortController();
const timeout = setTimeout(() => controller.abort(), 10000);
```

---

## 3. CSS Optimallashtirish

### Critical CSS Inline
```html
<style>
  /* Above-fold uchun minimal CSS — ~2KB */
  :root { --color-primary: #2563EB; --color-bg: #FFFFFF; ... }
  body { font-family: 'Inter', sans-serif; }
  .hero { min-height: 100vh; }
</style>
```

### Asinxron CSS Yuklash
```html
<!-- Non-critical CSS -->
<link rel="stylesheet" href="/assets/css/animations.css" media="print" onload="this.media='all'">
<noscript><link rel="stylesheet" href="/assets/css/animations.css"></noscript>
```

**Qoidalar:**
- ✅ Critical CSS `<style>` tegida inline
- ✅ Non-critical CSS asinxron yuklash
- ✅ CSS Custom Properties — runtime tema o'zgartirish
- ✅ `will-change` faqat animatsiya bo'lgan elementlarda

---

## 4. Font Optimallashtirish

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap">
```

**Qoidalar:**
- ✅ `font-display: swap` — FOIT oldini olish
- ✅ `preconnect` — DNS lookup tezlashtirish
- ✅ Faqat kerakli font vaznlari (400, 500, 600, 700, 800)

---

## 5. Caching Strategiyasi (Service Worker)

```javascript
// service-worker.js
// Cache-first strategiya statik aktivlar uchun
const CACHE_NAME = 'ambarella-v1';
const STATIC_ASSETS = [
  '/', '/assets/css/base.css', '/assets/js/main.js',
  '/assets/icons/sprite.svg', '/manifest.json'
];
```

**Cache siyosati:**
| Resurs turi | Strategiya | Muddati |
|-------------|-----------|---------|
| HTML sahifalar | Network-first | Har doim yangi |
| CSS/JS | Cache-first | Versiya o'zgarganda |
| Rasmlar | Cache-first | 30 kun |
| Shriftlar | Cache-first | 1 yil |
| API (mock JSON) | Network-first | Fallback cache |

---

## 6. Tashqi Kutubxonalar

| Kutubxona | Yuklash | Integrity | Crossorigin |
|-----------|---------|-----------|-------------|
| Bootstrap 5.3.3 CSS | `<link>` preload | ✅ | ✅ |
| Bootstrap 5.3.3 JS | `defer` | ✅ | ✅ |
| AOS 2.3.4 CSS | `<link>` | ✅ | ✅ |
| AOS 2.3.4 JS | `defer` | ✅ | ✅ |
| Swiper 11.x | `defer` | ✅ | ✅ |
| Chart.js 4.x | `defer` (faqat analytics) | ✅ | ✅ |

---

## 7. Video Optimallashtirish

- ✅ `autoplay` ishlatilmaydi
- ✅ Poster rasm ko'rsatiladi (`loading="lazy"`)
- ✅ Video modal orqali ochiladi (sahifa og'irligini kamaytirish)
- ✅ `preload="none"` yoki `preload="metadata"`

---

## 8. CLS (Cumulative Layout Shift) Oldini Olish

- ✅ Rasmlar `width`/`height` yoki `aspect-ratio` bilan
- ✅ Shriftlar `font-display: swap` bilan
- ✅ Skeleton loading — kontent o'rnini oldindan band qilish
- ✅ Fixed header — `padding-top` body ga qo'shilgan
