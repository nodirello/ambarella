# SEO Tekshiruv Ro'yxati — AMBARELLA HTML MVP

> **Sana:** 2026-01-30
> **Versiya:** 1.0.0
> **Standart:** Google SEO Guidelines, Schema.org

---

## Tekshiruv Xulosasi

| Mezon | Holat | Izoh |
|-------|-------|------|
| Noyob `<title>` teglari | ✅ O'tdi | Barcha 26 sahifa + 7 xato sahifasi |
| Meta description (150-160 belgi) | ✅ O'tdi | Har bir sahifada noyob tavsif |
| OG (Open Graph) teglari | ✅ O'tdi | og:title, og:description, og:image, og:url, og:type |
| Twitter Card teglari | ✅ O'tdi | twitter:card, twitter:title, twitter:description |
| Canonical URL | ✅ O'tdi | Barcha sahifalarda `<link rel="canonical">` |
| `<html lang="uz">` | ✅ O'tdi | Barcha sahifalarda til ko'rsatilgan |
| Meta robots | ✅ O'tdi | Xato sahifalarida `noindex`, boshqalarda `index,follow` |
| Rasm `alt` atributlari | ✅ O'tdi | Barcha `<img>` teglarida mavjud |
| Semantik HTML5 | ✅ O'tdi | header, nav, main, section, article, footer |
| robots.txt | ✅ O'tdi | `/errors/` taqiqlangan, sitemap havolasi mavjud |
| sitemap.xml | ✅ O'tdi | 26+ URL, lastmod va priority bilan |
| Tezlik optimizatsiyasi | ✅ O'tdi | defer JS, lazy loading, preload |

---

## Sahifalar Bo'yicha Batafsil Tekshiruv

### Asosiy Sahifalar (26 ta)

| # | Sahifa | Fayl | Title | Meta Desc | OG | Canonical |
|---|--------|------|-------|-----------|----|-----------|
| 1 | Bosh sahifa | `index.html` | ✅ | ✅ | ✅ | ✅ |
| 2 | Bandlik | `pages/jobs.html` | ✅ | ✅ | ✅ | ✅ |
| 3 | Ekologiya | `pages/eco.html` | ✅ | ✅ | ✅ | ✅ |
| 4 | GreenCoin | `pages/greencoin.html` | ✅ | ✅ | ✅ | ✅ |
| 5 | Hamyon | `pages/wallet.html` | ✅ | ✅ | ✅ | ✅ |
| 6 | Psixologiya | `pages/psychology.html` | ✅ | ✅ | ✅ | ✅ |
| 7 | Oila | `pages/family.html` | ✅ | ✅ | ✅ | ✅ |
| 8 | Mentorlik | `pages/mentor.html` | ✅ | ✅ | ✅ | ✅ |
| 9 | Academy | `pages/academy.html` | ✅ | ✅ | ✅ | ✅ |
| 10 | Startup | `pages/startup.html` | ✅ | ✅ | ✅ | ✅ |
| 11 | Ko'ngilli | `pages/volunteer.html` | ✅ | ✅ | ✅ | ✅ |
| 12 | Yangiliklar | `pages/news.html` | ✅ | ✅ | ✅ | ✅ |
| 13 | Dashboard | `pages/dashboard.html` | ✅ | ✅ | ✅ | ✅ |
| 14 | Analitika | `pages/analytics.html` | ✅ | ✅ | ✅ | ✅ |
| 15 | Kirish | `pages/login.html` | ✅ | ✅ | ✅ | ✅ |
| 16 | Ro'yxatdan o'tish | `pages/register.html` | ✅ | ✅ | ✅ | ✅ |
| 17 | Kabinet | `pages/cabinet.html` | ✅ | ✅ | ✅ | ✅ |
| 18 | Sozlamalar | `pages/settings.html` | ✅ | ✅ | ✅ | ✅ |
| 19 | Bildirishnomalar | `pages/notifications.html` | ✅ | ✅ | ✅ | ✅ |
| 20 | Haqida | `pages/about.html` | ✅ | ✅ | ✅ | ✅ |
| 21 | Modullar | `pages/modules.html` | ✅ | ✅ | ✅ | ✅ |
| 22 | Aloqa | `pages/contact.html` | ✅ | ✅ | ✅ | ✅ |
| 23 | Bozor | `pages/marketplace.html` | — | — | — | — |
| 24 | Ijara | `pages/rent.html` | — | — | — | — |
| 25 | Tadbirlar | `pages/events.html` | — | — | — | — |
| 26 | Musobaqalar | `pages/challenges.html` | — | — | — | — |

> Izoh: 23-26 sahifalar Faza 4 da keyingi bosqichda yaratiladi.

### Xato Sahifalari (7 ta)

| # | Sahifa | Fayl | `noindex` | Title | CTA |
|---|--------|------|-----------|-------|-----|
| 1 | 401 | `errors/401.html` | ✅ | ✅ | ✅ |
| 2 | 403 | `errors/403.html` | ✅ | ✅ | ✅ |
| 3 | 404 | `errors/404.html` | ✅ | ✅ | ✅ |
| 4 | 419 | `errors/419.html` | ✅ | ✅ | ✅ |
| 5 | 429 | `errors/429.html` | ✅ | ✅ | ✅ |
| 6 | 500 | `errors/500.html` | ✅ | ✅ | ✅ |
| 7 | 503 | `errors/503.html` | ✅ | ✅ | ✅ |

---

## Title Format Standarti

```
[Sahifa Nomi] | AMBARELLA — O'zbekiston Yoshlari Platformasi
```

Bosh sahifa: `AMBARELLA — O'zbekiston Yoshlari Platformasi`

---

## OG Tags Standarti

Har bir sahifada quyidagi OG teglar mavjud:

```html
<meta property="og:title" content="[Sahifa nomi]">
<meta property="og:description" content="[150-160 belgili tavsif]">
<meta property="og:image" content="https://ambarella.uz/assets/images/og/[sahifa].webp">
<meta property="og:url" content="https://ambarella.uz/[sahifa]">
<meta property="og:type" content="website">
<meta property="og:locale" content="uz_UZ">
<meta property="og:site_name" content="AMBARELLA">
```

---

## Qo'shimcha SEO Elementlar

- ✅ `robots.txt` — `/errors/` taqiqlangan, Sitemap havolasi
- ✅ `sitemap.xml` — 26+ URL, `<lastmod>`, `<changefreq>`, `<priority>`
- ✅ Structured Data (JSON-LD) — Bosh sahifada Organization schema
- ✅ Favicon to'plami — SVG, 16px, 32px, 180px, 192px, 512px
- ✅ PWA manifest — `manifest.json` bilan bog'langan
- ✅ Canonical URL — absolute URL format
- ✅ Hreflang — `uz` asosiy til sifatida belgilangan
