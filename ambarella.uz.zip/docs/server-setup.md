# AMBARELLA Laravel — Server O'rnatish Qo'llanmasi

## SSH orqali serverga ulanish

```bash
ssh root@YOUR_SERVER_IP
# yoki
ssh username@ambarella.uz
```

## 1-qadam: Laravel o'rnatish

```bash
cd /var/www/ambarella.uz

# Eski index.html ni o'chirish (yoki backup)
mv index.html index_old.html

# Composer orqali Laravel o'rnatish
composer create-project laravel/laravel . --prefer-dist

# Ruxsatlar
chmod -R 775 storage bootstrap/cache
chown -R www-data:www-data storage bootstrap/cache
```

## 2-qadam: .env sozlash

```bash
nano .env
```

Quyidagilarni o'zgartiring:
```env
APP_NAME=AMBARELLA
APP_ENV=production
APP_DEBUG=false
APP_URL=https://ambarella.uz

DB_CONNECTION=mysql
DB_HOST=localhost
DB_PORT=3306
DB_DATABASE=sizning_baza_nomi
DB_USERNAME=sizning_user
DB_PASSWORD=sizning_parol
```

## 3-qadam: Kalit generatsiya va migratsiya

```bash
php artisan key:generate
php artisan migrate
php artisan storage:link
```

## 4-qadam: Veb-server sozlash

ISPmanager da domen uchun "Document Root" ni o'zgartiring:
```
/var/www/ambarella.uz/public
```

Yoki `.htaccess` fayil root papkaga qo'ying (pastda tayyor).

## 5-qadam: Tekshirish

Brauzerda `https://ambarella.uz` oching — Laravel welcome sahifasi ko'rinishi kerak.

---

## Muammo bo'lsa:

**500 xato:** 
```bash
php artisan config:clear
php artisan cache:clear
chmod -R 775 storage
```

**Composer topilmadi:**
```bash
php -r "copy('https://getcomposer.org/installer', 'composer-setup.php');"
php composer-setup.php --install-dir=/usr/local/bin --filename=composer
```
