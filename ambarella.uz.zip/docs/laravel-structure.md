# AMBARELLA — Laravel Backend Tuzilishi

## O'rnatish

```bash
composer create-project laravel/laravel ambarella-backend
cd ambarella-backend
```

## Papka tuzilishi

```
ambarella-backend/
├── app/
│   ├── Http/
│   │   ├── Controllers/
│   │   │   ├── AuthController.php        # Login, Register, Logout
│   │   │   ├── JobController.php         # Ish e'lonlari CRUD
│   │   │   ├── EcoController.php         # Ekologik vazifalar
│   │   │   ├── GreenCoinController.php   # GreenCoin tranzaksiyalar
│   │   │   ├── CourseController.php      # Academy kurslar
│   │   │   ├── MentorController.php      # Mentorlik
│   │   │   ├── StartupController.php     # Startuplar
│   │   │   ├── MarketplaceController.php # Bozor mahsulotlar
│   │   │   ├── RentController.php        # Ijara e'lonlari
│   │   │   ├── EventController.php       # Tadbirlar
│   │   │   ├── ChallengeController.php   # Musobaqalar
│   │   │   ├── NewsController.php        # Yangiliklar
│   │   │   ├── DashboardController.php   # Dashboard
│   │   │   └── ProfileController.php     # Profil/Kabinet
│   │   └── Middleware/
│   │       └── EnsureAuthenticated.php
│   └── Models/
│       ├── User.php
│       ├── Job.php
│       ├── EcoTask.php
│       ├── GreenCoinTransaction.php
│       ├── Course.php
│       ├── Mentor.php
│       ├── Startup.php
│       ├── Product.php
│       ├── RentListing.php
│       ├── Event.php
│       ├── Challenge.php
│       └── News.php
├── database/
│   └── migrations/
│       ├── create_users_table.php
│       ├── create_jobs_table.php
│       ├── create_eco_tasks_table.php
│       ├── create_greencoin_transactions_table.php
│       ├── create_courses_table.php
│       ├── create_mentors_table.php
│       └── ...
├── routes/
│   ├── web.php          # Sahifa route'lari
│   └── api.php          # API route'lari (JSON)
└── resources/
    └── views/           # Blade shablonlari (yoki SPA)
```

## API Route'lari (`routes/api.php`)

```php
Route::prefix('v1')->group(function () {
    // Auth
    Route::post('/register', [AuthController::class, 'register']);
    Route::post('/login', [AuthController::class, 'login']);
    Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth:sanctum');

    // Jobs
    Route::get('/jobs', [JobController::class, 'index']);
    Route::get('/jobs/{id}', [JobController::class, 'show']);
    Route::post('/jobs/{id}/apply', [JobController::class, 'apply'])->middleware('auth:sanctum');

    // Eco
    Route::get('/eco/tasks', [EcoController::class, 'tasks']);
    Route::post('/eco/tasks/{id}/complete', [EcoController::class, 'complete'])->middleware('auth:sanctum');
    Route::get('/eco/stats', [EcoController::class, 'stats']);

    // GreenCoin
    Route::get('/greencoin/balance', [GreenCoinController::class, 'balance'])->middleware('auth:sanctum');
    Route::get('/greencoin/transactions', [GreenCoinController::class, 'transactions'])->middleware('auth:sanctum');
    Route::get('/greencoin/leaderboard', [GreenCoinController::class, 'leaderboard']);

    // Courses
    Route::get('/courses', [CourseController::class, 'index']);
    Route::get('/courses/{id}', [CourseController::class, 'show']);
    Route::post('/courses/{id}/enroll', [CourseController::class, 'enroll'])->middleware('auth:sanctum');

    // Mentors
    Route::get('/mentors', [MentorController::class, 'index']);
    Route::post('/mentors/{id}/request', [MentorController::class, 'request'])->middleware('auth:sanctum');

    // Marketplace
    Route::get('/products', [MarketplaceController::class, 'index']);
    Route::post('/cart/add', [MarketplaceController::class, 'addToCart'])->middleware('auth:sanctum');

    // News
    Route::get('/news', [NewsController::class, 'index']);

    // Dashboard
    Route::get('/dashboard', [DashboardController::class, 'index'])->middleware('auth:sanctum');
});
```

## Ma'lumotlar bazasi (MySQL)

```sql
-- Asosiy jadvallar
CREATE TABLE users (id, name, email, phone, password, greencoin_balance, avatar, created_at);
CREATE TABLE jobs (id, title, company, location, type, salary_min, salary_max, tags, description, is_active);
CREATE TABLE eco_tasks (id, title, description, reward_coins, category, deadline);
CREATE TABLE greencoin_transactions (id, user_id, amount, type, description, created_at);
CREATE TABLE courses (id, title, instructor, duration, price, level, rating, category);
CREATE TABLE mentors (id, user_id, skills, experience_years, rating, is_available);
CREATE TABLE challenges (id, title, description, reward, period, category);
CREATE TABLE news (id, title, content, image, author, category, published_at);
```

## Ishga tushirish

```bash
# .env sozlash
cp .env.example .env
php artisan key:generate

# Ma'lumotlar bazasi
php artisan migrate
php artisan db:seed

# Server
php artisan serve
```

## Frontend ulash

Frontend (hozirgi HTML) API ga fetch() orqali ulanadi:
```javascript
const response = await fetch('https://api.ambarella.uz/v1/jobs');
const jobs = await response.json();
```
