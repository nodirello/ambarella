# AMBARELLA — Deployment Qo'llanma

## 1-variant: Oddiy Hosting (Shared Hosting)

**Tavsiya:** Hostinger, Webhost.uz, PS.uz

### Qadamlar:
1. Domen sotib oling: `ambarella.uz` (webhost.uz dan ~50,000 so'm/yil)
2. Hosting sotib oling (50,000-150,000 so'm/yil)
3. FTP orqali barcha fayllarni `public_html/` ga yuklang
4. `.htaccess` allaqachon tayyor — URL'lar ishlaydi
5. SSL sertifikat yoqing (ko'pchilik hostinglarda bepul Let's Encrypt)

### Fayl tuzilishi serverda:
```
public_html/
├── index.html
├── 404.html
├── .htaccess
├── manifest.json
├── service-worker.js
├── robots.txt
├── sitemap.xml
├── pages/
│   ├── jobs.html
│   ├── eco.html
│   └── ... (20 ta sahifa)
└── assets/
    ├── icons/
    └── data/
```

---

## 2-variant: VPS (Virtual Private Server)

**Tavsiya:** DigitalOcean, Hetzner, Ahost.uz

### Qadamlar:
1. Ubuntu 22.04 VPS sotib oling ($5-10/oy)
2. Serverga SSH orqali ulaning va dastlabki sozlamalarni bajaring:
```bash
# Tizimni yangilash
sudo apt update && sudo apt upgrade -y

# Xavfsizlik uchun yangi foydalanuvchi yaratish (root o'rniga)
adduser newuser
usermod -aG sudo newuser

# Firewall (brandmauer) sozlash
sudo ufw allow 'Nginx Full'
sudo ufw allow 'OpenSSH'
sudo ufw enable
```

3. Nginx o'rnating:
```bash
sudo apt update
sudo apt install nginx -y
```

3. Fayllarni yuklang:
```bash
sudo mkdir -p /var/www/ambarella.uz
sudo cp -r ./* /var/www/ambarella.uz/
```

4. Nginx konfiguratsiya:
```bash
sudo cp nginx.conf /etc/nginx/sites-available/ambarella.uz
sudo ln -s /etc/nginx/sites-available/ambarella.uz /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

5. SSL (Let's Encrypt):
```bash
sudo apt install certbot python3-certbot-nginx -y
sudo certbot --nginx -d ambarella.uz -d www.ambarella.uz
```

6. Domen DNS sozlash:
```
A record:   ambarella.uz    →  SERVER_IP
A record:   www.ambarella.uz → SERVER_IP
```

---

## 3-variant: Vercel (Bepul, eng oson)

### Qadamlar:
1. https://vercel.com ga kiring
2. GitHub/GitLab accountingiz bilan bog'lang
3. Loyihani yuklang
4. "Deploy" bosing — tayyor!
5. Custom domen ulash: Settings → Domains → `ambarella.uz`

---

## Domen sozlash

`.uz` domen sotib olish uchun:
- https://webhost.uz
- https://ps.uz
- https://billur.uz

DNS sozlamalari:
```
Type    Name    Value           TTL
A       @       YOUR_SERVER_IP  3600
A       www     YOUR_SERVER_IP  3600
CNAME   www     ambarella.uz    3600
```

---

## Tekshirish (Deploy qilgandan keyin)

- [ ] https://ambarella.uz ochiladi
- [ ] SSL ishlaydi (qulf belgisi bor)
- [ ] Barcha sahifalar ochiladi
- [ ] Rasmlar ko'rinadi
- [ ] Mobilda to'g'ri ko'rinadi
- [ ] 404 sahifa ishlaydi
- [ ] robots.txt va sitemap.xml mavjud
