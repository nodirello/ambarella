# Responsive Dizayn Tekshiruv Ro'yxati — AMBARELLA HTML MVP

> **Sana:** 2026-01-30
> **Versiya:** 1.0.0
> **Framework:** Bootstrap 5.3.3 Grid System

---

## Tekshiruv Xulosasi

| Mezon | Holat | Izoh |
|-------|-------|------|
| Bootstrap responsive grid ishlatilishi | ✅ O'tdi | Barcha sahifalarda `col-*` klasslari |
| 320px minimum kenglik | ✅ O'tdi | Horizontal scroll yo'q |
| Breakpoint o'tishlari silliq | ✅ O'tdi | Media query transitions |
| Mobil drawer navigatsiya | ✅ O'tdi | 992px dan kichikda hamburger menu |
| Touch target 44×44px | ✅ O'tdi | Barcha interaktiv elementlar |
| Font o'lchamlari moslashishi | ✅ O'tdi | `clamp()` va responsive utilities |
| Rasm responsive | ✅ O'tdi | `max-width: 100%`, `height: auto` |

---

## Bootstrap Breakpoints

| Breakpoint | Kenglik | Qurilma | Holat |
|-----------|---------|---------|-------|
| xs | 320px — 575px | Mobil (kichik) | ✅ Tekshirildi |
| sm | 576px — 767px | Mobil (katta) | ✅ Tekshirildi |
| md | 768px — 991px | Planshet | ✅ Tekshirildi |
| lg | 992px — 1199px | Laptop | ✅ Tekshirildi |
| xl | 1200px — 1399px | Desktop | ✅ Tekshirildi |
| xxl | 1400px — 1920px | Katta ekran | ✅ Tekshirildi |

---

## Sahifalar Bo'yicha Grid Tuzilmasi

### Bosh Sahifa (index.html)

| Bo'lim | Desktop | Planshet | Mobil |
|--------|---------|----------|-------|
| Hero | `col-lg-6` × 2 | `col-md-12` | `col-12` stacked |
| Modullar Grid | `col-xl-3 col-md-6` | `col-md-6` | `col-12` |
| Jobs Preview | `col-lg-3 col-md-6` | `col-md-6` | `col-12` |
| News Grid | `col-md-4` | `col-md-6` | `col-12` |
| Mission Cards | `col-md-4` | `col-md-4` | `col-12` |
| FAQ | `col-lg-8 mx-auto` | `col-md-10` | `col-12` |

### Dashboard (pages/dashboard.html)

| Bo'lim | Desktop | Planshet | Mobil |
|--------|---------|----------|-------|
| Layout | `col-lg-3` sidebar + `col-lg-9` | Sidebar collapse | Full width |
| Widgets | `col-md-6 col-xl-3` | `col-md-6` | `col-12` |

### Modul Sahifalari

| Komponent | Desktop | Planshet | Mobil |
|-----------|---------|----------|-------|
| Filter Sidebar | `col-lg-3` | Top accordion | Hidden/toggle |
| Kontent Grid | `col-lg-9` | `col-12` | `col-12` |
| Kartalar | `col-lg-4 col-md-6` | `col-md-6` | `col-12` |

---

## Komponent Responsive Xulq-Atvori

### Header

| Kenglik | Xulq-atvor |
|---------|-----------|
| ≥ 992px | To'liq navigatsiya, mega-menu hover |
| < 992px | Hamburger tugmasi, drawer panel |
| ≤ 576px | Logo kichraytirilgan, minimal aksiyalar |

**Header balandliklari:**
- Desktop: 80px (`--header-height-desktop`)
- Tablet: 72px (`--header-height-tablet`)
- Mobile: 64px (`--header-height-mobile`)

### Footer

| Kenglik | Xulq-atvor |
|---------|-----------|
| ≥ 992px | 5 ustunli grid |
| 768-991px | 3 ustunli, pastki qator |
| < 768px | 1 ustunli, markazlashtirilgan |

### Kartalar (Cards)

| Kenglik | Xulq-atvor |
|---------|-----------|
| ≥ 1200px | 4 ta qatorda |
| 768-1199px | 2 ta qatorda |
| < 768px | 1 ta qatorda, to'liq kenglik |

---

## CSS Media Queries Ishlatilishi

```css
/* base.css, layout.css, va sahifa CSS fayllarida */
@media (max-width: 575.98px) { /* xs */ }
@media (min-width: 576px) and (max-width: 767.98px) { /* sm */ }
@media (min-width: 768px) and (max-width: 991.98px) { /* md */ }
@media (min-width: 992px) and (max-width: 1199.98px) { /* lg */ }
@media (min-width: 1200px) { /* xl+ */ }
```

---

## Tekshirilgan Holatlar

- ✅ Horizontal scroll 320px da yo'q
- ✅ Matn o'qilishi mumkin (font-size minimum 14px)
- ✅ Tugmalar bosish uchun yetarli kattalikda (44×44px)
- ✅ Formalar to'liq kenglikda ishlaydi
- ✅ Jadvallar `table-responsive` wrapper bilan
- ✅ Rasmlar `max-width: 100%` bilan
- ✅ Modal/drawer to'g'ri o'lchamda
- ✅ `prefers-reduced-motion` qo'llab-quvvatlanadi
- ✅ Landscape va portrait orientatsiyasi
- ✅ Container max-width: 1320px (xxl)
