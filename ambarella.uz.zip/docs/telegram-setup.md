# AMBARELLA — Telegram Auth Sozlash

## 1-qadam: Bot yaratish

1. Telegram'da @BotFather ga yozing
2. `/newbot` buyrug'ini yuboring
3. Bot nomini kiriting: `AMBARELLA`
4. Username: `AmbarellaBot` (yoki boshqa bo'sh nom)
5. BotFather sizga **token** beradi — saqlang!

Misol: `7123456789:AAHxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`

## 2-qadam: .env ga token yozish

```env
TELEGRAM_BOT_TOKEN=7123456789:AAHxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TELEGRAM_BOT_USERNAME=AmbarellaBot
```

## 3-qadam: Webhook o'rnatish

Brauzerda quyidagi URL ni oching (tokeningizni qo'ying):

```
https://api.telegram.org/bot{TOKEN}/setWebhook?url=https://ambarella.uz/webhook/telegram
```

Javob: `{"ok":true,"result":true,"description":"Webhook was set"}`

## 4-qadam: Login Widget sozlash

BotFather ga yozing:
```
/setdomain
```
Bot tanlang va domenii kiriting:
```
ambarella.uz
```

## Qanday ishlaydi

### Variant A: Telegram Login Widget
1. Foydalanuvchi "Telegram orqali kirish" tugmasini bosadi
2. Telegram oynasi ochiladi — "Tasdiqlash" bosadi
3. Telegram ma'lumotlari (id, name, photo) saytga yuboriladi
4. Sayt foydalanuvchini yaratadi/topadi va kiritadi

### Variant B: Kod bilan kirish
1. Foydalanuvchi avval @AmbarellaBot ga /start yozadi
2. Botga telefon raqamini yuboradi (bir martalik)
3. Saytda telefon raqam kiritadi → "Kod yuborish"
4. Bot Telegramga 6 xonali kod yuboradi
5. Foydalanuvchi kodni saytga kiritadi → kiradi

### Foydalanuvchi uchun xabar
Bot ga /start berganda:
```
Assalomu alaykum! 🇺🇿
Men AMBARELLA platformasi botiman.
Telefon raqamingizni yozing: +998901234567
```

Kod yuborilganda:
```
🔐 AMBARELLA tasdiqlash kodi: 123456
Kod 5 daqiqa amal qiladi.
```

## Xavfsizlik

- Kod 5 daqiqadan keyin o'chadi
- Telegram widget hash tekshiriladi (HMAC-SHA256)
- CSRF token barcha so'rovlarda tekshiriladi
- Telefon raqam validatsiya qilinadi
