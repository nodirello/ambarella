# AMBARELLA.UZ

O'zbekiston yoshlari uchun ko'p funksiyali platforma — bandlik, ekologiya, ta'lim, mentorlik, startup, biznes va ko'proq.

## Texnologiyalar

- **Backend:** Laravel 12 (PHP 8.2+)
- **Frontend:** Blade templates, CSS (dark theme)
- **Auth:** Email/parol + Telegram bot
- **PWA:** Offline + Push Notifications
- **Tillar:** UZ / RU / EN

---

## O'rnatish (Installation)

### Talab qilinadigan dasturlar:
- PHP 8.2+
- Composer
- MySQL 8+ yoki MariaDB
- Git

### Qadamlar:

```bash
# 1. Loyihani yuklab olish
git clone https://github.com/your-repo/ambarella.uz.git
cd ambarella.uz

# 2. PHP paketlarni o'rnatish
composer install

# 3. Environment faylni yaratish
cp .env.example .env

# 4. Application key generatsiya
php artisan key:generate

# 5. .env faylni sozlash (pastda ko'rsatilgan)
# nano .env

# 6. Ma'lumotlar bazasini yaratish
php artisan migrate

# 7. Demo ma'lumotlar (ixtiyoriy)
php artisan db:seed

# 8. Rasm yuklash uchun symlink
php artisan storage:link

# 9. Serverni ishga tushirish
php artisan serve
```

Brauzerda oching: http://127.0.0.1:8000

---

## .env sozlamalari

```env
APP_NAME=AMBARELLA
APP_URL=https://ambarella.uz

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=ambarella
DB_USERNAME=root
DB_PASSWORD=

TELEGRAM_BOT_TOKEN=your_bot_token_here
TELEGRAM_BOT_USERNAME=AmbarellaBot
TELEGRAM_WEBHOOK_SECRET=
```

---

## Admin panel

Seeder ishlatilganda:
- **Email:** admin@ambarella.uz
- **Parol:** admin12345
- **URL:** /admin

Qo'lda yaratish:
```sql
UPDATE users SET role = 'admin' WHERE email = 'your@email.com';
```

---

## Telegram bot sozlash

1. @BotFather dan yangi bot yarating
2. Token ni `.env` ga qo'shing: `TELEGRAM_BOT_TOKEN=...`
3. Webhook o'rnating:
```
https://api.telegram.org/bot{TOKEN}/setWebhook?url=https://ambarella.uz/webhook/telegram
```

---

## Server (production) deploy

### Nginx config:
```nginx
server {
    listen 80;
    server_name ambarella.uz;
    root /var/www/ambarella.uz/public;
    index index.php;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }

    location ~ /\.(?!well-known) {
        deny all;
    }
}
```

### Deploy qadamlari:
```bash
git pull origin main
composer install --no-dev --optimize-autoloader
php artisan migrate --force
php artisan config:cache
php artisan route:cache
php artisan view:cache
php artisan storage:link
```

---

## Loyiha tuzilishi

```
app/
├── Http/Controllers/        # 55+ controller
│   ├── Admin/               # 15 admin controller
│   ├── Business/            # 7 biznes panel controller
│   └── ...                  # User controllers
├── Models/                  # 25+ model
├── Traits/                  # TracksViews
├── Http/Middleware/          # CheckBanned, CheckProfileComplete, IsAdmin
resources/
├── views/                   # 100+ Blade template
│   ├── admin/               # 20+ admin view
│   ├── business/            # 7 biznes panel view
│   ├── layouts/app.blade.php
│   └── ...
public/
├── js/lang.js               # Multi-language
├── service-worker.js        # PWA offline
├── manifest.json            # PWA config
├── robots.txt               # SEO
├── assets/icons/            # Favicon, PWA icons
routes/web.php               # 160+ route
database/migrations/         # 26 migration
```

---

## Muallif

**SADAF DEV** | +998 90 074 10 70 | info@ambarella.uz
