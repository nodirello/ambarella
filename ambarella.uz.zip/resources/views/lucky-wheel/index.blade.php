@extends('layouts.app')
@section('title', 'Omad g\'ildiragi | AMBARELLA')
@section('styles')
<style>
.wheel-header{padding:32px 0;text-align:center}
.wheel-header h1{font-size:28px;font-weight:800;color:#fff}
.wheel-header p{color:var(--muted);font-size:14px;margin-top:6px}
.wheel-container{display:flex;flex-direction:column;align-items:center;margin-top:32px}
.wheel-wrapper{position:relative;width:320px;height:320px;margin:0 auto}
.wheel-canvas{width:320px;height:320px;border-radius:50%;border:4px solid var(--border);box-shadow:0 0 40px rgba(37,99,235,.2);transition:transform 4s cubic-bezier(.17,.67,.12,.99)}
.wheel-pointer{position:absolute;top:-10px;left:50%;transform:translateX(-50%);width:0;height:0;border-left:12px solid transparent;border-right:12px solid transparent;border-top:28px solid #f59e0b;filter:drop-shadow(0 2px 4px rgba(0,0,0,.5));z-index:10}
.wheel-center{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:50px;height:50px;border-radius:50%;background:linear-gradient(135deg,#1e293b,#334155);border:3px solid var(--border);display:flex;align-items:center;justify-content:center;font-size:18px;z-index:5}
.spin-btn{margin-top:28px;background:linear-gradient(135deg,var(--primary),#1d4ed8);color:#fff;border:none;padding:14px 40px;border-radius:12px;font-size:16px;font-weight:700;cursor:pointer;transition:all .3s;box-shadow:0 4px 20px rgba(37,99,235,.3)}
.spin-btn:hover{transform:translateY(-2px);box-shadow:0 6px 30px rgba(37,99,235,.5)}
.spin-btn:disabled{opacity:.5;cursor:not-allowed;transform:none}
.limit-msg{color:var(--muted);font-size:13px;margin-top:12px;display:flex;align-items:center;gap:6px}
.result-modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.7);backdrop-filter:blur(8px);z-index:1000;align-items:center;justify-content:center}
.result-modal.show{display:flex}
.result-box{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:40px;text-align:center;max-width:360px;width:90%;animation:popIn .3s ease}
@keyframes popIn{from{transform:scale(.8);opacity:0}to{transform:scale(1);opacity:1}}
.result-box .prize{font-size:48px;font-weight:800;color:#4ade80;margin:12px 0}
.result-box h3{font-size:20px;color:#fff;font-weight:700}
.result-box p{color:var(--muted);font-size:14px;margin-top:6px}
.result-box button{margin-top:20px;background:var(--primary);color:#fff;border:none;padding:10px 28px;border-radius:10px;font-size:14px;font-weight:600;cursor:pointer}
.prizes-list{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:24px;margin-top:24px;max-width:400px;width:100%}
.prizes-list h3{font-size:15px;font-weight:700;color:#fff;margin-bottom:12px}
.prizes-list .prize-row{display:flex;align-items:center;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border)}
.prizes-list .prize-row:last-child{border:none}
.prizes-list .prize-row span{font-size:13px;color:#94a3b8}
.prizes-list .prize-row strong{color:#4ade80;font-size:14px}
@media(max-width:768px){.wheel-wrapper{width:280px;height:280px}.wheel-canvas{width:280px;height:280px}}
</style>
@endsection
@section('content')
<section class="wheel-header"><div class="container">
    <h1>🎡 Omad g'ildiragi</h1>
    <p>Har kuni bir marta aylantiring va GreenCoin yutib oling!</p>
</div></section>

<div class="container">
    <div class="wheel-container">
        <div class="wheel-wrapper">
            <div class="wheel-pointer"></div>
            <canvas id="wheelCanvas" class="wheel-canvas" width="320" height="320"></canvas>
            <div class="wheel-center">🍀</div>
        </div>

        <button class="spin-btn" id="spinBtn" onclick="spinWheel()">🎰 Aylantirish</button>
        <div class="limit-msg">⏰ Kuniga 1 marta aylantirish mumkin</div>

        <div class="prizes-list">
            <h3>Mukofotlar</h3>
            <div class="prize-row"><span>🟢 1 GreenCoin</span><strong>Eng ko'p</strong></div>
            <div class="prize-row"><span>🟢 3 GreenCoin</span><strong>Ko'p</strong></div>
            <div class="prize-row"><span>🔵 5 GreenCoin</span><strong>O'rtacha</strong></div>
            <div class="prize-row"><span>🔵 10 GreenCoin</span><strong>Kam</strong></div>
            <div class="prize-row"><span>🟡 15 GreenCoin</span><strong>Kam</strong></div>
            <div class="prize-row"><span>🟡 20 GreenCoin</span><strong>Juda kam</strong></div>
            <div class="prize-row"><span>🏆 50 GreenCoin</span><strong>Noyob!</strong></div>
        </div>
    </div>
</div>

<div class="result-modal" id="resultModal">
    <div class="result-box">
        <h3>🎉 Tabriklaymiz!</h3>
        <div class="prize" id="prizeAmount">+5 GC</div>
        <p>GreenCoin hisobingizga qo'shildi</p>
        <button onclick="closeResult()">Yopish</button>
    </div>
</div>
@endsection
@section('scripts')
<script>
const segments=[1,3,5,10,15,20,50,1,3,5,10,15];
const colors=['#1e40af','#059669','#1e40af','#7c3aed','#b45309','#7c3aed','#dc2626','#059669','#1e40af','#059669','#7c3aed','#b45309'];
const canvas=document.getElementById('wheelCanvas');
const ctx=canvas.getContext('2d');
const numSeg=segments.length;
const arc=2*Math.PI/numSeg;
let currentAngle=0;
let spinning=false;

function drawWheel(){
    const centerX=canvas.width/2,centerY=canvas.height/2,radius=canvas.width/2-4;
    for(let i=0;i<numSeg;i++){
        const angle=currentAngle+i*arc;
        ctx.beginPath();
        ctx.moveTo(centerX,centerY);
        ctx.arc(centerX,centerY,radius,angle,angle+arc);
        ctx.fillStyle=colors[i];
        ctx.fill();
        ctx.strokeStyle='rgba(255,255,255,.1)';
        ctx.lineWidth=1;
        ctx.stroke();
        // Text
        ctx.save();
        ctx.translate(centerX,centerY);
        ctx.rotate(angle+arc/2);
        ctx.fillStyle='#fff';
        ctx.font='bold 14px sans-serif';
        ctx.textAlign='center';
        ctx.fillText(segments[i]+' GC',radius*0.65,5);
        ctx.restore();
    }
}
drawWheel();

function spinWheel(){
    if(spinning)return;
    spinning=true;
    document.getElementById('spinBtn').disabled=true;

    // Weighted random
    const weights=[20,18,15,12,10,8,3,20,18,15,12,10];
    const total=weights.reduce((a,b)=>a+b,0);
    let rand=Math.random()*total;
    let winIdx=0;
    for(let i=0;i<weights.length;i++){
        rand-=weights[i];
        if(rand<=0){winIdx=i;break;}
    }

    const spins=5+Math.random()*3;
    const targetAngle=spins*2*Math.PI-(winIdx*arc+arc/2);
    
    let start=null;
    const duration=4000;
    const startAngle=currentAngle;

    function animate(timestamp){
        if(!start)start=timestamp;
        const elapsed=timestamp-start;
        const progress=Math.min(elapsed/duration,1);
        const eased=1-Math.pow(1-progress,4);
        currentAngle=startAngle+targetAngle*eased;
        ctx.clearRect(0,0,canvas.width,canvas.height);
        drawWheel();
        if(progress<1){
            requestAnimationFrame(animate);
        }else{
            spinning=false;
            showResult(segments[winIdx]);
        }
    }
    requestAnimationFrame(animate);
}

function showResult(amount){
    document.getElementById('prizeAmount').textContent='+'+amount+' GC';
    document.getElementById('resultModal').classList.add('show');
}

function closeResult(){
    document.getElementById('resultModal').classList.remove('show');
}
</script>
@endsection
