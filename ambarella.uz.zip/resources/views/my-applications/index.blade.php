@extends('layouts.app')
@section('title', 'Mening arizalarim | AMBARELLA')
@section('styles')
<style>
.apps-page{padding:48px 0 64px}
.apps-header{margin-bottom:32px}
.apps-header h1{font-size:24px;font-weight:800;color:#fff;display:flex;align-items:center;gap:10px}
.apps-header h1 svg{width:24px;height:24px;stroke:#60a5fa;fill:none;stroke-width:2}
.apps-header p{color:var(--muted);font-size:13px;margin-top:6px}
.apps-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:28px}
.ast{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:16px;text-align:center}
.ast .ast-num{font-size:22px;font-weight:800}
.ast .ast-lbl{font-size:11px;color:var(--muted);margin-top:2px}
.apps-list{display:flex;flex-direction:column;gap:12px}
.app-card{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:20px 24px;display:grid;grid-template-columns:1fr auto;gap:20px;align-items:center;transition:all .3s;position:relative;overflow:hidden}
.app-card::before{content:'';position:absolute;left:0;top:0;bottom:0;width:3px;background:var(--ac-color,var(--border))}
.app-card:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(0,0,0,.1)}
.app-card h3{font-size:15px;font-weight:700;color:#fff;margin-bottom:4px}
.app-card .meta{font-size:12px;color:var(--muted);display:flex;align-items:center;gap:10px}
.app-card .meta svg{width:12px;height:12px;stroke:currentColor;fill:none;stroke-width:2}
.app-card .cover{font-size:12px;color:#94a3b8;margin-top:8px;max-width:500px;font-style:italic}
.app-status{display:flex;flex-direction:column;align-items:flex-end;gap:8px}
.status-badge{padding:5px 14px;border-radius:999px;font-size:11px;font-weight:700;display:inline-flex;align-items:center;gap:4px}
.status-badge svg{width:10px;height:10px;stroke:currentColor;fill:none;stroke-width:2.5}
.s-pending{background:rgba(234,179,8,.1);color:#fbbf24;border:1px solid rgba(234,179,8,.2)}
.s-accepted{background:rgba(34,197,94,.1);color:#4ade80;border:1px solid rgba(34,197,94,.2)}
.s-rejected{background:rgba(220,38,38,.1);color:#fca5a5;border:1px solid rgba(220,38,38,.2)}
.app-date{font-size:11px;color:var(--muted)}
.empty-apps{text-align:center;padding:80px 24px}
.empty-apps svg{width:80px;height:80px;margin:0 auto 20px;stroke:rgba(255,255,255,.06);fill:none;stroke-width:1}
@media(max-width:768px){.apps-stats{grid-template-columns:1fr 1fr}.app-card{grid-template-columns:1fr}.app-status{align-items:flex-start}}
</style>
@endsection
@section('content')
<div class="container apps-page">
  <div class="apps-header">
    <h1><svg viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg> Mening arizalarim</h1>
    <p>Topshirgan ish arizalaringiz holati va tarixi</p>
  </div>

  @php
    $total = $applications->total();
    $pending = $applications->where('status','pending')->count();
    $accepted = $applications->where('status','accepted')->count();
    $rejected = $applications->where('status','rejected')->count();
  @endphp

  <div class="apps-stats">
    <div class="ast"><div class="ast-num" style="color:#fff">{{ $total }}</div><div class="ast-lbl">Jami</div></div>
    <div class="ast"><div class="ast-num" style="color:#fbbf24">{{ $pending }}</div><div class="ast-lbl">Kutilmoqda</div></div>
    <div class="ast"><div class="ast-num" style="color:#4ade80">{{ $accepted }}</div><div class="ast-lbl">Qabul</div></div>
    <div class="ast"><div class="ast-num" style="color:#f87171">{{ $rejected }}</div><div class="ast-lbl">Rad etildi</div></div>
  </div>

  <div class="apps-list">
    @forelse($applications as $app)
    @php
      $color = match($app->status) { 'accepted' => '#4ade80', 'rejected' => '#f87171', default => '#fbbf24' };
    @endphp
    <div class="app-card" style="--ac-color:{{ $color }}">
      <div>
        <h3><a href="/jobs/{{ $app->job_id }}" style="color:inherit;transition:color .2s" onmouseover="this.style.color='#93c5fd'" onmouseout="this.style.color='inherit'">{{ $app->job->title ?? 'O\'chirilgan vakansiya' }}</a></h3>
        <div class="meta">
          <span><svg viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/></svg>{{ $app->job->company ?? '' }}</span>
          @if($app->job?->location)<span><svg viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>{{ $app->job->location }}</span>@endif
          @if($app->job?->salary_min)<span style="color:#4ade80;font-weight:600">{{ number_format($app->job->salary_min/1000000) }}–{{ number_format($app->job->salary_max/1000000) }}M so'm</span>@endif
        </div>
        @if($app->cover_letter)
        <p class="cover">"{{ Str::limit($app->cover_letter, 120) }}"</p>
        @endif
      </div>
      <div class="app-status">
        @if($app->status === 'pending')
          <span class="status-badge s-pending"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg> Kutilmoqda</span>
        @elseif($app->status === 'accepted')
          <span class="status-badge s-accepted"><svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg> Qabul qilindi</span>
        @else
          <span class="status-badge s-rejected"><svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg> Rad etildi</span>
        @endif
        <span class="app-date">{{ $app->created_at->format('d.m.Y') }}</span>
      </div>
    </div>
    @empty
    <div class="empty-apps">
      <svg viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/></svg>
      <p style="color:var(--muted);font-size:15px;margin-bottom:20px">Hali ariza topshirmagansiz.</p>
      <a href="/jobs" class="btn btn-primary">Ish e'lonlarini ko'rish</a>
    </div>
    @endforelse
  </div>

  @if($applications->hasPages())
  <div style="display:flex;justify-content:center;margin-top:32px">{{ $applications->links() }}</div>
  @endif
</div>
@endsection
