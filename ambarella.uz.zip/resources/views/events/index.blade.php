@extends('layouts.app')
@section('title', 'Tadbirlar — AMBARELLA')
@section('description', 'Yaqinlashayotgan tadbirlar — hackathonlar, vebinarlar va meetuplar.')

@section('styles')
<style>
.ev-hero{padding:64px 0 48px;text-align:center}
.ev-hero h1{font-size:clamp(28px,5vw,42px);font-weight:800;color:#fff;margin-bottom:12px}
.ev-hero p{color:var(--muted);font-size:16px;max-width:600px;margin:0 auto;line-height:1.8}
.ev-badge{display:inline-flex;align-items:center;gap:6px;padding:6px 14px;border-radius:20px;font-size:12px;font-weight:600;background:rgba(245,158,11,.1);color:#fbbf24;margin-bottom:20px}
.ev-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:20px;margin:48px 0}
.ev-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden;transition:all .2s}
.ev-card:hover{border-color:rgba(37,99,235,.3);transform:translateY(-2px)}
.ev-card-header{padding:24px 24px 0;display:flex;align-items:flex-start;gap:14px}
.ev-card-icon{width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.ev-card:nth-child(1) .ev-card-icon{background:rgba(37,99,235,.12)}
.ev-card:nth-child(2) .ev-card-icon{background:rgba(22,163,74,.12)}
.ev-card:nth-child(3) .ev-card-icon{background:rgba(124,58,237,.12)}
.ev-card-header div h3{font-size:16px;font-weight:700;color:#fff;margin-bottom:4px}
.ev-card-header div span{font-size:12px;color:var(--muted);font-weight:500}
.ev-card-body{padding:16px 24px 24px}
.ev-card-body p{font-size:14px;color:var(--muted);line-height:1.7;margin-bottom:16px}
.ev-meta{display:flex;flex-wrap:wrap;gap:12px}
.ev-meta-item{display:flex;align-items:center;gap:6px;font-size:12px;color:#94a3b8;background:rgba(255,255,255,.04);padding:4px 10px;border-radius:6px}
.ev-coming{text-align:center;margin:64px 0;padding:64px 24px;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius)}
.ev-coming h2{font-size:clamp(20px,4vw,28px);font-weight:800;color:#fff;margin-bottom:12px}
.ev-coming p{color:var(--muted);font-size:15px;max-width:480px;margin:0 auto 24px}
.ev-coming .pulse{width:64px;height:64px;border-radius:50%;background:rgba(37,99,235,.1);display:flex;align-items:center;justify-content:center;margin:0 auto 20px;animation:pulse 2s ease-in-out infinite}
@keyframes pulse{0%,100%{transform:scale(1);opacity:1}50%{transform:scale(1.1);opacity:.7}}
</style>
@endsection

@section('content')
<section class="ev-hero">
  <div class="container">
    <div class="ev-badge">
      <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="2" y="3" width="10" height="10" rx="1"/><line x1="2" y1="6" x2="12" y2="6"/><line x1="5" y1="1" x2="5" y2="3"/><line x1="9" y1="1" x2="9" y2="3"/></svg>
      Tadbirlar
    </div>
    <h1>Yaqinlashayotgan tadbirlar</h1>
    <p>Hackathonlar, vebinarlar, meetuplar va boshqa qiziqarli tadbirlar. Qatnashing va tajriba oling!</p>
  </div>
</section>

<section class="container">
  <div class="ev-grid">
    <div class="ev-card">
      <div class="ev-card-header">
        <div class="ev-card-icon">
          <svg width="22" height="22" fill="none" stroke="#2563eb" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="18" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>
        </div>
        <div>
          <h3>AI Hackathon 2025</h3>
          <span>48 soatlik musobaqa</span>
        </div>
      </div>
      <div class="ev-card-body">
        <p>Sun'iy intellekt yordamida ijtimoiy muammolarni hal qiling. Eng yaxshi loyihalar investitsiya oladi.</p>
        <div class="ev-meta">
          <div class="ev-meta-item">
            <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="2" width="10" height="9" rx="1"/><line x1="1" y1="5" x2="11" y2="5"/></svg>
            Tez orada
          </div>
          <div class="ev-meta-item">
            <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><circle cx="6" cy="6" r="5"/><path d="M6 3v3l2 1"/></svg>
            48 soat
          </div>
          <div class="ev-meta-item">
            <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 11H1V1"/><polyline points="3 8 5 5 8 7 11 3"/></svg>
            Online
          </div>
        </div>
      </div>
    </div>

    <div class="ev-card">
      <div class="ev-card-header">
        <div class="ev-card-icon">
          <svg width="22" height="22" fill="none" stroke="#16a34a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 1 14 8 22 9 16 14 18 22 11 18 4 22 6 14 0 9 8 8"/></svg>
        </div>
        <div>
          <h3>Karyera Vebinar</h3>
          <span>Bepul onlayn sessiya</span>
        </div>
      </div>
      <div class="ev-card-body">
        <p>IT sohasida karyera boshlash bo'yicha tajribali mutaxassislar bilan jonli vebinar.</p>
        <div class="ev-meta">
          <div class="ev-meta-item">
            <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="2" width="10" height="9" rx="1"/><line x1="1" y1="5" x2="11" y2="5"/></svg>
            Tez orada
          </div>
          <div class="ev-meta-item">
            <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><circle cx="6" cy="6" r="5"/><path d="M6 3v3l2 1"/></svg>
            2 soat
          </div>
          <div class="ev-meta-item">
            <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 11A5 5 0 0 1 1 6V1h10v5a5 5 0 0 1-5 5z"/></svg>
            Zoom
          </div>
        </div>
      </div>
    </div>

    <div class="ev-card">
      <div class="ev-card-header">
        <div class="ev-card-icon">
          <svg width="22" height="22" fill="none" stroke="#a78bfa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
        </div>
        <div>
          <h3>Tech Meetup Toshkent</h3>
          <span>Networking tadbir</span>
        </div>
      </div>
      <div class="ev-card-body">
        <p>IT mutaxassislar, startapchilar va yoshlar uchun noformal networking uchrashuvl.</p>
        <div class="ev-meta">
          <div class="ev-meta-item">
            <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="2" width="10" height="9" rx="1"/><line x1="1" y1="5" x2="11" y2="5"/></svg>
            Tez orada
          </div>
          <div class="ev-meta-item">
            <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><circle cx="6" cy="6" r="5"/><path d="M6 3v3l2 1"/></svg>
            3 soat
          </div>
          <div class="ev-meta-item">
            <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 1v2M6 9v2M1 6h2M9 6h2"/><circle cx="6" cy="6" r="3"/></svg>
            Offline
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="container">
  <div class="ev-coming">
    <div class="pulse">
      <svg width="28" height="28" fill="none" stroke="#2563eb" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="14" cy="14" r="12"/><path d="M14 8v6l4 2"/></svg>
    </div>
    <h2>Tez orada — yangi tadbirlar!</h2>
    <p>Biz doimiy ravishda yangi tadbirlar tashkil etamiz. Bildirishnomalarni yoqing va birinchilardan bo'lib xabardor bo'ling.</p>
    <a href="/register" class="btn btn-primary">Bildirishnomalarni yoqish</a>
  </div>
</section>
@endsection
