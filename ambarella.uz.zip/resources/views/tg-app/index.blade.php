<!DOCTYPE html>
<html lang="uz">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
<title>AMBARELLA</title>
<script src="https://telegram.org/js/telegram-web-app.js"></script>
<style>
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
:root{
  --bg: var(--tg-theme-bg-color, #0f172a);
  --bg2: var(--tg-theme-secondary-bg-color, #1e293b);
  --text: var(--tg-theme-text-color, #e2e8f0);
  --hint: var(--tg-theme-hint-color, #64748b);
  --link: var(--tg-theme-link-color, #60a5fa);
  --btn: var(--tg-theme-button-color, #2563eb);
  --btn-text: var(--tg-theme-button-text-color, #fff);
  --radius: 14px;
  --green: #4ade80;
  --yellow: #fbbf24;
  --purple: #a78bfa;
}
body{
  font-family:-apple-system,BlinkMacSystemFont,'Inter',sans-serif;
  background:var(--bg);
  color:var(--text);
  min-height:100vh;
  font-size:15px;
  line-height:1.5;
}
/* ── TAB BAR ── */
.tab-bar{
  position:fixed;bottom:0;left:0;right:0;
  background:var(--bg2);
  border-top:1px solid rgba(255,255,255,.07);
  display:flex;
  padding:6px 0 env(safe-area-inset-bottom, 6px);
  z-index:100;
}
.tab-item{
  flex:1;display:flex;flex-direction:column;align-items:center;
  gap:3px;padding:6px 4px;
  color:var(--hint);font-size:10px;font-weight:600;
  cursor:pointer;border:none;background:none;
  transition:color .15s;
}
.tab-item.active{color:var(--link)}
.tab-item svg{width:22px;height:22px;stroke:currentColor;fill:none;stroke-width:1.8}
/* ── PAGES ── */
.page{display:none;padding:16px 16px 80px;min-height:100vh}
.page.active{display:block}
/* ── HOME ── */
.home-header{
  background:linear-gradient(135deg,rgba(37,99,235,.15),rgba(124,58,237,.1));
  border:1px solid rgba(37,99,235,.2);
  border-radius:var(--radius);padding:18px;margin-bottom:16px;
}
.home-header .greeting{font-size:13px;color:var(--hint);margin-bottom:4px}
.home-header .name{font-size:18px;font-weight:800;color:var(--text)}
.home-header .balance{font-size:28px;font-weight:900;color:var(--green);margin-top:8px}
.home-header .balance span{font-size:14px;color:var(--hint);font-weight:400}
/* Stats row */
.stats-row{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:16px}
.stat-box{
  background:var(--bg2);border-radius:12px;padding:12px;text-align:center;
  border:1px solid rgba(255,255,255,.06);
}
.stat-box .val{font-size:18px;font-weight:800}
.stat-box .lbl{font-size:10px;color:var(--hint);margin-top:2px;font-weight:600}
/* Quick actions */
.section-title{font-size:13px;font-weight:700;color:var(--hint);text-transform:uppercase;letter-spacing:.8px;margin:16px 0 10px}
.quick-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-bottom:16px}
.quick-btn{
  background:var(--bg2);border:1px solid rgba(255,255,255,.06);border-radius:var(--radius);
  padding:14px;display:flex;align-items:center;gap:10px;
  cursor:pointer;transition:all .15s;border:none;width:100%;text-align:left;
  color:var(--text);
}
.quick-btn:active{transform:scale(.97);opacity:.85}
.quick-btn .qb-icon{
  width:36px;height:36px;border-radius:10px;
  display:flex;align-items:center;justify-content:center;flex-shrink:0;
}
.quick-btn .qb-icon svg{width:18px;height:18px;stroke:currentColor;fill:none;stroke-width:1.8}
.quick-btn .qb-title{font-size:13px;font-weight:600}
.quick-btn .qb-sub{font-size:11px;color:var(--hint);margin-top:1px}
/* List items */
.list-item{
  background:var(--bg2);border-radius:12px;padding:14px 16px;
  display:flex;align-items:center;gap:12px;margin-bottom:8px;
  cursor:pointer;border:1px solid rgba(255,255,255,.05);transition:all .15s;
}
.list-item:active{transform:scale(.98);opacity:.85}
.list-item .li-icon{
  width:38px;height:38px;border-radius:10px;
  display:flex;align-items:center;justify-content:center;flex-shrink:0;
}
.list-item .li-icon svg{width:18px;height:18px;stroke:currentColor;fill:none;stroke-width:1.8}
.list-item .li-body{flex:1;min-width:0}
.list-item .li-title{font-size:14px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.list-item .li-sub{font-size:12px;color:var(--hint);margin-top:2px}
.list-item .li-right{font-size:12px;font-weight:700;flex-shrink:0}
/* Badges */
.badge{display:inline-block;padding:3px 8px;border-radius:999px;font-size:10px;font-weight:700}
.badge-green{background:rgba(74,222,128,.12);color:var(--green)}
.badge-yellow{background:rgba(251,191,36,.12);color:var(--yellow)}
.badge-blue{background:rgba(96,165,250,.12);color:var(--link)}
.badge-purple{background:rgba(167,139,250,.12);color:var(--purple)}
/* ECO page */
.eco-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:16px}
.eco-stat{background:var(--bg2);border-radius:12px;padding:12px;text-align:center;border:1px solid rgba(34,197,94,.12)}
.eco-stat .ev{font-size:17px;font-weight:800;color:var(--green)}
.eco-stat .el{font-size:10px;color:var(--hint);margin-top:2px}
/* Task card */
.task-card{
  background:var(--bg2);border-radius:var(--radius);padding:16px;margin-bottom:10px;
  border:1px solid rgba(255,255,255,.05);border-left:3px solid var(--green);
}
.task-card .tc-title{font-size:14px;font-weight:700;margin-bottom:4px}
.task-card .tc-desc{font-size:12px;color:var(--hint);line-height:1.4;margin-bottom:10px}
.task-card .tc-footer{display:flex;align-items:center;justify-content:space-between}
.task-card .tc-reward{font-size:13px;font-weight:800;color:var(--green)}
/* Profile page */
.profile-header{text-align:center;padding:20px 0 16px}
.profile-avatar{
  width:72px;height:72px;border-radius:50%;
  background:linear-gradient(135deg,#2563eb,#7c3aed);
  display:flex;align-items:center;justify-content:center;
  font-size:28px;font-weight:900;color:#fff;
  margin:0 auto 12px;
}
.profile-name{font-size:18px;font-weight:800}
.profile-level{font-size:12px;color:var(--hint);margin-top:4px}
.profile-gc{font-size:24px;font-weight:900;color:var(--green);margin-top:8px}
/* Progress */
.prog-wrap{background:var(--bg2);border-radius:var(--radius);padding:16px;margin-bottom:12px;border:1px solid rgba(255,255,255,.05)}
.prog-wrap .pw-label{font-size:12px;font-weight:600;color:var(--hint);margin-bottom:8px;display:flex;justify-content:space-between}
.prog-bar{height:6px;background:rgba(255,255,255,.06);border-radius:3px;overflow:hidden}
.prog-fill{height:100%;border-radius:3px;background:linear-gradient(90deg,var(--green),#22d3ee);transition:width .6s ease}
/* Buttons */
.tg-btn{
  width:100%;padding:14px;border-radius:var(--radius);
  background:var(--btn);color:var(--btn-text);
  font-size:15px;font-weight:700;border:none;cursor:pointer;
  display:flex;align-items:center;justify-content:center;gap:8px;
  transition:opacity .15s;margin-bottom:10px;
}
.tg-btn:active{opacity:.85}
.tg-btn svg{width:18px;height:18px;stroke:currentColor;fill:none;stroke-width:2}
.tg-btn-outline{background:var(--bg2);color:var(--link);border:1px solid rgba(96,165,250,.25)}
/* Loading */
.loading{display:flex;align-items:center;justify-content:center;height:200px}
.spinner{width:32px;height:32px;border:3px solid rgba(255,255,255,.1);border-top-color:var(--link);border-radius:50%;animation:spin .6s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
/* Empty */
.empty{text-align:center;padding:40px 20px;color:var(--hint)}
.empty svg{width:48px;height:48px;stroke:rgba(255,255,255,.1);fill:none;stroke-width:1;margin:0 auto 12px}
</style>
</head>
<body>

{{-- TAB BAR --}}
<nav class="tab-bar">
  <button class="tab-item active" onclick="showPage('home')">
    <svg viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
    Bosh
  </button>
  <button class="tab-item" onclick="showPage('eco')">
    <svg viewBox="0 0 24 24"><path d="M12 22c4-2.5 7-6 7-10a7 7 0 00-14 0c0 4 3 7.5 7 10z"/></svg>
    Eco
  </button>
  <button class="tab-item" onclick="showPage('jobs')">
    <svg viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/></svg>
    Ishlar
  </button>
  <button class="tab-item" onclick="showPage('profile')">
    <svg viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
    Profil
  </button>
</nav>

{{-- HOME PAGE --}}
<div class="page active" id="page-home">
  <div class="home-header">
    <div class="greeting">Xush kelibsiz 👋</div>
    <div class="name" id="home-name">Yuklanmoqda...</div>
    <div class="balance"><span id="home-balance">0</span> <span>GC</span></div>
  </div>

  <div class="stats-row">
    <div class="stat-box">
      <div class="val" id="stat-streak" style="color:var(--yellow)">0</div>
      <div class="lbl">🔥 Streak</div>
    </div>
    <div class="stat-box">
      <div class="val" id="stat-tasks" style="color:var(--green)">0</div>
      <div class="lbl">Eco ish</div>
    </div>
    <div class="stat-box">
      <div class="val" id="stat-apps" style="color:var(--link)">0</div>
      <div class="lbl">Ariza</div>
    </div>
  </div>

  <div class="section-title">Tezkor harakatlar</div>
  <div class="quick-grid">
    <button class="quick-btn" onclick="showPage('eco')">
      <div class="qb-icon" style="background:rgba(74,222,128,.1);color:var(--green)"><svg viewBox="0 0 24 24"><path d="M12 22c4-2.5 7-6 7-10a7 7 0 00-14 0c0 4 3 7.5 7 10z"/></svg></div>
      <div><div class="qb-title">Eco vazifalar</div><div class="qb-sub">GC ishlash</div></div>
    </button>
    <button class="quick-btn" onclick="showPage('jobs')">
      <div class="qb-icon" style="background:rgba(96,165,250,.1);color:var(--link)"><svg viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/></svg></div>
      <div><div class="qb-title">Ish e'lonlari</div><div class="qb-sub">Vakansiyalar</div></div>
    </button>
    <button class="quick-btn" onclick="openUrl('/mentors')">
      <div class="qb-icon" style="background:rgba(167,139,250,.1);color:var(--purple)"><svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/></svg></div>
      <div><div class="qb-title">Mentorlar</div><div class="qb-sub">1:1 sessiya</div></div>
    </button>
    <button class="quick-btn" onclick="openUrl('/greencoin/leaderboard')">
      <div class="qb-icon" style="background:rgba(251,191,36,.1);color:var(--yellow)"><svg viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg></div>
      <div><div class="qb-title">Liderlar</div><div class="qb-sub">Top reyting</div></div>
    </button>
  </div>

  <div class="section-title">So'nggi ish e'lonlari</div>
  <div id="home-jobs"><div class="loading"><div class="spinner"></div></div></div>
</div>

{{-- ECO PAGE --}}
<div class="page" id="page-eco">
  <div class="section-title">Eco statistika</div>
  <div class="eco-stats">
    <div class="eco-stat"><div class="ev" id="eco-total">0</div><div class="el">Jami harakat</div></div>
    <div class="eco-stat"><div class="ev" id="eco-today">0</div><div class="el">Bugun</div></div>
    <div class="eco-stat"><div class="ev" id="eco-gc">0</div><div class="el">GC ishlangan</div></div>
  </div>

  <div class="section-title">Bugungi vazifalar</div>
  <div id="eco-tasks-list"><div class="loading"><div class="spinner"></div></div></div>
</div>

{{-- JOBS PAGE --}}
<div class="page" id="page-jobs">
  <div class="section-title">Faol vakansiyalar</div>
  <div id="jobs-list"><div class="loading"><div class="spinner"></div></div></div>
</div>

{{-- PROFILE PAGE --}}
<div class="page" id="page-profile">
  <div class="profile-header">
    <div class="profile-avatar" id="profile-avatar">A</div>
    <div class="profile-name" id="profile-name">Yuklanmoqda...</div>
    <div class="profile-level" id="profile-level"></div>
    <div class="profile-gc" id="profile-gc">0 GC</div>
  </div>

  <div class="prog-wrap">
    <div class="pw-label">
      <span>GreenCoin darajasi</span>
      <span id="prog-label">Starter</span>
    </div>
    <div class="prog-bar"><div class="prog-fill" id="prog-fill" style="width:0%"></div></div>
  </div>

  <button class="tg-btn" onclick="openUrl('/dashboard')">
    <svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
    Dashboard
  </button>
  <button class="tg-btn tg-btn-outline" onclick="openUrl('/settings')">
    <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83"/></svg>
    Sozlamalar
  </button>
  <button class="tg-btn tg-btn-outline" onclick="openUrl('/greencoin/shop')">
    <svg viewBox="0 0 24 24"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 001.94 1.61h9.72a2 2 0 001.94-1.61L23 6H6"/></svg>
    GC Do'kon
  </button>
</div>

<script>
const tg = window.Telegram.WebApp;
tg.ready();
tg.expand();

// Telegram theme ranglarini qo'llash
document.documentElement.style.setProperty('--bg', tg.themeParams.bg_color || '#0f172a');
document.documentElement.style.setProperty('--bg2', tg.themeParams.secondary_bg_color || '#1e293b');
document.documentElement.style.setProperty('--text', tg.themeParams.text_color || '#e2e8f0');
document.documentElement.style.setProperty('--hint', tg.themeParams.hint_color || '#64748b');

const BASE = '{{ url("") }}';
const TG_USER = tg.initDataUnsafe?.user;

// ── TAB NAVIGATION ──
function showPage(name) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.tab-item').forEach(t => t.classList.remove('active'));
  document.getElementById('page-' + name).classList.add('active');
  document.querySelectorAll('.tab-item')[['home','eco','jobs','profile'].indexOf(name)].classList.add('active');

  if (name === 'jobs' && !window._jobsLoaded) loadJobs();
  if (name === 'eco' && !window._ecoLoaded) loadEco();
}

// ── OPEN URL ──
function openUrl(path) {
  tg.openLink(BASE + path);
}

// ── API CALLS ──
async function fetchApi(path) {
  try {
    const res = await fetch(BASE + path, {
      headers: { 'Accept': 'application/json', 'X-Telegram-Init-Data': tg.initData }
    });
    return await res.json();
  } catch(e) { return null; }
}

// ── HOME DATA ──
async function loadHome() {
  const data = await fetchApi('/api/v1/tg/me');
  if (!data?.success) {
    document.getElementById('home-name').textContent = TG_USER?.first_name || 'Mehmon';
    document.getElementById('home-jobs').innerHTML = renderJobSkeleton();
    loadHomeJobs();
    return;
  }

  const u = data.user;
  document.getElementById('home-name').textContent = u.name;
  document.getElementById('home-balance').textContent = u.greencoin_balance.toLocaleString();
  document.getElementById('stat-streak').textContent = u.login_streak || 0;
  document.getElementById('stat-tasks').textContent = u.eco_actions || 0;
  document.getElementById('stat-apps').textContent = u.applications || 0;

  // Profile
  document.getElementById('profile-avatar').textContent = u.name[0].toUpperCase();
  document.getElementById('profile-name').textContent = u.name;
  document.getElementById('profile-gc').textContent = u.greencoin_balance.toLocaleString() + ' GC';

  const levels = [{n:'Starter',min:0,max:100},{n:'Bronze',min:100,max:500},{n:'Silver',min:500,max:1000},{n:'Gold',min:1000,max:5000},{n:'Platinum',min:5000,max:9999}];
  const cur = [...levels].reverse().find(l => u.greencoin_balance >= l.min) || levels[0];
  const nxt = levels.find(l => u.greencoin_balance < l.min);
  const pct = nxt ? Math.min(Math.round((u.greencoin_balance - cur.min) / (nxt.min - cur.min) * 100), 100) : 100;

  document.getElementById('profile-level').textContent = cur.n;
  document.getElementById('prog-label').textContent = nxt ? `${cur.n} → ${nxt.n}` : 'MAX';
  document.getElementById('prog-fill').style.width = pct + '%';

  loadHomeJobs();
}

async function loadHomeJobs() {
  const data = await fetchApi('/api/v1/jobs?per_page=3');
  const el = document.getElementById('home-jobs');
  if (!data?.data?.data?.length) { el.innerHTML = '<div class="empty"><p>Hozircha ish e\'lonlari yo\'q</p></div>'; return; }

  el.innerHTML = data.data.data.map(j => `
    <div class="list-item" onclick="openUrl('/jobs/${j.id}')">
      <div class="li-icon" style="background:rgba(37,99,235,.1);color:#60a5fa">
        <svg viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/></svg>
      </div>
      <div class="li-body">
        <div class="li-title">${j.title}</div>
        <div class="li-sub">${j.company || ''} · ${j.location || 'Remote'}</div>
      </div>
      <div class="li-right" style="color:#4ade80">${j.salary_min ? Math.round(j.salary_min/1000000)+'M' : '—'}</div>
    </div>
  `).join('') + `<button class="tg-btn tg-btn-outline" style="margin-top:8px" onclick="showPage('jobs')">Barchasi →</button>`;
}

// ── ECO DATA ──
async function loadEco() {
  window._ecoLoaded = true;
  const [statsData, tasksData] = await Promise.all([
    fetchApi('/api/v1/tg/eco-stats'),
    fetchApi('/api/v1/tg/eco-tasks'),
  ]);

  if (statsData?.success) {
    document.getElementById('eco-total').textContent = statsData.total_actions || 0;
    document.getElementById('eco-today').textContent = statsData.today_actions || 0;
    document.getElementById('eco-gc').textContent = (statsData.total_gc || 0).toLocaleString();
  }

  const el = document.getElementById('eco-tasks-list');
  if (!tasksData?.tasks?.length) { el.innerHTML = '<div class="empty"><p>Hozircha eco vazifalar yo\'q</p></div>'; return; }

  el.innerHTML = tasksData.tasks.map(t => `
    <div class="task-card">
      <div class="tc-title">${t.title}</div>
      <div class="tc-desc">${t.description || ''}</div>
      <div class="tc-footer">
        <span class="badge badge-green">+${t.reward} GC</span>
        <button class="tg-btn" style="width:auto;padding:8px 16px;margin:0;font-size:13px"
          onclick="openUrl('/eco')">Bajarish</button>
      </div>
    </div>
  `).join('');
}

// ── JOBS DATA ──
async function loadJobs() {
  window._jobsLoaded = true;
  const data = await fetchApi('/api/v1/jobs?per_page=15');
  const el = document.getElementById('jobs-list');

  if (!data?.data?.data?.length) { el.innerHTML = '<div class="empty"><svg viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2"/></svg><p>Ish e\'lonlari yo\'q</p></div>'; return; }

  el.innerHTML = data.data.data.map(j => `
    <div class="list-item" onclick="openUrl('/jobs/${j.id}')">
      <div class="li-icon" style="background:rgba(37,99,235,.1);color:#60a5fa;font-weight:800;font-size:14px">
        ${(j.company || 'C')[0].toUpperCase()}
      </div>
      <div class="li-body">
        <div class="li-title">${j.title}</div>
        <div class="li-sub">${j.company || ''} · ${j.location || 'Remote'}</div>
      </div>
      <div class="li-right" style="color:#4ade80">${j.salary_min ? Math.round(j.salary_min/1000000)+'M' : '—'}</div>
    </div>
  `).join('');
}

function renderJobSkeleton() {
  return Array(3).fill(`
    <div style="background:var(--bg2);border-radius:12px;padding:14px 16px;margin-bottom:8px;border:1px solid rgba(255,255,255,.05)">
      <div style="height:14px;width:60%;background:rgba(255,255,255,.06);border-radius:4px;margin-bottom:6px"></div>
      <div style="height:11px;width:40%;background:rgba(255,255,255,.04);border-radius:4px"></div>
    </div>
  `).join('');
}

// ── INIT ──
loadHome();
</script>
</body>
</html>
