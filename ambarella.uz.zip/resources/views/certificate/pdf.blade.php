<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sertifikat — {{ $user_name }}</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            background: #0f172a;
            font-family: 'Georgia', 'Times New Roman', serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px 20px;
        }

        .certificate-wrapper {
            width: 100%;
            max-width: 900px;
            position: relative;
        }

        .certificate {
            background: linear-gradient(145deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
            border-radius: 12px;
            padding: 60px;
            position: relative;
            overflow: hidden;
            box-shadow: 0 25px 80px rgba(0,0,0,.5), 0 0 40px rgba(212,175,55,.08);
        }

        /* Decorative border */
        .certificate::before {
            content: '';
            position: absolute;
            inset: 8px;
            border: 3px solid transparent;
            border-image: linear-gradient(135deg, #d4af37, #f0d060, #d4af37, #aa8c2c, #d4af37) 1;
            border-radius: 8px;
            pointer-events: none;
        }

        .certificate::after {
            content: '';
            position: absolute;
            inset: 14px;
            border: 1px solid rgba(212,175,55,.25);
            border-radius: 6px;
            pointer-events: none;
        }

        /* Corner decorations */
        .corner {
            position: absolute;
            width: 60px;
            height: 60px;
            border: 2px solid #d4af37;
            opacity: 0.6;
        }
        .corner-tl { top: 24px; left: 24px; border-right: none; border-bottom: none; }
        .corner-tr { top: 24px; right: 24px; border-left: none; border-bottom: none; }
        .corner-bl { bottom: 24px; left: 24px; border-right: none; border-top: none; }
        .corner-br { bottom: 24px; right: 24px; border-left: none; border-top: none; }

        /* Decorative circles */
        .deco-circle {
            position: absolute;
            border-radius: 50%;
            border: 1px solid rgba(212,175,55,.15);
        }
        .deco-circle-1 { width: 200px; height: 200px; top: -60px; right: -60px; }
        .deco-circle-2 { width: 150px; height: 150px; bottom: -40px; left: -40px; }
        .deco-circle-3 { width: 100px; height: 100px; top: 50%; left: -30px; transform: translateY(-50%); }

        .content {
            position: relative;
            z-index: 10;
            text-align: center;
        }

        .logo {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            margin-bottom: 30px;
        }

        .logo-icon {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, #d4af37, #f0d060);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            box-shadow: 0 4px 20px rgba(212,175,55,.3);
        }

        .logo-text {
            font-size: 20px;
            font-weight: 700;
            color: #d4af37;
            letter-spacing: 3px;
            text-transform: uppercase;
            font-family: 'Arial', sans-serif;
        }

        .divider {
            width: 120px;
            height: 2px;
            background: linear-gradient(90deg, transparent, #d4af37, transparent);
            margin: 20px auto;
        }

        .title {
            font-size: 48px;
            font-weight: 700;
            color: #d4af37;
            letter-spacing: 12px;
            text-transform: uppercase;
            text-shadow: 0 2px 10px rgba(212,175,55,.3);
            margin-bottom: 10px;
        }

        .subtitle {
            font-size: 14px;
            color: #94a3b8;
            letter-spacing: 4px;
            text-transform: uppercase;
            margin-bottom: 32px;
        }

        .award-text {
            font-size: 15px;
            color: #cbd5e1;
            margin-bottom: 10px;
        }

        .recipient-name {
            font-size: 36px;
            font-weight: 700;
            color: #fff;
            font-style: italic;
            margin-bottom: 16px;
            padding-bottom: 12px;
            border-bottom: 2px solid rgba(212,175,55,.3);
            display: inline-block;
        }

        .course-label {
            font-size: 14px;
            color: #94a3b8;
            margin-bottom: 8px;
        }

        .course-name {
            font-size: 22px;
            font-weight: 600;
            color: #e2e8f0;
            margin-bottom: 36px;
            padding: 12px 24px;
            background: rgba(212,175,55,.05);
            border: 1px solid rgba(212,175,55,.15);
            border-radius: 8px;
            display: inline-block;
        }

        .details-row {
            display: flex;
            justify-content: center;
            gap: 60px;
            margin-top: 36px;
            padding-top: 24px;
            border-top: 1px solid rgba(212,175,55,.15);
        }

        .detail-item {
            text-align: center;
        }

        .detail-label {
            font-size: 11px;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 2px;
            margin-bottom: 6px;
        }

        .detail-value {
            font-size: 15px;
            color: #e2e8f0;
            font-weight: 600;
        }

        .cert-id {
            margin-top: 28px;
            font-size: 11px;
            color: #475569;
            letter-spacing: 2px;
            font-family: 'Courier New', monospace;
        }

        .qr-section {
            margin-top: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
        }

        .qr-placeholder {
            width: 80px;
            height: 80px;
            background: rgba(255,255,255,.05);
            border: 1px solid rgba(212,175,55,.2);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 10px;
            color: #64748b;
        }

        .qr-text {
            font-size: 11px;
            color: #475569;
            text-align: left;
            line-height: 1.5;
        }

        .print-section {
            text-align: center;
            margin-top: 30px;
        }

        .print-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 14px 32px;
            background: linear-gradient(135deg, #d4af37, #aa8c2c);
            color: #0f172a;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 700;
            cursor: pointer;
            transition: all .2s;
            box-shadow: 0 4px 20px rgba(212,175,55,.3);
        }

        .print-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 30px rgba(212,175,55,.4);
        }

        /* Stars decorations */
        .star {
            position: absolute;
            color: #d4af37;
            opacity: 0.3;
            font-size: 18px;
        }
        .star-1 { top: 40px; left: 80px; }
        .star-2 { top: 40px; right: 80px; }
        .star-3 { bottom: 40px; left: 80px; }
        .star-4 { bottom: 40px; right: 80px; }

        @media print {
            body {
                background: #fff;
                padding: 0;
            }
            .certificate {
                background: #fff !important;
                box-shadow: none;
                border: 3px solid #d4af37;
            }
            .certificate::before {
                border-image: linear-gradient(135deg, #d4af37, #b8860b, #d4af37) 1;
            }
            .title { color: #b8860b; text-shadow: none; }
            .logo-text { color: #b8860b; }
            .recipient-name { color: #1a1a2e; border-bottom-color: #d4af37; }
            .course-name { color: #1a1a2e; background: rgba(212,175,55,.05); }
            .award-text, .course-label { color: #4a5568; }
            .detail-value { color: #1a1a2e; }
            .detail-label { color: #6b7280; }
            .cert-id { color: #6b7280; }
            .subtitle { color: #6b7280; }
            .print-section { display: none; }
            .logo-icon { print-color-adjust: exact; -webkit-print-color-adjust: exact; }
            .corner { border-color: #b8860b; }
        }

        @media (max-width: 640px) {
            .certificate { padding: 30px 20px; }
            .title { font-size: 28px; letter-spacing: 6px; }
            .recipient-name { font-size: 24px; }
            .course-name { font-size: 16px; }
            .details-row { flex-direction: column; gap: 16px; }
        }
    </style>
</head>
<body>
    <div class="certificate-wrapper">
        <div class="certificate">
            <!-- Decorative elements -->
            <div class="corner corner-tl"></div>
            <div class="corner corner-tr"></div>
            <div class="corner corner-bl"></div>
            <div class="corner corner-br"></div>
            <div class="deco-circle deco-circle-1"></div>
            <div class="deco-circle deco-circle-2"></div>
            <div class="deco-circle deco-circle-3"></div>
            <span class="star star-1">✦</span>
            <span class="star star-2">✦</span>
            <span class="star star-3">✦</span>
            <span class="star star-4">✦</span>

            <div class="content">
                <!-- Logo -->
                <div class="logo">
                    <div class="logo-icon">🌿</div>
                    <span class="logo-text">AMBARELLA.UZ</span>
                </div>

                <div class="divider"></div>

                <h1 class="title">SERTIFIKAT</h1>
                <p class="subtitle">Certificate of Completion</p>

                <p class="award-text">Ushbu sertifikat quyidagi shaxsga berildi:</p>

                <h2 class="recipient-name">{{ $user_name }}</h2>

                <p class="course-label">quyidagi kursni muvaffaqiyatli yakunlaganligi uchun:</p>

                <div class="course-name">{{ $course_title }}</div>

                <div class="details-row">
                    <div class="detail-item">
                        <div class="detail-label">O'qituvchi</div>
                        <div class="detail-value">{{ $instructor ?? 'AMBARELLA Team' }}</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Sana</div>
                        <div class="detail-value">{{ $date }}</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Sertifikat ID</div>
                        <div class="detail-value">{{ $certificate_id }}</div>
                    </div>
                </div>

                <div class="qr-section">
                    <div class="qr-placeholder">
                        <svg width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect x="5" y="5" width="15" height="15" stroke="#64748b" stroke-width="2" fill="none"/>
                            <rect x="8" y="8" width="9" height="9" fill="#64748b"/>
                            <rect x="30" y="5" width="15" height="15" stroke="#64748b" stroke-width="2" fill="none"/>
                            <rect x="33" y="8" width="9" height="9" fill="#64748b"/>
                            <rect x="5" y="30" width="15" height="15" stroke="#64748b" stroke-width="2" fill="none"/>
                            <rect x="8" y="33" width="9" height="9" fill="#64748b"/>
                            <rect x="30" y="30" width="5" height="5" fill="#64748b"/>
                            <rect x="37" y="30" width="5" height="5" fill="#64748b"/>
                            <rect x="30" y="37" width="5" height="5" fill="#64748b"/>
                            <rect x="40" y="40" width="5" height="5" fill="#64748b"/>
                        </svg>
                    </div>
                    <div class="qr-text">
                        Tekshirish:<br>
                        <span style="color:#d4af37">{{ url('/certificate/verify/' . $certificate_id) }}</span>
                    </div>
                </div>

                <p class="cert-id">{{ $certificate_id }}</p>
            </div>
        </div>

        <div class="print-section">
            <button class="print-btn" onclick="window.print()">
                <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path d="M6 9V2h12v7M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/>
                    <rect x="6" y="14" width="12" height="8"/>
                </svg>
                PDF sifatida saqlash
            </button>
        </div>
    </div>
</body>
</html>
