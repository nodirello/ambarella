@extends('layouts.app')
@section('title', 'Sertifikat topilmadi')
@section('styles')
<style>
.invalid-page{padding:60px 0;text-align:center}
.invalid-card{max-width:440px;margin:0 auto;background:var(--surface);border:1px solid rgba(220,38,38,.3);border-radius:var(--radius);padding:40px;box-shadow:0 0 40px rgba(220,38,38,.05)}
.invalid-icon{font-size:56px;margin-bottom:16px}
.invalid-title{font-size:22px;font-weight:800;color:#fca5a5;margin-bottom:12px}
.invalid-text{color:var(--muted);font-size:14px;line-height:1.6;margin-bottom:24px}
</style>
@endsection
@section('content')
<div class="container">
    <div class="invalid-page">
        <div class="invalid-card">
            <div class="invalid-icon">❌</div>
            <h1 class="invalid-title">Sertifikat topilmadi</h1>
            <p class="invalid-text">
                Ushbu sertifikat ID bo'yicha ma'lumot topilmadi. 
                Iltimos, sertifikat raqamini tekshiring yoki administratsiya bilan bog'laning.
            </p>
            <a href="{{ route('home') }}" class="btn btn-primary" style="padding:12px 24px;font-size:14px">
                ← Bosh sahifaga qaytish
            </a>
        </div>
    </div>
</div>
@endsection
