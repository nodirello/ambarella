@extends('layouts.app')
@section('title', 'Sertifikat tekshirish')
@section('styles')
<style>
.verify-page{padding:60px 0;text-align:center}
.verify-card{max-width:500px;margin:0 auto;background:var(--surface);border:1px solid rgba(34,197,94,.3);border-radius:var(--radius);padding:40px;box-shadow:0 0 40px rgba(34,197,94,.05)}
.verify-icon{font-size:56px;margin-bottom:16px}
.verify-title{font-size:22px;font-weight:800;color:#86efac;margin-bottom:24px}
.verify-info{text-align:left;margin-top:20px}
.verify-row{display:flex;justify-content:space-between;padding:12px 0;border-bottom:1px solid var(--border)}
.verify-row:last-child{border-bottom:none}
.verify-label{font-size:13px;color:var(--muted);font-weight:600}
.verify-value{font-size:14px;color:#fff;font-weight:600}
.verify-badge{display:inline-flex;align-items:center;gap:8px;background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.3);border-radius:20px;padding:8px 20px;font-size:13px;color:#86efac;font-weight:600;margin-top:20px}
</style>
@endsection
@section('content')
<div class="container">
    <div class="verify-page">
        <div class="verify-card">
            <div class="verify-icon">✅</div>
            <h1 class="verify-title">Bu sertifikat haqiqiy!</h1>
            <p style="color:var(--muted);font-size:14px">Ushbu sertifikat AMBARELLA.UZ platformasi tomonidan berilgan.</p>
            
            <div class="verify-info">
                <div class="verify-row">
                    <span class="verify-label">Foydalanuvchi</span>
                    <span class="verify-value">{{ $user->name }}</span>
                </div>
                <div class="verify-row">
                    <span class="verify-label">Kurs</span>
                    <span class="verify-value">{{ $course->title }}</span>
                </div>
                <div class="verify-row">
                    <span class="verify-label">O'qituvchi</span>
                    <span class="verify-value">{{ $course->instructor ?? 'AMBARELLA Team' }}</span>
                </div>
                <div class="verify-row">
                    <span class="verify-label">Sertifikat ID</span>
                    <span class="verify-value" style="font-family:monospace;color:#d4af37">{{ $id }}</span>
                </div>
            </div>

            <div class="verify-badge">
                <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
                </svg>
                Tasdiqlangan
            </div>
        </div>
    </div>
</div>
@endsection
