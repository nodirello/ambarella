@extends('layouts.app')
@section('title', 'Ekologiya — Eco Vazifalar | AMBARELLA')
@section('description', 'Ekologik harakatlar: daraxt ekish, chiqindi tozalash, CO₂ kamaytirish. Har bir harakatga GreenCoin oling.')
@section('styles')
<style>
/* HERO */
.eco-hero{padding:64px 0 48px;position:relative;overflow:hidden}
.eco-hero::before{content:'';position:absolute;inset:0;background:radial-gradient(ellipse at 30% 50%,rgba(22,163,74,.08),transparent 60%),radial-gradient(ellipse at 80% 20%,rgba(8,145,178,.06),transparent 50%)}
.eco-hero-inner{display:grid;grid-template-columns:1fr 1fr;gap:48px;align-items:center}
.eco-hero h1{font-size:clamp(28px,4vw,42px);font-weight:900;color:#fff;margin-bottom:12px}
.eco-hero h1 span{background:linear-gradient(135deg,#4ade80,#22d3ee);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.eco-hero p{font-size:16px;color:#94a3b8;line-height:1.7;max-width:460px}
/* ECO Stats */
.eco-global-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-top:48px}
.egs-card{background:var(--surface);border:1px solid rgba(22,163,74,.15);border-radius:14px;padding:20px;text-align:center;transition:all .3s;position:relative;overflow:hidden}
.egs-card::before{content:'';position:absolute;inset:0;background:linear-gradient(135deg,rgba(22,163,74,.03),transparent)}
.egs-card:hover{border-color:rgba(22,163,74,.3);transform:translateY(-2px)}
.egs-card .egs-num{font-size:26px;font-weight:800;color:#4ade80}
.egs-card .egs-lbl{font-size:11px;color:var(--muted);margin-top:4px}
/* User Stats Banner */
.eco-user-banner{background:linear-gradient(135deg,rgba(22,163,74,.06),rgba(8,145,178,.04));border:1px solid rgba(22,163,74,.15);border-radius:16px;padding:20px 28px;margin-bottom:32px;display:flex;align-items:center;gap:32px;flex-wrap:wrap}
.eub-item{text-align:center}
.eub-item strong{display:block;font-size:24px;font-weight:800;color:#4ade80}
.eub-item span{font-size:11px;color:var(--muted)}
.eub-divider{width:1px;height:40px;background:var(--border)}
/* Tasks Layout */
.eco-layout{display:grid;grid-template-columns:220px 1fr;gap:28px;padding-bottom:64px}
/* Category Sidebar */
.eco-categories{display:flex;flex-direction:column;gap:6px;position:sticky;top:90px}
.eco-cat-btn{display:flex;align-items:center;gap:10px;padding:12px 16px;border-radius:12px;font-size:13px;font-weight:600;color:#94a3b8;background:var(--surface);border:1px solid var(--border);transition:all .2s;cursor:pointer;text-decoration:none}
.eco-cat-btn:hover{color:#fff;border-color:rgba(34,197,94,.3)}
.eco-cat-btn.active{background:rgba(34,197,94,.08);color:#4ade80;border-color:rgba(34,197,94,.2)}
.eco-cat-btn svg{width:16px;height:16px;stroke:currentColor;fill:none;stroke-width:1.8}
/* Tasks */
.eco-tasks{display:flex;flex-direction:column;gap:14px}
.eco-task-card{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:22px 26px;transition:all .35s cubic-bezier(.4,0,.2,1);position:relative;overflow:hidden}
.eco-task-card:hover{transform:translateY(-3px);box-shadow:0 12px 32px rgba(0,0,0,.12)}
.eco-task-card.completed{opacity:.65}
.etc-accent{position:absolute;left:0;top:0;bottom:0;width:4px;border-radius:4px 0 0 4px;transition:width .3s}
.eco-task-card:hover .etc-accent{width:5px}
.etc-main{display:grid;grid-template-columns:1fr auto;gap:20px;align-items:center}
.etc-icon{width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-right:16px}
.etc-icon svg{width:22px;height:22px;stroke:currentColor;fill:none;stroke-width:1.8}
.etc-left{display:flex;align-items:center}
.etc-title{font-size:16px;font-weight:700;color:#fff;margin-bottom:4px}
.etc-desc{font-size:13px;color:#94a3b8;line-height:1.5}
.etc-meta{display:flex;align-items:center;gap:12px;margin-top:10px;flex-wrap:wrap}
.etc-cat{padding:3px 10px;border-radius:999px;font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:.5px}
.etc-co2{font-size:11px;color:#22d3ee;font-weight:600;display:flex;align-items:center;gap:4px}
.etc-co2 svg{width:11px;height:11px;stroke:currentColor;fill:none;stroke-width:2}
.etc-right{display:flex;flex-direction:column;align-items:flex-end;gap:10px}
.etc-reward{display:flex;align-items:center;gap:6px;padding:10px 18px;border-radius:12px;font-size:20px;font-weight:800;white-space:nowrap}
.etc-reward svg{width:18px;height:18px;stroke:currentColor;fill:none;stroke-width:2}
.etc-done-badge{display:flex;align-items:center;gap:6px;padding:8px 16px;border-radius:999px;font-size:12px;font-weight:700;background:rgba(34,197,94,.1);color:#4ade80;border:1px solid rgba(34,197,94,.2)}
.etc-done-badge svg{width:13px;height:13px;stroke:currentColor;fill:none;stroke-width:2.5}
/* Leaderboard */
.eco-lb{background:var(--surface);border:1px solid var(--border);border-radius:16px;overflow:hidden;margin-top:28px}
.eco-lb-header{padding:18px 24px;border-bottom:1px solid var(--border);font-size:14px;font-weight:700;color:#fff;display:flex;align-items:center;gap:8px}
.eco-lb-header svg{width:16px;height:16px;stroke:#fbbf24;fill:none;stroke-width:2}
.eco-lb-row{display:flex;align-items:center;gap:12px;padding:12px 24px;border-bottom:1px solid var(--border);transition:background .2s}
.eco-lb-row:last-child{border:none}
.eco-lb-row:hover{background:rgba(255,255,255,.02)}
.eco-lb-rank{width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:800;flex-shrink:0}
.eco-lb-name{flex:1;font-size:13px;color:#e2e8f0;font-weight:500}
.eco-lb-coin{font-size:13px;font-weight:700;color:#4ade80}
@media(max-width:1024px){.eco-hero-inner{grid-template-columns:1fr}.eco-layout{grid-template-columns:1fr}.eco-categories{flex-direction:row;flex-wrap:wrap;position:static}.eco-global-stats{grid-template-columns:1fr 1fr}}
@media(max-width:768px){.eco-global-stats{grid-template-columns:1fr 1fr}.etc-main{grid-template-columns:1fr}.etc-right{align-items:flex-start;flex-direction:row;flex-wrap:wrap}.eco-user-banner{gap:16px}.eub-divider{display:none}}
</style>
@endsection
@section('content')

{{-- HERO --}}
<section class="eco-hero">
  <div class="container">
    <div class="eco-hero-inner">
      <div>
        <h1>Ekologiya uchun <span>harakat qiling</span></h1>
        <p>Daraxt ekish, chiqindi yig'ish, velosiped minish — har bir yaxshi harakat uchun GreenCoin ishlang va tabiatni asrang.</p>
        @guest
        <div style="display:flex;gap:12px;margin-top:24px">
          <a href="/register" class="btn btn-success">Boshlash — bepul</a>
          <a href="/login" class="btn btn-outline">Kirish</a>
        </div>
        @endguest
      </div>
      <div>
        <svg viewBox="0 0 320 280" style="max-width:320px;width:100%;height:auto">
          <defs>
            <linearGradient id="treeGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#16a34a" stop-opacity=".8"/>
              <stop offset="100%" stop-color="#22d3ee" stop-opacity=".6"/>
            </linearGradient>
          </defs>
          <circle cx="160" cy="140" r="130" fill="rgba(22,163,74,.04)" stroke="rgba(22,163,74,.08)" stroke-width="1"/>
          <circle cx="160" cy="140" r="90" fill="none" stroke="rgba(22,163,74,.06)" stroke-width="1" stroke-dasharray="4 6"/>
          <!-- Tree -->
          <rect x="153" y="200" width="14" height="40" rx="4" fill="rgba(134,87,47,.4)"/>
          <polygon points="160,80 130,160 190,160" fill="rgba(22,163,74,.5)"/>
          <polygon points="160,110 125,190 195,190" fill="rgba(22,163,74,.7)"/>
          <polygon points="160,140 120,220 200,220" fill="rgba(22,163,74,.9)"/>
          <!-- Leaf particles -->
          <circle cx="100" cy="100" r="6" fill="rgba(74,222,128,.4)"><animate attributeName="cy" values="100;90;100" dur="3s" repeatCount="indefinite"/></circle>
          <circle cx="220" cy="120" r="5" fill="rgba(34,197,94,.5)"><animate attributeName="cy" values="120;108;120" dur="4s" repeatCount="indefinite"/></circle>
          <circle cx="80" cy="170" r="4" fill="rgba(74,222,128,.3)"><animate attributeName="cy" values="170;158;170" dur="3.5s" repeatCount="indefinite"/></circle>
          <circle cx="240" cy="180" r="7" fill="rgba(22,163,74,.4)"><animate attributeName="cy" values="180;168;180" dur="2.8s" repeatCount="indefinite"/></circle>
          <!-- CO2 -->
          <text x="90" y="75" fill="#22d3ee" font-size="11" font-weight="700" font-family="Inter,sans-serif" opacity=".7">CO₂</text>
          <text x="205" y="90" fill="#4ade80" font-size="11" font-weight="700" font-family="Inter,sans-serif" opacity=".7">-2g</text>
          <text x="60" y="145" fill="#a78bfa" font-size="10" font-family="Inter,sans-serif" opacity=".6">+GC</text>
        </svg>
      </div>
    </div>

    {{-- Global Stats --}}
    <div class="eco-global-stats">
      <div class="egs-card">
        <div class="egs-num">{{ number_format($stats['total_actions']) }}</div>
        <div class="egs-lbl">Jami eco-harakatlar</div>
      </div>
      <div class="egs-card">
        <div class="egs-num">{{ number_format($stats['total_co2']) }}g</div>
        <div class="egs-lbl">Tejlagan CO₂</div>
      </div>
      <div class="egs-card">
        <div class="egs-num">{{ number_format($stats['total_coins']) }}</div>
        <div class="egs-lbl">GreenCoin berildi</div>
      </div>
      <div class="egs-card">
        <div class="egs-num">{{ number_format($stats['total_users']) }}</div>
        <div class="egs-lbl">Faol ekologlar</div>
      </div>
    </div>
  </div>
</section>

<div class="container">
  {{-- User stats banner --}}
  @auth
  <div class="eco-user-banner">
    <div class="eub-item"><strong>{{ number_format($userStats['balance']) }}</strong><span>GC balans</span></div>
    <div class="eub-divider"></div>
    <div class="eub-item"><strong>{{ $userStats['tasks_done'] }}</strong><span>Jami bajarildi</span></div>
    <div class="eub-divider"></div>
    <div class="eub-item"><strong>+{{ $userStats['today_earned'] }}</strong><span>Bugun GC</span></div>
    <div class="eub-divider"></div>
    <div class="eub-item"><strong>{{ number_format($userStats['total_earned']) }}</strong><span>Jami ishlangan</span></div>
    <div style="margin-left:auto">
      <a href="/greencoin" class="btn btn-outline" style="font-size:13px;padding:10px 18px">Hamyon &rarr;</a>
    </div>
  </div>
  @endauth

  @if(session('success'))
    <div class="alert alert-success" style="margin-bottom:20px">{!! session('success') !!}</div>
  @endif
  @if($errors->any())
    <div class="alert alert-error" style="margin-bottom:20px">{{ $errors->first() }}</div>
  @endif

  <div class="eco-layout">
    {{-- Category filter --}}
    <div class="eco-categories">
      <a href="#" class="eco-cat-btn active" data-cat="all" onclick="filterTasks('all',this);return false">
        <svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
        Barchasi
      </a>
      @foreach($categories as $cat)
      <a href="#" class="eco-cat-btn" data-cat="{{ $cat }}" onclick="filterTasks('{{ $cat }}',this);return false">
        <svg viewBox="0 0 24 24"><path d="M12 22c4-2.5 7-6 7-10a7 7 0 00-14 0c0 4 3 7.5 7 10z"/></svg>
        {{ ucfirst($cat) }}
      </a>
      @endforeach
      <div style="margin-top:12px;padding:14px;background:rgba(22,163,74,.04);border:1px solid rgba(22,163,74,.1);border-radius:12px;font-size:11px;color:var(--muted);line-height:1.6">
        💡 Har bir vazifa <strong style="color:#4ade80">1 marta/kun</strong> bajarilishi mumkin
      </div>
    </div>

    {{-- Tasks + Leaderboard --}}
    <div>
      <div class="eco-tasks" id="ecoTasksList">
        @forelse($tasks as $task)
        @php $color = $task->category_color ?? '#4ade80'; @endphp
        <div class="eco-task-card {{ !empty($task->completed_today) ? 'completed' : '' }}" data-cat="{{ $task->category }}">
          <div class="etc-accent" style="background:{{ $color }}"></div>
          <div class="etc-main">
            <div class="etc-left">
              <div class="etc-icon" style="background:color-mix(in srgb,{{ $color }} 10%,transparent);color:{{ $color }}">
                <svg viewBox="0 0 24 24">{!! $task->category_icon !!}</svg>
              </div>
              <div>
                <div class="etc-title">{{ $task->title }}</div>
                <div class="etc-desc">{{ $task->description }}</div>
                <div class="etc-meta">
                  @if($task->category)
                  <span class="etc-cat" style="background:color-mix(in srgb,{{ $color }} 10%,transparent);color:{{ $color }}">{{ $task->category }}</span>
                  @endif
                  <span class="etc-co2">
                    <svg viewBox="0 0 24 24"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
                    ~{{ ($task->reward * 2) }}g CO₂ tejlaydi
                  </span>
                </div>
              </div>
            </div>
            <div class="etc-right">
              <div class="etc-reward" style="background:color-mix(in srgb,{{ $color }} 8%,transparent);color:{{ $color }};border:1px solid color-mix(in srgb,{{ $color }} 15%,transparent)">
                <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 6v12M8 10h8"/></svg>
                +{{ $task->reward }} GC
              </div>
              @auth
                @if(!empty($task->completed_today))
                  <span class="etc-done-badge"><svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg> Bajarildi</span>
                @else
                  <form action="/eco/tasks/{{ $task->id }}/complete" method="POST">
                    @csrf
                    <button type="submit" class="btn btn-success" style="padding:10px 20px;font-size:13px">Bajarish</button>
                  </form>
                @endif
              @else
                <a href="/login" class="btn btn-outline" style="padding:10px 18px;font-size:12px">Kirish</a>
              @endauth
            </div>
          </div>
        </div>
        @empty
        <div style="text-align:center;padding:60px;color:var(--muted)">
          <p>Hozircha eco vazifalar yo'q.</p>
        </div>
        @endforelse
      </div>

      {{-- Leaderboard --}}
      <div class="eco-lb">
        <div class="eco-lb-header">
          <svg viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
          GreenCoin Liderlar
        </div>
        @foreach($leaderboard as $i => $leader)
        <div class="eco-lb-row">
          <div class="eco-lb-rank" style="
            @if($i===0) background:rgba(251,191,36,.15);color:#fbbf24
            @elseif($i===1) background:rgba(148,163,184,.12);color:#94a3b8
            @elseif($i===2) background:rgba(180,83,9,.12);color:#f97316
            @else background:rgba(255,255,255,.04);color:var(--muted)
            @endif">{{ $i+1 }}</div>
          <a href="/user/{{ $leader->id }}" class="eco-lb-name">{{ $leader->name }}</a>
          @auth @if(auth()->id() === $leader->id)
            <span style="font-size:10px;background:rgba(37,99,235,.1);color:#93c5fd;padding:2px 6px;border-radius:4px">Sen</span>
          @endif @endauth
          <span class="eco-lb-coin">{{ number_format($leader->greencoin_balance) }} GC</span>
        </div>
        @endforeach
        <div style="padding:12px 24px;text-align:center">
          <a href="/greencoin/leaderboard" style="font-size:12px;color:var(--primary)">To'liq liderlar jadvali &rarr;</a>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
function filterTasks(cat, btn) {
  document.querySelectorAll('.eco-cat-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.querySelectorAll('.eco-task-card').forEach(card => {
    if (cat === 'all' || card.dataset.cat === cat) {
      card.style.display = '';
    } else {
      card.style.display = 'none';
    }
  });
}
</script>
@endsection
