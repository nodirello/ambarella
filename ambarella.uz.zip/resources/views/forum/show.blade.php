@extends('layouts.app')
@section('title', $topic->title . ' — Forum | AMBARELLA')
@section('styles')
<style>
.forum-page{padding:40px 0 80px;max-width:860px;margin:0 auto}
.forum-back{display:inline-flex;align-items:center;gap:6px;color:var(--muted);font-size:13px;margin-bottom:24px;transition:color .2s}
.forum-back:hover{color:#93c5fd}
.forum-back svg{width:15px;height:15px;stroke:currentColor;fill:none;stroke-width:2}
/* Question */
.q-card{background:var(--surface);border:1px solid var(--border);border-radius:18px;overflow:hidden;margin-bottom:28px}
.q-header{padding:28px 32px;border-bottom:1px solid var(--border)}
.q-meta-top{display:flex;align-items:center;gap:8px;margin-bottom:14px;flex-wrap:wrap}
.q-badge{padding:4px 12px;border-radius:999px;font-size:11px;font-weight:700}
.qb-cat{background:rgba(124,58,237,.1);color:#a78bfa;border:1px solid rgba(124,58,237,.15)}
.qb-solved{background:rgba(34,197,94,.1);color:#4ade80;border:1px solid rgba(34,197,94,.15);display:flex;align-items:center;gap:4px}
.q-title{font-size:clamp(18px,3vw,24px);font-weight:800;color:#fff;line-height:1.4;margin-bottom:14px}
.q-author-row{display:flex;align-items:center;gap:10px}
.q-avatar{width:38px;height:38px;border-radius:50%;background:linear-gradient(135deg,#2563eb,#7c3aed);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:13px;flex-shrink:0}
.q-author-name{font-size:13px;font-weight:600;color:#fff}
.q-author-date{font-size:11px;color:var(--muted)}
.q-stats{display:flex;gap:16px;margin-left:auto}
.q-stat{font-size:12px;color:var(--muted);display:flex;align-items:center;gap:4px}
.q-stat svg{width:13px;height:13px;stroke:currentColor;fill:none;stroke-width:2}
.q-body{padding:28px 32px;font-size:14px;color:#cbd5e1;line-height:1.9;white-space:pre-wrap;word-break:break-word}
/* Replies */
.replies-header{font-size:17px;font-weight:700;color:#fff;margin-bottom:18px;display:flex;align-items:center;gap:8px}
.rh-count{background:rgba(37,99,235,.12);color:#93c5fd;padding:2px 10px;border-radius:999px;font-size:12px}
.reply-card{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:22px 26px;margin-bottom:12px;transition:border-color .3s;position:relative}
.reply-card:hover{border-color:rgba(37,99,235,.15)}
.reply-card.best{border-color:rgba(34,197,94,.25);background:rgba(34,197,94,.02)}
.best-tag{display:inline-flex;align-items:center;gap:5px;font-size:11px;font-weight:700;color:#4ade80;background:rgba(34,197,94,.1);padding:4px 10px;border-radius:999px;margin-bottom:12px}
.best-tag svg{width:11px;height:11px;stroke:currentColor;fill:none;stroke-width:2.5}
.reply-body{font-size:13.5px;color:#cbd5e1;line-height:1.8;white-space:pre-wrap;word-break:break-word;margin-bottom:14px}
.reply-footer{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;padding-top:12px;border-top:1px solid var(--border)}
.reply-author-row{display:flex;align-items:center;gap:8px}
.r-avatar{width:30px;height:30px;border-radius:50%;background:linear-gradient(135deg,#7c3aed,#ec4899);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:600;font-size:11px;flex-shrink:0}
.r-name{font-size:12px;font-weight:600;color:#fff}
.r-date{font-size:10px;color:var(--muted)}
.best-btn{display:inline-flex;align-items:center;gap:5px;padding:6px 14px;border-radius:999px;background:rgba(34,197,94,.08);border:1px solid rgba(34,197,94,.15);color:#4ade80;font-size:11px;font-weight:700;cursor:pointer;transition:all .2s}
.best-btn:hover{background:rgba(34,197,94,.15)}
.best-btn svg{width:11px;height:11px;stroke:currentColor;fill:none;stroke-width:2.5}
/* Reply Form */
.reply-form-card{background:var(--surface);border:1px solid var(--border);border-radius:18px;padding:28px}
.rfc-title{font-size:16px;font-weight:700;color:#fff;margin-bottom:16px;display:flex;align-items:center;gap:8px}
.rfc-title svg{width:17px;height:17px;stroke:#60a5fa;fill:none;stroke-width:2}
.rfc-textarea{width:100%;min-height:120px;padding:14px;border-radius:12px;border:1px solid var(--border);background:rgba(255,255,255,.02);color:#fff;font-size:14px;resize:vertical;font-family:inherit;line-height:1.6;transition:border-color .2s}
.rfc-textarea:focus{outline:none;border-color:var(--primary)}
.rfc-actions{display:flex;justify-content:flex-end;gap:10px;margin-top:12px}
</style>
@endsection
@section('content')
<div class="container">
  <div class="forum-page">
    <a href="{{ route('forum') }}" class="forum-back">
      <svg viewBox="0 0 24 24"><polyline points="15 18 9 12 15 6"/></svg>
      Forumga qaytish
    </a>

    {{-- Question --}}
    <div class="q-card">
      <div class="q-header">
        <div class="q-meta-top">
          <span class="q-badge qb-cat">{{ $topic->category }}</span>
          @if($topic->is_solved)
            <span class="q-badge qb-solved"><svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>Hal qilindi</span>
          @endif
        </div>
        <h1 class="q-title">{{ $topic->title }}</h1>
        <div class="q-author-row">
          <div class="q-avatar">{{ strtoupper(mb_substr($topic->user->name ?? 'U', 0, 1)) }}</div>
          <div>
            <div class="q-author-name">{{ $topic->user->name ?? 'Foydalanuvchi' }}</div>
            <div class="q-author-date">{{ $topic->created_at->format('d M Y, H:i') }}</div>
          </div>
          <div class="q-stats">
            <span class="q-stat"><svg viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>{{ $topic->views_count }}</span>
            <span class="q-stat"><svg viewBox="0 0 24 24"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>{{ $topic->replies->count() }}</span>
          </div>
        </div>
      </div>
      <div class="q-body">{{ $topic->body }}</div>
    </div>

    @if(session('success'))
      <div class="alert alert-success" style="margin-bottom:16px">{{ session('success') }}</div>
    @endif
    @if($errors->any())
      <div class="alert alert-error" style="margin-bottom:16px">{{ $errors->first() }}</div>
    @endif

    {{-- Replies --}}
    <div class="replies-header">
      Javoblar <span class="rh-count">{{ $topic->replies->count() }}</span>
    </div>

    @foreach($topic->replies->sortByDesc('is_best_answer') as $reply)
    <div class="reply-card {{ $reply->is_best_answer ? 'best' : '' }}">
      @if($reply->is_best_answer)
        <div class="best-tag"><svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>Eng yaxshi javob</div>
      @endif
      <div class="reply-body">{{ $reply->body }}</div>
      <div class="reply-footer">
        <div class="reply-author-row">
          <div class="r-avatar">{{ strtoupper(mb_substr($reply->user->name ?? 'U', 0, 1)) }}</div>
          <div>
            <div class="r-name">{{ $reply->user->name ?? 'Foydalanuvchi' }}</div>
            <div class="r-date">{{ $reply->created_at->diffForHumans() }}</div>
          </div>
        </div>
        @if(auth()->id() === $topic->user_id && !$reply->is_best_answer)
          <form action="{{ route('forum.best', $reply) }}" method="POST">
            @csrf
            <button type="submit" class="best-btn"><svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>Eng yaxshi javob</button>
          </form>
        @endif
      </div>
    </div>
    @endforeach

    @if($topic->replies->isEmpty())
    <div style="text-align:center;padding:40px;color:var(--muted);margin-bottom:24px">
      <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.06)" stroke-width="1" style="margin:0 auto 12px"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
      <p>Hali javob yo'q. Birinchi bo'lib javob bering!</p>
    </div>
    @endif

    {{-- Reply Form --}}
    @auth
    <div class="reply-form-card">
      <div class="rfc-title">
        <svg viewBox="0 0 24 24"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
        Javob yozing
      </div>
      <form action="{{ route('forum.reply', $topic) }}" method="POST">
        @csrf
        <textarea class="rfc-textarea" name="body" placeholder="Javobingizni batafsil yozing..." required>{{ old('body') }}</textarea>
        <div class="rfc-actions">
          <button type="submit" class="btn btn-primary">Javobni yuborish</button>
        </div>
      </form>
    </div>
    @else
    <div class="reply-form-card" style="text-align:center">
      <p style="color:var(--muted);margin-bottom:14px">Javob berish uchun tizimga kiring</p>
      <a href="/login" class="btn btn-primary">Kirish</a>
    </div>
    @endauth
  </div>
</div>
@endsection
