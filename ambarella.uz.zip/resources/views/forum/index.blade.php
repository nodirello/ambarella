@extends('layouts.app')
@section('title', 'Forum — Savollar va Javoblar | AMBARELLA')

@section('styles')
<style>
.forum-hero{padding:48px 0 32px;text-align:center}
.forum-hero h1{font-size:32px;font-weight:800;color:#fff;margin-bottom:8px}
.forum-hero p{color:var(--muted);font-size:15px}
.forum-actions{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;flex-wrap:wrap;gap:16px}
.category-tabs{display:flex;gap:8px;flex-wrap:wrap}
.cat-tab{padding:8px 16px;border-radius:10px;font-size:13px;font-weight:600;background:var(--surface);border:1px solid var(--border);color:var(--muted);cursor:pointer;transition:all .2s;text-decoration:none}
.cat-tab:hover{border-color:var(--primary);color:#93c5fd}
.cat-tab.active{background:rgba(37,99,235,.15);color:#93c5fd;border-color:rgba(37,99,235,.3)}
.topic-list{display:flex;flex-direction:column;gap:12px;margin-bottom:32px}
.topic-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:20px 24px;display:flex;align-items:flex-start;gap:16px;transition:all .3s}
.topic-card:hover{border-color:rgba(37,99,235,.3);transform:translateY(-2px);box-shadow:0 8px 24px rgba(0,0,0,.2)}
.topic-votes{display:flex;flex-direction:column;align-items:center;gap:4px;min-width:48px}
.topic-votes .count{font-size:18px;font-weight:700;color:#fff}
.topic-votes .label{font-size:10px;color:var(--muted);text-transform:uppercase}
.topic-main{flex:1;min-width:0}
.topic-title{font-size:16px;font-weight:600;color:#fff;margin-bottom:6px;display:flex;align-items:center;gap:8px}
.topic-title a{color:#fff;transition:color .2s}
.topic-title a:hover{color:#93c5fd}
.solved-badge{background:rgba(22,163,74,.15);color:#4ade80;font-size:11px;font-weight:600;padding:3px 8px;border-radius:6px;border:1px solid rgba(22,163,74,.2)}
.topic-meta{display:flex;align-items:center;gap:12px;font-size:12px;color:var(--muted);flex-wrap:wrap}
.topic-meta .cat-label{background:rgba(124,58,237,.12);color:#a78bfa;padding:2px 8px;border-radius:5px;font-weight:500}
.topic-stats{display:flex;gap:16px;align-items:center;min-width:120px}
.topic-stat{display:flex;flex-direction:column;align-items:center;gap:2px}
.topic-stat .num{font-size:14px;font-weight:600;color:#cbd5e1}
.topic-stat .lbl{font-size:10px;color:var(--muted)}
.empty-state{text-align:center;padding:64px 24px;color:var(--muted)}
.empty-state svg{width:64px;height:64px;margin-bottom:16px;opacity:.4}
.pagination-wrap{display:flex;justify-content:center;gap:6px;margin-top:24px}
.pagination-wrap .page-link{padding:8px 14px;border-radius:8px;background:var(--surface);border:1px solid var(--border);color:var(--muted);font-size:13px;transition:all .2s}
.pagination-wrap .page-link:hover,.pagination-wrap .page-item.active .page-link{background:rgba(37,99,235,.15);color:#93c5fd;border-color:rgba(37,99,235,.3)}
@media(max-width:768px){
  .topic-card{flex-direction:column;gap:12px}
  .topic-stats{flex-direction:row;min-width:auto}
  .forum-actions{flex-direction:column;align-items:stretch}
}
</style>
@endsection

@section('content')
<div class="container">
  <div class="forum-hero">
    <h1>💬 Forum — Savollar va Javoblar</h1>
    <p>Savol bering, javob bering, bilim almashing</p>
  </div>

  <div class="forum-actions">
    <div class="category-tabs">
      <a href="{{ route('forum') }}" class="cat-tab {{ !request('category') || request('category') == 'all' ? 'active' : '' }}">Barchasi</a>
      <a href="{{ route('forum', ['category' => 'Dasturlash']) }}" class="cat-tab {{ request('category') == 'Dasturlash' ? 'active' : '' }}">💻 Dasturlash</a>
      <a href="{{ route('forum', ['category' => 'Dizayn']) }}" class="cat-tab {{ request('category') == 'Dizayn' ? 'active' : '' }}">🎨 Dizayn</a>
      <a href="{{ route('forum', ['category' => 'Biznes']) }}" class="cat-tab {{ request('category') == 'Biznes' ? 'active' : '' }}">📈 Biznes</a>
      <a href="{{ route('forum', ['category' => 'Boshqa']) }}" class="cat-tab {{ request('category') == 'Boshqa' ? 'active' : '' }}">📌 Boshqa</a>
    </div>
    <a href="{{ route('forum.create') }}" class="btn btn-primary">+ Yangi savol</a>
  </div>

  <div class="topic-list">
    @forelse($topics as $topic)
    <div class="topic-card glow-card">
      <div class="topic-votes">
        <span class="count">{{ $topic->replies_count }}</span>
        <span class="label">javob</span>
      </div>
      <div class="topic-main">
        <div class="topic-title">
          <a href="{{ route('forum.show', $topic) }}">{{ $topic->title }}</a>
          @if($topic->is_solved)
            <span class="solved-badge">✓ Hal qilindi</span>
          @endif
        </div>
        <div class="topic-meta">
          <span class="cat-label">{{ $topic->category }}</span>
          <span>{{ $topic->user->name ?? 'Foydalanuvchi' }}</span>
          <span>•</span>
          <span>{{ $topic->created_at->diffForHumans() }}</span>
        </div>
      </div>
      <div class="topic-stats">
        <div class="topic-stat">
          <span class="num">{{ $topic->views_count }}</span>
          <span class="lbl">ko'rish</span>
        </div>
      </div>
    </div>
    @empty
    <div class="empty-state">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
      <p>Hali savollar yo'q. Birinchi bo'lib savol bering!</p>
    </div>
    @endforelse
  </div>

  @if($topics->hasPages())
  <div class="pagination-wrap">
    {{ $topics->appends(request()->query())->links('pagination::bootstrap-4') }}
  </div>
  @endif
</div>
@endsection
