@extends('layouts.app')

@section('title', 'Code Playground — AMBARELLA')
@section('description', 'Online kod muharriri — Python, JavaScript, HTML tillarida kod yozing va sinab ko\'ring.')

@section('styles')
<style>
.playground-container {
  padding: 40px 0 80px;
}
.playground-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 16px;
  margin-bottom: 24px;
}
.playground-title {
  font-size: 28px;
  font-weight: 800;
  color: #fff;
  display: flex;
  align-items: center;
  gap: 12px;
}
.playground-title svg {
  width: 32px;
  height: 32px;
  stroke: #60a5fa;
  fill: none;
  stroke-width: 1.5;
}
.playground-controls {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
}
.lang-selector {
  display: flex;
  gap: 4px;
  background: rgba(255,255,255,.03);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 4px;
}
.lang-selector button {
  padding: 8px 16px;
  border-radius: 8px;
  font-size: 13px;
  font-weight: 600;
  color: var(--muted);
  transition: all .2s;
  cursor: pointer;
  border: none;
  background: none;
}
.lang-selector button.active {
  background: rgba(37,99,235,.15);
  color: #93c5fd;
  box-shadow: 0 2px 8px rgba(37,99,235,.2);
}
.lang-selector button:hover:not(.active) {
  color: #cbd5e1;
  background: rgba(255,255,255,.03);
}
.btn-run {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 10px 24px;
  background: linear-gradient(135deg, #16a34a, #059669);
  color: #fff;
  border-radius: 10px;
  font-weight: 600;
  font-size: 14px;
  border: none;
  cursor: pointer;
  transition: all .3s;
  box-shadow: 0 4px 14px rgba(22,163,74,.3);
}
.btn-run:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(22,163,74,.4);
}
.btn-run svg {
  width: 16px;
  height: 16px;
  fill: #fff;
}
.btn-clear {
  padding: 10px 20px;
  background: rgba(220,38,38,.1);
  color: #f87171;
  border-radius: 10px;
  font-weight: 600;
  font-size: 13px;
  border: 1px solid rgba(220,38,38,.2);
  cursor: pointer;
  transition: all .3s;
}
.btn-clear:hover {
  background: rgba(220,38,38,.2);
  transform: translateY(-1px);
}
.editor-wrapper {
  border-radius: 16px;
  overflow: hidden;
  border: 1px solid rgba(255,255,255,.06);
  box-shadow: 0 20px 60px rgba(0,0,0,.4);
}
.editor-topbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 20px;
  background: #1e293b;
  border-bottom: 1px solid rgba(255,255,255,.06);
}
.editor-dots {
  display: flex;
  gap: 8px;
}
.editor-dots span {
  width: 12px;
  height: 12px;
  border-radius: 50%;
}
.editor-dots span:nth-child(1) { background: #ef4444; }
.editor-dots span:nth-child(2) { background: #f59e0b; }
.editor-dots span:nth-child(3) { background: #22c55e; }
.editor-filename {
  font-size: 12px;
  color: var(--muted);
  font-weight: 500;
}
.editor-tabs {
  display: flex;
  gap: 2px;
}
.editor-tab {
  padding: 4px 12px;
  border-radius: 6px;
  font-size: 11px;
  color: var(--muted);
  background: rgba(255,255,255,.03);
  cursor: pointer;
  transition: all .2s;
}
.editor-tab.active {
  background: rgba(37,99,235,.15);
  color: #93c5fd;
}
.editor-body {
  position: relative;
  display: flex;
}
.line-numbers {
  padding: 20px 0;
  background: #0d1117;
  color: #475569;
  font-family: 'JetBrains Mono', 'Fira Code', 'Cascadia Code', Consolas, monospace;
  font-size: 14px;
  line-height: 1.7;
  text-align: right;
  user-select: none;
  min-width: 50px;
  padding-right: 12px;
  padding-left: 12px;
  border-right: 1px solid rgba(255,255,255,.04);
}
.code-editor {
  flex: 1;
  min-height: 400px;
  padding: 20px;
  background: #0d1117;
  color: #e6edf3;
  font-family: 'JetBrains Mono', 'Fira Code', 'Cascadia Code', Consolas, monospace;
  font-size: 14px;
  line-height: 1.7;
  border: none;
  outline: none;
  resize: vertical;
  tab-size: 2;
  white-space: pre;
  overflow-x: auto;
}
.code-editor::placeholder {
  color: #374151;
}
.output-panel {
  margin-top: 20px;
  border-radius: 16px;
  overflow: hidden;
  border: 1px solid rgba(255,255,255,.06);
  box-shadow: 0 10px 40px rgba(0,0,0,.3);
}
.output-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 20px;
  background: #1e293b;
  border-bottom: 1px solid rgba(255,255,255,.06);
}
.output-header-title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  font-weight: 600;
  color: #94a3b8;
}
.output-header-title .dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #22c55e;
  animation: pulseLive 2s ease-in-out infinite;
}
.output-body {
  padding: 20px;
  background: #0d1117;
  min-height: 120px;
  max-height: 300px;
  overflow-y: auto;
  font-family: 'JetBrains Mono', 'Fira Code', Consolas, monospace;
  font-size: 13px;
  line-height: 1.7;
  color: #a5d6ff;
  white-space: pre-wrap;
}
.output-body .error {
  color: #f87171;
}
.output-body .info {
  color: #fbbf24;
}
.output-body .success {
  color: #4ade80;
}
.playground-features {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 16px;
  margin-top: 32px;
}
.feature-pill {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 14px 18px;
  background: rgba(255,255,255,.02);
  border: 1px solid var(--border);
  border-radius: 12px;
  font-size: 13px;
  color: #94a3b8;
}
.feature-pill svg {
  width: 18px;
  height: 18px;
  stroke: #60a5fa;
  fill: none;
  stroke-width: 2;
}
/* Minimap decoration */
.editor-minimap {
  width: 60px;
  background: #0d1117;
  border-left: 1px solid rgba(255,255,255,.04);
  position: relative;
  overflow: hidden;
}
.minimap-lines {
  padding: 20px 8px;
}
.minimap-line {
  height: 3px;
  margin-bottom: 2px;
  border-radius: 1px;
  opacity: 0.3;
}
@media(max-width: 768px) {
  .playground-header { flex-direction: column; align-items: flex-start; }
  .playground-controls { width: 100%; }
  .lang-selector { flex: 1; }
  .lang-selector button { flex: 1; padding: 8px 10px; font-size: 12px; }
  .code-editor { min-height: 300px; font-size: 13px; }
  .editor-minimap { display: none; }
  .line-numbers { min-width: 36px; font-size: 12px; padding-left: 8px; padding-right: 8px; }
}
</style>
@endsection

@section('content')
<div class="container playground-container">
  <div class="playground-header">
    <h1 class="playground-title">
      <svg viewBox="0 0 24 24"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>
      Code Playground
    </h1>
    <div class="playground-controls">
      <div class="lang-selector" id="langSelector">
        <button class="active" data-lang="javascript" onclick="setEditorLang('javascript')">JavaScript</button>
        <button data-lang="python" onclick="setEditorLang('python')">Python</button>
        <button data-lang="html" onclick="setEditorLang('html')">HTML</button>
      </div>
      <button class="btn-run" onclick="runCode()">
        <svg viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3"/></svg>
        Ishlatish
      </button>
      <button class="btn-clear" onclick="clearEditor()">Tozalash</button>
    </div>
  </div>

  <div class="editor-wrapper">
    <div class="editor-topbar">
      <div class="editor-dots"><span></span><span></span><span></span></div>
      <span class="editor-filename" id="editorFilename">main.js</span>
      <div class="editor-tabs">
        <div class="editor-tab active">main</div>
        <div class="editor-tab">output</div>
      </div>
    </div>
    <div class="editor-body">
      <div class="line-numbers" id="lineNumbers">1</div>
      <textarea class="code-editor" id="codeEditor" placeholder="// Kodingizni shu yerga yozing..." spellcheck="false">// AMBARELLA Code Playground
// JavaScript yozing va "Ishlatish" tugmasini bosing

function salom(ism) {
  return `Salom, ${ism}! AMBARELLA'ga xush kelibsiz! 🎉`;
}

console.log(salom("Dasturchi"));
console.log("2 + 2 =", 2 + 2);
console.log("Bugun:", new Date().toLocaleDateString("uz"));</textarea>
      <div class="editor-minimap">
        <div class="minimap-lines" id="minimapLines"></div>
      </div>
    </div>
  </div>

  <div class="output-panel">
    <div class="output-header">
      <div class="output-header-title"><span class="dot"></span> Natija (Output)</div>
      <button onclick="clearOutput()" style="font-size:12px;color:var(--muted);cursor:pointer;background:none;border:none">Tozalash</button>
    </div>
    <div class="output-body" id="outputBody">
      <span class="info">▸ Kodni ishlatish uchun "Ishlatish" tugmasini bosing...</span>
    </div>
  </div>

  <div class="playground-features">
    <div class="feature-pill">
      <svg viewBox="0 0 24 24"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
      Tezkor bajarish
    </div>
    <div class="feature-pill">
      <svg viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
      Xavfsiz sandbox
    </div>
    <div class="feature-pill">
      <svg viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>
      VS Code uslubi
    </div>
    <div class="feature-pill">
      <svg viewBox="0 0 24 24"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg>
      3 til qo'llab-quvvatlaydi
    </div>
  </div>
</div>

<script>
let currentLang = 'javascript';

const defaultCode = {
  javascript: `// AMBARELLA Code Playground\n// JavaScript yozing va "Ishlatish" tugmasini bosing\n\nfunction salom(ism) {\n  return \`Salom, \${ism}! AMBARELLA'ga xush kelibsiz! 🎉\`;\n}\n\nconsole.log(salom("Dasturchi"));\nconsole.log("2 + 2 =", 2 + 2);\nconsole.log("Bugun:", new Date().toLocaleDateString("uz"));`,
  python: `# AMBARELLA Code Playground\n# Python kodni serverda ishlatish tez orada...\n\ndef salom(ism):\n    return f"Salom, {ism}! AMBARELLA'ga xush kelibsiz! 🎉"\n\nprint(salom("Dasturchi"))\nprint("2 + 2 =", 2 + 2)\n\n# Ro'yxat bilan ishlash\nfoydalar = ["Ta'lim", "Ish", "Ekologiya", "Mentorlik"]\nfor i, f in enumerate(foydalar, 1):\n    print(f"{i}. {f}")`,
  html: `<!-- AMBARELLA Code Playground -->\n<!-- HTML kodingizni yozing -->\n\n<!DOCTYPE html>\n<html>\n<head>\n  <style>\n    body {\n      font-family: 'Inter', sans-serif;\n      background: #0f172a;\n      color: #e2e8f0;\n      display: flex;\n      align-items: center;\n      justify-content: center;\n      min-height: 100vh;\n    }\n    .card {\n      padding: 32px;\n      border-radius: 16px;\n      background: rgba(255,255,255,.03);\n      border: 1px solid rgba(255,255,255,.08);\n      text-align: center;\n    }\n    h1 { color: #60a5fa; }\n  </style>\n</head>\n<body>\n  <div class="card">\n    <h1>🌱 AMBARELLA</h1>\n    <p>O'zbekiston yoshlari platformasi</p>\n  </div>\n</body>\n</html>`
};

const fileNames = { javascript: 'main.js', python: 'main.py', html: 'index.html' };

function setEditorLang(lang) {
  currentLang = lang;
  document.querySelectorAll('#langSelector button').forEach(b => {
    b.classList.toggle('active', b.dataset.lang === lang);
  });
  document.getElementById('editorFilename').textContent = fileNames[lang];
  document.getElementById('codeEditor').value = defaultCode[lang];
  updateLineNumbers();
  updateMinimap();
}

function runCode() {
  const code = document.getElementById('codeEditor').value;
  const output = document.getElementById('outputBody');

  if (!code.trim()) {
    output.innerHTML = '<span class="error">✕ Kod bo\'sh. Biror narsa yozing!</span>';
    return;
  }

  if (currentLang === 'javascript') {
    output.innerHTML = '';
    const originalLog = console.log;
    const logs = [];

    console.log = function(...args) {
      logs.push(args.map(a => typeof a === 'object' ? JSON.stringify(a, null, 2) : String(a)).join(' '));
    };

    try {
      const result = eval(code);
      let outputText = '';
      if (logs.length) {
        outputText = logs.map(l => '<span class="success">▸ ' + escapeHtml(l) + '</span>').join('\n');
      }
      if (result !== undefined && !logs.length) {
        outputText += '<span class="success">⇒ ' + escapeHtml(String(result)) + '</span>';
      }
      if (!outputText) outputText = '<span class="info">✓ Kod muvaffaqiyatli bajarildi (natija yo\'q)</span>';
      output.innerHTML = outputText;
    } catch (e) {
      output.innerHTML = '<span class="error">✕ Xatolik: ' + escapeHtml(e.message) + '</span>';
    }

    console.log = originalLog;
  } else if (currentLang === 'html') {
    output.innerHTML = '<span class="info">▸ HTML preview tez orada qo\'shiladi...\n\n📌 Hozircha kodni nusxalab brauzerda sinab ko\'ring.</span>';
    // Open in new window as preview
    const preview = window.open('', '_blank');
    if (preview) {
      preview.document.write(code);
      preview.document.close();
      output.innerHTML = '<span class="success">✓ HTML yangi oynada ochildi!</span>';
    }
  } else if (currentLang === 'python') {
    output.innerHTML = '<span class="info">🐍 Python serverda ishlatish uchun tez orada...\n\n📌 Hozircha Python kodni lokal muhitda sinab ko\'ring:\n   python main.py</span>';
  }
}

function clearEditor() {
  document.getElementById('codeEditor').value = '';
  updateLineNumbers();
  updateMinimap();
}

function clearOutput() {
  document.getElementById('outputBody').innerHTML = '<span class="info">▸ Tayyor...</span>';
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function updateLineNumbers() {
  const editor = document.getElementById('codeEditor');
  const lines = editor.value.split('\n').length;
  const lineNums = document.getElementById('lineNumbers');
  lineNums.innerHTML = Array.from({length: lines}, (_, i) => i + 1).join('<br>');
}

function updateMinimap() {
  const editor = document.getElementById('codeEditor');
  const lines = editor.value.split('\n');
  const container = document.getElementById('minimapLines');
  const colors = ['#3b82f6','#22c55e','#94a3b8','#f59e0b','#8b5cf6'];
  container.innerHTML = lines.slice(0, 40).map(line => {
    const width = Math.min(line.length * 1.2, 44);
    const color = colors[Math.floor(Math.random() * colors.length)];
    return `<div class="minimap-line" style="width:${width}px;background:${color}"></div>`;
  }).join('');
}

// Init
document.getElementById('codeEditor').addEventListener('input', () => {
  updateLineNumbers();
  updateMinimap();
});
document.getElementById('codeEditor').addEventListener('scroll', function() {
  document.getElementById('lineNumbers').scrollTop = this.scrollTop;
});

// Tab key support
document.getElementById('codeEditor').addEventListener('keydown', function(e) {
  if (e.key === 'Tab') {
    e.preventDefault();
    const start = this.selectionStart;
    const end = this.selectionEnd;
    this.value = this.value.substring(0, start) + '  ' + this.value.substring(end);
    this.selectionStart = this.selectionEnd = start + 2;
    updateLineNumbers();
  }
});

// Initial render
updateLineNumbers();
updateMinimap();
</script>
@endsection
