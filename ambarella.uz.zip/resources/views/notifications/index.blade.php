@extends('layouts.app')
@section('title', 'Bildirishnomalar — AMBARELLA')
@section('description', 'Sizning barcha bildirishnomalaringiz.')

@section('styles')
<style>
.notif-hero{padding:48px 0 32px}
.notif-hero h1{font-size:clamp(24px,5vw,36px);font-weight:800;color:#fff;margin-bottom:8px}
.notif-hero p{color:var(--muted);font-size:15px}
.notif-hero-row{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px}
.notif-list{display:flex;flex-direction:column;gap:12px;margin:32px 0;max-width:720px}
.notif-item{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:18px 20px;display:flex;align-items:flex-start;gap:14px;transition:all .2s}
.notif-item:hover{border-color:rgba(37,99,235,.2);background:rgba(255,255,255,.04)}
.notif-item.unread{border-left:3px solid var(--primary)}
.notif-icon{width:38px;height:38px;border-radius:10px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.notif-icon.info{background:rgba(37,99,235,.12)}
.notif-icon.success{background:rgba(22,163,74,.12)}
.notif-icon.warning{background:rgba(245,158,11,.12)}
.notif-icon.system{background:rgba(124,58,237,.12)}
.notif-content{flex:1;min-width:0}
.notif-content h4{font-size:14px;font-weight:600;color:#e2e8f0;margin-bottom:4px}
.notif-content p{font-size:13px;color:var(--muted);line-height:1.6}
.notif-time{font-size:11px;color:var(--muted);white-space:nowrap;flex-shrink:0;margin-top:2px}
.notif-empty{text-align:center;padding:64px 24px;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);margin:32px 0;max-width:720px}
.notif-empty svg{margin:0 auto 16px;opacity:.3}
.notif-empty h3{font-size:18px;font-weight:700;color:#fff;margin-bottom:8px}
.notif-empty p{color:var(--muted);font-size:14px;max-width:360px;margin:0 auto}
.notif-mark-all{font-size:13px;color:var(--primary);font-weight:500;cursor:pointer;background:none;border:none;transition:opacity .2s}
.notif-mark-all:hover{opacity:.8}
</style>
@endsection

@section('content')
<section class="notif-hero">
  <div class="container">
    <div class="notif-hero-row">
      <div>
        <h1>🔔 Bildirishnomalar</h1>
        <p>Platforma bildirishnomalari va xabarnomalar.</p>
      </div>
      @if(isset($notifications) && $notifications->count())
      <form action="/notifications/mark-all-read" method="POST">
        @csrf
        <button type="submit" class="notif-mark-all">Barchasini o'qilgan deb belgilash</button>
      </form>
      @endif
    </div>
  </div>
</section>

<section class="container">
  @if(isset($notifications) && $notifications->count())
  <div class="notif-list">
    @foreach($notifications as $notification)
    <div class="notif-item {{ $notification->read_at ? '' : 'unread' }}">
      <div class="notif-icon {{ $notification->data['type'] ?? 'info' }}">
        @switch($notification->data['type'] ?? 'info')
          @case('success')
            <svg width="18" height="18" fill="none" stroke="#4ade80" stroke-width="2" stroke-linecap="round"><polyline points="2 10 6 14 16 4"/></svg>
            @break
          @case('warning')
            <svg width="18" height="18" fill="none" stroke="#fbbf24" stroke-width="2" stroke-linecap="round"><path d="M9 1L1 16h16L9 1z"/><line x1="9" y1="6" x2="9" y2="10"/><line x1="9" y1="13" x2="9" y2="13"/></svg>
            @break
          @case('system')
            <svg width="18" height="18" fill="none" stroke="#a78bfa" stroke-width="2" stroke-linecap="round"><circle cx="9" cy="9" r="7"/><path d="M9 6v3l2 1"/></svg>
            @break
          @default
            <svg width="18" height="18" fill="none" stroke="#60a5fa" stroke-width="2" stroke-linecap="round"><circle cx="9" cy="9" r="7"/><line x1="9" y1="6" x2="9" y2="9"/><line x1="9" y1="12" x2="9" y2="12"/></svg>
        @endswitch
      </div>
      <div class="notif-content">
        <h4>{{ $notification->data['title'] ?? 'Bildirishnoma' }}</h4>
        <p>{{ $notification->data['message'] ?? '' }}</p>
      </div>
      <div class="notif-time">{{ $notification->created_at->diffForHumans() }}</div>
    </div>
    @endforeach
  </div>
  @else
  <div class="notif-empty">
    <svg width="56" height="56" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
      <path d="M42 16A14 14 0 0 0 14 16c0 16-7 20-7 20h42s-7-4-7-20"/>
      <path d="M32 46a4 4 0 0 1-8 0"/>
      <line x1="8" y1="4" x2="48" y2="52"/>
    </svg>
    <h3>Bildirishnomalar yo'q</h3>
    <p>Hozircha yangi bildirishnomalar mavjud emas. Faoliyat bo'lganda bu yerda ko'rinadi.</p>
  </div>
  @endif
</section>
@endsection
