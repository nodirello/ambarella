@extends('layouts.app')
@section('title', $poll->question . ' | So\'rovnoma | AMBARELLA')
@section('styles')
<style>
.poll-section{padding:48px 0;max-width:640px;margin:0 auto}
.poll-back{display:inline-flex;align-items:center;gap:6px;color:var(--muted);font-size:13px;margin-bottom:24px;transition:color .2s}
.poll-back:hover{color:#fff}
.poll-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:32px;position:relative;overflow:hidden}
.poll-card::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,var(--primary),#8b5cf6)}
.poll-badge{display:inline-flex;align-items:center;gap:4px;font-size:12px;font-weight:600;color:var(--primary);margin-bottom:12px}
.poll-badge svg{width:14px;height:14px}
.poll-question{font-size:clamp(20px,3vw,26px);font-weight:800;color:#fff;margin-bottom:8px;line-height:1.3}
.poll-meta{font-size:13px;color:var(--muted);margin-bottom:24px}
.poll-options{display:flex;flex-direction:column;gap:12px;margin-bottom:24px}
.poll-option{position:relative;display:flex;align-items:center;gap:12px;padding:14px 16px;background:rgba(255,255,255,.02);border:1px solid var(--border);border-radius:10px;cursor:pointer;transition:all .2s}
.poll-option:hover{border-color:var(--primary);background:rgba(59,130,246,.04)}
.poll-option.selected{border-color:var(--primary);background:rgba(59,130,246,.08)}
.poll-radio{width:18px;height:18px;border-radius:50%;border:2px solid var(--border);display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all .2s}
.poll-option.selected .poll-radio{border-color:var(--primary)}
.poll-option.selected .poll-radio::after{content:'';width:8px;height:8px;border-radius:50%;background:var(--primary)}
.poll-option-text{font-size:15px;color:#e2e8f0;font-weight:500}
.poll-submit{width:100%;padding:12px;background:var(--primary);color:#fff;border:none;border-radius:var(--radius);font-size:15px;font-weight:600;cursor:pointer;transition:all .2s}
.poll-submit:hover{opacity:.9;transform:translateY(-1px)}
.poll-submit:disabled{opacity:.5;cursor:not-allowed;transform:none}

/* Natijalar */
.poll-results{display:flex;flex-direction:column;gap:14px}
.poll-result-item{position:relative}
.poll-result-bar{height:44px;border-radius:10px;background:rgba(255,255,255,.03);border:1px solid var(--border);overflow:hidden;position:relative}
.poll-result-fill{height:100%;background:linear-gradient(90deg,rgba(59,130,246,.15),rgba(59,130,246,.05));border-radius:10px;transition:width .8s ease}
.poll-result-content{position:absolute;inset:0;display:flex;align-items:center;justify-content:space-between;padding:0 16px}
.poll-result-text{font-size:14px;color:#e2e8f0;font-weight:500}
.poll-result-percent{font-size:14px;color:var(--primary);font-weight:700}
.poll-result-votes{font-size:12px;color:var(--muted);margin-top:4px;padding-left:16px}
.poll-total{text-align:center;margin-top:20px;font-size:13px;color:var(--muted)}
.poll-voted-badge{display:inline-flex;align-items:center;gap:6px;background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.2);border-radius:8px;padding:8px 14px;font-size:13px;color:#10b981;font-weight:500;margin-bottom:20px}
</style>
@endsection
@section('content')
<div class="container">
  <div class="poll-section">
    <a href="{{ url()->previous() }}" class="poll-back">← Orqaga</a>

    <div class="poll-card tilt-card">
      <div class="poll-badge">
        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
        </svg>
        So'rovnoma
      </div>

      <h1 class="poll-question">{{ $poll->question }}</h1>

      <div class="poll-meta">
        @if($poll->ends_at)
          Muddat: {{ $poll->ends_at->format('d M Y') }}
        @endif
        · Jami: {{ $totalVotes }} ovoz
      </div>

      @if($hasVoted || !$poll->is_active || ($poll->ends_at && $poll->ends_at->isPast()))
        {{-- Natijalarni ko'rsatish --}}
        @if($hasVoted)
        <div class="poll-voted-badge">
          ✓ Siz ovoz bergansiz
        </div>
        @endif

        <div class="poll-results">
          @foreach($poll->options as $option)
            @php
              $percent = $totalVotes > 0 ? round(($option->votes_count / $totalVotes) * 100) : 0;
            @endphp
            <div class="poll-result-item">
              <div class="poll-result-bar">
                <div class="poll-result-fill" style="width:{{ $percent }}%"></div>
                <div class="poll-result-content">
                  <span class="poll-result-text">{{ $option->text }}</span>
                  <span class="poll-result-percent">{{ $percent }}%</span>
                </div>
              </div>
              <div class="poll-result-votes">{{ $option->votes_count }} ovoz</div>
            </div>
          @endforeach
        </div>

        <div class="poll-total">Jami {{ $totalVotes }} kishi ishtirok etdi</div>

      @else
        {{-- Ovoz berish formasi --}}
        <form action="{{ route('polls.vote', $poll) }}" method="POST" id="pollForm">
          @csrf
          <div class="poll-options">
            @foreach($poll->options as $option)
            <label class="poll-option" data-option>
              <input type="radio" name="option_id" value="{{ $option->id }}" style="display:none" required>
              <span class="poll-radio"></span>
              <span class="poll-option-text">{{ $option->text }}</span>
            </label>
            @endforeach
          </div>
          <button type="submit" class="poll-submit" id="pollSubmitBtn" disabled>Ovoz berish</button>
        </form>

        <script>
        document.querySelectorAll('[data-option]').forEach(opt => {
          opt.addEventListener('click', function() {
            document.querySelectorAll('[data-option]').forEach(o => o.classList.remove('selected'));
            this.classList.add('selected');
            document.getElementById('pollSubmitBtn').disabled = false;
          });
        });
        </script>
      @endif
    </div>
  </div>
</div>
@endsection
