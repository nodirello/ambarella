@extends('layouts.app')
@section('title', $news->title . ' | AMBARELLA')
@section('styles')
<style>
.news-detail{padding:48px 0}
.news-back{display:inline-flex;align-items:center;gap:6px;color:var(--muted);font-size:13px;margin-bottom:24px;transition:color .2s}
.news-back:hover{color:#fff}
.news-category{font-size:12px;font-weight:600;color:var(--primary);margin-bottom:8px;display:inline-block}
.news-detail h1{font-size:clamp(24px,4vw,36px);font-weight:800;color:#fff;margin-bottom:16px;line-height:1.3}
.news-meta-row{display:flex;gap:16px;color:var(--muted);font-size:13px;margin-bottom:32px}
.news-content{font-size:15px;line-height:1.9;color:#cbd5e1;white-space:pre-line}
.news-image{width:100%;max-height:400px;object-fit:cover;border-radius:var(--radius);margin-bottom:24px}
.related-section{margin-top:48px;padding-top:32px;border-top:1px solid var(--border)}
.related-section h3{font-size:18px;font-weight:700;color:#fff;margin-bottom:16px}
.related-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px}
.related-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:20px;transition:all .2s}
.related-card:hover{border-color:var(--primary);transform:translateY(-2px)}
.related-card h4{font-size:15px;font-weight:600;color:#fff;margin-bottom:6px}
.related-card p{font-size:13px;color:var(--muted)}
</style>
@endsection
@section('content')
<div class="container">
  <div class="news-detail">
    <a href="/news" class="news-back">← Yangiliklarga qaytish</a>
    <span class="news-category">{{ $news->category }}</span>
    <h1>{{ $news->title }}</h1>
    <div class="news-meta-row">
      <span>{{ $news->author }}</span>
      <span>{{ $news->created_at->format('d M Y') }}</span>
    </div>
    @if($news->image)
      <img src="{{ $news->image }}" alt="{{ $news->title }}" class="news-image">
    @endif
    <div class="news-content">{{ $news->content }}</div>

    @if($related->count() > 0)
    <div class="related-section">
      <h3>O'xshash yangiliklar</h3>
      <div class="related-grid">
        @foreach($related as $item)
        <a href="/news/{{ $item->id }}" class="related-card">
          <h4>{{ $item->title }}</h4>
          <p>{{ Str::limit($item->content, 80) }}</p>
        </a>
        @endforeach
      </div>
    </div>
    @endif
  </div>
</div>
@endsection
