@extends('layouts.app')
@section('title', 'Sozlamalar | AMBARELLA')
@section('styles')
<style>
.settings-page{padding:40px 0}
.settings-header{margin-bottom:32px}
.settings-header h1{font-size:24px;font-weight:800;color:#fff;display:flex;align-items:center;gap:10px}
.settings-header p{color:var(--muted);font-size:13px;margin-top:4px}
.settings-grid{display:grid;grid-template-columns:240px 1fr;gap:32px}
.settings-nav{display:flex;flex-direction:column;gap:4px}
.settings-nav a{display:flex;align-items:center;gap:10px;padding:12px 16px;border-radius:10px;font-size:13px;font-weight:500;color:#94a3b8;transition:all .2s}
.settings-nav a:hover{background:rgba(37,99,235,.06);color:#fff}
.settings-nav a.active{background:rgba(37,99,235,.1);color:#93c5fd;border:1px solid rgba(37,99,235,.2)}
.settings-nav a svg{width:18px;height:18px;stroke:currentColor;fill:none;stroke-width:1.8}
.settings-content{display:flex;flex-direction:column;gap:24px}
.s-panel{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:28px}
.s-panel h3{font-size:16px;font-weight:700;color:#fff;margin-bottom:6px;display:flex;align-items:center;gap:8px}
.s-panel h3 svg{width:18px;height:18px;stroke:currentColor;fill:none;stroke-width:1.8}
.s-panel p{font-size:12px;color:var(--muted);margin-bottom:20px}
.s-field{margin-bottom:16px}
.s-field label{display:block;font-size:12px;font-weight:600;color:#94a3b8;margin-bottom:6px}
.s-field input,.s-field select,.s-field textarea{width:100%;padding:12px 14px;background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:10px;color:#fff;font-size:13px;transition:border-color .2s}
.s-field input:focus,.s-field select:focus,.s-field textarea:focus{outline:none;border-color:var(--primary)}
.s-field textarea{min-height:80px;resize:vertical}
.s-row{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.s-actions{display:flex;gap:10px;margin-top:8px}
.s-toggle{display:flex;align-items:center;justify-content:space-between;padding:16px;background:rgba(255,255,255,.02);border:1px solid var(--border);border-radius:12px;margin-bottom:12px}
.s-toggle-info h4{font-size:13px;font-weight:600;color:#fff}
.s-toggle-info p{font-size:11px;color:var(--muted);margin-top:2px}
.toggle-switch{width:44px;height:24px;border-radius:12px;background:var(--border);position:relative;cursor:pointer;transition:background .2s}
.toggle-switch.on{background:var(--primary)}
.toggle-switch::after{content:'';position:absolute;top:3px;left:3px;width:18px;height:18px;border-radius:50%;background:#fff;transition:transform .2s}
.toggle-switch.on::after{transform:translateX(20px)}
.danger-zone{border-color:rgba(220,38,38,.2)}
.danger-zone h3{color:#f87171}
@media(max-width:768px){.settings-grid{grid-template-columns:1fr}.settings-nav{flex-direction:row;overflow-x:auto;gap:6px}.s-row{grid-template-columns:1fr}}
</style>
@endsection
@section('content')
<div class="container settings-page">
  <div class="settings-header">
    <h1>
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#60a5fa" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-3.83-2.83l.06-.06"/></svg>
      Sozlamalar
    </h1>
    <p>Profil, xavfsizlik va bildirishnomalar sozlamalari</p>
  </div>

  @if(session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
  @endif
  @if($errors->any())
    <div class="alert alert-error">{{ $errors->first() }}</div>
  @endif

  <div class="settings-content">

    {{-- PROFIL --}}
    <div class="s-panel">
      <h3><svg viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg> Profil ma'lumotlari</h3>
      <p>Shaxsiy ma'lumotlaringizni yangilang</p>
      <form action="/settings/profile" method="POST">
        @csrf
        <div class="s-row">
          <div class="s-field">
            <label>Ism</label>
            <input type="text" name="name" value="{{ $user->name }}" required>
          </div>
          <div class="s-field">
            <label>Region</label>
            <select name="region">
              <option value="">Tanlang</option>
              @foreach(['Toshkent','Samarqand','Buxoro','Farg\'ona','Andijon','Namangan','Xorazm','Qashqadaryo','Surxondaryo','Jizzax','Sirdaryo','Navoiy','Qoraqalpog\'iston'] as $r)
                <option value="{{ $r }}" {{ $user->region === $r ? 'selected' : '' }}>{{ $r }}</option>
              @endforeach
            </select>
          </div>
        </div>
        <div class="s-row">
          <div class="s-field">
            <label>Jins</label>
            <select name="gender">
              <option value="">Tanlang</option>
              <option value="male" {{ $user->gender === 'male' ? 'selected' : '' }}>Erkak</option>
              <option value="female" {{ $user->gender === 'female' ? 'selected' : '' }}>Ayol</option>
            </select>
          </div>
          <div class="s-field">
            <label>Tug'ilgan sana</label>
            <input type="date" name="birth_date" value="{{ $user->birth_date?->format('Y-m-d') }}">
          </div>
        </div>
        <div class="s-field">
          <label>Bio</label>
          <textarea name="bio" placeholder="O'zingiz haqingizda qisqacha...">{{ $user->bio }}</textarea>
        </div>
        <div class="s-actions">
          <button type="submit" class="btn btn-primary">Saqlash</button>
        </div>
      </form>
    </div>

    {{-- XAVFSIZLIK --}}
    <div class="s-panel">
      <h3><svg viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg> Xavfsizlik</h3>
      <p>Parol va ikki faktorli autentifikatsiya</p>

      {{-- Parol o'zgartirish --}}
      <form action="/settings/password" method="POST" style="margin-bottom:24px">
        @csrf
        <div class="s-field">
          <label>Joriy parol</label>
          <input type="password" name="current_password" required>
        </div>
        <div class="s-row">
          <div class="s-field">
            <label>Yangi parol</label>
            <input type="password" name="password" required minlength="8">
          </div>
          <div class="s-field">
            <label>Tasdiqlash</label>
            <input type="password" name="password_confirmation" required>
          </div>
        </div>
        <div class="s-actions">
          <button type="submit" class="btn btn-outline">Parolni o'zgartirish</button>
        </div>
      </form>

      {{-- 2FA --}}
      <div class="s-toggle">
        <div class="s-toggle-info">
          <h4>Ikki faktorli autentifikatsiya (2FA)</h4>
          <p>Har kirganingizda emailga kod yuboriladi</p>
        </div>
        <div class="toggle-switch {{ $user->two_factor_enabled ? 'on' : '' }}" onclick="document.getElementById('tfa-form').submit()"></div>
      </div>
      <form id="tfa-form" action="/settings/2fa" method="POST" style="display:none">
        @csrf
        <input type="hidden" name="password" id="tfa-password">
      </form>
    </div>

    {{-- MA'LUMOTLAR --}}
    <div class="s-panel">
      <h3><svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Ma'lumotlarim</h3>
      <p>Shaxsiy ma'lumotlaringizni JSON formatda yuklab oling (GDPR)</p>
      <div class="s-actions">
        <a href="/settings/export" class="btn btn-outline">Ma'lumotlarni yuklab olish</a>
      </div>
    </div>

    {{-- HISOB O'CHIRISH --}}
    <div class="s-panel danger-zone">
      <h3><svg viewBox="0 0 24 24" style="stroke:#f87171"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg> Xavfli zona</h3>
      <p>Hisobingizni o'chirsangiz, barcha ma'lumotlaringiz qaytarib bo'lmas tarzda yo'qoladi.</p>
      <form action="/settings/delete-account" method="POST" onsubmit="return confirm('DIQQAT! Hisobingiz butunlay o\'chiriladi. Davom etasizmi?')">
        @csrf
        <div class="s-field">
          <label>Tasdiqlash uchun parolingizni kiriting</label>
          <input type="password" name="password" required placeholder="Parolingiz">
        </div>
        <button type="submit" class="btn btn-danger">Hisobni o'chirish</button>
      </form>
    </div>
  </div>
</div>

<script>
document.querySelector('.toggle-switch').addEventListener('click', function(e) {
  e.preventDefault();
  const pwd = prompt('2FA o\'zgartirish uchun parolingizni kiriting:');
  if (pwd) {
    document.getElementById('tfa-password').value = pwd;
    document.getElementById('tfa-form').submit();
  }
});
</script>
@endsection
