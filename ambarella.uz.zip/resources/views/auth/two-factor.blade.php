@extends('layouts.app')
@section('title', '2FA Tasdiqlash | AMBARELLA')
@section('styles')
<style>
.tfa-page{min-height:60vh;display:flex;align-items:center;justify-content:center;padding:60px 24px}
.tfa-card{max-width:420px;width:100%;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:48px;text-align:center}
.tfa-icon{width:72px;height:72px;margin:0 auto 20px;border-radius:50%;background:rgba(124,58,237,.1);display:flex;align-items:center;justify-content:center}
.tfa-icon svg{width:32px;height:32px;stroke:#a78bfa;fill:none;stroke-width:1.5}
.tfa-card h2{font-size:20px;font-weight:800;color:#fff;margin-bottom:8px}
.tfa-card p{font-size:13px;color:var(--muted);margin-bottom:24px}
.tfa-input{display:flex;justify-content:center;gap:8px;margin-bottom:20px}
.tfa-input input{width:100%;padding:14px;text-align:center;font-size:24px;font-weight:800;letter-spacing:8px;background:var(--surface);border:1px solid var(--border);border-radius:12px;color:#fff;transition:border-color .2s}
.tfa-input input:focus{outline:none;border-color:var(--primary)}
</style>
@endsection
@section('content')
<section class="tfa-page">
  <div class="tfa-card">
    <div class="tfa-icon">
      <svg viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M9 12l2 2 4-4"/></svg>
    </div>
    <h2>Ikki faktorli tasdiqlash</h2>
    <p>Emailingizga yuborilgan 6 raqamli kodni kiriting</p>

    @if($errors->any())
      <div class="alert alert-error" style="margin-bottom:16px;text-align:left">{{ $errors->first() }}</div>
    @endif
    @if(session('success'))
      <div class="alert alert-success" style="margin-bottom:16px">{{ session('success') }}</div>
    @endif

    <form action="/2fa/verify" method="POST">
      @csrf
      <div class="tfa-input">
        <input type="text" name="code" maxlength="6" pattern="[0-9]{6}" inputmode="numeric" autocomplete="one-time-code" placeholder="000000" required autofocus>
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;margin-bottom:12px">Tasdiqlash</button>
    </form>

    <form action="/2fa/resend" method="POST" style="display:inline">
      @csrf
      <button type="submit" class="btn btn-outline" style="width:100%;justify-content:center;font-size:12px">Kodni qayta yuborish</button>
    </form>
  </div>
</section>
@endsection
