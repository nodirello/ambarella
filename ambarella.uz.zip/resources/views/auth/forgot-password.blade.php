@extends('layouts.app')
@section('title', 'Parolni tiklash | AMBARELLA')
@section('content')
<div style="min-height:calc(100vh - 140px);display:flex;align-items:center;justify-content:center;padding:48px 24px">
  <form method="POST" action="/forgot-password" style="width:100%;max-width:400px">
    @csrf
    <h1 style="font-size:28px;font-weight:800;margin-bottom:8px">Parolni tiklash</h1>
    <p style="color:var(--muted);margin-bottom:32px">Email manzilingizni kiriting — Telegram orqali kod yuboramiz</p>
    <div style="margin-bottom:20px"><label style="display:block;font-size:14px;font-weight:500;margin-bottom:6px">Email</label><input type="email" name="email" required placeholder="email@misol.uz" style="width:100%;padding:14px 16px;border:1.5px solid var(--border);border-radius:10px;font-size:15px"></div>
    <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:14px">Kod yuborish</button>
    <p style="margin-top:16px;text-align:center;font-size:14px;color:var(--muted)"><a href="/login" style="color:var(--primary);font-weight:600">Kirish sahifasiga qaytish</a></p>
  </form>
</div>
@endsection
