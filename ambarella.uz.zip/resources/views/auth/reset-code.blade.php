@extends('layouts.app')
@section('title', 'Kodni kiriting | AMBARELLA')
@section('content')
<div style="min-height:calc(100vh - 140px);display:flex;align-items:center;justify-content:center;padding:48px 24px">
  <form method="POST" action="/reset-password" style="width:100%;max-width:400px">
    @csrf
    <h1 style="font-size:28px;font-weight:800;margin-bottom:8px">Kodni kiriting</h1>
    <p style="color:var(--muted);margin-bottom:32px">Telegram orqali yuborilgan 6 xonali kodni kiriting</p>
    <input type="hidden" name="email" value="{{ $email }}">
    <div style="margin-bottom:20px"><label style="display:block;font-size:14px;font-weight:500;margin-bottom:6px">Kod</label><input type="text" name="code" required maxlength="6" placeholder="123456" style="width:100%;padding:14px 16px;border:1.5px solid var(--border);border-radius:10px;font-size:20px;text-align:center;letter-spacing:8px"></div>
    <div style="margin-bottom:20px"><label style="display:block;font-size:14px;font-weight:500;margin-bottom:6px">Yangi parol</label><input type="password" name="password" required minlength="8" placeholder="Kamida 8 belgi" style="width:100%;padding:14px 16px;border:1.5px solid var(--border);border-radius:10px;font-size:15px"></div>
    <div style="margin-bottom:20px"><label style="display:block;font-size:14px;font-weight:500;margin-bottom:6px">Parolni tasdiqlang</label><input type="password" name="password_confirmation" required minlength="8" placeholder="Parolni takrorlang" style="width:100%;padding:14px 16px;border:1.5px solid var(--border);border-radius:10px;font-size:15px"></div>
    <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:14px">Parolni yangilash</button>
  </form>
</div>
@endsection
