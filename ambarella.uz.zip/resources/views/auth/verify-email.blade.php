@extends('layouts.app')
@section('title', 'Email tasdiqlash | AMBARELLA')
@section('styles')
<style>
.verify-page{min-height:60vh;display:flex;align-items:center;justify-content:center;padding:60px 24px}
.verify-card{max-width:480px;width:100%;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:48px;text-align:center}
.verify-icon{width:80px;height:80px;margin:0 auto 24px;border-radius:50%;background:rgba(37,99,235,.1);display:flex;align-items:center;justify-content:center}
.verify-icon svg{width:36px;height:36px;stroke:#60a5fa;fill:none;stroke-width:1.5}
.verify-card h2{font-size:22px;font-weight:800;color:#fff;margin-bottom:10px}
.verify-card p{font-size:14px;color:var(--muted);margin-bottom:24px;line-height:1.7}
</style>
@endsection
@section('content')
<section class="verify-page">
  <div class="verify-card">
    <div class="verify-icon">
      <svg viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
    </div>
    <h2>Emailni tasdiqlang</h2>
    <p>Ro'yxatdan o'tganingiz uchun rahmat! Iltimos, <strong>{{ auth()->user()->email }}</strong> manziliga yuborilgan havolani bosib emailingizni tasdiqlang.</p>

    @if(session('success'))
      <div class="alert alert-success" style="margin-bottom:20px">{{ session('success') }}</div>
    @endif

    <form action="/email/verification-notification" method="POST">
      @csrf
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;margin-bottom:12px">Qayta yuborish</button>
    </form>
    <form action="/logout" method="POST">
      @csrf
      <button type="submit" class="btn btn-outline" style="width:100%;justify-content:center">Chiqish</button>
    </form>
  </div>
</section>
@endsection
