@extends('layouts.app')
@section('title', 'GreenCoin Liderlar | AMBARELLA')
@section('styles')
<style>
.lb-page{padding:48px 0 80px;max-width:800px;margin:0 auto}
.lb-hero{text-align:center;margin-bottom:40px}
.lb-hero h1{font-size:28px;font-weight:900;color:#fff;margin-bottom:8px}
.lb-hero p{font-size:14px;color:var(--muted)}
@if(auth()->check())
.lb-my-rank{background:rgba(37,99,235,.06);border:1px solid rgba(37,99,235,.15);border-radius:14px;padding:16px 24px;display:flex;align-items:center;gap:14px;margin-bottom:24px}
.lb-my-rank .rank-num{font-size:24px;font-weight:900;color:#60a5fa}
.lb-my-rank .rank-lbl{font-size:13px;color:var(--muted)}
@endif
.lb-table{background:var(--surface);border:1px solid var(--border);border-radius:18px;overflow:hidden}
.lb-row{display:grid;grid-template-columns:48px 1fr auto;align-items:center;gap:16px;padding:16px 24px;border-bottom:1px solid var(--border);transition:background .2s}
.lb-row:last-child{border:none}
.lb-row:hover{background:rgba(255,255,255,.02)}
.lb-row.top1{background:linear-gradient(135deg,rgba(251,191,36,.04),transparent)}
.lb-row.top2{background:linear-gradient(135deg,rgba(148,163,184,.04),transparent)}
.lb-row.top3{background:linear-gradient(135deg,rgba(180,83,9,.04),transparent)}
.lb-row.me{background:rgba(37,99,235,.04);border-color:rgba(37,99,235,.15)!important}
.lb-rank-num{width:38px;height:38px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:800;flex-shrink:0}
.r1{background:rgba(251,191,36,.15);color:#fbbf24}
.r2{background:rgba(148,163,184,.12);color:#94a3b8}
.r3{background:rgba(180,83,9,.12);color:#f97316}
.rn{background:rgba(255,255,255,.05);color:var(--muted);font-size:13px}
.lb-user{display:flex;align-items:center;gap:10px}
.lb-avatar{width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,rgba(37,99,235,.2),rgba(124,58,237,.15));display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;color:#93c5fd;flex-shrink:0}
.lb-name{font-size:14px;font-weight:600;color:#fff}
.lb-region{font-size:11px;color:var(--muted)}
.lb-coin{font-size:16px;font-weight:800;color:#4ade80;white-space:nowrap}
.lb-coin small{font-size:10px;font-weight:400;color:var(--muted);display:block;text-align:right}
.me-badge{font-size:9px;background:rgba(37,99,235,.15);color:#93c5fd;padding:2px 6px;border-radius:4px;margin-left:6px;font-weight:700}
</style>
@endsection
@section('content')
<div class="container lb-page">
  <div class="lb-hero">
    <h1>🏆 GreenCoin Liderlar</h1>
    <p>Eng faol ekologlar — platforma yulduzlari</p>
  </div>

  @auth
  @if($userRank)
  <div class="lb-my-rank">
    <div>
      <div class="rank-num">#{{ $userRank }}</div>
      <div class="rank-lbl">Sizning o'rningiz</div>
    </div>
    <div style="width:1px;height:36px;background:var(--border)"></div>
    <div>
      <div style="font-size:18px;font-weight:800;color:#4ade80">{{ number_format(auth()->user()->greencoin_balance) }}</div>
      <div style="font-size:11px;color:var(--muted)">GreenCoin</div>
    </div>
    <div style="margin-left:auto">
      <a href="/eco" class="btn btn-success" style="padding:10px 18px;font-size:13px">GC ishlash &rarr;</a>
    </div>
  </div>
  @endif
  @endauth

  <div class="lb-table">
    @foreach($leaders as $i => $leader)
    @php $isMe = auth()->check() && auth()->id() === $leader->id; @endphp
    <div class="lb-row {{ $i===0?'top1':($i===1?'top2':($i===2?'top3':'')) }} {{ $isMe?'me':'' }}">
      <div class="lb-rank-num {{ $i===0?'r1':($i===1?'r2':($i===2?'r3':'rn')) }}">
        {{ $i===0 ? '🥇' : ($i===1 ? '🥈' : ($i===2 ? '🥉' : $i+1)) }}
      </div>
      <div class="lb-user">
        <div class="lb-avatar">{{ strtoupper(mb_substr($leader->name, 0, 1)) }}</div>
        <div>
          <a href="/user/{{ $leader->id }}" class="lb-name">
            {{ $leader->name }}
            @if($isMe)<span class="me-badge">Sen</span>@endif
          </a>
          @if($leader->region)<div class="lb-region">{{ $leader->region }}</div>@endif
        </div>
      </div>
      <div class="lb-coin">
        {{ number_format($leader->greencoin_balance) }}
        <small>GreenCoin</small>
      </div>
    </div>
    @endforeach
  </div>
</div>
@endsection
