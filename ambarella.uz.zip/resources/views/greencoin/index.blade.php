@extends('layouts.app')
@section('title', 'GreenCoin Hamyon | AMBARELLA')
@section('styles')
<style>
.gc-page{padding:48px 0 80px}
.gc-hero{background:linear-gradient(135deg,rgba(34,197,94,.06),rgba(8,145,178,.04));border:1px solid rgba(34,197,94,.12);border-radius:20px;padding:32px;margin-bottom:28px;display:grid;grid-template-columns:1fr auto;gap:24px;align-items:center}
.gc-hero-left h1{font-size:22px;font-weight:800;color:#fff;margin-bottom:4px}
.gc-hero-left p{font-size:13px;color:var(--muted)}
.gc-balance-box{text-align:center;padding:20px 32px;background:rgba(34,197,94,.06);border:1px solid rgba(34,197,94,.15);border-radius:16px}
.gcb-num{font-size:42px;font-weight:900;color:#4ade80;line-height:1}
.gcb-label{font-size:12px;color:var(--muted);margin-top:4px}
.gcb-rank{font-size:11px;color:#22d3ee;margin-top:8px;font-weight:600}
/* Stats */
.gc-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:28px}
.gcs{background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:20px;text-align:center;position:relative;overflow:hidden;transition:all .3s}
.gcs:hover{border-color:rgba(34,197,94,.2);transform:translateY(-2px)}
.gcs .gcs-icon{width:40px;height:40px;border-radius:10px;display:flex;align-items:center;justify-content:center;margin:0 auto 10px}
.gcs .gcs-icon svg{width:20px;height:20px;stroke:currentColor;fill:none;stroke-width:2}
.gcs .gcs-num{font-size:24px;font-weight:800}
.gcs .gcs-lbl{font-size:11px;color:var(--muted);margin-top:3px}
/* Quick Actions */
.gc-actions{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:28px}
.gca-card{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:22px;transition:all .3s}
.gca-card:hover{border-color:rgba(37,99,235,.2)}
.gca-card h3{font-size:14px;font-weight:700;color:#fff;margin-bottom:14px;display:flex;align-items:center;gap:8px}
.gca-card h3 svg{width:16px;height:16px;stroke:var(--primary);fill:none;stroke-width:2}
.transfer-form input{width:100%;padding:10px 12px;background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:8px;color:#fff;font-size:13px;margin-bottom:8px}
.transfer-form input:focus{outline:none;border-color:var(--primary)}
.transfer-form input::placeholder{color:#475569}
/* Transactions */
.gc-tx-header{font-size:17px;font-weight:700;color:#fff;margin-bottom:16px;display:flex;align-items:center;justify-content:space-between}
.gc-tx-header a{font-size:12px;color:var(--primary)}
.gc-table-wrap{background:var(--surface);border:1px solid var(--border);border-radius:16px;overflow:hidden}
.gc-table{width:100%;border-collapse:collapse}
.gc-table th{text-align:left;padding:12px 20px;font-size:10px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid var(--border)}
.gc-table td{padding:13px 20px;font-size:13px;color:#e2e8f0;border-bottom:1px solid var(--border)}
.gc-table tr:last-child td{border:none}
.gc-table tr:hover td{background:rgba(255,255,255,.015)}
.tx-badge{display:inline-flex;align-items:center;gap:4px;padding:3px 10px;border-radius:999px;font-size:10px;font-weight:700}
.tx-earned{background:rgba(34,197,94,.1);color:#4ade80;border:1px solid rgba(34,197,94,.15)}
.tx-spent{background:rgba(245,158,11,.1);color:#fbbf24;border:1px solid rgba(245,158,11,.15)}
.tx-amount-earned{font-weight:800;color:#4ade80}
.tx-amount-spent{font-weight:800;color:#fbbf24}
.gc-empty{text-align:center;padding:56px;color:var(--muted)}
@media(max-width:768px){.gc-hero{grid-template-columns:1fr}.gc-stats{grid-template-columns:1fr 1fr}.gc-actions{grid-template-columns:1fr}}
</style>
@endsection
@section('content')
<div class="container gc-page">
  {{-- Hero --}}
  <div class="gc-hero">
    <div class="gc-hero-left">
      <h1>GreenCoin Hamyon</h1>
      <p>Ekologik harakatlar uchun virtual mukofot — ishlang, sarflang, ulamlang</p>
      <div style="display:flex;gap:10px;margin-top:16px;flex-wrap:wrap">
        <a href="/eco" class="btn btn-success" style="padding:10px 20px;font-size:13px">GC ishlash</a>
        <a href="/greencoin/shop" class="btn btn-outline" style="padding:10px 20px;font-size:13px">Do'kon</a>
        <a href="/greencoin/leaderboard" class="btn btn-outline" style="padding:10px 20px;font-size:13px">Liderlar</a>
      </div>
    </div>
    <div class="gc-balance-box">
      <div class="gcb-num">{{ number_format($stats['balance']) }}</div>
      <div class="gcb-label">GreenCoin</div>
      <div class="gcb-rank">Reyting: #{{ $stats['rank'] }}</div>
    </div>
  </div>

  {{-- Stats --}}
  <div class="gc-stats">
    <div class="gcs">
      <div class="gcs-icon" style="background:rgba(34,197,94,.1);color:#4ade80"><svg viewBox="0 0 24 24"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/></svg></div>
      <div class="gcs-num" style="color:#4ade80">+{{ number_format($stats['earned']) }}</div>
      <div class="gcs-lbl">Jami ishlangan</div>
    </div>
    <div class="gcs">
      <div class="gcs-icon" style="background:rgba(245,158,11,.1);color:#fbbf24"><svg viewBox="0 0 24 24"><polyline points="23 18 13.5 8.5 8.5 13.5 1 6"/></svg></div>
      <div class="gcs-num" style="color:#fbbf24">-{{ number_format($stats['spent']) }}</div>
      <div class="gcs-lbl">Jami sarflangan</div>
    </div>
    <div class="gcs">
      <div class="gcs-icon" style="background:rgba(96,165,250,.1);color:#60a5fa"><svg viewBox="0 0 24 24"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg></div>
      <div class="gcs-num" style="color:#60a5fa">{{ number_format($stats['balance']) }}</div>
      <div class="gcs-lbl">Joriy balans</div>
    </div>
  </div>

  {{-- Quick Actions --}}
  <div class="gc-actions">
    {{-- Transfer --}}
    <div class="gca-card">
      <h3><svg viewBox="0 0 24 24"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9"/></svg>GC Transfer</h3>
      @if(session('success'))
        <div class="alert alert-success" style="margin-bottom:12px;font-size:12px">{{ session('success') }}</div>
      @endif
      @if($errors->any())
        <div class="alert alert-error" style="margin-bottom:12px;font-size:12px">{{ $errors->first() }}</div>
      @endif
      <form action="/greencoin/transfer" method="POST" class="transfer-form">
        @csrf
        <input type="email" name="recipient_email" placeholder="Qabul qiluvchi email...">
        <input type="number" name="amount" placeholder="Miqdor (min: 10)" min="10" max="5000">
        <input type="text" name="message" placeholder="Xabar (ixtiyoriy)">
        <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:10px;font-size:13px;margin-top:4px">Yuborish</button>
      </form>
    </div>

    {{-- Level Progress --}}
    <div class="gca-card">
      <h3><svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="7"/><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/></svg>Daraja progressi</h3>
      @php
        $bal = $stats['balance'];
        $levels = [['name'=>'Starter','min'=>0,'max'=>100,'color'=>'#64748b'],['name'=>'Bronze','min'=>100,'max'=>500,'color'=>'#cd7f32'],['name'=>'Silver','min'=>500,'max'=>1000,'color'=>'#94a3b8'],['name'=>'Gold','min'=>1000,'max'=>5000,'color'=>'#fbbf24'],['name'=>'Platinum','min'=>5000,'max'=>9999,'color'=>'#a78bfa']];
        $current = collect($levels)->last(fn($l) => $bal >= $l['min']);
        $next = collect($levels)->first(fn($l) => $bal < $l['min']);
        $pct = $next ? min(round(($bal - $current['min']) / ($next['min'] - $current['min']) * 100), 100) : 100;
      @endphp
      <div style="display:flex;justify-content:space-between;margin-bottom:10px">
        <span style="font-size:14px;font-weight:700;color:{{ $current['color'] }}">{{ $current['name'] }}</span>
        @if($next)<span style="font-size:12px;color:var(--muted)">Keyingi: {{ $next['name'] }} ({{ number_format($next['min']) }} GC)</span>@endif
      </div>
      <div style="height:8px;background:var(--border);border-radius:4px;overflow:hidden">
        <div style="height:100%;width:{{ $pct }}%;background:linear-gradient(90deg,{{ $current['color'] }},{{ $next['color'] ?? $current['color'] }});border-radius:4px;transition:width 1s ease"></div>
      </div>
      <div style="font-size:11px;color:var(--muted);margin-top:8px">{{ $pct }}% — {{ number_format($bal) }} GC</div>
      <div style="display:flex;gap:6px;margin-top:14px;flex-wrap:wrap">
        @foreach($levels as $lv)
        <span style="padding:3px 9px;border-radius:999px;font-size:10px;font-weight:700;background:{{ $bal >= $lv['min'] ? 'rgba(0,0,0,.2)' : 'transparent' }};color:{{ $lv['color'] }};border:1px solid {{ $lv['color'] }}55">{{ $lv['name'] }}</span>
        @endforeach
      </div>
    </div>
  </div>

  {{-- Transactions --}}
  <div class="gc-tx-header">
    Tranzaksiyalar tarixi
    <a href="#">Export</a>
  </div>

  @if($transactions->count())
  <div class="gc-table-wrap">
    <table class="gc-table">
      <thead><tr><th>Miqdor</th><th>Tur</th><th>Tavsif</th><th>Sana</th></tr></thead>
      <tbody>
        @foreach($transactions as $tx)
        <tr>
          <td class="{{ $tx->type === 'earned' ? 'tx-amount-earned' : 'tx-amount-spent' }}">
            {{ $tx->type === 'earned' ? '+' : '-' }}{{ $tx->amount }} GC
          </td>
          <td>
            <span class="tx-badge {{ $tx->type === 'earned' ? 'tx-earned' : 'tx-spent' }}">
              {{ $tx->type === 'earned' ? 'Ishlangan' : 'Sarflangan' }}
            </span>
          </td>
          <td style="max-width:280px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">{{ $tx->description }}</td>
          <td style="color:var(--muted);font-size:12px;white-space:nowrap">{{ $tx->created_at->format('d.m.Y H:i') }}</td>
        </tr>
        @endforeach
      </tbody>
    </table>
  </div>
  <div style="display:flex;justify-content:center;margin-top:20px">{{ $transactions->links() }}</div>
  @else
  <div class="gc-empty">
    <p>Tranzaksiyalar yo'q. <a href="/eco" style="color:var(--primary)">Eco vazifalarni bajaring</a> va GreenCoin ishlang!</p>
  </div>
  @endif
</div>
@endsection
