@extends('layouts.app')
@section('title', 'Maqola yozish | Blog | AMBARELLA')
@section('styles')
<style>
.form-page{padding:48px 0;max-width:640px;margin:0 auto}
.form-page h1{font-size:22px;font-weight:800;color:#fff;margin-bottom:32px}
.form-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:32px}
.form-group{margin-bottom:18px}
.form-group label{display:block;font-size:13px;font-weight:600;color:#94a3b8;margin-bottom:6px}
.form-group input,.form-group select,.form-group textarea{width:100%;padding:12px 16px;border:1px solid var(--border);border-radius:var(--radius);font-size:14px;background:rgba(255,255,255,.02);color:#fff;font-family:inherit}
.form-group input::placeholder,.form-group textarea::placeholder{color:#475569}
.form-group textarea{resize:vertical;min-height:200px}
.form-group select option{background:#1e293b;color:#fff}
.back-link{display:inline-flex;align-items:center;gap:6px;color:var(--muted);font-size:13px;margin-bottom:20px;transition:color .2s;text-decoration:none}
.back-link:hover{color:#fff}
.form-hint{font-size:11px;color:#475569;margin-top:4px}
</style>
@endsection
@section('content')
<div class="container">
  <div class="form-page">
    <a href="{{ route('blog') }}" class="back-link">← Blog</a>
    <h1>✍️ Yangi maqola yozish</h1>
    @if($errors->any())
    <div style="background:rgba(220,38,38,.1);border:1px solid rgba(220,38,38,.3);border-radius:var(--radius);padding:14px;margin-bottom:20px">
      @foreach($errors->all() as $error)
        <p style="color:#fca5a5;font-size:13px;margin:2px 0">{{ $error }}</p>
      @endforeach
    </div>
    @endif
    <form method="POST" action="{{ route('blog.store') }}" class="form-card">
      @csrf
      <div class="form-group">
        <label>Sarlavha *</label>
        <input name="title" required placeholder="Maqola sarlavhasi" value="{{ old('title') }}">
      </div>
      <div class="form-group">
        <label>Kategoriya *</label>
        <select name="category" required>
          <option value="Texnologiya" {{ old('category') == 'Texnologiya' ? 'selected' : '' }}>Texnologiya</option>
          <option value="Biznes" {{ old('category') == 'Biznes' ? 'selected' : '' }}>Biznes</option>
          <option value="Ta'lim" {{ old('category') == "Ta'lim" ? 'selected' : '' }}>Ta'lim</option>
          <option value="Ekologiya" {{ old('category') == 'Ekologiya' ? 'selected' : '' }}>Ekologiya</option>
          <option value="Hayot" {{ old('category') == 'Hayot' ? 'selected' : '' }}>Hayot tarzi</option>
          <option value="Karera" {{ old('category') == 'Karera' ? 'selected' : '' }}>Karera</option>
        </select>
      </div>
      <div class="form-group">
        <label>Qisqa ta'rif (excerpt)</label>
        <input name="excerpt" placeholder="Maqola haqida qisqacha..." value="{{ old('excerpt') }}">
        <p class="form-hint">Ixtiyoriy. Ko'rsatilmasa matndan avtomatik kesiladi.</p>
      </div>
      <div class="form-group">
        <label>Rasm URL (ixtiyoriy)</label>
        <input name="image" placeholder="https://example.com/image.jpg" value="{{ old('image') }}">
      </div>
      <div class="form-group">
        <label>Matn *</label>
        <textarea name="content" required placeholder="Maqola matnini yozing...">{{ old('content') }}</textarea>
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:14px">📤 Nashr qilish</button>
    </form>
  </div>
</div>
@endsection
