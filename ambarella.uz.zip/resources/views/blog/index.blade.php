@extends('layouts.app')
@section('title', 'Blog | AMBARELLA')
@section('styles')
<style>
.page-hero{padding:56px 0 40px;text-align:center;position:relative}
.page-hero h1{font-size:clamp(28px,4vw,38px);font-weight:800;color:#fff;margin-bottom:8px}
.page-hero p{color:var(--muted);font-size:15px}
.blog-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:20px;padding:40px 0}
.blog-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden;transition:all .3s;display:flex;flex-direction:column;text-decoration:none}
.blog-card:hover{border-color:rgba(37,99,235,.4);transform:translateY(-3px);box-shadow:0 8px 32px rgba(37,99,235,.08)}
.blog-card-img{width:100%;height:180px;object-fit:cover;background:rgba(255,255,255,.03)}
.blog-card-img-placeholder{width:100%;height:180px;background:linear-gradient(135deg,rgba(37,99,235,.1),rgba(139,92,246,.1));display:flex;align-items:center;justify-content:center;font-size:40px}
.blog-card-body{padding:22px;flex:1;display:flex;flex-direction:column}
.blog-card .category-badge{font-size:11px;font-weight:700;color:#93c5fd;background:rgba(37,99,235,.1);padding:3px 10px;border-radius:20px;display:inline-block;margin-bottom:10px;text-transform:uppercase;letter-spacing:.5px}
.blog-card h3{font-size:16px;font-weight:700;color:#fff;margin-bottom:8px;line-height:1.4}
.blog-card .excerpt{font-size:13px;color:var(--muted);line-height:1.6;flex:1}
.blog-card-meta{display:flex;justify-content:space-between;align-items:center;font-size:12px;color:#475569;margin-top:14px;padding-top:14px;border-top:1px solid var(--border)}
.blog-card-meta .author{color:#94a3b8;font-weight:500}
.blog-card-meta .views{display:flex;align-items:center;gap:4px}
.blog-actions{display:flex;justify-content:flex-end;margin-bottom:20px}
.pagination-wrap{padding:24px 0;display:flex;justify-content:center}
@media(max-width:768px){.blog-grid{grid-template-columns:1fr}}
</style>
@endsection
@section('content')
<section class="page-hero"><div class="container">
  <h1>Blog</h1>
  <p>Foydali maqolalar va tajribalar</p>
</div></section>
<div class="container">
  @auth
  <div class="blog-actions">
    <a href="{{ route('blog.create') }}" class="btn btn-primary" style="padding:10px 20px;font-size:13px">✍️ Maqola yozish</a>
  </div>
  @endauth
  <div class="blog-grid">
    @foreach($posts as $post)
    <a href="{{ route('blog.show', $post->slug) }}" class="blog-card">
      @if($post->image)
        <img src="{{ $post->image }}" alt="{{ $post->title }}" class="blog-card-img">
      @else
        <div class="blog-card-img-placeholder">📝</div>
      @endif
      <div class="blog-card-body">
        <span class="category-badge">{{ $post->category }}</span>
        <h3>{{ $post->title }}</h3>
        <p class="excerpt">{{ $post->excerpt ?? Str::limit(strip_tags($post->content), 120) }}</p>
        <div class="blog-card-meta">
          <span class="author">{{ $post->user->name ?? 'Anonim' }}</span>
          <span class="views">👁 {{ $post->views_count }} · {{ $post->created_at->format('d M Y') }}</span>
        </div>
      </div>
    </a>
    @endforeach
  </div>
  @if($posts->isEmpty())
    <div style="text-align:center;padding:60px 0;color:var(--muted)">
      <p style="font-size:40px;margin-bottom:12px">📭</p>
      <p>Hali blog postlar yo'q</p>
    </div>
  @endif
  <div class="pagination-wrap">{{ $posts->links() }}</div>
</div>
@endsection
