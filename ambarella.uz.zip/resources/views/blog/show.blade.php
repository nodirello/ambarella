@extends('layouts.app')
@section('title', $post->title . ' | Blog | AMBARELLA')
@section('styles')
<style>
.blog-show{padding:48px 0;max-width:780px;margin:0 auto}
.back-link{display:inline-flex;align-items:center;gap:6px;color:var(--muted);font-size:13px;margin-bottom:24px;transition:color .2s;text-decoration:none}
.back-link:hover{color:#fff}
.blog-header{margin-bottom:32px}
.blog-header .category-badge{font-size:11px;font-weight:700;color:#93c5fd;background:rgba(37,99,235,.1);padding:4px 12px;border-radius:20px;display:inline-block;margin-bottom:12px;text-transform:uppercase;letter-spacing:.5px}
.blog-header h1{font-size:clamp(24px,3.5vw,32px);font-weight:800;color:#fff;line-height:1.3;margin-bottom:16px}
.blog-meta{display:flex;flex-wrap:wrap;gap:16px;align-items:center;font-size:13px;color:#64748b}
.blog-meta .author{color:#94a3b8;font-weight:600}
.blog-meta .views{display:flex;align-items:center;gap:4px}
.blog-cover{width:100%;border-radius:var(--radius);margin-bottom:32px;max-height:400px;object-fit:cover}
.blog-content{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:36px;margin-bottom:24px}
.blog-content p,.blog-content li{font-size:15px;color:#cbd5e1;line-height:1.8;margin-bottom:16px}
.blog-content h2,.blog-content h3{color:#fff;margin:24px 0 12px;font-weight:700}
.blog-tags{display:flex;flex-wrap:wrap;gap:8px;margin-top:24px;padding-top:20px;border-top:1px solid var(--border)}
.blog-tag{font-size:11px;color:#93c5fd;background:rgba(37,99,235,.08);padding:4px 12px;border-radius:20px;font-weight:500}
</style>
@endsection
@section('content')
<div class="container">
  <div class="blog-show">
    <a href="{{ route('blog') }}" class="back-link">← Barcha maqolalar</a>
    <div class="blog-header">
      <span class="category-badge">{{ $post->category }}</span>
      <h1>{{ $post->title }}</h1>
      <div class="blog-meta">
        <span class="author">{{ $post->user->name ?? 'Anonim' }}</span>
        <span>{{ $post->created_at->format('d M Y') }}</span>
        <span class="views">👁 {{ $post->views_count }} ko'rilgan</span>
      </div>
    </div>
    @if($post->image)
      <img src="{{ $post->image }}" alt="{{ $post->title }}" class="blog-cover">
    @endif
    <div class="blog-content">
      {!! nl2br(e($post->content)) !!}
    </div>
    @if($post->tags && count($post->tags) > 0)
    <div class="blog-tags">
      @foreach($post->tags as $tag)
        <span class="blog-tag">#{{ $tag }}</span>
      @endforeach
    </div>
    @endif
  </div>
</div>
@endsection
