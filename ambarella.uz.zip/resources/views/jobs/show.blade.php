@extends('layouts.app')
@section('title', $job->title . ' — ' . $job->company . ' | AMBARELLA')
@section('description', Str::limit($job->description ?? '', 160))
@section('styles')
<style>
.job-page{padding:48px 0 80px}
.job-back{display:inline-flex;align-items:center;gap:6px;color:var(--muted);font-size:13px;margin-bottom:28px;transition:color .2s}
.job-back:hover{color:#fff}
.job-back svg{width:16px;height:16px;stroke:currentColor;fill:none;stroke-width:2}
.job-layout{display:grid;grid-template-columns:1fr 340px;gap:32px;align-items:start}
/* Main */
.job-main-card{background:var(--surface);border:1px solid var(--border);border-radius:20px;overflow:hidden}
.job-header{padding:32px;border-bottom:1px solid var(--border);position:relative}
.job-header::before{content:'';position:absolute;top:0;left:0;right:0;height:4px;background:linear-gradient(90deg,var(--primary),#7c3aed)}
.job-logo-row{display:flex;align-items:center;gap:16px;margin-bottom:20px}
.job-logo{width:64px;height:64px;border-radius:16px;background:rgba(37,99,235,.1);border:1px solid rgba(37,99,235,.15);display:flex;align-items:center;justify-content:center;font-size:24px;font-weight:900;color:#60a5fa;flex-shrink:0}
.job-h1{font-size:clamp(20px,3vw,26px);font-weight:800;color:#fff;margin-bottom:6px}
.job-company{font-size:15px;color:var(--muted)}
.job-badges{display:flex;gap:8px;flex-wrap:wrap;margin-top:16px}
.job-badge{display:inline-flex;align-items:center;gap:5px;padding:6px 14px;border-radius:999px;font-size:12px;font-weight:600}
.jb-type{background:rgba(37,99,235,.1);color:#93c5fd;border:1px solid rgba(37,99,235,.15)}
.jb-location{background:rgba(20,184,166,.08);color:#2dd4bf;border:1px solid rgba(20,184,166,.15)}
.jb-salary{background:rgba(34,197,94,.08);color:#4ade80;border:1px solid rgba(34,197,94,.15)}
.jb-views{background:rgba(255,255,255,.04);color:var(--muted);border:1px solid var(--border)}
.job-badges svg{width:13px;height:13px;stroke:currentColor;fill:none;stroke-width:2}
/* Tags */
.job-tags-row{display:flex;gap:6px;flex-wrap:wrap;padding:16px 32px;border-bottom:1px solid var(--border)}
.job-tags-row span{padding:4px 12px;border-radius:999px;font-size:11px;font-weight:500;background:rgba(37,99,235,.06);color:#93c5fd;border:1px solid rgba(37,99,235,.1)}
/* Content */
.job-section{padding:28px 32px;border-bottom:1px solid var(--border)}
.job-section:last-child{border:none}
.job-section h3{font-size:15px;font-weight:700;color:#fff;margin-bottom:14px;display:flex;align-items:center;gap:8px}
.job-section h3 svg{width:16px;height:16px;stroke:var(--primary);fill:none;stroke-width:2}
.job-section p,.job-section li{font-size:14px;color:#94a3b8;line-height:1.8}
.job-section ul{padding-left:0;list-style:none;display:flex;flex-direction:column;gap:6px}
.job-section ul li{display:flex;align-items:flex-start;gap:8px}
.job-section ul li::before{content:'';width:6px;height:6px;background:var(--primary);border-radius:50%;flex-shrink:0;margin-top:7px}
/* Sidebar */
.job-sidebar{display:flex;flex-direction:column;gap:16px;position:sticky;top:90px}
.js-card{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:24px}
.js-card h3{font-size:14px;font-weight:700;color:#fff;margin-bottom:16px}
.js-apply-btn{width:100%;padding:14px;border-radius:12px;font-size:15px;font-weight:700;text-align:center;display:flex;align-items:center;justify-content:center;gap:8px;margin-bottom:10px}
.js-apply-btn svg{width:18px;height:18px;stroke:currentColor;fill:none;stroke-width:2}
.js-info-row{display:flex;justify-content:space-between;align-items:center;padding:9px 0;border-bottom:1px solid var(--border);font-size:12px}
.js-info-row:last-child{border:none}
.js-info-row .label{color:var(--muted)}
.js-info-row .value{color:#fff;font-weight:600}
/* Form */
.apply-form-wrap{margin-top:12px}
.apply-form-wrap textarea{width:100%;padding:12px;background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:10px;color:#fff;font-size:13px;resize:vertical;min-height:80px;font-family:inherit}
.apply-form-wrap textarea:focus{outline:none;border-color:var(--primary)}
/* Related */
.related-list{display:flex;flex-direction:column;gap:10px}
.rel-card{display:flex;align-items:center;gap:12px;padding:12px;background:rgba(255,255,255,.02);border:1px solid var(--border);border-radius:12px;transition:all .2s}
.rel-card:hover{border-color:rgba(37,99,235,.25);background:rgba(37,99,235,.03)}
.rel-logo{width:36px;height:36px;border-radius:8px;background:rgba(37,99,235,.1);display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:800;color:#60a5fa;flex-shrink:0}
.rel-info h4{font-size:12px;font-weight:600;color:#fff}
.rel-info p{font-size:11px;color:var(--muted)}
@media(max-width:1024px){.job-layout{grid-template-columns:1fr}.job-sidebar{position:static}}
@media(max-width:768px){.job-header{padding:20px}.job-section{padding:20px}.job-tags-row{padding:12px 20px}}
</style>
@endsection
@section('content')
<div class="container job-page">
  <a href="/jobs" class="job-back"><svg viewBox="0 0 24 24"><path d="M19 12H5M12 19l-7-7 7-7"/></svg> Barcha vakansiyalar</a>

  <div class="job-layout">
    {{-- MAIN --}}
    <div>
      <div class="job-main-card">
        {{-- Header --}}
        <div class="job-header">
          <div class="job-logo-row">
            <div class="job-logo">{{ strtoupper(substr($job->company ?? 'C', 0, 1)) }}</div>
            <div>
              <h1 class="job-h1">{{ $job->title }}</h1>
              <p class="job-company">{{ $job->company }}</p>
            </div>
          </div>
          <div class="job-badges">
            <span class="job-badge jb-type"><svg viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/></svg>{{ $job->type ?? "To'liq kunlik" }}</span>
            <span class="job-badge jb-location"><svg viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>{{ $job->location }}</span>
            @if($job->salary_min)
            <span class="job-badge jb-salary"><svg viewBox="0 0 24 24"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>{{ number_format($job->salary_min/1000000) }}–{{ number_format($job->salary_max/1000000) }}M so'm</span>
            @endif
            <span class="job-badge jb-views"><svg viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>{{ $job->views_count ?? 0 }} ko'rish</span>
            <span class="job-badge jb-views"><svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>{{ $applicationsCount }} ariza</span>
          </div>
        </div>

        {{-- Tags --}}
        @if(!empty($job->tags))
        <div class="job-tags-row">
          @foreach($job->tags as $tag)<span>{{ $tag }}</span>@endforeach
        </div>
        @endif

        {{-- Description --}}
        <div class="job-section">
          <h3><svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg> Ish haqida</h3>
          <p style="white-space:pre-line">{{ $job->description ?? 'Ish tavsifi tez orada qo\'shiladi.' }}</p>
        </div>

        {{-- Requirements --}}
        @if($job->requirements)
        <div class="job-section">
          <h3><svg viewBox="0 0 24 24"><polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></svg> Talablar</h3>
          <ul>
            @foreach(explode("\n", $job->requirements) as $req)
            @if(trim($req))<li>{{ trim($req) }}</li>@endif
            @endforeach
          </ul>
        </div>
        @endif

        {{-- Benefits --}}
        @if($job->benefits)
        <div class="job-section">
          <h3><svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="7"/><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/></svg> Imtiyozlar</h3>
          <ul>
            @foreach(explode("\n", $job->benefits) as $ben)
            @if(trim($ben))<li>{{ trim($ben) }}</li>@endif
            @endforeach
          </ul>
        </div>
        @endif
      </div>

      {{-- Related --}}
      @if($related->count() > 0)
      <div style="margin-top:24px">
        <h3 style="font-size:16px;font-weight:700;color:#fff;margin-bottom:14px">O'xshash vakansiyalar</h3>
        <div class="related-list">
          @foreach($related as $r)
          <a href="/jobs/{{ $r->id }}" class="rel-card">
            <div class="rel-logo">{{ strtoupper(substr($r->company ?? 'C', 0, 1)) }}</div>
            <div class="rel-info">
              <h4>{{ $r->title }}</h4>
              <p>{{ $r->company }} · {{ $r->location }}</p>
            </div>
            @if($r->salary_min)<span style="margin-left:auto;font-size:12px;font-weight:700;color:#4ade80;white-space:nowrap">{{ number_format($r->salary_min/1000000) }}–{{ number_format($r->salary_max/1000000) }}M</span>@endif
          </a>
          @endforeach
        </div>
      </div>
      @endif
    </div>

    {{-- SIDEBAR --}}
    <div class="job-sidebar">
      {{-- Apply Card --}}
      <div class="js-card">
        <h3>Ariza topshirish</h3>
        @if(session('success'))
          <div class="alert alert-success" style="margin-bottom:12px;font-size:13px">{{ session('success') }}</div>
        @endif
        @if($errors->any())
          <div class="alert alert-error" style="margin-bottom:12px;font-size:13px">{{ $errors->first() }}</div>
        @endif

        @auth
          @if($isApplied)
            <div style="display:flex;align-items:center;gap:8px;padding:12px;background:rgba(34,197,94,.06);border:1px solid rgba(34,197,94,.15);border-radius:10px;margin-bottom:12px">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#4ade80" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
              <span style="font-size:13px;color:#4ade80;font-weight:600">Ariza topshirildi</span>
            </div>
            <a href="/my-applications" class="btn btn-outline" style="width:100%;justify-content:center">Arizalarimni ko'rish</a>
          @elseif($job->is_active)
            <form action="/jobs/{{ $job->id }}/apply" method="POST">
              @csrf
              <div class="apply-form-wrap">
                <textarea name="cover_letter" placeholder="Motivatsion xat (ixtiyoriy) — nima uchun bu lavozim siz uchun mos?"></textarea>
              </div>
              <button type="submit" class="btn btn-primary js-apply-btn" style="margin-top:10px">
                <svg viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 12a19.79 19.79 0 01-3-8.63A2 2 0 012 1.18H5a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.91 8.22a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 15.18v1.74z"/></svg>
                Ariza topshirish
              </button>
            </form>
            <p style="font-size:11px;color:var(--muted);text-align:center;margin-top:8px">Ariza topshirsangiz +5 GreenCoin olasiz</p>
          @else
            <div style="padding:14px;text-align:center;color:var(--muted);font-size:13px">Bu vakansiya yopilgan</div>
          @endif
        @else
          <a href="/login" class="btn btn-primary js-apply-btn">
            <svg viewBox="0 0 24 24"><path d="M15 3h4a2 2 0 012 2v14a2 2 0 01-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/></svg>
            Kirish va ariza topshirish
          </a>
          <a href="/register" class="btn btn-outline" style="width:100%;justify-content:center;margin-top:8px">Ro'yxatdan o'tish</a>
        @endauth
      </div>

      {{-- Job Info --}}
      <div class="js-card">
        <h3>Vakansiya ma'lumotlari</h3>
        <div class="js-info-row"><span class="label">Kompaniya</span><span class="value">{{ $job->company }}</span></div>
        <div class="js-info-row"><span class="label">Joylashuv</span><span class="value">{{ $job->location }}</span></div>
        <div class="js-info-row"><span class="label">Ish turi</span><span class="value">{{ $job->type ?? "To'liq" }}</span></div>
        @if($job->salary_min)
        <div class="js-info-row"><span class="label">Maosh</span><span class="value" style="color:#4ade80">{{ number_format($job->salary_min/1000000) }}–{{ number_format($job->salary_max/1000000) }}M so'm</span></div>
        @endif
        <div class="js-info-row"><span class="label">E'lon qilingan</span><span class="value">{{ $job->created_at->format('d.m.Y') }}</span></div>
        @if($job->deadline)
        <div class="js-info-row"><span class="label">Muddat</span><span class="value" style="color:#fbbf24">{{ $job->deadline->format('d.m.Y') }}</span></div>
        @endif
        <div class="js-info-row"><span class="label">Arizalar</span><span class="value">{{ $applicationsCount }} ta</span></div>
      </div>

      {{-- Save button --}}
      @auth
      <form action="/jobs/{{ $job->id }}/save" method="POST">
        @csrf
        <button type="submit" class="btn btn-outline" style="width:100%;justify-content:center;gap:8px">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>
          Saqlash
        </button>
      </form>
      @endauth
    </div>
  </div>
</div>
@endsection
