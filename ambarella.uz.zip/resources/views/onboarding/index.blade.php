@extends('layouts.app')
@section('title', 'Profilingizni to\'ldiring | AMBARELLA')
@section('styles')
<style>
.onboard-page{min-height:calc(100vh - 200px);padding:48px 0}
.onboard-container{max-width:600px;margin:0 auto}
.onboard-header{text-align:center;margin-bottom:40px}
.onboard-header .step-badge{display:inline-flex;align-items:center;gap:6px;padding:6px 14px;border-radius:999px;font-size:12px;font-weight:600;background:rgba(37,99,235,.1);color:#60a5fa;margin-bottom:16px}
.onboard-header h1{font-size:clamp(24px,4vw,32px);font-weight:800;color:#fff;margin-bottom:8px}
.onboard-header p{color:var(--muted);font-size:15px}
.onboard-form{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:32px}
.form-section{margin-bottom:28px;padding-bottom:24px;border-bottom:1px solid var(--border)}
.form-section:last-of-type{border:none;margin-bottom:0;padding-bottom:0}
.form-section-title{font-size:14px;font-weight:700;color:#fff;margin-bottom:16px;display:flex;align-items:center;gap:8px}
.form-section-title svg{width:18px;height:18px;stroke:var(--primary);stroke-width:2;fill:none}
.form-group{margin-bottom:16px}
.form-group label{display:block;font-size:13px;font-weight:600;color:#94a3b8;margin-bottom:6px}
.form-group input,.form-group select,.form-group textarea{width:100%;padding:12px 16px;border:1px solid var(--border);border-radius:var(--radius);font-size:14px;background:rgba(255,255,255,.02);color:#fff;font-family:inherit;transition:border .2s}
.form-group input:focus,.form-group select:focus,.form-group textarea:focus{outline:none;border-color:var(--primary);box-shadow:0 0 0 3px rgba(37,99,235,.1)}
.form-group input::placeholder,.form-group textarea::placeholder{color:#475569}
.form-group textarea{resize:vertical;min-height:80px}
.form-group .hint{font-size:11px;color:var(--muted);margin-top:4px}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.interests-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}
.interest-item{position:relative}
.interest-item input{position:absolute;opacity:0;width:0;height:0}
.interest-item label{display:block;text-align:center;padding:10px 8px;border:1px solid var(--border);border-radius:var(--radius);font-size:12px;font-weight:500;color:var(--muted);cursor:pointer;transition:all .2s}
.interest-item input:checked+label{border-color:var(--primary);color:#fff;background:rgba(37,99,235,.1)}
.interest-item label:hover{border-color:rgba(37,99,235,.3)}
.avatar-upload{display:flex;align-items:center;gap:16px}
.avatar-preview{width:64px;height:64px;border-radius:50%;background:var(--surface);border:2px solid var(--border);display:flex;align-items:center;justify-content:center;overflow:hidden;flex-shrink:0}
.avatar-preview svg{width:24px;height:24px;stroke:var(--muted);stroke-width:1.5;fill:none}
</style>
@media(max-width:768px){.form-row{grid-template-columns:1fr}.interests-grid{grid-template-columns:repeat(2,1fr)}}
</style>
@endsection
@section('content')
<div class="onboard-page">
<div class="container">
<div class="onboard-container">
  <div class="onboard-header">
    <div class="step-badge">
      <svg viewBox="0 0 24 24" style="width:14px;height:14px;stroke:currentColor;fill:none;stroke-width:2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
      Yakuniy qadam
    </div>
    <h1>Profilingizni to'ldiring</h1>
    <p>Platformadan to'liq foydalanish uchun shaxsiy ma'lumotlaringizni kiriting</p>
  </div>

  <form action="/onboarding" method="POST" enctype="multipart/form-data" class="onboard-form">
    @csrf

    {{-- Asosiy ma'lumotlar --}}
    <div class="form-section">
      <div class="form-section-title">
        <svg viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
        Shaxsiy ma'lumotlar
      </div>
      <div class="form-group">
        <label>To'liq ism *</label>
        <input type="text" name="name" required placeholder="Ismingiz va familiyangiz" value="{{ old('name', auth()->user()->name) }}">
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Telefon raqam *</label>
          <input type="tel" name="phone" required placeholder="+998 90 000 00 00" value="{{ old('phone', auth()->user()->phone) }}">
        </div>
        <div class="form-group">
          <label>Tug'ilgan sana *</label>
          <input type="date" name="birth_date" required value="{{ old('birth_date') }}">
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Jins *</label>
          <select name="gender" required>
            <option value="">Tanlang</option>
            <option value="male" {{ old('gender')=='male'?'selected':'' }}>Erkak</option>
            <option value="female" {{ old('gender')=='female'?'selected':'' }}>Ayol</option>
          </select>
        </div>
        <div class="form-group">
          <label>Hudud *</label>
          <select name="region" required>
            <option value="">Tanlang</option>
            @foreach(['Toshkent','Samarqand','Buxoro','Farg\'ona','Andijon','Namangan','Qashqadaryo','Surxondaryo','Xorazm','Navoiy','Jizzax','Sirdaryo','Qoraqalpog\'iston'] as $reg)
            <option value="{{ $reg }}" {{ old('region')==$reg?'selected':'' }}>{{ $reg }}</option>
            @endforeach
          </select>
        </div>
      </div>
    </div>

    {{-- Bio va avatar --}}
    <div class="form-section">
      <div class="form-section-title">
        <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
        Qo'shimcha
      </div>
      <div class="form-group">
        <label>O'zingiz haqida</label>
        <textarea name="bio" placeholder="Qisqacha o'zingiz haqida yozing... (ixtiyoriy)" maxlength="500">{{ old('bio') }}</textarea>
        <p class="hint">Maks. 500 belgi</p>
      </div>
      <div class="form-group">
        <label>Profil rasmi</label>
        <div class="avatar-upload">
          <div class="avatar-preview">
            <svg viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
          </div>
          <input type="file" name="avatar" accept="image/jpeg,image/png,image/webp">
        </div>
        <p class="hint">JPG, PNG yoki WebP. Max 2MB</p>
      </div>
    </div>

    {{-- Qiziqishlar --}}
    <div class="form-section">
      <div class="form-section-title">
        <svg viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26"/></svg>
        Qiziqishlaringiz *
      </div>
      <p style="font-size:13px;color:var(--muted);margin-bottom:14px">Kamida 1, ko'pi bilan 5 ta tanlang</p>
      <div class="interests-grid">
        @foreach(['Dasturlash','Dizayn','Marketing','Biznes','Ekologiya','Mentorlik','Volontyorlik','Sport','Psixologiya','Fermerlik','Til o\'rganish','AI/ML'] as $interest)
        <div class="interest-item">
          <input type="checkbox" name="interests[]" value="{{ $interest }}" id="int_{{ $loop->index }}" {{ in_array($interest, old('interests', [])) ? 'checked' : '' }}>
          <label for="int_{{ $loop->index }}">{{ $interest }}</label>
        </div>
        @endforeach
      </div>
    </div>

    @if($errors->any())
    <div style="background:rgba(220,38,38,.06);border:1px solid rgba(220,38,38,.15);border-radius:var(--radius);padding:12px 16px;margin-bottom:20px">
      @foreach($errors->all() as $e)<p style="color:#fca5a5;font-size:13px;margin:2px 0">{{ $e }}</p>@endforeach
    </div>
    @endif

    <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:16px;font-size:15px">Profilni saqlash va davom etish</button>
  </form>
</div>
</div>
</div>
@endsection
