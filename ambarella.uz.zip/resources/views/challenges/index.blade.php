@extends('layouts.app')
@section('title', 'Musobaqalar — AMBARELLA')
@section('description', 'Coding, dizayn, biznes va ekologiya bo\'yicha musobaqalar va tanlovlar.')

@section('styles')
<style>
.ch-hero{padding:64px 0 48px;text-align:center}
.ch-hero h1{font-size:clamp(28px,5vw,42px);font-weight:800;color:#fff;margin-bottom:12px}
.ch-hero p{color:var(--muted);font-size:16px;max-width:620px;margin:0 auto;line-height:1.8}
.ch-badge{display:inline-flex;align-items:center;gap:6px;padding:6px 14px;border-radius:20px;font-size:12px;font-weight:600;background:rgba(220,38,38,.1);color:#fca5a5;margin-bottom:20px}
.ch-categories{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:20px;margin:48px 0}
.ch-cat{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:28px;text-align:center;transition:all .2s}
.ch-cat:hover{border-color:rgba(37,99,235,.3);transform:translateY(-3px)}
.ch-cat .icon{width:56px;height:56px;border-radius:14px;display:flex;align-items:center;justify-content:center;margin:0 auto 16px}
.ch-cat:nth-child(1) .icon{background:rgba(37,99,235,.12)}
.ch-cat:nth-child(2) .icon{background:rgba(245,158,11,.12)}
.ch-cat:nth-child(3) .icon{background:rgba(22,163,74,.12)}
.ch-cat:nth-child(4) .icon{background:rgba(124,58,237,.12)}
.ch-cat h3{font-size:16px;font-weight:700;color:#fff;margin-bottom:8px}
.ch-cat p{font-size:14px;color:var(--muted);line-height:1.7}
.ch-cat .tag{display:inline-block;margin-top:12px;padding:4px 10px;border-radius:6px;font-size:11px;font-weight:600;background:rgba(255,255,255,.05);color:#94a3b8}
.ch-leaderboard{margin:64px 0}
.ch-leaderboard h2{font-size:24px;font-weight:700;color:#fff;margin-bottom:24px;text-align:center}
.ch-lb-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden;max-width:600px;margin:0 auto}
.ch-lb-row{display:flex;align-items:center;padding:14px 20px;border-bottom:1px solid var(--border);gap:14px}
.ch-lb-row:last-child{border-bottom:none}
.ch-lb-row:hover{background:rgba(255,255,255,.02)}
.ch-lb-rank{width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;flex-shrink:0}
.ch-lb-row:nth-child(1) .ch-lb-rank{background:rgba(245,158,11,.15);color:#fbbf24}
.ch-lb-row:nth-child(2) .ch-lb-rank{background:rgba(148,163,184,.15);color:#94a3b8}
.ch-lb-row:nth-child(3) .ch-lb-rank{background:rgba(180,83,9,.15);color:#f59e0b}
.ch-lb-row:nth-child(n+4) .ch-lb-rank{background:rgba(255,255,255,.05);color:var(--muted)}
.ch-lb-name{flex:1;font-size:14px;font-weight:500;color:#e2e8f0}
.ch-lb-score{font-size:13px;font-weight:700;color:#4ade80}
.ch-cta{text-align:center;padding:64px 24px;margin:48px 0;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius)}
.ch-cta h2{font-size:clamp(20px,4vw,28px);font-weight:800;color:#fff;margin-bottom:12px}
.ch-cta p{color:var(--muted);font-size:15px;margin-bottom:24px;max-width:480px;margin-left:auto;margin-right:auto}
</style>
@endsection

@section('content')
<section class="ch-hero">
  <div class="container">
    <div class="ch-badge">
      <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polygon points="7 1 9 5 13 5.5 10 8.5 11 13 7 11 3 13 4 8.5 1 5.5 5 5"/></svg>
      Musobaqalar
    </div>
    <h1>Bilimingizni sinang, g'olib bo'ling!</h1>
    <p>Turli yo'nalishlar bo'yicha musobaqalarda qatnashing, o'z darajangizni ko'rsating va qimmatli sovg'alar yutib oling.</p>
  </div>
</section>

<section class="container">
  <div class="ch-categories">
    <div class="ch-cat">
      <div class="icon">
        <svg width="26" height="26" fill="none" stroke="#2563eb" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/><line x1="14" y1="4" x2="10" y2="20"/></svg>
      </div>
      <h3>Coding</h3>
      <p>Algoritmik masalalar, web development va mobil ilovalar bo'yicha musobaqalar.</p>
      <span class="tag">Python, JS, Java</span>
    </div>
    <div class="ch-cat">
      <div class="icon">
        <svg width="26" height="26" fill="none" stroke="#f59e0b" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="20" height="20" rx="3"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="23 16 17 10 5 23"/></svg>
      </div>
      <h3>Dizayn</h3>
      <p>UI/UX, grafik dizayn va brending bo'yicha ijodiy tanlovlar.</p>
      <span class="tag">Figma, Adobe, Canva</span>
    </div>
    <div class="ch-cat">
      <div class="icon">
        <svg width="26" height="26" fill="none" stroke="#16a34a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="13" y1="2" x2="13" y2="24"/><path d="M18 6H9.5a3.5 3.5 0 0 0 0 7h7a3.5 3.5 0 0 1 0 7H6"/></svg>
      </div>
      <h3>Biznes</h3>
      <p>Biznes-reja, pitch deck va startup g'oyalar bo'yicha tanlovlar.</p>
      <span class="tag">Startup, Pitching</span>
    </div>
    <div class="ch-cat">
      <div class="icon">
        <svg width="26" height="26" fill="none" stroke="#a78bfa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22c5.5-3 9-7.5 9-12a9 9 0 0 0-18 0c0 4.5 3.5 9 9 12z"/><path d="M12 8v4"/><circle cx="12" cy="8" r="1"/></svg>
      </div>
      <h3>Ekologiya</h3>
      <p>Yashil loyihalar, ekologik innovatsiyalar va barqaror rivojlanish musobaqalari.</p>
      <span class="tag">Green Tech</span>
    </div>
  </div>
</section>

<section class="container">
  <div class="ch-leaderboard">
    <h2>🏆 Liderlar jadvali</h2>
    <div class="ch-lb-card">
      <div class="ch-lb-row">
        <div class="ch-lb-rank">1</div>
        <div class="ch-lb-name">Jasurbek M.</div>
        <div class="ch-lb-score">2,450 ball</div>
      </div>
      <div class="ch-lb-row">
        <div class="ch-lb-rank">2</div>
        <div class="ch-lb-name">Nodira K.</div>
        <div class="ch-lb-score">2,180 ball</div>
      </div>
      <div class="ch-lb-row">
        <div class="ch-lb-rank">3</div>
        <div class="ch-lb-name">Sardor T.</div>
        <div class="ch-lb-score">1,960 ball</div>
      </div>
      <div class="ch-lb-row">
        <div class="ch-lb-rank">4</div>
        <div class="ch-lb-name">Dilnoza R.</div>
        <div class="ch-lb-score">1,720 ball</div>
      </div>
      <div class="ch-lb-row">
        <div class="ch-lb-rank">5</div>
        <div class="ch-lb-name">Bobur A.</div>
        <div class="ch-lb-score">1,540 ball</div>
      </div>
    </div>
  </div>
</section>

<section class="container">
  <div class="ch-cta">
    <h2>Musobaqada qatnashmoqchimisiz?</h2>
    <p>Ro'yxatdan o'ting, o'z kategoriyangizni tanlang va g'olib bo'ling!</p>
    <a href="/register" class="btn btn-primary">Qatnashish</a>
  </div>
</section>
@endsection
