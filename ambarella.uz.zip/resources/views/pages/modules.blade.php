@extends('layouts.app')
@section('title', 'Modullar — AMBARELLA')
@section('description', 'AMBARELLA platformasining barcha modullari — bandlik, ta\'lim, ekologiya, mentorlik va boshqalar.')

@section('styles')
<style>
.mod-hero{padding:64px 0 48px;text-align:center}
.mod-hero h1{font-size:clamp(28px,5vw,42px);font-weight:800;color:#fff;margin-bottom:12px}
.mod-hero p{color:var(--muted);font-size:16px;max-width:620px;margin:0 auto;line-height:1.8}
.mod-badge{display:inline-flex;align-items:center;gap:6px;padding:6px 14px;border-radius:20px;font-size:12px;font-weight:600;background:rgba(37,99,235,.1);color:#60a5fa;margin-bottom:20px}
.mod-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px;margin:48px 0}
.mod-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:24px;transition:all .2s;display:flex;flex-direction:column}
.mod-card:hover{border-color:rgba(37,99,235,.25);transform:translateY(-2px);background:rgba(255,255,255,.04)}
.mod-card .icon{width:44px;height:44px;border-radius:11px;display:flex;align-items:center;justify-content:center;margin-bottom:14px}
.mod-card h3{font-size:15px;font-weight:700;color:#fff;margin-bottom:6px}
.mod-card p{font-size:13px;color:var(--muted);line-height:1.6;flex:1}
.mod-card .link{display:inline-flex;align-items:center;gap:6px;margin-top:14px;font-size:12px;font-weight:600;color:var(--primary);transition:gap .2s}
.mod-card:hover .link{gap:10px}

/* Icon colors */
.mod-card:nth-child(1) .icon{background:rgba(37,99,235,.12)}
.mod-card:nth-child(2) .icon{background:rgba(22,163,74,.12)}
.mod-card:nth-child(3) .icon{background:rgba(245,158,11,.12)}
.mod-card:nth-child(4) .icon{background:rgba(124,58,237,.12)}
.mod-card:nth-child(5) .icon{background:rgba(236,72,153,.12)}
.mod-card:nth-child(6) .icon{background:rgba(56,189,248,.12)}
.mod-card:nth-child(7) .icon{background:rgba(22,163,74,.12)}
.mod-card:nth-child(8) .icon{background:rgba(245,158,11,.12)}
.mod-card:nth-child(9) .icon{background:rgba(220,38,38,.12)}
.mod-card:nth-child(10) .icon{background:rgba(236,72,153,.12)}
.mod-card:nth-child(11) .icon{background:rgba(34,197,94,.12)}
.mod-card:nth-child(12) .icon{background:rgba(37,99,235,.12)}
.mod-card:nth-child(13) .icon{background:rgba(124,58,237,.12)}
.mod-card:nth-child(14) .icon{background:rgba(56,189,248,.12)}
.mod-card:nth-child(15) .icon{background:rgba(245,158,11,.12)}
</style>
@endsection

@section('content')
<section class="mod-hero">
  <div class="container">
    <div class="mod-badge">
      <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="1" y="1" width="5" height="5" rx="1"/><rect x="8" y="1" width="5" height="5" rx="1"/><rect x="1" y="8" width="5" height="5" rx="1"/><rect x="8" y="8" width="5" height="5" rx="1"/></svg>
      Barcha modullar
    </div>
    <h1>Platforma modullari</h1>
    <p>AMBARELLA platformasining barcha modullari bir joyda. O'zingizga keraklisini tanlang va boshlang!</p>
  </div>
</section>

<section class="container">
  <div class="mod-grid">
    {{-- 1. Jobs --}}
    <a href="/jobs" class="mod-card">
      <div class="icon">
        <svg width="22" height="22" fill="none" stroke="#60a5fa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="18" height="13" rx="2"/><path d="M16 7V5a2 2 0 0 0-2-2h-6a2 2 0 0 0-2 2v2"/></svg>
      </div>
      <h3>Bandlik</h3>
      <p>Ish e'lonlari, resume builder va karyera maslahatlar.</p>
      <span class="link">Ochish <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 6h10M7 2l4 4-4 4"/></svg></span>
    </a>

    {{-- 2. Eco --}}
    <a href="/eco" class="mod-card">
      <div class="icon">
        <svg width="22" height="22" fill="none" stroke="#4ade80" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22c5.5-3 9-7.5 9-12a9 9 0 0 0-18 0c0 4.5 3.5 9 9 12z"/><path d="M12 8v6"/><path d="M9 11h6"/></svg>
      </div>
      <h3>Ekologiya</h3>
      <p>Yashil vazifalar, GreenCoin va tabiatni asrash.</p>
      <span class="link">Ochish <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 6h10M7 2l4 4-4 4"/></svg></span>
    </a>

    {{-- 3. Academy --}}
    <a href="/academy" class="mod-card">
      <div class="icon">
        <svg width="22" height="22" fill="none" stroke="#fbbf24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 10L12 5 2 10l10 5 10-5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg>
      </div>
      <h3>Academy</h3>
      <p>Bepul kurslar, video darsliklar va sertifikatlar.</p>
      <span class="link">Ochish <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 6h10M7 2l4 4-4 4"/></svg></span>
    </a>

    {{-- 4. Mentor --}}
    <a href="/mentor" class="mod-card">
      <div class="icon">
        <svg width="22" height="22" fill="none" stroke="#a78bfa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
      </div>
      <h3>Mentorlik</h3>
      <p>Tajribali mentorlar bilan 1:1 sessiyalar.</p>
      <span class="link">Ochish <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 6h10M7 2l4 4-4 4"/></svg></span>
    </a>

    {{-- 5. Farm --}}
    <a href="/farm" class="mod-card">
      <div class="icon">
        <svg width="22" height="22" fill="none" stroke="#f472b6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
      </div>
      <h3>Qishloq xo'jaligi</h3>
      <p>Fermer mahsulotlari, agronomiya maslahatlari.</p>
      <span class="link">Ochish <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 6h10M7 2l4 4-4 4"/></svg></span>
    </a>

    {{-- 6. Startup --}}
    <a href="/startup" class="mod-card">
      <div class="icon">
        <svg width="22" height="22" fill="none" stroke="#38bdf8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 1 14 8 22 9 16 14 18 22 11 18 4 22 6 14 0 9 8 8"/></svg>
      </div>
      <h3>Startup</h3>
      <p>Startup inkubator, investorlar va hackathonlar.</p>
      <span class="link">Ochish <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 6h10M7 2l4 4-4 4"/></svg></span>
    </a>

    {{-- 7. Volunteer --}}
    <a href="/volunteer" class="mod-card">
      <div class="icon">
        <svg width="22" height="22" fill="none" stroke="#4ade80" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
      </div>
      <h3>Volontyorlik</h3>
      <p>Ko'ngillilik faoliyati va ijtimoiy yordam.</p>
      <span class="link">Ochish <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 6h10M7 2l4 4-4 4"/></svg></span>
    </a>

    {{-- 8. Events --}}
    <a href="/events" class="mod-card">
      <div class="icon">
        <svg width="22" height="22" fill="none" stroke="#fbbf24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="16" height="16" rx="2"/><line x1="3" y1="9" x2="19" y2="9"/><line x1="8" y1="2" x2="8" y2="4"/><line x1="14" y1="2" x2="14" y2="4"/></svg>
      </div>
      <h3>Tadbirlar</h3>
      <p>Hackathonlar, vebinarlar va meetuplar.</p>
      <span class="link">Ochish <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 6h10M7 2l4 4-4 4"/></svg></span>
    </a>

    {{-- 9. Challenges --}}
    <a href="/challenges" class="mod-card">
      <div class="icon">
        <svg width="22" height="22" fill="none" stroke="#fca5a5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9V2h10v7"/><path d="M3 9h16v2c0 5-3 8-8 10-5-2-8-5-8-10V9z"/></svg>
      </div>
      <h3>Musobaqalar</h3>
      <p>Coding, dizayn va biznes tanlovlari.</p>
      <span class="link">Ochish <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 6h10M7 2l4 4-4 4"/></svg></span>
    </a>

    {{-- 10. Psychology --}}
    <a href="/psychology" class="mod-card">
      <div class="icon">
        <svg width="22" height="22" fill="none" stroke="#f472b6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="9"/><path d="M8 14s1.5 2 3 2 3-2 3-2"/><line x1="8" y1="8" x2="8" y2="8"/><line x1="14" y1="8" x2="14" y2="8"/></svg>
      </div>
      <h3>Psixologiya</h3>
      <p>Ruhiy salomatlik va anonim yordam.</p>
      <span class="link">Ochish <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 6h10M7 2l4 4-4 4"/></svg></span>
    </a>

    {{-- 11. GreenCoin --}}
    <a href="/greencoin" class="mod-card">
      <div class="icon">
        <svg width="22" height="22" fill="none" stroke="#22c55e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="9"/><path d="M11 7v8M8 10h6M8 12h6"/></svg>
      </div>
      <h3>GreenCoin</h3>
      <p>Virtual valyuta — ishlash va sarflash.</p>
      <span class="link">Ochish <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 6h10M7 2l4 4-4 4"/></svg></span>
    </a>

    {{-- 12. Daily Tasks --}}
    <a href="/daily-tasks" class="mod-card">
      <div class="icon">
        <svg width="22" height="22" fill="none" stroke="#60a5fa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
      </div>
      <h3>Kundalik vazifalar</h3>
      <p>Har kunlik vazifalar va GreenCoin mukofotlar.</p>
      <span class="link">Ochish <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 6h10M7 2l4 4-4 4"/></svg></span>
    </a>

    {{-- 13. Habits --}}
    <a href="/habits" class="mod-card">
      <div class="icon">
        <svg width="22" height="22" fill="none" stroke="#a78bfa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 20V10"/><path d="M12 20V4"/><path d="M6 20v-6"/></svg>
      </div>
      <h3>Odatlar</h3>
      <p>Yaxshi odatlarni shakllantirish va kuzatish.</p>
      <span class="link">Ochish <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 6h10M7 2l4 4-4 4"/></svg></span>
    </a>

    {{-- 14. Mentorship --}}
    <a href="/mentorship" class="mod-card">
      <div class="icon">
        <svg width="22" height="22" fill="none" stroke="#38bdf8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="7" r="4"/><path d="M5.2 20c.6-3.4 3.1-6 5.8-6s5.2 2.6 5.8 6"/><path d="M17 10l2 2 4-4"/></svg>
      </div>
      <h3>Mentorlik tizimi</h3>
      <p>Mentor-shogird aloqasi va vazifalar tizimi.</p>
      <span class="link">Ochish <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 6h10M7 2l4 4-4 4"/></svg></span>
    </a>

    {{-- 15. News --}}
    <a href="/news" class="mod-card">
      <div class="icon">
        <svg width="22" height="22" fill="none" stroke="#fbbf24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"/><line x1="6" y1="8" x2="16" y2="8"/><line x1="6" y1="12" x2="16" y2="12"/><line x1="6" y1="16" x2="10" y2="16"/></svg>
      </div>
      <h3>Yangiliklar</h3>
      <p>Platforma va IT sohasidagi so'nggi yangiliklar.</p>
      <span class="link">Ochish <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 6h10M7 2l4 4-4 4"/></svg></span>
    </a>
  </div>
</section>
@endsection
