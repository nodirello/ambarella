@extends('layouts.app')
@section('title', 'Biz haqimizda — AMBARELLA')
@section('description', 'AMBARELLA platformasi haqida — missiya, vazifa, jamoa va texnologiyalar.')

@section('styles')
<style>
.about-hero{padding:64px 0 48px;text-align:center}
.about-hero h1{font-size:clamp(28px,5vw,42px);font-weight:800;color:#fff;margin-bottom:12px}
.about-hero p{color:var(--muted);font-size:16px;max-width:640px;margin:0 auto;line-height:1.8}
.about-badge{display:inline-flex;align-items:center;gap:6px;padding:6px 14px;border-radius:20px;font-size:12px;font-weight:600;background:rgba(37,99,235,.1);color:#60a5fa;margin-bottom:20px}
.about-mission{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:20px;margin:48px 0}
.about-mission-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:28px;text-align:center}
.about-mission-card .icon{width:56px;height:56px;border-radius:14px;display:flex;align-items:center;justify-content:center;margin:0 auto 16px}
.about-mission-card:nth-child(1) .icon{background:rgba(37,99,235,.12)}
.about-mission-card:nth-child(2) .icon{background:rgba(22,163,74,.12)}
.about-mission-card h3{font-size:18px;font-weight:700;color:#fff;margin-bottom:8px}
.about-mission-card p{font-size:14px;color:var(--muted);line-height:1.7}
.about-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:16px;margin:48px 0;text-align:center}
.about-stat{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:24px 16px}
.about-stat .num{font-size:28px;font-weight:800;color:#fff;margin-bottom:4px}
.about-stat .label{font-size:12px;color:var(--muted);font-weight:500}
.about-team{margin:64px 0;text-align:center}
.about-team h2{font-size:24px;font-weight:700;color:#fff;margin-bottom:12px}
.about-team>p{color:var(--muted);font-size:15px;margin-bottom:32px}
.about-team-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:32px;max-width:480px;margin:0 auto;display:flex;align-items:center;gap:20px}
.about-team-avatar{width:64px;height:64px;border-radius:16px;background:linear-gradient(135deg,var(--primary),#7c3aed);display:flex;align-items:center;justify-content:center;font-size:24px;font-weight:800;color:#fff;flex-shrink:0}
.about-team-info h4{font-size:16px;font-weight:700;color:#fff;margin-bottom:4px}
.about-team-info p{font-size:13px;color:var(--muted)}
.about-tech{margin:48px 0}
.about-tech h2{font-size:24px;font-weight:700;color:#fff;margin-bottom:24px;text-align:center}
.about-tech-grid{display:flex;flex-wrap:wrap;justify-content:center;gap:12px}
.about-tech-item{display:inline-flex;align-items:center;gap:8px;padding:10px 18px;background:var(--surface);border:1px solid var(--border);border-radius:10px;font-size:13px;font-weight:500;color:#94a3b8;transition:all .2s}
.about-tech-item:hover{border-color:var(--primary);color:#fff}
.about-values{margin:64px 0}
.about-values h2{font-size:24px;font-weight:700;color:#fff;margin-bottom:24px;text-align:center}
.about-values-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px}
.about-value{padding:20px;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);display:flex;gap:12px;align-items:flex-start}
.about-value .dot{width:8px;height:8px;border-radius:50%;margin-top:6px;flex-shrink:0}
.about-value:nth-child(1) .dot{background:var(--primary)}
.about-value:nth-child(2) .dot{background:var(--success)}
.about-value:nth-child(3) .dot{background:var(--warning)}
.about-value:nth-child(4) .dot{background:#a78bfa}
.about-value h4{font-size:14px;font-weight:600;color:#e2e8f0;margin-bottom:4px}
.about-value p{font-size:13px;color:var(--muted)}
</style>
@endsection

@section('content')
<section class="about-hero">
  <div class="container">
    <div class="about-badge">
      <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="7" cy="7" r="6"/><line x1="7" y1="4" x2="7" y2="7"/><line x1="7" y1="10" x2="7" y2="10"/></svg>
      Biz haqimizda
    </div>
    <h1>O'zbekiston yoshlarining kelajagi</h1>
    <p>AMBARELLA — O'zbekiston yoshlari uchun bandlik, ta'lim, ekologiya va shaxsiy rivojlanish platformasi. Biz har bir yoshga imkoniyat yaratamiz.</p>
  </div>
</section>

<section class="container">
  <div class="about-mission">
    <div class="about-mission-card">
      <div class="icon">
        <svg width="28" height="28" fill="none" stroke="#60a5fa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="14" cy="14" r="12"/><path d="M14 8v6l4 2"/></svg>
      </div>
      <h3>Missiyamiz</h3>
      <p>O'zbekiston yoshlariga zamonaviy texnologiyalar yordamida bilim olish, ish topish va jamiyatga hissa qo'shish imkoniyatini yaratish.</p>
    </div>
    <div class="about-mission-card">
      <div class="icon">
        <svg width="28" height="28" fill="none" stroke="#4ade80" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s4-8 12-8 12 8 12 8-4 8-12 8-12-8-12-8z"/><circle cx="14" cy="12" r="3"/></svg>
      </div>
      <h3>Vazifamiz</h3>
      <p>2030 yilgacha 1 million yoshga ta'sir ko'rsatish va ularning hayot sifatini yaxshilashga hissa qo'shish.</p>
    </div>
  </div>
</section>

<section class="container">
  <div class="about-stats">
    <div class="about-stat">
      <div class="num">15+</div>
      <div class="label">Modullar</div>
    </div>
    <div class="about-stat">
      <div class="num">5000+</div>
      <div class="label">Foydalanuvchilar</div>
    </div>
    <div class="about-stat">
      <div class="num">100+</div>
      <div class="label">Mentorlar</div>
    </div>
    <div class="about-stat">
      <div class="num">50+</div>
      <div class="label">Kurslar</div>
    </div>
    <div class="about-stat">
      <div class="num">10K+</div>
      <div class="label">GreenCoin</div>
    </div>
  </div>
</section>

<section class="container">
  <div class="about-values">
    <h2>Qadriyatlarimiz</h2>
    <div class="about-values-grid">
      <div class="about-value">
        <div class="dot"></div>
        <div>
          <h4>Innovatsiya</h4>
          <p>Eng zamonaviy texnologiyalardan foydalanish</p>
        </div>
      </div>
      <div class="about-value">
        <div class="dot"></div>
        <div>
          <h4>Ochiqlik</h4>
          <p>Shaffof va ochiq hamjamiyat qurish</p>
        </div>
      </div>
      <div class="about-value">
        <div class="dot"></div>
        <div>
          <h4>Barqarorlik</h4>
          <p>Ekologik mas'uliyat va yashil texnologiyalar</p>
        </div>
      </div>
      <div class="about-value">
        <div class="dot"></div>
        <div>
          <h4>Inklyuzivlik</h4>
          <p>Har bir yosh uchun teng imkoniyatlar</p>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="container">
  <div class="about-team">
    <h2>Jamoa</h2>
    <p>AMBARELLA platformasi SADAF DEV jamoasi tomonidan ishlab chiqilgan.</p>
    <div class="about-team-card">
      <div class="about-team-avatar">SD</div>
      <div class="about-team-info">
        <h4>SADAF DEV</h4>
        <p>Full-stack dasturchilar jamoasi. Laravel, Vue.js, AI va zamonaviy web texnologiyalar bo'yicha ixtisoslashgan.</p>
      </div>
    </div>
  </div>
</section>

<section class="container">
  <div class="about-tech">
    <h2>Texnologiyalar</h2>
    <div class="about-tech-grid">
      <div class="about-tech-item">
        <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="10" height="10" rx="2"/></svg>
        Laravel 11
      </div>
      <div class="about-tech-item">
        <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><polygon points="7 1 13 5 13 11 7 13 1 11 1 5"/></svg>
        PHP 8.3
      </div>
      <div class="about-tech-item">
        <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><circle cx="7" cy="7" r="5"/><path d="M7 4v3h3"/></svg>
        MySQL
      </div>
      <div class="about-tech-item">
        <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><polyline points="2 8 7 3 12 8"/><polyline points="2 12 7 7 12 12"/></svg>
        Blade Templates
      </div>
      <div class="about-tech-item">
        <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M7 1v12M1 7h12"/></svg>
        REST API
      </div>
      <div class="about-tech-item">
        <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><circle cx="7" cy="7" r="6"/><path d="M4 10c1-2 5-2 6 0"/><circle cx="5" cy="6" r="1"/><circle cx="9" cy="6" r="1"/></svg>
        Telegram Bot
      </div>
      <div class="about-tech-item">
        <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M13 7A6 6 0 0 0 1 7"/><path d="M1 7a6 6 0 0 0 12 0"/><circle cx="7" cy="7" r="2"/></svg>
        AI Integration
      </div>
    </div>
  </div>
</section>
@endsection
