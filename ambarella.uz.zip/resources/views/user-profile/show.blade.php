@extends('layouts.app')
@section('title', $user->name . ' | AMBARELLA')
@section('styles')
<style>
.profile-header{padding:40px 0;text-align:center}
.profile-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:40px;max-width:600px;margin:0 auto;position:relative;overflow:hidden}
.profile-card::before{content:'';position:absolute;top:0;left:0;right:0;height:80px;background:linear-gradient(135deg,rgba(37,99,235,.15),rgba(124,58,237,.15))}
.profile-avatar{width:80px;height:80px;border-radius:50%;background:linear-gradient(135deg,var(--primary),#7c3aed);display:flex;align-items:center;justify-content:center;font-size:28px;font-weight:800;color:#fff;margin:0 auto 16px;position:relative;z-index:1;border:3px solid var(--border)}
.profile-avatar img{width:100%;height:100%;border-radius:50%;object-fit:cover}
.profile-name{font-size:22px;font-weight:800;color:#fff;position:relative;z-index:1}
.profile-level{display:inline-flex;align-items:center;gap:6px;padding:4px 14px;border-radius:999px;font-size:12px;font-weight:700;margin-top:8px}
.profile-region{color:var(--muted);font-size:13px;margin-top:8px;display:flex;align-items:center;justify-content:center;gap:4px}
.profile-bio{color:#94a3b8;font-size:14px;margin-top:16px;line-height:1.6;padding:0 20px}
.profile-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:1px;background:var(--border);border-radius:12px;overflow:hidden;margin-top:24px}
.profile-stat{background:rgba(0,0,0,.2);padding:18px;text-align:center}
.profile-stat .num{font-size:22px;font-weight:800;color:#fff}
.profile-stat .label{font-size:11px;color:var(--muted);margin-top:2px;text-transform:uppercase;letter-spacing:.5px}
.profile-interests{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin-top:20px}
.interest-tag{background:rgba(37,99,235,.1);border:1px solid rgba(37,99,235,.2);color:#60a5fa;padding:5px 12px;border-radius:999px;font-size:12px;font-weight:500}
.profile-meta{display:flex;align-items:center;justify-content:center;gap:16px;margin-top:20px;padding-top:20px;border-top:1px solid var(--border)}
.profile-meta span{color:var(--muted);font-size:12px;display:flex;align-items:center;gap:4px}
@media(max-width:768px){.profile-card{padding:24px 16px}.profile-stats{grid-template-columns:1fr}}
</style>
@endsection
@section('content')
<section class="profile-header"><div class="container">
    <div class="profile-card">
        <div class="profile-avatar">
            @if($user->avatar)
                <img src="{{ $user->avatar }}" alt="{{ $user->name }}">
            @else
                {{ mb_substr($user->name, 0, 1) }}
            @endif
        </div>
        <div class="profile-name">{{ $user->name }}</div>
        <div class="profile-level" style="background:{{ $level['color'] }}20;color:{{ $level['color'] }}">
            ⭐ {{ $level['name'] }}
        </div>

        @if($user->region)
            <div class="profile-region">📍 {{ $user->region }}</div>
        @endif

        @if($user->bio)
            <p class="profile-bio">{{ $user->bio }}</p>
        @endif

        <div class="profile-stats">
            <div class="profile-stat">
                <div class="num" style="color:#4ade80">{{ number_format($user->greencoin_balance) }}</div>
                <div class="label">GreenCoin</div>
            </div>
            <div class="profile-stat">
                <div class="num" style="color:#60a5fa">{{ $achievementsCount }}</div>
                <div class="label">Yutuqlar</div>
            </div>
            <div class="profile-stat">
                <div class="num" style="color:#fbbf24">{{ $user->referral_count ?? 0 }}</div>
                <div class="label">Referallar</div>
            </div>
        </div>

        @if($user->interests && count($user->interests) > 0)
            <div class="profile-interests">
                @foreach($user->interests as $interest)
                    <span class="interest-tag">{{ $interest }}</span>
                @endforeach
            </div>
        @endif

        <div class="profile-meta">
            <span>📅 {{ $user->created_at->format('M Y') }} dan beri a'zo</span>
        </div>
    </div>
</div></section>
@endsection
