@extends('layouts.app')
@section('title', 'Qidiruv: ' . $q . ' | AMBARELLA')
@section('styles')
<style>
.page-hero{padding:56px 0 40px}
.page-hero h1{font-size:clamp(28px,4vw,38px);font-weight:800;color:#fff;margin-bottom:8px}
.page-hero p{color:var(--muted);font-size:15px;max-width:500px}
.search-box{display:flex;gap:10px;margin-top:24px;max-width:560px}
.search-box input{flex:1;padding:14px 18px;border:1px solid var(--border);border-radius:var(--radius);font-size:15px;font-family:inherit;background:var(--surface);color:#fff}
.search-box input::placeholder{color:#475569}
.results-section{margin-top:40px;margin-bottom:32px}
.results-section h2{font-size:18px;font-weight:700;color:#fff;margin-bottom:16px;display:flex;align-items:center;gap:10px}
.results-section h2 span{font-size:12px;padding:3px 10px;border-radius:99px;background:rgba(37,99,235,.1);color:#93c5fd;border:1px solid rgba(37,99,235,.2)}
.result-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:12px}
.result-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:18px;transition:all .3s;display:block}
.result-card:hover{border-color:rgba(37,99,235,.4);transform:translateY(-2px)}
.result-card h3{font-size:15px;font-weight:700;color:#fff;margin-bottom:4px}
.result-card p{font-size:13px;color:var(--muted)}
.empty-state{text-align:center;padding:64px 24px;color:var(--muted);font-size:15px}
@media(max-width:768px){.search-box{flex-direction:column}.result-grid{grid-template-columns:1fr}}
</style>
@endsection
@section('content')
<section class="page-hero"><div class="container">
  <h1>🔍 Qidiruv</h1>
  <p>Platforma bo'ylab ish, kurs, mentor, yangilik va mahsulotlarni qidiring</p>
  <form class="search-box" method="GET" action="/search">
    <input type="text" name="q" value="{{ $q }}" placeholder="Qidiruv so'zini kiriting..." autofocus>
    <button type="submit" class="btn btn-primary">Qidirish</button>
  </form>
</div></section>
<div class="container">
  @if(strlen($q) < 2 && strlen($q) > 0)
    <div class="empty-state">Kamida 2 ta belgi kiriting</div>
  @elseif(strlen($q) >= 2)
    @php
      $totalResults = $jobs->count() + $courses->count() + $mentors->count() + $news->count() + $products->count();
    @endphp

    @if($totalResults === 0)
      <div class="empty-state">
        <p>«{{ $q }}» bo'yicha hech narsa topilmadi</p>
        <p style="margin-top:8px;font-size:13px">Boshqa so'zlar bilan qidiring</p>
      </div>
    @else
      @if($jobs->count())
      <div class="results-section">
        <h2>Ish e'lonlari <span>{{ $jobs->count() }}</span></h2>
        <div class="result-grid">
          @foreach($jobs as $job)
          <a href="/jobs/{{ $job->id }}" class="result-card">
            <h3>{{ $job->title }}</h3>
            <p>{{ $job->company }} — {{ $job->location }}</p>
          </a>
          @endforeach
        </div>
      </div>
      @endif

      @if($courses->count())
      <div class="results-section">
        <h2>Kurslar <span>{{ $courses->count() }}</span></h2>
        <div class="result-grid">
          @foreach($courses as $course)
          <a href="/academy/{{ $course->id }}" class="result-card">
            <h3>{{ $course->title }}</h3>
            <p>{{ $course->instructor }} — {{ $course->level }}</p>
          </a>
          @endforeach
        </div>
      </div>
      @endif

      @if($mentors->count())
      <div class="results-section">
        <h2>Mentorlar <span>{{ $mentors->count() }}</span></h2>
        <div class="result-grid">
          @foreach($mentors as $mentor)
          <a href="/mentor/{{ $mentor->id }}" class="result-card">
            <h3>{{ $mentor->name }}</h3>
            <p>{{ $mentor->role }}</p>
          </a>
          @endforeach
        </div>
      </div>
      @endif

      @if($news->count())
      <div class="results-section">
        <h2>Yangiliklar <span>{{ $news->count() }}</span></h2>
        <div class="result-grid">
          @foreach($news as $item)
          <a href="/news/{{ $item->id }}" class="result-card">
            <h3>{{ $item->title }}</h3>
            <p>{{ $item->category }} — {{ $item->author }}</p>
          </a>
          @endforeach
        </div>
      </div>
      @endif

      @if($products->count())
      <div class="results-section">
        <h2>Mahsulotlar <span>{{ $products->count() }}</span></h2>
        <div class="result-grid">
          @foreach($products as $product)
          <a href="/farm/{{ $product->id }}" class="result-card">
            <h3>{{ $product->name }}</h3>
            <p>{{ $product->region }} — {{ number_format($product->price) }} so'm</p>
          </a>
          @endforeach
        </div>
      </div>
      @endif
    @endif
  @else
    <div class="empty-state">Qidiruv so'zini kiriting</div>
  @endif
</div>
@endsection
