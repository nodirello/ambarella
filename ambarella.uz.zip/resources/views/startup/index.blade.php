@extends('layouts.app')
@section('title', 'Startup Inkubator — AMBARELLA')
@section('description', 'O\'zbekiston yoshlari uchun startup inkubator — biznes-reja, investorlar, mentorlar va hackathonlar.')

@section('styles')
<style>
.su-hero{padding:64px 0 48px;text-align:center}
.su-hero h1{font-size:clamp(28px,5vw,42px);font-weight:800;color:#fff;margin-bottom:12px}
.su-hero p{color:var(--muted);font-size:16px;max-width:620px;margin:0 auto;line-height:1.8}
.su-badge{display:inline-flex;align-items:center;gap:6px;padding:6px 14px;border-radius:20px;font-size:12px;font-weight:600;background:rgba(124,58,237,.1);color:#a78bfa;margin-bottom:20px}
.su-features{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:20px;margin:48px 0}
.su-feature{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:28px;transition:all .2s}
.su-feature:hover{border-color:rgba(124,58,237,.3);transform:translateY(-2px)}
.su-feature .icon{width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center;margin-bottom:16px}
.su-feature:nth-child(1) .icon{background:rgba(37,99,235,.12)}
.su-feature:nth-child(2) .icon{background:rgba(22,163,74,.12)}
.su-feature:nth-child(3) .icon{background:rgba(245,158,11,.12)}
.su-feature:nth-child(4) .icon{background:rgba(124,58,237,.12)}
.su-feature h3{font-size:16px;font-weight:700;color:#fff;margin-bottom:8px}
.su-feature p{font-size:14px;color:var(--muted);line-height:1.7}
.su-process{margin:64px 0;text-align:center}
.su-process h2{font-size:24px;font-weight:700;color:#fff;margin-bottom:32px}
.su-steps{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:24px}
.su-step{position:relative;padding:24px}
.su-step .num{width:36px;height:36px;border-radius:50%;background:var(--primary);color:#fff;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:700;margin:0 auto 12px}
.su-step h4{font-size:14px;font-weight:600;color:#fff;margin-bottom:6px}
.su-step p{font-size:13px;color:var(--muted)}
.su-cta{text-align:center;padding:64px 0;margin:32px 0;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius)}
.su-cta h2{font-size:clamp(20px,4vw,28px);font-weight:800;color:#fff;margin-bottom:12px}
.su-cta p{color:var(--muted);font-size:15px;margin-bottom:24px;max-width:480px;margin-left:auto;margin-right:auto}
</style>
@endsection

@section('content')
<section class="su-hero">
  <div class="container">
    <div class="su-badge">
      <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polygon points="7 1 9 5 13 5.5 10 8.5 11 13 7 11 3 13 4 8.5 1 5.5 5 5"/></svg>
      Startup Inkubator
    </div>
    <h1>G'oyangizni biznesga aylantiring</h1>
    <p>O'zbekiston yoshlari uchun maxsus startup inkubator dasturi. G'oyadan tayyor mahsulotgacha — biz yoningizda.</p>
  </div>
</section>

<section class="container">
  <div class="su-features">
    <div class="su-feature">
      <div class="icon">
        <svg width="24" height="24" fill="none" stroke="#2563eb" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
      </div>
      <h3>Biznes-reja</h3>
      <p>Professional biznes-reja tuzishni o'rganing. Shablonlar, AI yordamchi va ekspert maslahatlar bilan.</p>
    </div>
    <div class="su-feature">
      <div class="icon">
        <svg width="24" height="24" fill="none" stroke="#16a34a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
      </div>
      <h3>Investorlar</h3>
      <p>Mahalliy va xalqaro investorlar bilan bog'laning. Pitching mahoratini oshiring va moliya jalb qiling.</p>
    </div>
    <div class="su-feature">
      <div class="icon">
        <svg width="24" height="24" fill="none" stroke="#f59e0b" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
      </div>
      <h3>Mentorlar</h3>
      <p>Tajribali biznes mentorlar sizning startupingizni rivojlantirishda yordam beradi. 1:1 sessiyalar.</p>
    </div>
    <div class="su-feature">
      <div class="icon">
        <svg width="24" height="24" fill="none" stroke="#a78bfa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>
      </div>
      <h3>Hackathonlar</h3>
      <p>Muntazam hackathonlar va musobaqalarda qatnashing. G'oyangizni 48 soat ichida MVP qiling.</p>
    </div>
  </div>
</section>

<section class="container">
  <div class="su-process">
    <h2>Qanday ishlaydi?</h2>
    <div class="su-steps">
      <div class="su-step">
        <div class="num">1</div>
        <h4>G'oyani kiriting</h4>
        <p>Startup g'oyangizni tasvirlab bering va ariza topshiring</p>
      </div>
      <div class="su-step">
        <div class="num">2</div>
        <h4>Baholash</h4>
        <p>Ekspertlar g'oyangizni baholaydi va qaytaloq fikr beradi</p>
      </div>
      <div class="su-step">
        <div class="num">3</div>
        <h4>Inkubatsiya</h4>
        <p>Mentorlik, resurslar va tarmoqdan foydalaning</p>
      </div>
      <div class="su-step">
        <div class="num">4</div>
        <h4>Demo Day</h4>
        <p>Investorlar oldida pitching qiling va moliya jalb qiling</p>
      </div>
    </div>
  </div>
</section>

<section class="container">
  <div class="su-cta">
    <h2>Startupingizni boshlashga tayyormisiz?</h2>
    <p>Hoziroq ariza topshiring va O'zbekistonning eng yirik startup hamjamiyatiga qo'shiling.</p>
    <a href="/register" class="btn btn-primary">Ariza topshirish</a>
  </div>
</section>
@endsection
