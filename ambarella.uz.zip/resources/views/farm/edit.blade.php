@extends('layouts.app')
@section('title', 'Mahsulot tahrirlash | AMBARELLA')
@section('styles')
<style>
.form-page{padding:48px 0;max-width:560px;margin:0 auto}
.form-page h1{font-size:24px;font-weight:800;color:#fff;margin-bottom:32px}
.form-group{margin-bottom:20px}
.form-group label{display:block;font-size:13px;font-weight:600;color:#94a3b8;margin-bottom:6px}
.form-group input,.form-group select,.form-group textarea{width:100%;padding:12px 16px;border-radius:var(--radius);border:1px solid var(--border);background:var(--surface);color:#fff;font-size:14px}
.form-group textarea{resize:vertical;min-height:100px}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.form-actions{display:flex;gap:10px;margin-top:24px}
</style>
@endsection
@section('content')
<div class="container">
  <div class="form-page">
    <h1>Mahsulotni tahrirlash</h1>
    <form action="/farm/{{ $product->id }}" method="POST">
      @csrf @method('PUT')
      <div class="form-group">
        <label>Mahsulot nomi</label>
        <input type="text" name="name" required maxlength="255" value="{{ $product->name }}">
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Kategoriya</label>
          <select name="category" required>
            @foreach(['Sabzavotlar','Mevalar','Don mahsulotlari','Sut mahsulotlari','Go\'sht','Boshqa'] as $cat)
            <option value="{{ $cat }}" {{ $product->category == $cat ? 'selected' : '' }}>{{ $cat }}</option>
            @endforeach
          </select>
        </div>
        <div class="form-group">
          <label>Hudud</label>
          <select name="region" required>
            @foreach(['Toshkent','Samarqand','Buxoro','Farg\'ona','Andijon','Namangan','Qashqadaryo','Surxondaryo','Xorazm','Navoiy','Jizzax','Sirdaryo','Qoraqalpog\'iston'] as $reg)
            <option value="{{ $reg }}" {{ $product->region == $reg ? 'selected' : '' }}>{{ $reg }}</option>
            @endforeach
          </select>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Narxi (so'm)</label>
          <input type="number" name="price" required min="100" value="{{ $product->price }}">
        </div>
        <div class="form-group">
          <label>O'lchov birligi</label>
          <select name="unit" required>
            @foreach(['kg','dona','litr','tonna'] as $u)
            <option value="{{ $u }}" {{ $product->unit == $u ? 'selected' : '' }}>{{ $u }}</option>
            @endforeach
          </select>
        </div>
      </div>
      <div class="form-group">
        <label>Tavsif</label>
        <textarea name="description" maxlength="1000">{{ $product->description }}</textarea>
      </div>
      <div class="form-actions">
        <button type="submit" class="btn btn-success">Saqlash</button>
        <a href="/farm/my-products" class="btn btn-outline">Bekor qilish</a>
      </div>
    </form>
  </div>
</div>
@endsection
