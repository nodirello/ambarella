@extends('layouts.app')
@section('title', $product->name . ' | AMBARELLA')
@section('styles')
<style>
.product-detail{padding:48px 0}
.back-link{display:inline-flex;align-items:center;gap:6px;color:var(--muted);font-size:13px;margin-bottom:24px;transition:color .2s}
.back-link:hover{color:#fff}
.product-main{display:grid;grid-template-columns:1fr 1fr;gap:40px;align-items:start}
.product-info h1{font-size:28px;font-weight:800;color:#fff;margin-bottom:12px}
.product-info .price{font-size:32px;font-weight:800;color:#4ade80;margin-bottom:16px}
.detail-row{display:flex;justify-content:space-between;padding:12px 0;border-bottom:1px solid var(--border);font-size:14px}
.detail-row span:first-child{color:var(--muted)}
.detail-row span:last-child{color:#fff;font-weight:500}
.seller-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:20px;margin-top:24px}
.seller-card h4{font-size:14px;font-weight:600;color:#fff;margin-bottom:8px}
.similar-section{margin-top:48px;padding-top:32px;border-top:1px solid var(--border)}
.similar-section h3{font-size:18px;font-weight:700;color:#fff;margin-bottom:16px}
.similar-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px}
.similar-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:18px;transition:all .2s}
.similar-card:hover{border-color:rgba(22,163,74,.3)}
@media(max-width:768px){.product-main{grid-template-columns:1fr}}
</style>
@endsection
@section('content')
<div class="container">
  <div class="product-detail">
    <a href="/farm" class="back-link">← Mahsulotlarga qaytish</a>
    <div class="product-main">
      <div class="product-info">
        <span style="font-size:12px;font-weight:600;color:var(--success);text-transform:uppercase">{{ $product->category }}</span>
        <h1>{{ $product->name }}</h1>
        <div class="price">{{ number_format($product->price) }} so'm/{{ $product->unit }}</div>
        @if($product->description)
          <p style="color:#94a3b8;font-size:15px;line-height:1.7;margin-bottom:24px">{{ $product->description }}</p>
        @endif
        <div class="detail-row"><span>Hudud</span><span>{{ $product->region }}</span></div>
        <div class="detail-row"><span>Kategoriya</span><span>{{ $product->category }}</span></div>
        <div class="detail-row"><span>O'lchov birligi</span><span>{{ $product->unit }}</span></div>
        <div class="detail-row"><span>Joylangan sana</span><span>{{ $product->created_at->format('d M Y') }}</span></div>
      </div>
      <div>
        <div class="seller-card">
          <h4>Sotuvchi</h4>
          <p style="color:#fff;font-size:15px;font-weight:600">{{ $product->user->name ?? 'Fermer' }}</p>
          <p style="color:var(--muted);font-size:13px;margin-top:4px">Ro'yxatga olingan: {{ $product->user->created_at->format('M Y') ?? '' }}</p>
        </div>
      </div>
    </div>

    @if($similar->count() > 0)
    <div class="similar-section">
      <h3>O'xshash mahsulotlar</h3>
      <div class="similar-grid">
        @foreach($similar as $item)
        <a href="/farm/{{ $item->id }}" class="similar-card">
          <span style="font-size:11px;color:var(--success)">{{ $item->category }}</span>
          <h4 style="font-size:14px;font-weight:600;color:#fff;margin:4px 0">{{ $item->name }}</h4>
          <span style="font-size:15px;font-weight:700;color:#4ade80">{{ number_format($item->price) }} so'm</span>
        </a>
        @endforeach
      </div>
    </div>
    @endif
  </div>
</div>
@endsection
