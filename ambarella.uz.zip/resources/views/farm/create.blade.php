@extends('layouts.app')
@section('title', 'Mahsulot qo\'shish | AMBARELLA')
@section('styles')
<style>
.form-page{padding:48px 0;max-width:560px;margin:0 auto}
.form-page h1{font-size:24px;font-weight:800;color:#fff;margin-bottom:8px}
.form-page>p{color:var(--muted);font-size:14px;margin-bottom:32px}
.form-group{margin-bottom:20px}
.form-group label{display:block;font-size:13px;font-weight:600;color:#94a3b8;margin-bottom:6px}
.form-group input,.form-group select,.form-group textarea{width:100%;padding:12px 16px;border-radius:var(--radius);border:1px solid var(--border);background:var(--surface);color:#fff;font-size:14px}
.form-group textarea{resize:vertical;min-height:100px}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.form-actions{display:flex;gap:10px;margin-top:24px}
</style>
@endsection
@section('content')
<div class="container">
  <div class="form-page">
    <h1>Mahsulot qo'shish</h1>
    <p>Fermer mahsulotingizni platformaga joylashtiring</p>
    <form action="/farm" method="POST">
      @csrf
      <div class="form-group">
        <label>Mahsulot nomi</label>
        <input type="text" name="name" placeholder="Masalan: Yangi pomidor" required maxlength="255" value="{{ old('name') }}">
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Kategoriya</label>
          <select name="category" required>
            <option value="">Tanlang</option>
            <option value="Sabzavotlar">Sabzavotlar</option>
            <option value="Mevalar">Mevalar</option>
            <option value="Don mahsulotlari">Don mahsulotlari</option>
            <option value="Sut mahsulotlari">Sut mahsulotlari</option>
            <option value="Go'sht">Go'sht</option>
            <option value="Boshqa">Boshqa</option>
          </select>
        </div>
        <div class="form-group">
          <label>Hudud</label>
          <select name="region" required>
            <option value="">Tanlang</option>
            <option value="Toshkent">Toshkent</option>
            <option value="Samarqand">Samarqand</option>
            <option value="Buxoro">Buxoro</option>
            <option value="Farg'ona">Farg'ona</option>
            <option value="Andijon">Andijon</option>
            <option value="Namangan">Namangan</option>
            <option value="Qashqadaryo">Qashqadaryo</option>
            <option value="Surxondaryo">Surxondaryo</option>
            <option value="Xorazm">Xorazm</option>
            <option value="Navoiy">Navoiy</option>
            <option value="Jizzax">Jizzax</option>
            <option value="Sirdaryo">Sirdaryo</option>
            <option value="Qoraqalpog'iston">Qoraqalpog'iston</option>
          </select>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Narxi (so'm)</label>
          <input type="number" name="price" placeholder="5000" required min="100" value="{{ old('price') }}">
        </div>
        <div class="form-group">
          <label>O'lchov birligi</label>
          <select name="unit" required>
            <option value="kg">kg</option>
            <option value="dona">dona</option>
            <option value="litr">litr</option>
            <option value="tonna">tonna</option>
          </select>
        </div>
      </div>
      <div class="form-group">
        <label>Tavsif</label>
        <textarea name="description" placeholder="Mahsulot haqida qo'shimcha ma'lumot..." maxlength="1000">{{ old('description') }}</textarea>
      </div>
      <div class="form-actions">
        <button type="submit" class="btn btn-success">Joylash</button>
        <a href="/farm" class="btn btn-outline">Bekor qilish</a>
      </div>
    </form>
  </div>
</div>
@endsection
