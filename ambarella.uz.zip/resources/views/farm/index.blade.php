@extends('layouts.app')
@section('title', 'Qishloq mahsulotlari | AMBARELLA')
@section('styles')
<style>
.page-hero{padding:48px 0}
.page-hero h1{font-size:clamp(28px,4vw,36px);font-weight:800;color:#fff;margin-bottom:8px}
.page-hero p{color:var(--muted);font-size:15px;max-width:500px}
.filters{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:24px;align-items:center}
.filters select,.filters input{padding:10px 14px;border-radius:var(--radius);border:1px solid var(--border);background:var(--surface);color:#fff;font-size:13px}
.products-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(270px,1fr));gap:16px}
.product-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:22px;transition:all .2s}
.product-card:hover{border-color:rgba(22,163,74,.3);transform:translateY(-2px)}
.product-category{font-size:11px;font-weight:600;color:var(--success);text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px}
.product-card h3{font-size:16px;font-weight:700;color:#fff;margin-bottom:6px}
.product-card p{font-size:13px;color:var(--muted);margin-bottom:12px}
.product-price{font-size:18px;font-weight:800;color:#4ade80;margin-bottom:4px}
.product-meta{display:flex;justify-content:space-between;align-items:center;font-size:12px;color:var(--muted);margin-top:12px;padding-top:12px;border-top:1px solid var(--border)}
.hero-actions{display:flex;gap:10px;margin-top:16px}
.empty-state{text-align:center;padding:48px;color:var(--muted);font-size:14px;grid-column:1/-1}
</style>
@endsection
@section('content')
<section class="page-hero"><div class="container">
  <h1>Qishloq mahsulotlari</h1>
  <p>Fermerlardan to'g'ridan-to'g'ri yangi mahsulotlar sotib oling</p>
  <div class="hero-actions">
    @auth
      <a href="/farm/create" class="btn btn-success">+ Mahsulot qo'shish</a>
      <a href="/farm/my-products" class="btn btn-outline">Mening mahsulotlarim</a>
    @else
      <a href="/login" class="btn btn-primary">Kirish</a>
    @endauth
  </div>
</div></section>
<div class="container">
  <form class="filters" method="GET" action="/farm">
    <input type="text" name="search" placeholder="Qidirish..." value="{{ request('search') }}">
    <select name="category" onchange="this.form.submit()">
      <option value="">Barcha kategoriyalar</option>
      @foreach($categories as $cat)<option value="{{ $cat }}" {{ request('category') == $cat ? 'selected' : '' }}>{{ $cat }}</option>@endforeach
    </select>
    <select name="region" onchange="this.form.submit()">
      <option value="">Barcha hududlar</option>
      @foreach($regions as $reg)<option value="{{ $reg }}" {{ request('region') == $reg ? 'selected' : '' }}>{{ $reg }}</option>@endforeach
    </select>
    <button type="submit" class="btn btn-outline" style="padding:10px 16px;font-size:13px">Filtr</button>
  </form>

  <div class="products-grid">
    @forelse($products as $product)
    <a href="/farm/{{ $product->id }}" class="product-card">
      <span class="product-category">{{ $product->category }}</span>
      <h3>{{ $product->name }}</h3>
      <p>{{ Str::limit($product->description, 80) }}</p>
      <div class="product-price">{{ number_format($product->price) }} so'm/{{ $product->unit }}</div>
      <div class="product-meta">
        <span>📍 {{ $product->region }}</span>
        <span>{{ $product->user->name ?? 'Fermer' }}</span>
      </div>
    </a>
    @empty
    <div class="empty-state">Hozircha mahsulotlar yo'q.</div>
    @endforelse
  </div>

  <div style="margin-top:24px">{{ $products->links() }}</div>
</div>
@endsection
