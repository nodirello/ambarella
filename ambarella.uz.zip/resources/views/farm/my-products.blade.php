@extends('layouts.app')
@section('title', 'Mening mahsulotlarim | AMBARELLA')
@section('styles')
<style>
.page-hero{padding:48px 0}
.page-hero h1{font-size:24px;font-weight:800;color:#fff;margin-bottom:8px}
.products-table{width:100%;border-collapse:collapse;margin-top:24px}
.products-table th{text-align:left;padding:12px 14px;font-size:12px;text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid var(--border)}
.products-table td{padding:14px;border-bottom:1px solid var(--border);font-size:14px}
.active-badge{padding:3px 8px;border-radius:999px;font-size:11px;font-weight:600}
.active-badge.yes{background:rgba(22,163,74,.1);color:#4ade80}
.active-badge.no{background:rgba(220,38,38,.1);color:#fca5a5}
.actions-cell{display:flex;gap:6px}
.empty-state{text-align:center;padding:48px;color:var(--muted);font-size:14px}
</style>
@endsection
@section('content')
<section class="page-hero"><div class="container">
  <div style="display:flex;justify-content:space-between;align-items:center">
    <h1>Mening mahsulotlarim</h1>
    <a href="/farm/create" class="btn btn-success">+ Yangi mahsulot</a>
  </div>
</div></section>
<div class="container">
  @if($products->count() > 0)
  <table class="products-table">
    <thead><tr><th>Nomi</th><th>Kategoriya</th><th>Narxi</th><th>Hudud</th><th>Holat</th><th>Amallar</th></tr></thead>
    <tbody>
      @foreach($products as $product)
      <tr>
        <td style="font-weight:600;color:#fff">{{ $product->name }}</td>
        <td>{{ $product->category }}</td>
        <td style="color:#4ade80;font-weight:600">{{ number_format($product->price) }} so'm/{{ $product->unit }}</td>
        <td>{{ $product->region }}</td>
        <td><span class="active-badge {{ $product->is_active ? 'yes' : 'no' }}">{{ $product->is_active ? 'Faol' : 'Nofaol' }}</span></td>
        <td>
          <div class="actions-cell">
            <a href="/farm/{{ $product->id }}/edit" class="btn btn-outline" style="padding:6px 10px;font-size:11px">Tahrirlash</a>
            <form action="/farm/{{ $product->id }}/toggle" method="POST">@csrf<button class="btn btn-outline" style="padding:6px 10px;font-size:11px">{{ $product->is_active ? 'O\'chirish' : 'Yoqish' }}</button></form>
            <form action="/farm/{{ $product->id }}" method="POST" onsubmit="return confirm('Rostan o\'chirmoqchimisiz?')">@csrf @method('DELETE')<button class="btn" style="padding:6px 10px;font-size:11px;color:var(--danger)">🗑️</button></form>
          </div>
        </td>
      </tr>
      @endforeach
    </tbody>
  </table>
  @else
  <div class="empty-state">Hali mahsulot qo'shmagansiz. <a href="/farm/create" style="color:var(--primary)">Birinchi mahsulotingizni qo'shing!</a></div>
  @endif
</div>
@endsection
