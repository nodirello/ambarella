@extends('layouts.app')
@section('title', 'Volontyorlik — AMBARELLA')
@section('description', 'Volontyorlik faoliyati — ta\'lim, ekologiya, ijtimoiy va sport sohalarida ko\'ngillilik.')

@section('styles')
<style>
.vol-hero{padding:64px 0 48px;text-align:center}
.vol-hero h1{font-size:clamp(28px,5vw,42px);font-weight:800;color:#fff;margin-bottom:12px}
.vol-hero p{color:var(--muted);font-size:16px;max-width:600px;margin:0 auto;line-height:1.8}
.vol-badge{display:inline-flex;align-items:center;gap:6px;padding:6px 14px;border-radius:20px;font-size:12px;font-weight:600;background:rgba(22,163,74,.1);color:#4ade80;margin-bottom:20px}
.vol-categories{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:20px;margin:48px 0}
.vol-cat{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:28px;transition:all .2s;position:relative;overflow:hidden}
.vol-cat:hover{border-color:rgba(22,163,74,.3);transform:translateY(-2px)}
.vol-cat::before{content:'';position:absolute;top:0;left:0;width:4px;height:100%;border-radius:4px 0 0 4px}
.vol-cat:nth-child(1)::before{background:var(--primary)}
.vol-cat:nth-child(2)::before{background:var(--success)}
.vol-cat:nth-child(3)::before{background:var(--warning)}
.vol-cat:nth-child(4)::before{background:#a78bfa}
.vol-cat .icon{width:44px;height:44px;border-radius:10px;display:flex;align-items:center;justify-content:center;margin-bottom:14px}
.vol-cat:nth-child(1) .icon{background:rgba(37,99,235,.12)}
.vol-cat:nth-child(2) .icon{background:rgba(22,163,74,.12)}
.vol-cat:nth-child(3) .icon{background:rgba(245,158,11,.12)}
.vol-cat:nth-child(4) .icon{background:rgba(167,139,250,.12)}
.vol-cat h3{font-size:16px;font-weight:700;color:#fff;margin-bottom:8px}
.vol-cat p{font-size:14px;color:var(--muted);line-height:1.7}
.vol-benefits{margin:64px 0}
.vol-benefits h2{font-size:24px;font-weight:700;color:#fff;margin-bottom:32px;text-align:center}
.vol-benefits-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:20px}
.vol-benefit{display:flex;gap:14px;padding:20px;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius)}
.vol-benefit .check{width:32px;height:32px;border-radius:8px;background:rgba(22,163,74,.1);display:flex;align-items:center;justify-content:center;flex-shrink:0}
.vol-benefit h4{font-size:14px;font-weight:600;color:#fff;margin-bottom:4px}
.vol-benefit p{font-size:13px;color:var(--muted)}
.vol-cta{text-align:center;padding:64px 24px;margin:48px 0;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius)}
.vol-cta h2{font-size:clamp(20px,4vw,28px);font-weight:800;color:#fff;margin-bottom:12px}
.vol-cta p{color:var(--muted);font-size:15px;margin-bottom:24px;max-width:480px;margin-left:auto;margin-right:auto}
</style>
@endsection

@section('content')
<section class="vol-hero">
  <div class="container">
    <div class="vol-badge">
      <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 7c0 4-5 7-5 7S2 11 2 7a5 5 0 0 1 10 0z"/><circle cx="7" cy="7" r="2"/></svg>
      Volontyorlik
    </div>
    <h1>Yaxshilik qilish — bu kuch</h1>
    <p>Ko'ngillilik faoliyati orqali jamiyatga hissa qo'shing, yangi ko'nikmalar oling va GreenCoin ishlang.</p>
  </div>
</section>

<section class="container">
  <div class="vol-categories">
    <div class="vol-cat">
      <div class="icon">
        <svg width="22" height="22" fill="none" stroke="#2563eb" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>
      </div>
      <h3>Ta'lim</h3>
      <p>Bolalar va o'spirinlarga bepul dars berish, kitob tarqatish, ta'lim loyihalarida ishtirok etish.</p>
    </div>
    <div class="vol-cat">
      <div class="icon">
        <svg width="22" height="22" fill="none" stroke="#16a34a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22c5.5-3 9-7.5 9-12a9 9 0 0 0-18 0c0 4.5 3.5 9 9 12z"/><path d="M12 8v4"/><circle cx="12" cy="8" r="1"/></svg>
      </div>
      <h3>Ekologiya</h3>
      <p>Daraxt ekish, chiqindilarni yig'ish, ekologik ong-la'lni targ'ib qilish va tabiatni asrash.</p>
    </div>
    <div class="vol-cat">
      <div class="icon">
        <svg width="22" height="22" fill="none" stroke="#f59e0b" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
      </div>
      <h3>Ijtimoiy</h3>
      <p>Qarilar uyiga tashrif, nogironlik imkoniyati cheklangan shaxslarga yordam, xayriya tadbirlari.</p>
    </div>
    <div class="vol-cat">
      <div class="icon">
        <svg width="22" height="22" fill="none" stroke="#a78bfa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="3"/><path d="M11 1v3M11 18v3M4.2 4.2l2.1 2.1M15.7 15.7l2.1 2.1M1 11h3M18 11h3M4.2 17.8l2.1-2.1M15.7 6.3l2.1-2.1"/></svg>
      </div>
      <h3>Sport</h3>
      <p>Sport tadbirlarni tashkil etish, bolalar sportini qo'llab-quvvatlash, sog'lom turmush targ'iboti.</p>
    </div>
  </div>
</section>

<section class="container">
  <div class="vol-benefits">
    <h2>Volontyorlik nima beradi?</h2>
    <div class="vol-benefits-grid">
      <div class="vol-benefit">
        <div class="check">
          <svg width="16" height="16" fill="none" stroke="#4ade80" stroke-width="2" stroke-linecap="round"><polyline points="1 9 5 13 15 3"/></svg>
        </div>
        <div>
          <h4>GreenCoin mukofotlar</h4>
          <p>Har bir volontyorlik faoliyati uchun GreenCoin ishlaysiz</p>
        </div>
      </div>
      <div class="vol-benefit">
        <div class="check">
          <svg width="16" height="16" fill="none" stroke="#4ade80" stroke-width="2" stroke-linecap="round"><polyline points="1 9 5 13 15 3"/></svg>
        </div>
        <div>
          <h4>Yangi ko'nikmalar</h4>
          <p>Jamoaviy ish, muloqot va liderlik sifatlarini rivojlantiring</p>
        </div>
      </div>
      <div class="vol-benefit">
        <div class="check">
          <svg width="16" height="16" fill="none" stroke="#4ade80" stroke-width="2" stroke-linecap="round"><polyline points="1 9 5 13 15 3"/></svg>
        </div>
        <div>
          <h4>Sertifikatlar</h4>
          <p>Faoliyatingiz uchun rasmiy sertifikat va tavsifnomalar oling</p>
        </div>
      </div>
      <div class="vol-benefit">
        <div class="check">
          <svg width="16" height="16" fill="none" stroke="#4ade80" stroke-width="2" stroke-linecap="round"><polyline points="1 9 5 13 15 3"/></svg>
        </div>
        <div>
          <h4>Networking</h4>
          <p>O'xshash fikrli yoshlar bilan tanishing va hamkorlik qiling</p>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="container">
  <div class="vol-cta">
    <h2>Ko'ngilli bo'lishga tayyormisiz?</h2>
    <p>Ro'yxatdan o'ting va o'zingizga mos volontyorlik yo'nalishini tanlang.</p>
    <a href="/register" class="btn btn-success">Ko'ngilli bo'lish</a>
  </div>
</section>
@endsection
