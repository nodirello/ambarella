@extends('layouts.app')
@section('title', 'Mentorlik tizimi | AMBARELLA')
@section('styles')
<style>
.page-hero{padding:48px 0}
.page-hero h1{font-size:clamp(24px,4vw,32px);font-weight:800;color:#fff;margin-bottom:8px}
.page-hero p{color:var(--muted);font-size:14px}
.section-title{font-size:18px;font-weight:700;color:#fff;margin:32px 0 16px;display:flex;align-items:center;gap:10px}
.mentorship-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:22px;margin-bottom:14px;transition:all .2s}
.mentorship-card:hover{border-color:rgba(124,58,237,.3)}
.mentorship-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px}
.mentorship-header h3{font-size:15px;font-weight:600;color:#fff}
.status-badge{padding:4px 10px;border-radius:999px;font-size:11px;font-weight:600}
.status-pending{background:rgba(245,158,11,.1);color:#fbbf24;border:1px solid rgba(245,158,11,.2)}
.status-active{background:rgba(22,163,74,.1);color:#4ade80;border:1px solid rgba(22,163,74,.2)}
.mentorship-goal{font-size:13px;color:var(--muted);margin-bottom:14px}
.task-list-mini{display:flex;flex-direction:column;gap:6px;margin-top:12px}
.mini-task{display:flex;align-items:center;gap:8px;font-size:13px;color:#94a3b8;padding:8px 12px;background:rgba(255,255,255,.02);border-radius:8px}
.mini-task.done{text-decoration:line-through;opacity:.6}
.add-task-form{display:flex;gap:8px;margin-top:12px}
.add-task-form input{flex:1;padding:8px 12px;border-radius:8px;border:1px solid var(--border);background:var(--surface);color:#fff;font-size:13px}
.actions-row{display:flex;gap:8px;margin-top:12px}
.empty-state{text-align:center;padding:32px;color:var(--muted);font-size:14px}
</style>
@endsection
@section('content')
<section class="page-hero"><div class="container">
  <div style="display:flex;justify-content:space-between;align-items:center">
    <div><h1>Mentorlik tizimi</h1><p>Ustoz-shogird bog'lanishlaringiz</p></div>
    <a href="/mentorship/create" class="btn btn-primary">+ Shogird qo'shish</a>
  </div>
</div></section>
<div class="container">

  {{-- Ustoz sifatida --}}
  <h2 class="section-title">🎓 Ustoz sifatida</h2>
  @forelse($asmentor as $m)
  <div class="mentorship-card">
    <div class="mentorship-header">
      <h3>Shogird: {{ $m->student->name }}</h3>
      <span class="status-badge status-{{ $m->status }}">{{ $m->status }}</span>
    </div>
    <p class="mentorship-goal">Maqsad: {{ $m->goal ?? 'Belgilanmagan' }}</p>

    @if($m->status === 'active')
    {{-- Vazifalar --}}
    <div class="task-list-mini">
      @foreach($m->tasks as $task)
      <div class="mini-task {{ $task->is_done ? 'done' : '' }}">
        {{ $task->is_done ? '✅' : '⬜' }} {{ $task->title }}
        @if($task->deadline) <span style="margin-left:auto;font-size:11px;color:var(--warning)">{{ $task->deadline->format('d.m') }}</span> @endif
      </div>
      @endforeach
    </div>
    <form action="/mentorship/{{ $m->id }}/task" method="POST" class="add-task-form">
      @csrf
      <input type="text" name="title" placeholder="Yangi vazifa..." required>
      <input type="date" name="deadline" style="width:140px">
      <button type="submit" class="btn btn-outline" style="padding:8px 12px;font-size:12px">Qo'shish</button>
    </form>
    @endif
  </div>
  @empty
  <div class="empty-state">Sizda hali shogirdlar yo'q.</div>
  @endforelse

  {{-- Shogird sifatida --}}
  <h2 class="section-title">📚 Shogird sifatida</h2>
  @forelse($asstudent as $m)
  <div class="mentorship-card">
    <div class="mentorship-header">
      <h3>Ustoz: {{ $m->mentor->name }}</h3>
      <span class="status-badge status-{{ $m->status }}">{{ $m->status }}</span>
    </div>
    <p class="mentorship-goal">Maqsad: {{ $m->goal ?? 'Belgilanmagan' }}</p>

    @if($m->status === 'pending')
    <div class="actions-row">
      <form action="/mentorship/{{ $m->id }}/accept" method="POST">@csrf<button class="btn btn-success" style="padding:8px 14px;font-size:12px">Qabul qilish</button></form>
      <form action="/mentorship/{{ $m->id }}/reject" method="POST">@csrf<button class="btn btn-outline" style="padding:8px 14px;font-size:12px;color:var(--danger)">Rad etish</button></form>
    </div>
    @endif

    @if($m->status === 'active')
    <div class="task-list-mini">
      @foreach($m->tasks as $task)
      <div class="mini-task {{ $task->is_done ? 'done' : '' }}" style="justify-content:space-between">
        <span>{{ $task->is_done ? '✅' : '⬜' }} {{ $task->title }}</span>
        @if(!$task->is_done)
        <form action="/mentorship/task/{{ $task->id }}/complete" method="POST">@csrf
          <button type="submit" class="btn btn-success" style="padding:4px 10px;font-size:11px">Bajarish</button>
        </form>
        @endif
      </div>
      @endforeach
    </div>
    @endif
  </div>
  @empty
  <div class="empty-state">Sizda hali ustozlar yo'q.</div>
  @endforelse
</div>
@endsection
