@extends('layouts.app')
@section('title', 'Shogird qo\'shish | AMBARELLA')
@section('styles')
<style>
.form-page{padding:48px 0;max-width:560px;margin:0 auto}
.form-page h1{font-size:24px;font-weight:800;color:#fff;margin-bottom:8px}
.form-page p{color:var(--muted);font-size:14px;margin-bottom:32px}
.form-group{margin-bottom:20px}
.form-group label{display:block;font-size:13px;font-weight:600;color:#94a3b8;margin-bottom:6px}
.form-group input,.form-group textarea{width:100%;padding:12px 16px;border-radius:var(--radius);border:1px solid var(--border);background:var(--surface);color:#fff;font-size:14px}
.form-group textarea{resize:vertical;min-height:100px}
.form-actions{display:flex;gap:10px;margin-top:24px}
</style>
@endsection
@section('content')
<div class="container">
  <div class="form-page">
    <h1>Shogird qo'shish</h1>
    <p>Shogirdingizning email manzilini kiriting va mentorlik maqsadini belgilang</p>
    <form action="/mentorship" method="POST">
      @csrf
      <div class="form-group">
        <label>Shogird emaili</label>
        <input type="email" name="student_email" placeholder="shogird@example.com" required value="{{ old('student_email') }}">
      </div>
      <div class="form-group">
        <label>Mentorlik maqsadi</label>
        <textarea name="goal" placeholder="Masalan: Frontend dasturchiga aylanish..." required maxlength="500">{{ old('goal') }}</textarea>
      </div>
      <div class="form-actions">
        <button type="submit" class="btn btn-primary">Taklif yuborish</button>
        <a href="/mentorship" class="btn btn-outline">Bekor qilish</a>
      </div>
    </form>
  </div>
</div>
@endsection
