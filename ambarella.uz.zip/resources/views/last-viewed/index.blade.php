@extends('layouts.app')
@section('title', 'Oxirgi ko\'rilganlar | AMBARELLA')
@section('styles')
<style>
.page-hero{padding:56px 0 40px;text-align:center;position:relative}
.page-hero h1{font-size:clamp(28px,4vw,38px);font-weight:800;color:#fff;margin-bottom:8px}
.page-hero p{color:var(--muted);font-size:15px}
.viewed-list{max-width:700px;margin:0 auto;padding:40px 0;display:flex;flex-direction:column;gap:12px}
.viewed-item{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:18px 22px;display:flex;align-items:center;gap:14px;transition:all .2s;text-decoration:none}
.viewed-item:hover{border-color:rgba(37,99,235,.4);transform:translateX(4px)}
.viewed-icon{width:42px;height:42px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0}
.viewed-icon.job{background:rgba(37,99,235,.1)}
.viewed-icon.course{background:rgba(139,92,246,.1)}
.viewed-icon.news{background:rgba(234,179,8,.1)}
.viewed-icon.product{background:rgba(34,197,94,.1)}
.viewed-icon.blog{background:rgba(236,72,153,.1)}
.viewed-info{flex:1;min-width:0}
.viewed-info h3{font-size:14px;font-weight:600;color:#fff;margin-bottom:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.viewed-info p{font-size:12px;color:var(--muted)}
.viewed-time{font-size:11px;color:#475569;flex-shrink:0}
.empty-state{text-align:center;padding:80px 0;color:var(--muted)}
.empty-state p:first-child{font-size:48px;margin-bottom:12px}
</style>
@endsection
@section('content')
<section class="page-hero"><div class="container">
  <h1>Oxirgi ko'rilganlar</h1>
  <p>Siz yaqinda ko'rgan sahifalar</p>
</div></section>
<div class="container">
  <div class="viewed-list">
    @forelse($items as $item)
    <a href="{{ $item['url'] }}" class="viewed-item">
      <div class="viewed-icon {{ $item['type'] }}">
        @switch($item['type'])
          @case('job') 💼 @break
          @case('course') 📚 @break
          @case('news') 📰 @break
          @case('product') 🌿 @break
          @case('blog') 📝 @break
          @default 📄
        @endswitch
      </div>
      <div class="viewed-info">
        <h3>{{ $item['title'] }}</h3>
        <p>{{ ucfirst($item['type']) }}</p>
      </div>
      <span class="viewed-time">{{ \Carbon\Carbon::parse($item['time'])->diffForHumans() }}</span>
    </a>
    @empty
    <div class="empty-state">
      <p>👀</p>
      <p>Hali hech narsa ko'rilmagan</p>
      <p style="font-size:13px;margin-top:8px">Platformadagi sahifalarni ko'ring — ular shu yerda ko'rinadi</p>
    </div>
    @endforelse
  </div>
</div>
@endsection
