@extends('layouts.app')
@section('title', 'Kundalik vazifalar | AMBARELLA')
@section('styles')
<style>
.page-hero{padding:48px 0}
.page-hero h1{font-size:clamp(24px,4vw,32px);font-weight:800;color:#fff;margin-bottom:8px}
.page-hero p{color:var(--muted);font-size:14px}
.stats-row{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:32px}
.mini-stat{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:20px;text-align:center}
.mini-stat strong{display:block;font-size:24px;font-weight:800;color:#60a5fa}
.mini-stat span{font-size:12px;color:var(--muted)}
.add-form{display:flex;gap:10px;margin-bottom:24px}
.add-form input{flex:1;padding:12px 16px;border-radius:var(--radius);border:1px solid var(--border);background:var(--surface);color:#fff;font-size:14px}
.task-list{display:flex;flex-direction:column;gap:8px}
.task-item{display:flex;align-items:center;gap:12px;padding:14px 18px;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);transition:all .2s}
.task-item:hover{border-color:rgba(37,99,235,.3)}
.task-item.done{opacity:.6}
.task-item.done .task-text{text-decoration:line-through;color:var(--muted)}
.task-text{flex:1;font-size:14px;color:#e2e8f0}
.task-actions{display:flex;gap:6px}
.empty-state{text-align:center;padding:48px;color:var(--muted);font-size:14px}
@media(max-width:768px){.stats-row{grid-template-columns:1fr}.add-form{flex-direction:column}}
</style>
@endsection
@section('content')
<section class="page-hero"><div class="container">
  <h1>Kundalik vazifalar</h1>
  <p>Bugungi rejalaringizni yozing va bajaring</p>
</div></section>
<div class="container">
  <div class="stats-row">
    <div class="mini-stat"><strong>{{ $stats['total_today'] }}</strong><span>Bugun jami</span></div>
    <div class="mini-stat"><strong style="color:#4ade80">{{ $stats['done_today'] }}</strong><span>Bajarilgan</span></div>
    <div class="mini-stat"><strong style="color:#fbbf24">{{ $stats['streak'] }}</strong><span>Streak (kun)</span></div>
  </div>

  <form action="/daily-tasks" method="POST" class="add-form">
    @csrf
    <input type="text" name="text" placeholder="Yangi vazifa yozing..." required maxlength="255">
    <button type="submit" class="btn btn-primary">Qo'shish</button>
  </form>

  <div class="task-list">
    @forelse($tasks as $task)
    <div class="task-item {{ $task->is_done ? 'done' : '' }}">
      <form action="/daily-tasks/{{ $task->id }}/toggle" method="POST">
        @csrf
        <button type="submit" style="width:22px;height:22px;border-radius:50%;border:2px solid {{ $task->is_done ? '#4ade80' : 'var(--border)' }};background:{{ $task->is_done ? '#4ade80' : 'transparent' }};cursor:pointer;display:flex;align-items:center;justify-content:center">
          @if($task->is_done)<svg viewBox="0 0 24 24" style="width:12px;height:12px;stroke:#fff;stroke-width:3;fill:none"><path d="M5 13l4 4L19 7"/></svg>@endif
        </button>
      </form>
      <span class="task-text">{{ $task->text }}</span>
      <div class="task-actions">
        <form action="/daily-tasks/{{ $task->id }}" method="POST">@csrf @method('DELETE')
          <button type="submit" class="btn" style="padding:4px 8px;color:var(--danger);font-size:12px">✕</button>
        </form>
      </div>
    </div>
    @empty
    <div class="empty-state">Bugun hali vazifa yo'q. Birinchi vazifangizni qo'shing!</div>
    @endforelse
  </div>
</div>
@endsection
