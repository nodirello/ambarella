<!DOCTYPE html>
<html lang="uz">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Texnik ishlar | AMBARELLA</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Inter',system-ui,sans-serif;background:#0f172a;color:#e2e8f0;min-height:100vh;display:flex;align-items:center;justify-content:center;text-align:center;padding:24px}
.maintenance{max-width:500px}
.m-icon{width:80px;height:80px;margin:0 auto 24px;border-radius:50%;background:rgba(245,158,11,.1);display:flex;align-items:center;justify-content:center}
.m-icon svg{width:36px;height:36px;stroke:#fbbf24;fill:none;stroke-width:1.5;animation:spin 4s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
h1{font-size:28px;font-weight:800;margin-bottom:12px;background:linear-gradient(135deg,#fbbf24,#f97316);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
p{color:#94a3b8;font-size:15px;line-height:1.7;margin-bottom:24px}
.timer{font-size:13px;color:#64748b;margin-top:16px}
a{color:#60a5fa;text-decoration:none;font-weight:600}
</style>
</head>
<body>
<div class="maintenance">
  <div class="m-icon">
    <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15 1.65 1.65 0 003 14.08V14a2 2 0 014 0"/></svg>
  </div>
  <h1>Texnik ishlar olib borilmoqda</h1>
  <p>Platforma yangilanmoqda. Tez orada qaytib ishga tushamiz. Sabringiz uchun rahmat!</p>
  <p class="timer">Taxminiy vaqt: 5-15 daqiqa</p>
  <p><a href="https://t.me/AmbarellaBot">Telegram: @AmbarellaBot</a></p>
</div>
</body>
</html>
