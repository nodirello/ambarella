@extends('layouts.app')
@section('title', '404 — Sahifa topilmadi | AMBARELLA')
@section('styles')
<style>
.error-page{min-height:60vh;display:flex;align-items:center;justify-content:center;text-align:center;padding:60px 24px}
.error-icon{width:120px;height:120px;margin:0 auto 24px;position:relative}
.error-icon svg{width:100%;height:100%;stroke:var(--primary);fill:none;stroke-width:1;animation:float-err 3s ease-in-out infinite}
@keyframes float-err{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}
.error-code{font-size:72px;font-weight:900;background:linear-gradient(135deg,#60a5fa,#a78bfa);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;margin-bottom:8px}
.error-msg{font-size:18px;color:#fff;font-weight:700;margin-bottom:8px}
.error-desc{font-size:14px;color:var(--muted);margin-bottom:32px;max-width:400px;margin-left:auto;margin-right:auto}
.error-actions{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
</style>
@endsection
@section('content')
<section class="error-page">
  <div>
    <div class="error-icon">
      <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M16 16s-1.5-2-4-2-4 2-4 2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg>
    </div>
    <div class="error-code">404</div>
    <p class="error-msg">Sahifa topilmadi</p>
    <p class="error-desc">Siz qidirayotgan sahifa mavjud emas yoki ko'chirilgan. Bosh sahifaga qayting yoki qidiruv orqali toping.</p>
    <div class="error-actions">
      <a href="/" class="btn btn-primary">Bosh sahifa</a>
      <a href="/search" class="btn btn-outline">Qidirish</a>
      <a href="/jobs" class="btn btn-outline">Ish e'lonlari</a>
    </div>
  </div>
</section>
@endsection
