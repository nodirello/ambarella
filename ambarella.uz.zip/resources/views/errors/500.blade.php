@extends('layouts.app')
@section('title', '500 — Server xatosi | AMBARELLA')
@section('styles')
<style>
.error-page{min-height:60vh;display:flex;align-items:center;justify-content:center;text-align:center;padding:60px 24px}
.error-icon{width:120px;height:120px;margin:0 auto 24px}
.error-icon svg{width:100%;height:100%;stroke:#f87171;fill:none;stroke-width:1;animation:pulse-err 2s ease-in-out infinite}
@keyframes pulse-err{0%,100%{transform:scale(1);opacity:1}50%{transform:scale(1.05);opacity:.8}}
.error-code{font-size:72px;font-weight:900;background:linear-gradient(135deg,#f87171,#fbbf24);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;margin-bottom:8px}
.error-msg{font-size:18px;color:#fff;font-weight:700;margin-bottom:8px}
.error-desc{font-size:14px;color:var(--muted);margin-bottom:32px;max-width:400px;margin-left:auto;margin-right:auto}
.error-actions{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
</style>
@endsection
@section('content')
<section class="error-page">
  <div>
    <div class="error-icon">
      <svg viewBox="0 0 24 24"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
    </div>
    <div class="error-code">500</div>
    <p class="error-msg">Server xatosi</p>
    <p class="error-desc">Nimadir noto'g'ri ketdi. Biz muammoni tuzatish ustida ishlaymiz. Iltimos, biroz kutib qayta urinib ko'ring.</p>
    <div class="error-actions">
      <a href="/" class="btn btn-primary">Bosh sahifa</a>
      <a href="javascript:location.reload()" class="btn btn-outline">Qayta yuklash</a>
    </div>
  </div>
</section>
@endsection
