@extends('layouts.app')
@section('title', 'So\'rovnomalar | Admin')
@section('styles')
<style>
.admin-page{padding:32px 0}
.admin-page-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;flex-wrap:wrap;gap:12px}
.admin-page-header h1{font-size:22px;font-weight:800;color:#fff}
.polls-list{display:flex;flex-direction:column;gap:12px}
.poll-item{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:18px;display:flex;align-items:center;gap:16px;transition:all .2s}
.poll-item:hover{border-color:rgba(37,99,235,.3)}
.poll-icon{width:42px;height:42px;border-radius:10px;background:linear-gradient(135deg,rgba(139,92,246,.15),rgba(59,130,246,.15));display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0}
.poll-info{flex:1;min-width:0}
.poll-info h3{font-size:15px;font-weight:600;color:#fff;margin-bottom:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.poll-info p{font-size:12px;color:var(--muted)}
.poll-stats{display:flex;gap:12px;flex-shrink:0}
.poll-stat{text-align:center;padding:4px 12px;background:rgba(255,255,255,.03);border-radius:6px}
.poll-stat-value{font-size:14px;font-weight:700;color:#fff}
.poll-stat-label{font-size:10px;color:#64748b;text-transform:uppercase}
.status-badge{font-size:11px;font-weight:600;padding:3px 10px;border-radius:12px;flex-shrink:0}
.status-active{background:rgba(34,197,94,.1);color:#86efac}
.status-inactive{background:rgba(239,68,68,.1);color:#fca5a5}
.actions-cell{display:flex;gap:6px;flex-shrink:0}
.action-btn{padding:6px 12px;border-radius:6px;font-size:11px;font-weight:600;cursor:pointer;border:none;text-decoration:none;display:inline-block}
.action-delete{background:rgba(220,38,38,.1);color:#fca5a5}
@media(max-width:768px){.poll-item{flex-direction:column;align-items:flex-start}.poll-stats{align-self:stretch}.actions-cell{align-self:flex-end}}
</style>
@endsection
@section('content')
<div class="container">
    <div class="admin-page">
        <div class="admin-page-header">
            <h1>📊 So'rovnomalar ({{ $polls->count() }})</h1>
            <div style="display:flex;gap:10px">
                <a href="{{ route('admin.dashboard') }}" class="btn btn-outline" style="padding:8px 16px;font-size:12px">← Admin</a>
                <a href="{{ route('admin.polls.create') }}" class="btn btn-primary" style="padding:8px 16px;font-size:12px">+ Yangi so'rovnoma</a>
            </div>
        </div>

        @if(session('success'))
        <div style="background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.3);border-radius:var(--radius);padding:12px 16px;margin-bottom:16px;color:#86efac;font-size:13px">{{ session('success') }}</div>
        @endif

        <div class="polls-list">
            @foreach($polls as $poll)
            <div class="poll-item">
                <div class="poll-icon">📊</div>
                <div class="poll-info">
                    <h3>{{ $poll->question }}</h3>
                    <p>{{ $poll->options->count() }} ta variant · Yaratilgan: {{ $poll->created_at->format('d.m.Y') }}{{ $poll->ends_at ? ' · Tugaydi: ' . $poll->ends_at->format('d.m.Y') : '' }}</p>
                </div>
                <div class="poll-stats">
                    <div class="poll-stat">
                        <div class="poll-stat-value">{{ $poll->options->count() }}</div>
                        <div class="poll-stat-label">Variant</div>
                    </div>
                    <div class="poll-stat">
                        <div class="poll-stat-value">{{ $poll->votes_count }}</div>
                        <div class="poll-stat-label">Ovoz</div>
                    </div>
                </div>
                <span class="status-badge {{ $poll->is_active ? 'status-active' : 'status-inactive' }}">
                    {{ $poll->is_active ? 'Faol' : 'Nofaol' }}
                </span>
                <div class="actions-cell">
                    <form method="POST" action="{{ route('admin.polls.destroy', $poll) }}" onsubmit="return confirm('O\'chirilsinmi?')" style="display:inline">
                        @csrf @method('DELETE')
                        <button class="action-btn action-delete">🗑️ O'chirish</button>
                    </form>
                </div>
            </div>
            @endforeach
        </div>

        @if($polls->isEmpty())
        <div style="text-align:center;padding:60px 0;color:var(--muted)">
            <p style="font-size:40px;margin-bottom:12px">📊</p>
            <p>So'rovnomalar yo'q</p>
        </div>
        @endif
    </div>
</div>
@endsection
