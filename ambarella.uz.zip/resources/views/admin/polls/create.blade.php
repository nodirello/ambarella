@extends('layouts.app')
@section('title', 'Yangi so\'rovnoma | Admin')
@section('styles')
<style>
.form-page{padding:48px 0;max-width:640px;margin:0 auto}
.form-page h1{font-size:22px;font-weight:800;color:#fff;margin-bottom:32px}
.form-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:32px}
.form-group{margin-bottom:18px}
.form-group label{display:block;font-size:13px;font-weight:600;color:#94a3b8;margin-bottom:6px}
.form-group input,.form-group textarea{width:100%;padding:12px 16px;border:1px solid var(--border);border-radius:var(--radius);font-size:14px;background:rgba(255,255,255,.02);color:#fff;font-family:inherit}
.form-group input::placeholder,.form-group textarea::placeholder{color:#475569}
.back-link{display:inline-flex;align-items:center;gap:6px;color:var(--muted);font-size:13px;margin-bottom:20px;transition:color .2s;text-decoration:none}
.back-link:hover{color:#fff}
.options-container{display:flex;flex-direction:column;gap:10px}
.option-row{display:flex;gap:8px;align-items:center}
.option-row input{flex:1}
.remove-option-btn{padding:8px 12px;background:rgba(220,38,38,.1);border:1px solid rgba(220,38,38,.3);border-radius:var(--radius);color:#fca5a5;cursor:pointer;font-size:14px;transition:all .2s}
.remove-option-btn:hover{background:rgba(220,38,38,.2)}
.add-option-btn{display:inline-flex;align-items:center;gap:6px;padding:10px 16px;background:rgba(59,130,246,.1);border:1px solid rgba(59,130,246,.3);border-radius:var(--radius);color:#93c5fd;cursor:pointer;font-size:13px;font-weight:600;transition:all .2s;margin-top:10px}
.add-option-btn:hover{background:rgba(59,130,246,.2)}
.form-hint{font-size:11px;color:#475569;margin-top:4px}
</style>
@endsection
@section('content')
<div class="container">
    <div class="form-page">
        <a href="{{ route('admin.polls') }}" class="back-link">← Barcha so'rovnomalar</a>
        <h1>📊 Yangi so'rovnoma yaratish</h1>

        @if($errors->any())
        <div style="background:rgba(220,38,38,.1);border:1px solid rgba(220,38,38,.3);border-radius:var(--radius);padding:14px;margin-bottom:20px">
            @foreach($errors->all() as $error)
                <p style="color:#fca5a5;font-size:13px;margin:2px 0">{{ $error }}</p>
            @endforeach
        </div>
        @endif

        <form method="POST" action="{{ route('admin.polls.store') }}" class="form-card">
            @csrf
            <div class="form-group">
                <label>Savol *</label>
                <textarea name="question" required placeholder="So'rovnoma savolini yozing..." rows="3" minlength="5" maxlength="500">{{ old('question') }}</textarea>
            </div>

            <div class="form-group">
                <label>Variantlar * (kamida 2 ta)</label>
                <div class="options-container" id="optionsContainer">
                    <div class="option-row">
                        <input type="text" name="options[]" placeholder="1-variant" required value="{{ old('options.0') }}">
                    </div>
                    <div class="option-row">
                        <input type="text" name="options[]" placeholder="2-variant" required value="{{ old('options.1') }}">
                    </div>
                    @if(old('options'))
                        @foreach(array_slice(old('options'), 2) as $i => $opt)
                        <div class="option-row">
                            <input type="text" name="options[]" placeholder="{{ $i + 3 }}-variant" value="{{ $opt }}">
                            <button type="button" class="remove-option-btn" onclick="this.parentElement.remove()">✕</button>
                        </div>
                        @endforeach
                    @endif
                </div>
                <button type="button" class="add-option-btn" onclick="addOption()">
                    <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>
                    Variant qo'shish
                </button>
            </div>

            <div class="form-group">
                <label>Tugash sanasi (ixtiyoriy)</label>
                <input type="date" name="ends_at" value="{{ old('ends_at') }}">
                <p class="form-hint">Bo'sh qoldirilsa — muddatsiz so'rovnoma</p>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:14px">Yaratish</button>
        </form>
    </div>
</div>

<script>
(function(){
    let optionCount = document.querySelectorAll('.option-row').length;
    window.addOption = function() {
        optionCount++;
        const container = document.getElementById('optionsContainer');
        const row = document.createElement('div');
        row.className = 'option-row';
        row.innerHTML = '<input type="text" name="options[]" placeholder="' + optionCount + '-variant"><button type="button" class="remove-option-btn" onclick="this.parentElement.remove()">✕</button>';
        container.appendChild(row);
    };
})();
</script>
@endsection
