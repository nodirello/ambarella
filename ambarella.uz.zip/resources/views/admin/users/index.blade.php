@extends('layouts.app')
@section('title', 'Foydalanuvchilar | Admin')
@section('styles')
<style>
.admin-page{padding:32px 0}
.admin-page-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;flex-wrap:wrap;gap:12px}
.admin-page-header h1{font-size:22px;font-weight:800;color:#fff}
.search-row{display:flex;gap:10px;margin-bottom:24px}
.search-row input{flex:1;padding:12px 16px;border:1px solid var(--border);border-radius:var(--radius);font-size:14px;background:var(--surface);color:#fff}
.search-row input::placeholder{color:#475569}
.admin-table{width:100%;border-collapse:collapse;font-size:13px}
.admin-table th{text-align:left;padding:12px 14px;font-size:11px;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);border-bottom:1px solid var(--border);background:var(--surface)}
.admin-table td{padding:12px 14px;border-bottom:1px solid var(--border);color:#cbd5e1}
.admin-table tr:hover td{background:rgba(255,255,255,.02)}
.badge-role{padding:3px 8px;border-radius:999px;font-size:10px;font-weight:600}
.badge-admin{background:rgba(37,99,235,.1);color:#93c5fd}
.badge-user{background:rgba(255,255,255,.04);color:var(--muted)}
.badge-banned{color:#fca5a5;font-weight:600}
.badge-active{color:#4ade80}
.actions-cell{display:flex;gap:6px;flex-wrap:wrap}
.action-btn{padding:4px 10px;border-radius:6px;font-size:11px;font-weight:600;cursor:pointer;border:none}
.action-ban{background:rgba(220,38,38,.1);color:#fca5a5}
.action-unban{background:rgba(22,163,74,.1);color:#4ade80}
.action-admin{background:rgba(37,99,235,.1);color:#93c5fd}
@media(max-width:768px){.admin-table{font-size:12px}.admin-table th:nth-child(3),.admin-table td:nth-child(3){display:none}}
</style>
@endsection
@section('content')
<div class="container">
  <div class="admin-page">
    <div class="admin-page-header">
      <h1>Foydalanuvchilar ({{ $users->total() }})</h1>
      <a href="/admin" class="btn btn-outline" style="padding:8px 16px;font-size:12px">← Admin panel</a>
    </div>
    <form method="GET" class="search-row">
      <input name="search" value="{{ request('search') }}" placeholder="Ism yoki email qidirish...">
      <button type="submit" class="btn btn-primary" style="padding:12px 20px;font-size:13px">Qidirish</button>
    </form>
    <div style="overflow-x:auto;border:1px solid var(--border);border-radius:var(--radius)">
      <table class="admin-table">
        <thead><tr><th>Ism</th><th>Email</th><th>GreenCoin</th><th>Role</th><th>Holat</th><th>Amallar</th></tr></thead>
        <tbody>
          @foreach($users as $u)
          <tr>
            <td style="color:#fff;font-weight:500">{{ $u->name }}</td>
            <td>{{ $u->email }}</td>
            <td style="color:#4ade80;font-weight:600">{{ $u->greencoin_balance }}</td>
            <td><span class="badge-role {{ $u->role==='admin'?'badge-admin':'badge-user' }}">{{ $u->role }}</span></td>
            <td>{!! $u->is_banned ? '<span class="badge-banned">Bloklangan</span>' : '<span class="badge-active">Faol</span>' !!}</td>
            <td>
              <div class="actions-cell">
                <form method="POST" action="/admin/users/{{ $u->id }}/ban">@csrf<button class="action-btn {{ $u->is_banned ? 'action-unban' : 'action-ban' }}">{{ $u->is_banned ? 'Unban' : 'Ban' }}</button></form>
                @if($u->role !== 'admin')
                  <form method="POST" action="/admin/users/{{ $u->id }}/admin">@csrf<button class="action-btn action-admin">Admin</button></form>
                @else
                  <form method="POST" action="/admin/users/{{ $u->id }}/remove-admin">@csrf<button class="action-btn action-ban">Admin olib tashlash</button></form>
                @endif
              </div>
            </td>
          </tr>
          @endforeach
        </tbody>
      </table>
    </div>
    <div style="margin-top:16px">{{ $users->links() }}</div>
  </div>
</div>
@endsection
