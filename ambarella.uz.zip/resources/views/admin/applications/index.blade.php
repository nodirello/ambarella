@extends('layouts.app')
@section('title', 'Arizalar | Admin')
@section('styles')
<style>
.admin-page{padding:32px 0}
.admin-page-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px}
.admin-page-header h1{font-size:22px;font-weight:800;color:#fff}
.admin-page-header p{font-size:13px;color:var(--muted);margin-top:4px}
.admin-table{width:100%;border-collapse:collapse;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden}
.admin-table th{text-align:left;padding:12px 14px;font-size:11px;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);border-bottom:1px solid var(--border)}
.admin-table td{padding:14px;border-bottom:1px solid var(--border);font-size:14px;color:#cbd5e1}
.admin-table tr:last-child td{border:none}
.badge{padding:3px 10px;border-radius:999px;font-size:11px;font-weight:600;display:inline-block}
.badge-pending{background:rgba(234,179,8,.15);color:#fde047}
.badge-accepted{background:rgba(34,197,94,.15);color:#86efac}
.badge-rejected{background:rgba(239,68,68,.15);color:#fca5a5}
.status-actions{display:flex;gap:6px;align-items:center;flex-wrap:wrap}
.status-btn{padding:5px 10px;font-size:11px;font-weight:600;border-radius:var(--radius);border:1px solid var(--border);background:transparent;cursor:pointer;transition:all .2s}
.status-btn.accept{color:#86efac;border-color:rgba(34,197,94,.3)}
.status-btn.accept:hover{background:rgba(34,197,94,.1)}
.status-btn.reject{color:#fca5a5;border-color:rgba(239,68,68,.3)}
.status-btn.reject:hover{background:rgba(239,68,68,.1)}
.table-responsive{overflow-x:auto;border-radius:var(--radius)}
@media(max-width:768px){.admin-page-header{flex-direction:column;align-items:flex-start;gap:12px}.status-actions{flex-direction:column}}
</style>
@endsection
@section('content')
<div class="container">
  <div class="admin-page">
    <div class="admin-page-header">
      <div>
        <h1>Ish arizalari</h1>
        <p>Ishga ariza topshirgan foydalanuvchilarni ko'rish va boshqarish</p>
      </div>
    </div>
    <div class="table-responsive">
      <table class="admin-table">
        <thead>
          <tr>
            <th>Ariza beruvchi</th>
            <th>Ish nomi</th>
            <th>Holati</th>
            <th>Sana</th>
            <th>Amallar</th>
          </tr>
        </thead>
        <tbody>
          @forelse($applications as $application)
          <tr>
            <td style="font-weight:600;color:#fff">{{ $application->user->name }}</td>
            <td>{{ $application->job->title }}</td>
            <td>
              @if($application->status === 'pending')
                <span class="badge badge-pending">Kutilmoqda</span>
              @elseif($application->status === 'accepted')
                <span class="badge badge-accepted">Qabul qilindi</span>
              @elseif($application->status === 'rejected')
                <span class="badge badge-rejected">Rad etildi</span>
              @endif
            </td>
            <td>{{ \Carbon\Carbon::parse($application->created_at)->format('d.m.Y') }}</td>
            <td>
              <div class="status-actions">
                @if($application->status !== 'accepted')
                <form action="/admin/applications/{{ $application->id }}/status" method="POST" style="display:inline">
                  @csrf
                  <input type="hidden" name="status" value="accepted">
                  <button type="submit" class="status-btn accept">✓ Qabul</button>
                </form>
                @endif
                @if($application->status !== 'rejected')
                <form action="/admin/applications/{{ $application->id }}/status" method="POST" style="display:inline">
                  @csrf
                  <input type="hidden" name="status" value="rejected">
                  <button type="submit" class="status-btn reject">✕ Rad</button>
                </form>
                @endif
              </div>
            </td>
          </tr>
          @empty
          <tr><td colspan="5" style="text-align:center;color:var(--muted);padding:32px">Arizalar topilmadi</td></tr>
          @endforelse
        </tbody>
      </table>
    </div>
    <div style="margin-top:20px">{{ $applications->links() }}</div>
  </div>
</div>
@endsection
