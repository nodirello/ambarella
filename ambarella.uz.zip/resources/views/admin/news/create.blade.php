@extends('layouts.app')
@section('title', 'Yangi yangilik | Admin')
@section('styles')
<style>
.form-page{padding:48px 0;max-width:640px;margin:0 auto}
.form-page h1{font-size:22px;font-weight:800;color:#fff;margin-bottom:32px}
.form-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:32px}
.form-group{margin-bottom:18px}
.form-group label{display:block;font-size:13px;font-weight:600;color:#94a3b8;margin-bottom:6px}
.form-group input,.form-group select,.form-group textarea{width:100%;padding:12px 16px;border:1px solid var(--border);border-radius:var(--radius);font-size:14px;background:rgba(255,255,255,.02);color:#fff;font-family:inherit}
.form-group input::placeholder,.form-group textarea::placeholder{color:#475569}
.form-group textarea{resize:vertical;min-height:120px}
.back-link{display:inline-flex;align-items:center;gap:6px;color:var(--muted);font-size:13px;margin-bottom:20px;transition:color .2s}
.back-link:hover{color:#fff}
</style>
@endsection
@section('content')
<div class="container">
  <div class="form-page">
    <a href="/admin/news" class="back-link">← Barcha yangiliklar</a>
    <h1>Yangi yangilik qo'shish</h1>
    <form method="POST" action="/admin/news" class="form-card">
      @csrf
      <div class="form-group"><label>Sarlavha *</label><input name="title" required placeholder="Yangilik sarlavhasi" value="{{ old('title') }}"></div>
      <div class="form-group"><label>Muallif *</label><input name="author" required placeholder="Muallif ismi" value="{{ old('author') }}"></div>
      <div class="form-group"><label>Kategoriya *</label>
        <select name="category"><option value="Platforma">Platforma</option><option value="Ekologiya">Ekologiya</option><option value="Ta'lim">Ta'lim</option><option value="Bandlik">Bandlik</option><option value="Texnologiya">Texnologiya</option></select>
      </div>
      <div class="form-group"><label>Rasm URL (ixtiyoriy)</label><input name="image" placeholder="https://..." value="{{ old('image') }}"></div>
      <div class="form-group"><label>Matn *</label><textarea name="content" required placeholder="Yangilik matni...">{{ old('content') }}</textarea></div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:14px">Saqlash</button>
    </form>
  </div>
</div>
@endsection
