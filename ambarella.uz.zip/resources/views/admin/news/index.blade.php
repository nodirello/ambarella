@extends('layouts.app')
@section('title', 'Yangiliklar | Admin')
@section('styles')
<style>
.admin-page{padding:32px 0}
.admin-page-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;flex-wrap:wrap;gap:12px}
.admin-page-header h1{font-size:22px;font-weight:800;color:#fff}
.news-list{display:flex;flex-direction:column;gap:12px}
.news-item{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:20px;display:flex;justify-content:space-between;align-items:center;gap:16px;transition:all .2s}
.news-item:hover{border-color:rgba(37,99,235,.3)}
.news-item h3{font-size:15px;font-weight:600;color:#fff;margin-bottom:3px}
.news-item p{font-size:12px;color:var(--muted)}
.actions-cell{display:flex;gap:6px;flex-shrink:0}
.action-btn{padding:6px 12px;border-radius:6px;font-size:11px;font-weight:600;cursor:pointer;border:none;text-decoration:none;display:inline-block}
.action-edit{background:rgba(37,99,235,.1);color:#93c5fd}
.action-delete{background:rgba(220,38,38,.1);color:#fca5a5}
@media(max-width:768px){.news-item{flex-direction:column;align-items:flex-start}.actions-cell{align-self:flex-end}}
</style>
@endsection
@section('content')
<div class="container">
  <div class="admin-page">
    <div class="admin-page-header">
      <h1>Yangiliklar ({{ $news->total() }})</h1>
      <div style="display:flex;gap:10px">
        <a href="/admin" class="btn btn-outline" style="padding:8px 16px;font-size:12px">← Admin</a>
        <a href="/admin/news/create" class="btn btn-primary" style="padding:8px 16px;font-size:12px">+ Yangi yangilik</a>
      </div>
    </div>
    <div class="news-list">
      @foreach($news as $item)
      <div class="news-item">
        <div>
          <h3>{{ $item->title }}</h3>
          <p>{{ $item->author }} · {{ $item->category }} · {{ $item->created_at->format('d.m.Y') }}</p>
        </div>
        <div class="actions-cell">
          <a href="/admin/news/{{ $item->id }}/edit" class="action-btn action-edit">Tahrir</a>
          <form method="POST" action="/admin/news/{{ $item->id }}" onsubmit="return confirm('O\'chirilsinmi?')">@csrf @method('DELETE')<button class="action-btn action-delete">🗑️</button></form>
        </div>
      </div>
      @endforeach
    </div>
    <div style="margin-top:16px">{{ $news->links() }}</div>
  </div>
</div>
@endsection
