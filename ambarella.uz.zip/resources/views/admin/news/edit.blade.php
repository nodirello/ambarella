@extends('layouts.app')
@section('title', 'Tahrirlash | Admin')
@section('styles')
<style>
.form-page{padding:48px 0;max-width:640px;margin:0 auto}
.form-page h1{font-size:22px;font-weight:800;color:#fff;margin-bottom:32px}
.form-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:32px}
.form-group{margin-bottom:18px}
.form-group label{display:block;font-size:13px;font-weight:600;color:#94a3b8;margin-bottom:6px}
.form-group input,.form-group select,.form-group textarea{width:100%;padding:12px 16px;border:1px solid var(--border);border-radius:var(--radius);font-size:14px;background:rgba(255,255,255,.02);color:#fff;font-family:inherit}
.form-group textarea{resize:vertical;min-height:120px}
.back-link{display:inline-flex;align-items:center;gap:6px;color:var(--muted);font-size:13px;margin-bottom:20px;transition:color .2s}
.back-link:hover{color:#fff}
</style>
@endsection
@section('content')
<div class="container">
  <div class="form-page">
    <a href="/admin/news" class="back-link">← Yangiliklar</a>
    <h1>Tahrirlash: {{ $news->title }}</h1>
    <form method="POST" action="/admin/news/{{ $news->id }}" class="form-card">
      @csrf @method('PUT')
      <div class="form-group"><label>Sarlavha</label><input name="title" value="{{ $news->title }}" required></div>
      <div class="form-group"><label>Muallif</label><input name="author" value="{{ $news->author }}"></div>
      <div class="form-group"><label>Kategoriya</label><input name="category" value="{{ $news->category }}"></div>
      <div class="form-group"><label>Rasm URL</label><input name="image" value="{{ $news->image }}"></div>
      <div class="form-group"><label>Matn</label><textarea name="content" required>{{ $news->content }}</textarea></div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:14px">Saqlash</button>
    </form>
  </div>
</div>
@endsection
