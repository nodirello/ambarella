@extends('layouts.app')
@section('title', 'GreenCoin | Admin')
@section('styles')
<style>
.admin-page{padding:32px 0}
.admin-page-header{margin-bottom:24px}
.admin-page-header h1{font-size:22px;font-weight:800;color:#fff}
.admin-page-header p{font-size:13px;color:var(--muted);margin-top:4px}
.stats-row{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:28px}
.stat-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:20px;transition:all .3s}
.stat-card:hover{border-color:rgba(37,99,235,.3);transform:translateY(-2px)}
.stat-card p{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px}
.stat-card strong{font-size:26px;font-weight:800}
.adjust-section{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:20px;margin-bottom:28px}
.adjust-section h3{font-size:15px;font-weight:700;color:#fff;margin-bottom:16px}
.adjust-form{display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end}
.adjust-form .form-group{flex:1;min-width:120px}
.adjust-form .form-group label{display:block;font-size:12px;color:#94a3b8;margin-bottom:4px;font-weight:600}
.adjust-form .form-group input,.adjust-form .form-group select{width:100%;padding:10px 12px;border-radius:var(--radius);border:1px solid var(--border);background:var(--surface);color:#fff;font-size:13px}
.admin-table{width:100%;border-collapse:collapse;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden}
.admin-table th{text-align:left;padding:12px 14px;font-size:11px;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);border-bottom:1px solid var(--border)}
.admin-table td{padding:14px;border-bottom:1px solid var(--border);font-size:14px;color:#cbd5e1}
.admin-table tr:last-child td{border:none}
.badge{padding:3px 10px;border-radius:999px;font-size:11px;font-weight:600;display:inline-block}
.badge-earned{background:rgba(34,197,94,.15);color:#86efac}
.badge-spent{background:rgba(239,68,68,.15);color:#fca5a5}
.table-responsive{overflow-x:auto;border-radius:var(--radius)}
@media(max-width:768px){.stats-row{grid-template-columns:1fr}.adjust-form{flex-direction:column}}
</style>
@endsection
@section('content')
<div class="container">
  <div class="admin-page">
    <div class="admin-page-header">
      <h1>GreenCoin boshqaruvi</h1>
      <p>GreenCoin statistikasi va tranzaksiyalar</p>
    </div>

    {{-- Stats --}}
    <div class="stats-row">
      <div class="stat-card">
        <p>Jami ishlangan</p>
        <strong style="color:#4ade80">{{ number_format($stats['total_earned']) }}</strong>
      </div>
      <div class="stat-card">
        <p>Jami sarflangan</p>
        <strong style="color:#f87171">{{ number_format($stats['total_spent']) }}</strong>
      </div>
      <div class="stat-card">
        <p>Jami tranzaksiyalar</p>
        <strong style="color:#60a5fa">{{ number_format($stats['total_transactions']) }}</strong>
      </div>
    </div>

    {{-- Adjust Balance --}}
    <div class="adjust-section">
      <h3>Balans o'zgartirish</h3>

      @if(session('success'))
        <div style="background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.3);border-radius:var(--radius);padding:10px 14px;margin-bottom:16px">
          <p style="color:#86efac;font-size:13px">{{ session('success') }}</p>
        </div>
      @endif

      @if($errors->any())
        <div style="background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);border-radius:var(--radius);padding:10px 14px;margin-bottom:16px">
          @foreach($errors->all() as $error)
            <p style="color:#fca5a5;font-size:13px">{{ $error }}</p>
          @endforeach
        </div>
      @endif

      <form action="" method="POST" class="adjust-form" id="adjustForm">
        @csrf
        <div class="form-group">
          <label>Foydalanuvchi ID</label>
          <input type="number" name="user_id" id="adjustUserId" required min="1" placeholder="Masalan: 12" value="{{ old('user_id') }}">
        </div>
        <div class="form-group">
          <label>Miqdor</label>
          <input type="number" name="amount" required min="1" placeholder="100" value="{{ old('amount') }}">
        </div>
        <div class="form-group">
          <label>Turi</label>
          <select name="type" required>
            <option value="earned" {{ old('type') == 'earned' ? 'selected' : '' }}>Qo'shish (earned)</option>
            <option value="spent" {{ old('type') == 'spent' ? 'selected' : '' }}>Ayirish (spent)</option>
          </select>
        </div>
        <div class="form-group" style="flex:2">
          <label>Izoh</label>
          <input type="text" name="description" required maxlength="255" placeholder="Sabab yozing..." value="{{ old('description') }}">
        </div>
        <button type="submit" class="btn btn-primary" style="height:42px;padding:0 20px">Tasdiqlash</button>
      </form>
    </div>

    <script>
      document.getElementById('adjustForm').addEventListener('submit', function() {
        const userId = document.getElementById('adjustUserId').value;
        this.action = '/admin/greencoin/users/' + userId + '/adjust';
      });
    </script>

    {{-- Transactions Table --}}
    <div class="table-responsive">
      <table class="admin-table">
        <thead>
          <tr>
            <th>Foydalanuvchi</th>
            <th>Miqdor</th>
            <th>Turi</th>
            <th>Izoh</th>
            <th>Sana</th>
          </tr>
        </thead>
        <tbody>
          @forelse($transactions as $tx)
          <tr>
            <td style="font-weight:600;color:#fff">{{ $tx->user->name }}</td>
            <td style="font-weight:700;{{ $tx->type === 'earned' ? 'color:#4ade80' : 'color:#f87171' }}">
              {{ $tx->type === 'earned' ? '+' : '-' }}{{ number_format($tx->amount) }}
            </td>
            <td>
              @if($tx->type === 'earned')
                <span class="badge badge-earned">Earned</span>
              @else
                <span class="badge badge-spent">Spent</span>
              @endif
            </td>
            <td>{{ $tx->description }}</td>
            <td>{{ \Carbon\Carbon::parse($tx->created_at)->format('d.m.Y H:i') }}</td>
          </tr>
          @empty
          <tr><td colspan="5" style="text-align:center;color:var(--muted);padding:32px">Tranzaksiyalar topilmadi</td></tr>
          @endforelse
        </tbody>
      </table>
    </div>
    <div style="margin-top:20px">{{ $transactions->links() }}</div>
  </div>
</div>
@endsection
