@extends('layouts.app')
@section('title', 'Telegram topshiriq tafsilotlari | Admin')
@section('styles')
<style>
.form-card{background:var(--surface);border:1px solid var(--border);border-radius:18px;padding:24px}
.form-card h2{font-size:22px;font-weight:800;color:#fff;margin-bottom:16px}
.detail-row{display:grid;grid-template-columns:minmax(140px,1fr) 1.8fr;gap:16px;margin-bottom:14px}
.detail-row label{font-size:12px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.7px}
.detail-row span{font-size:14px;color:#fff}
.text-block{background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:14px;padding:16px;color:#e2e8f0;white-space:pre-wrap}
.button-group{display:flex;gap:10px;margin-top:22px}
</style>
@endsection
@section('content')
<div class="container">
  <a href="{{ route('admin.telegram-submissions.index') }}" class="back-link">← Barcha Telegram topshiriqlari</a>
  <div class="form-card" style="margin-top:18px">
    <h2>Topshiriq #{{ $submission->id }}</h2>
    <div class="detail-row"><label>Foydalanuvchi</label><span>{{ $submission->user->name ?? 'Noma' }} ({{ $submission->user->phone ?? 'Noma' }})</span></div>
    <div class="detail-row"><label>Vazifa</label><span>{{ $submission->task->title ?? 'Noma' }}</span></div>
    <div class="detail-row"><label>Batafsil</label><div class="text-block">{{ $submission->payload['text'] ?? 'Ma'lumot yo'q' }}</div></div>
    <div class="detail-row"><label>Status</label><span>{{ ucfirst($submission->status) }}</span></div>
    <div class="detail-row"><label>Reward</label><span>{{ $submission->reward_amount }} GC</span></div>
    <div class="detail-row"><label>Sharh</label><span>{{ $submission->notes ?? 'Yo‘q' }}</span></div>
    <div class="detail-row"><label>Yuborilgan</label><span>{{ $submission->created_at->format('d.m.Y H:i') }}</span></div>
    <div class="button-group">
      @if($submission->status === 'pending')
      <form action="{{ route('admin.telegram-submissions.approve', $submission) }}" method="POST">@csrf<button class="btn btn-success">Tasdiqlash</button></form>
      <form action="{{ route('admin.telegram-submissions.reject', $submission) }}" method="POST">@csrf<button class="btn btn-danger">Rad etish</button></form>
      @endif
    </div>
  </div>
</div>
@endsection
