@extends('layouts.app')
@section('title', 'Telegram topshiriq yuborishlari | Admin')
@section('styles')
<style>
.admin-header{padding:32px 0;display:flex;justify-content:space-between;align-items:center}
.admin-header h1{font-size:22px;font-weight:800;color:#fff}
.admin-table{width:100%;border-collapse:collapse}
.admin-table th{text-align:left;padding:12px 14px;font-size:12px;text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid var(--border)}
.admin-table td{padding:14px;border-bottom:1px solid var(--border);font-size:14px}
.actions-cell{display:flex;gap:6px}
.badge{padding:3px 8px;border-radius:999px;font-size:11px;font-weight:600}
.badge-green{background:rgba(22,163,74,.1);color:#4ade80}
.badge-red{background:rgba(220,38,38,.1);color:#fca5a5}
.badge-yellow{background:rgba(245,158,11,.12);color:#fbbf24}
</style>
@endsection
@section('content')
<div class="container">
  <div class="admin-header">
    <h1>Telegram topshiriq yuborishlari</h1>
  </div>
  <table class="admin-table">
    <thead><tr><th>ID</th><th>Foydalanuvchi</th><th>Vazifa</th><th>Miqdor</th><th>Holat</th><th>Amallar</th></tr></thead>
    <tbody>
      @forelse($submissions as $submission)
      <tr>
        <td>#{{ $submission->id }}</td>
        <td>{{ $submission->user->name ?? 'Noma' }}</td>
        <td>{{ $submission->task->title ?? 'Noma' }}</td>
        <td>{{ $submission->reward_amount }} GC</td>
        <td><span class="badge {{ $submission->status == 'approved' ? 'badge-green' : ($submission->status == 'pending' ? 'badge-yellow' : 'badge-red') }}">{{ ucfirst($submission->status) }}</span></td>
        <td><div class="actions-cell">
          <a href="{{ route('admin.telegram-submissions.show', $submission) }}" class="btn btn-outline" style="padding:6px 10px;font-size:11px">Ko'rish</a>
        </div></td>
      </tr>
      @empty
      <tr><td colspan="6" style="color:var(--muted);text-align:center;padding:20px">Hozircha topshiriqlar mavjud emas.</td></tr>
      @endforelse
    </tbody>
  </table>
  {{ $submissions->links() }}
</div>
@endsection
