﻿@extends('layouts.app')
@section('title', 'Admin Panel | AMBARELLA CRM')
@section('styles')
<style>
*{box-sizing:border-box}
.adm-wrap{display:flex;min-height:calc(100vh - 70px);background:#06090f}
/* ── Sidebar ── */
.adm-sb{
  width:250px;flex-shrink:0;
  background:rgba(255,255,255,.01);
  border-right:1px solid rgba(255,255,255,.04);
  padding:16px 0;
  position:sticky;top:70px;
  height:calc(100vh - 70px);
  overflow-y:auto;
}
.adm-sb::-webkit-scrollbar{width:0}
.adm-brand{padding:14px 16px 18px;margin:0 10px 14px;border-radius:14px;background:linear-gradient(135deg,rgba(37,99,235,.1),rgba(124,58,237,.06));border:1px solid rgba(37,99,235,.15);display:flex;align-items:center;gap:10px}
.adm-brand-icon{width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,#2563eb,#7c3aed);display:flex;align-items:center;justify-content:center;flex-shrink:0}
.adm-brand-icon svg{width:18px;height:18px;stroke:#fff;fill:none;stroke-width:2}
.adm-brand-t{font-size:13px;font-weight:800;color:#fff}
.adm-brand-s{font-size:10px;color:#334155;margin-top:1px}
/* Nav */
.adm-nav{padding:0 10px}
.adm-st{font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:2px;color:#1e293b;padding:8px 12px;margin-top:6px}
.adm-nl{display:flex;align-items:center;gap:9px;padding:9px 12px;border-radius:10px;font-size:12px;font-weight:500;color:#334155;transition:all .2s;margin-bottom:1px;position:relative}
.adm-nl:hover{background:rgba(255,255,255,.04);color:#94a3b8}
.adm-nl.on{background:rgba(37,99,235,.08);color:#93c5fd;border:1px solid rgba(37,99,235,.12)}
.adm-nl svg{width:15px;height:15px;stroke:currentColor;fill:none;stroke-width:1.8;flex-shrink:0}
.adm-badge{margin-left:auto;font-size:9px;font-weight:700;padding:1px 6px;border-radius:999px;background:rgba(37,99,235,.15);color:#93c5fd}
.adm-badge.red{background:rgba(239,68,68,.15);color:#fca5a5}
/* ── Main ── */
.adm-main{flex:1;min-width:0;padding:24px 28px 80px;overflow-y:auto}
/* ── Mobile quick nav ── */
.adm-mob-nav{display:none;overflow-x:auto;gap:8px;padding:12px 16px;background:rgba(6,9,15,.95);border-bottom:1px solid rgba(255,255,255,.04);-webkit-overflow-scrolling:touch;scrollbar-width:none}
.adm-mob-nav::-webkit-scrollbar{display:none}
.amn{display:inline-flex;align-items:center;gap:6px;padding:7px 13px;border-radius:10px;font-size:11px;font-weight:600;color:#334155;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.05);white-space:nowrap;flex-shrink:0;transition:all .2s}
.amn:hover,.amn.on{color:#93c5fd;border-color:rgba(37,99,235,.2);background:rgba(37,99,235,.06)}
.amn svg{width:13px;height:13px;stroke:currentColor;fill:none;stroke-width:2}
/* ── Top ── */
.adm-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;flex-wrap:wrap;gap:12px}
.adm-top h1{font-size:clamp(18px,3vw,22px);font-weight:900;color:#fff}
.adm-top p{font-size:12px;color:#1e293b;margin-top:3px}
.adm-date{display:flex;align-items:center;gap:6px;font-size:12px;color:#1e293b;padding:8px 14px;border-radius:10px;border:1px solid rgba(255,255,255,.04);background:rgba(255,255,255,.02)}
.adm-date svg{width:13px;height:13px;stroke:currentColor;fill:none;stroke-width:2}
</style>
<style>
/* ── Stats ── */
.adm-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:22px}
.ast{background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.05);border-radius:16px;padding:20px;position:relative;overflow:hidden;transition:all .3s}
.ast:hover{border-color:var(--ac);background:color-mix(in srgb,var(--ac) 3%,transparent);transform:translateY(-2px)}
.ast::after{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:var(--ac)}
.ast-ic{width:38px;height:38px;border-radius:10px;display:flex;align-items:center;justify-content:center;margin-bottom:10px;background:color-mix(in srgb,var(--ac) 10%,transparent)}
.ast-ic svg{width:18px;height:18px;stroke:var(--ac);fill:none;stroke-width:2}
.ast-n{font-size:28px;font-weight:900;color:var(--ac);line-height:1}
.ast-l{font-size:10px;color:#1e293b;margin-top:4px;font-weight:600;text-transform:uppercase;letter-spacing:.5px}
.ast-m{font-size:11px;color:#4ade80;margin-top:6px;display:flex;align-items:center;gap:4px}
.ast-m svg{width:11px;height:11px;stroke:currentColor;fill:none;stroke-width:2}
/* ── Quick Actions ── */
.adm-qa{display:grid;grid-template-columns:repeat(6,1fr);gap:12px;margin-bottom:22px}
.aq{display:flex;flex-direction:column;align-items:center;gap:7px;padding:16px 8px;background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.05);border-radius:14px;font-size:11px;font-weight:600;color:#334155;transition:all .25s;text-align:center}
.aq:hover{border-color:var(--aqc,rgba(37,99,235,.3));color:#94a3b8;background:rgba(255,255,255,.04);transform:translateY(-2px)}
.aq svg{width:20px;height:20px;stroke:var(--aqc,#475569);fill:none;stroke-width:1.8;transition:filter .2s}
.aq:hover svg{filter:drop-shadow(0 2px 6px var(--aqc,#2563eb))}
/* ── Grid ── */
.adm-grid{display:grid;grid-template-columns:1.6fr 1fr;gap:18px}
.adm-panel{background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.05);border-radius:16px;padding:20px;transition:border-color .3s}
.adm-panel:hover{border-color:rgba(37,99,235,.1)}
.aph{font-size:13px;font-weight:700;color:#fff;margin-bottom:14px;display:flex;align-items:center;gap:8px}
.aph svg{width:15px;height:15px;stroke:#60a5fa;fill:none;stroke-width:2}
.aph a{margin-left:auto;font-size:11px;color:#1e293b;transition:color .2s}
.aph a:hover{color:#60a5fa}
/* Table */
.adm-tbl{width:100%;border-collapse:collapse;font-size:12px}
.adm-tbl th{text-align:left;padding:8px 12px;color:#1e293b;font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.8px;border-bottom:1px solid rgba(255,255,255,.04)}
.adm-tbl td{padding:10px 12px;color:#64748b;border-bottom:1px solid rgba(255,255,255,.03)}
.adm-tbl tr:last-child td{border:none}
.adm-tbl tr:hover td{background:rgba(255,255,255,.015);color:#94a3b8}
.adm-tbl td.nm{color:#fff;font-weight:600}
.tbl-wrap{overflow-x:auto;-webkit-overflow-scrolling:touch}
/* Badges */
.ubadge{display:inline-flex;align-items:center;gap:3px;padding:2px 8px;border-radius:999px;font-size:9px;font-weight:700}
.ub-admin{background:rgba(37,99,235,.12);color:#93c5fd}
.ub-active{background:rgba(34,197,94,.1);color:#4ade80}
.ub-banned{background:rgba(239,68,68,.1);color:#fca5a5}
.ub-user{background:rgba(255,255,255,.04);color:#334155}
.udot{width:5px;height:5px;border-radius:50%;display:inline-block}
/* Right panels */
.adm-right{display:flex;flex-direction:column;gap:16px}
.adm-health-row{display:flex;justify-content:space-between;align-items:center;padding:9px 0;border-bottom:1px solid rgba(255,255,255,.04);font-size:12px}
.adm-health-row:last-child{border:none}
.ahr-lbl{color:#334155;display:flex;align-items:center;gap:7px}
.ahr-lbl svg{width:13px;height:13px;stroke:currentColor;fill:none;stroke-width:2}
.ahr-val{font-weight:700}
.mod-row{display:flex;justify-content:space-between;align-items:center;padding:7px 0;border-bottom:1px solid rgba(255,255,255,.03);font-size:12px}
.mod-row:last-child{border:none}
.mod-nm{color:#fff;font-weight:600;font-size:12px}
.mod-on{display:inline-flex;align-items:center;gap:4px;font-size:9px;font-weight:700;color:#4ade80;background:rgba(34,197,94,.08);padding:2px 7px;border-radius:999px}
.mod-on::before{content:'';width:5px;height:5px;border-radius:50%;background:#4ade80}
/* Responsive */
@media(max-width:1200px){.adm-wrap{flex-direction:column}.adm-sb{display:none}.adm-mob-nav{display:flex}.adm-main{padding:20px 16px 80px}.adm-stats{grid-template-columns:1fr 1fr}.adm-qa{grid-template-columns:repeat(3,1fr)}.adm-grid{grid-template-columns:1fr}}
@media(max-width:640px){.adm-stats{grid-template-columns:1fr 1fr}.adm-qa{grid-template-columns:repeat(3,1fr)}.adm-top{flex-direction:column;align-items:flex-start}.adm-date{display:none}}
@media(max-width:400px){.adm-qa{grid-template-columns:1fr 1fr}}
</style>
@endsection
@section('content')

{{-- Mobile nav --}}
<div class="adm-mob-nav">
  <a href="/admin" class="amn on"><svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>Dashboard</a>
  <a href="/admin/users" class="amn"><svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>Userlar</a>
  <a href="/admin/jobs" class="amn"><svg viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/></svg>Ishlar</a>
  <a href="/admin/news" class="amn"><svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/></svg>Yangilik</a>
  <a href="/admin/courses" class="amn"><svg viewBox="0 0 24 24"><path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z"/></svg>Kurslar</a>
  <a href="/admin/eco-tasks" class="amn"><svg viewBox="0 0 24 24"><path d="M12 22c4-2.5 7-6 7-10a7 7 0 00-14 0c0 4 3 7.5 7 10z"/></svg>Eco</a>
  <a href="/admin/stats" class="amn"><svg viewBox="0 0 24 24"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>Stats</a>
  <a href="/admin/greencoin" class="amn"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 6v12M8 10h8"/></svg>GreenCoin</a>
  <a href="/admin/contacts" class="amn"><svg viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/></svg>Xabar</a>
  <a href="/admin/activity-log" class="amn"><svg viewBox="0 0 24 24"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>Log</a>
</div>

<div class="adm-wrap">
{{-- ── SIDEBAR ── --}}
<aside class="adm-sb">
  <div class="adm-brand">
    <div class="adm-brand-icon"><svg viewBox="0 0 24 24"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg></div>
    <div><div class="adm-brand-t">AMBARELLA</div><div class="adm-brand-s">Admin CRM Panel</div></div>
  </div>
  <div class="adm-nav">
    <div class="adm-st">Boshqaruv</div>
    <a href="/admin" class="adm-nl on"><svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>Dashboard</a>
    <a href="/admin/stats" class="adm-nl"><svg viewBox="0 0 24 24"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>Statistika</a>
    <a href="/admin/activity-log" class="adm-nl"><svg viewBox="0 0 24 24"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>Activity Log</a>
    <div class="adm-st">Foydalanuvchilar</div>
    <a href="/admin/users" class="adm-nl"><svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>Userlar <span class="adm-badge">{{ number_format($stats['users']) }}</span></a>
    <a href="/admin/moderation" class="adm-nl"><svg viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>Moderatsiya</a>
    <a href="/admin/applications" class="adm-nl"><svg viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/></svg>Arizalar</a>
    <div class="adm-st">Kontent</div>
    <a href="/admin/jobs" class="adm-nl"><svg viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/></svg>Ish e'lonlari <span class="adm-badge" style="background:rgba(34,197,94,.1);color:#4ade80">{{ $stats['jobs'] }}</span></a>
    <a href="/admin/news" class="adm-nl"><svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/></svg>Yangiliklar</a>
    <a href="/admin/courses" class="adm-nl"><svg viewBox="0 0 24 24"><path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z"/><path d="M22 3h-6a4 4 0 00-4 4v14a3 3 0 013-3h7z"/></svg>Kurslar <span class="adm-badge">{{ $stats['courses'] }}</span></a>
    <a href="/admin/eco-tasks" class="adm-nl"><svg viewBox="0 0 24 24"><path d="M12 22c4-2.5 7-6 7-10a7 7 0 00-14 0c0 4 3 7.5 7 10z"/></svg>Eco vazifalar</a>
    <a href="/admin/mentors" class="adm-nl"><svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="7"/><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/></svg>Mentorlar</a>
    <a href="/admin/events" class="adm-nl"><svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/></svg>Tadbirlar</a>
    <a href="/admin/farm" class="adm-nl"><svg viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/></svg>Mahsulotlar</a>
    <div class="adm-st">Tizim</div>
    <a href="/admin/greencoin" class="adm-nl"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 6v12M8 10h8"/></svg>GreenCoin</a>
    <a href="/admin/contacts" class="adm-nl"><svg viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/></svg>Xabarlar <span class="adm-badge red">!</span></a>
    <a href="/admin/announcements" class="adm-nl"><svg viewBox="0 0 24 24"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>E'lonlar</a>
    <a href="/admin/faq" class="adm-nl"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 015.83 1c0 2-3 3-3 3"/></svg>FAQ</a>
    <a href="/admin/banners" class="adm-nl"><svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/></svg>Bannerlar</a>
    <a href="/admin/export/users" class="adm-nl"><svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>CSV Export</a>
  </div>
</aside>

{{-- ── MAIN ── --}}
<main class="adm-main">
  <div class="adm-top">
    <div>
      <h1>Admin Dashboard</h1>
      <p>CRM/LMS boshqaruv paneli — barcha modullar nazoratda</p>
    </div>
    <div class="adm-date"><svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>{{ now()->format('d M Y, l') }}</div>
  </div>

  {{-- Stats --}}
  <div class="adm-stats">
    <div class="ast" style="--ac:#60a5fa">
      <div class="ast-ic"><svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/></svg></div>
      <div class="ast-n">{{ number_format($stats['users']) }}</div>
      <div class="ast-l">Foydalanuvchilar</div>
      <div class="ast-m"><svg viewBox="0 0 24 24"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/></svg>+{{ $stats['today_users'] ?? 0 }} bugun</div>
    </div>
    <div class="ast" style="--ac:#4ade80">
      <div class="ast-ic"><svg viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/></svg></div>
      <div class="ast-n">{{ $stats['jobs'] }}</div>
      <div class="ast-l">Ish e'lonlari</div>
      <div class="ast-m"><svg viewBox="0 0 24 24"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/></svg>{{ $stats['active_jobs'] ?? $stats['jobs'] }} faol</div>
    </div>
    <div class="ast" style="--ac:#fbbf24">
      <div class="ast-ic"><svg viewBox="0 0 24 24"><path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z"/><path d="M22 3h-6a4 4 0 00-4 4v14a3 3 0 013-3h7z"/></svg></div>
      <div class="ast-n">{{ $stats['courses'] }}</div>
      <div class="ast-l">Kurslar</div>
      <div class="ast-m" style="color:#475569">ta'lim moduli</div>
    </div>
    <div class="ast" style="--ac:#a78bfa">
      <div class="ast-ic"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 6v12M8 10h8"/></svg></div>
      <div class="ast-n">{{ number_format($stats['coins_total']) }}</div>
      <div class="ast-l">GreenCoin</div>
      <div class="ast-m"><svg viewBox="0 0 24 24"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/></svg>jami ishlab chiqildi</div>
    </div>
  </div>

  {{-- Quick Actions --}}
  <div class="adm-qa">
    <a href="/admin/jobs/create" class="aq" style="--aqc:#4ade80"><svg viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/><line x1="12" y1="11" x2="12" y2="17"/><line x1="9" y1="14" x2="15" y2="14"/></svg>Yangi ish</a>
    <a href="/admin/news/create" class="aq" style="--aqc:#ec4899"><svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="12" y1="12" x2="12" y2="18"/></svg>Yangi yangilik</a>
    <a href="/admin/courses/create" class="aq" style="--aqc:#fbbf24"><svg viewBox="0 0 24 24"><path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z"/><path d="M22 3h-6a4 4 0 00-4 4v14a3 3 0 013-3h7z"/></svg>Yangi kurs</a>
    <a href="/admin/eco-tasks/create" class="aq" style="--aqc:#22d3ee"><svg viewBox="0 0 24 24"><path d="M12 22c4-2.5 7-6 7-10a7 7 0 00-14 0c0 4 3 7.5 7 10z"/><line x1="12" y1="9" x2="12" y2="15"/><line x1="9" y1="12" x2="15" y2="12"/></svg>Eco vazifa</a>
    <a href="/admin/events/create" class="aq" style="--aqc:#8b5cf6"><svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="12" y1="11" x2="12" y2="17"/><line x1="9.5" y1="14" x2="14.5" y2="14"/></svg>Yangi tadbir</a>
    <a href="/admin/announcements" class="aq" style="--aqc:#f97316"><svg viewBox="0 0 24 24"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>E'lon qo'shish</a>
  </div>

  {{-- Main grid --}}
  <div class="adm-grid">
    {{-- Users table --}}
    <div class="adm-panel">
      <div class="aph"><svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>So'nggi foydalanuvchilar<a href="/admin/users">Hammasi →</a></div>
      <div class="tbl-wrap">
        <table class="adm-tbl">
          <thead><tr><th>Foydalanuvchi</th><th>Email</th><th>Sana</th><th>Rol</th><th>Holat</th></tr></thead>
          <tbody>
            @foreach($recentUsers as $u)
            <tr>
              <td class="nm" style="display:flex;align-items:center;gap:8px">
                <span style="width:26px;height:26px;border-radius:50%;background:rgba(37,99,235,.15);display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:800;color:#93c5fd;flex-shrink:0">{{ strtoupper(mb_substr($u->name,0,1)) }}</span>
                {{ $u->name }}
              </td>
              <td style="max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">{{ $u->email }}</td>
              <td style="white-space:nowrap">{{ $u->created_at->format('d.m.Y') }}</td>
              <td><span class="ubadge {{ $u->role==='admin'?'ub-admin':'ub-user' }}">{{ $u->role }}</span></td>
              <td><span class="ubadge {{ ($u->is_banned??false)?'ub-banned':'ub-active' }}"><span class="udot" style="background:{{ ($u->is_banned??false)?'#f87171':'#4ade80' }}"></span>{{ ($u->is_banned??false)?'Banned':'Active' }}</span></td>
            </tr>
            @endforeach
          </tbody>
        </table>
      </div>
    </div>

    {{-- Right --}}
    <div class="adm-right">
      {{-- Health --}}
      <div class="adm-panel">
        <div class="aph"><svg viewBox="0 0 24 24"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>Platforma holati</div>
        <div class="adm-health-row"><span class="ahr-lbl"><svg viewBox="0 0 24 24"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>Server</span><span class="ahr-val" style="color:#4ade80">● Online</span></div>
        <div class="adm-health-row"><span class="ahr-lbl"><svg viewBox="0 0 24 24"><path d="M12 2L2 7l10 5 10-5-10-5z"/></svg>Laravel</span><span class="ahr-val" style="color:#60a5fa">v12.64.0</span></div>
        <div class="adm-health-row"><span class="ahr-lbl"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/></svg>PHP</span><span class="ahr-val" style="color:#a78bfa">8.4.22</span></div>
        <div class="adm-health-row"><span class="ahr-lbl"><svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/></svg>Modullar</span><span class="ahr-val" style="color:#fbbf24">35+</span></div>
        @if(isset($stats['banned_users']) && $stats['banned_users'] > 0)
        <div class="adm-health-row"><span class="ahr-lbl"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg>Bloklangan</span><span class="ahr-val" style="color:#f87171">{{ $stats['banned_users'] }}</span></div>
        @endif
      </div>
      {{-- Modules --}}
      <div class="adm-panel">
        <div class="aph"><svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>Modul statusi</div>
        @foreach(['Bandlik','Ekologiya','Academy','Mentorlik','Forum','Startup','GreenCoin'] as $mod)
        <div class="mod-row"><span class="mod-nm">{{ $mod }}</span><span class="mod-on">Faol</span></div>
        @endforeach
      </div>
    </div>
  </div>
</main>
</div>
@endsection
