@extends('layouts.app')
@section('title', 'Tadbirlar | Admin')
@section('styles')
<style>
.admin-page{padding:32px 0}
.admin-page-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px}
.admin-page-header h1{font-size:22px;font-weight:800;color:#fff}
.admin-page-header p{font-size:13px;color:var(--muted);margin-top:4px}
.admin-table{width:100%;border-collapse:collapse;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden}
.admin-table th{text-align:left;padding:12px 14px;font-size:11px;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);border-bottom:1px solid var(--border)}
.admin-table td{padding:14px;border-bottom:1px solid var(--border);font-size:14px;color:#cbd5e1}
.admin-table tr:last-child td{border:none}
.badge{padding:3px 10px;border-radius:999px;font-size:11px;font-weight:600;display:inline-block}
.badge-hackathon{background:rgba(99,102,241,.15);color:#a5b4fc}
.badge-webinar{background:rgba(14,165,233,.15);color:#7dd3fc}
.badge-meetup{background:rgba(16,185,129,.15);color:#6ee7b7}
.badge-conference{background:rgba(249,115,22,.15);color:#fdba74}
.badge-active{background:rgba(34,197,94,.15);color:#86efac}
.badge-inactive{background:rgba(239,68,68,.15);color:#fca5a5}
.actions-cell{display:flex;gap:6px;align-items:center}
.action-btn{padding:6px 10px;font-size:11px;border-radius:var(--radius);border:1px solid var(--border);background:transparent;color:#cbd5e1;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;transition:all .2s}
.action-btn:hover{border-color:rgba(37,99,235,.4);color:#fff}
.action-btn.danger{color:var(--danger)}
.action-btn.danger:hover{border-color:rgba(239,68,68,.4)}
.table-responsive{overflow-x:auto;border-radius:var(--radius)}
@media(max-width:768px){.admin-page-header{flex-direction:column;align-items:flex-start;gap:12px}}
</style>
@endsection
@section('content')
<div class="container">
  <div class="admin-page">
    <div class="admin-page-header">
      <div>
        <h1>Tadbirlar boshqaruvi</h1>
        <p>Barcha tadbirlarni ko'rish va boshqarish</p>
      </div>
      <a href="/admin/events/create" class="btn btn-primary">+ Yangi tadbir</a>
    </div>
    <div class="table-responsive">
      <table class="admin-table">
        <thead>
          <tr>
            <th>Nomi</th>
            <th>Turi</th>
            <th>Sana</th>
            <th>Joylashuv</th>
            <th>Holati</th>
            <th>Amallar</th>
          </tr>
        </thead>
        <tbody>
          @forelse($events as $event)
          <tr>
            <td style="font-weight:600;color:#fff">{{ $event->title }}</td>
            <td><span class="badge badge-{{ $event->type }}">{{ $event->type }}</span></td>
            <td>{{ \Carbon\Carbon::parse($event->date)->format('d.m.Y') }}</td>
            <td>{{ $event->location }}</td>
            <td>
              @if($event->is_active)
                <span class="badge badge-active">Faol</span>
              @else
                <span class="badge badge-inactive">Nofaol</span>
              @endif
            </td>
            <td>
              <div class="actions-cell">
                <a href="/admin/events/{{ $event->id }}/edit" class="action-btn">Tahrir</a>
                <form action="/admin/events/{{ $event->id }}" method="POST" onsubmit="return confirm('O\'chirmoqchimisiz?')">
                  @csrf
                  @method('DELETE')
                  <button type="submit" class="action-btn danger">🗑️</button>
                </form>
              </div>
            </td>
          </tr>
          @empty
          <tr><td colspan="6" style="text-align:center;color:var(--muted);padding:32px">Tadbirlar topilmadi</td></tr>
          @endforelse
        </tbody>
      </table>
    </div>
    <div style="margin-top:20px">{{ $events->links() }}</div>
  </div>
</div>
@endsection
