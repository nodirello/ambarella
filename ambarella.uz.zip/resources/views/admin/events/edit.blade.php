@extends('layouts.app')
@section('title', 'Tadbirni tahrirlash | Admin')
@section('styles')
<style>
.form-page{padding:48px 0;max-width:560px;margin:0 auto}
.form-page h1{font-size:22px;font-weight:800;color:#fff;margin-bottom:8px}
.form-page .desc{font-size:13px;color:var(--muted);margin-bottom:32px}
.form-group{margin-bottom:20px}
.form-group label{display:block;font-size:13px;font-weight:600;color:#94a3b8;margin-bottom:6px}
.form-group input,.form-group select,.form-group textarea{width:100%;padding:12px 16px;border-radius:var(--radius);border:1px solid var(--border);background:var(--surface);color:#fff;font-size:14px}
.form-group textarea{resize:vertical;min-height:100px}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.form-check{display:flex;align-items:center;gap:10px;margin-bottom:20px}
.form-check input[type="checkbox"]{width:18px;height:18px;accent-color:#2563eb}
.form-check label{font-size:13px;color:#94a3b8;margin-bottom:0}
</style>
@endsection
@section('content')
<div class="container"><div class="form-page">
  <h1>Tadbirni tahrirlash</h1>
  <p class="desc">Tadbir ma'lumotlarini yangilang</p>

  @if($errors->any())
    <div style="background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);border-radius:var(--radius);padding:12px;margin-bottom:20px">
      @foreach($errors->all() as $error)
        <p style="color:#fca5a5;font-size:13px;margin:2px 0">{{ $error }}</p>
      @endforeach
    </div>
  @endif

  <form action="/admin/events/{{ $event->id }}" method="POST">
    @csrf
    @method('PUT')
    <div class="form-group">
      <label>Tadbir nomi</label>
      <input type="text" name="title" required maxlength="255" value="{{ $event->title }}">
    </div>
    <div class="form-group">
      <label>Tavsif</label>
      <textarea name="description" maxlength="2000">{{ $event->description }}</textarea>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label>Turi</label>
        <select name="type" required>
          @foreach(['hackathon','webinar','meetup','conference'] as $type)
          <option value="{{ $type }}" {{ $event->type == $type ? 'selected' : '' }}>{{ ucfirst($type) }}</option>
          @endforeach
        </select>
      </div>
      <div class="form-group">
        <label>Sana</label>
        <input type="date" name="date" required value="{{ $event->date }}">
      </div>
    </div>
    <div class="form-group">
      <label>Joylashuv</label>
      <input type="text" name="location" required maxlength="255" value="{{ $event->location }}">
    </div>
    <div class="form-check">
      <input type="checkbox" name="is_active" id="is_active" value="1" {{ $event->is_active ? 'checked' : '' }}>
      <label for="is_active">Faol holat</label>
    </div>
    <button type="submit" class="btn btn-success">Saqlash</button>
    <a href="/admin/events" class="btn btn-outline" style="margin-left:8px">Bekor</a>
  </form>
</div></div>
@endsection
