@extends('layouts.app')
@section('title', 'FAQ tahrirlash | Admin')
@section('styles')
<style>
.form-page{padding:48px 0;max-width:720px;margin:0 auto}
.form-page h1{font-size:22px;font-weight:800;color:#fff;margin-bottom:32px}
.form-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:32px}
.form-group{margin-bottom:18px}
.form-group label{display:block;font-size:13px;font-weight:600;color:#94a3b8;margin-bottom:6px}
.form-group input,.form-group select,.form-group textarea{width:100%;padding:12px 16px;border:1px solid var(--border);border-radius:var(--radius);font-size:14px;background:rgba(255,255,255,.02);color:#fff;font-family:inherit}
.form-group input::placeholder,.form-group textarea::placeholder{color:#475569}
.form-group textarea{resize:vertical;min-height:100px}
.back-link{display:inline-flex;align-items:center;gap:6px;color:var(--muted);font-size:13px;margin-bottom:20px;transition:color .2s}
.back-link:hover{color:#fff}
.tabs{display:flex;gap:0;margin-bottom:24px;border-bottom:1px solid var(--border)}
.tab-btn{padding:10px 20px;font-size:13px;font-weight:600;color:var(--muted);cursor:pointer;border:none;background:none;border-bottom:2px solid transparent;transition:all .2s}
.tab-btn.active{color:#93c5fd;border-bottom-color:#3b82f6}
.tab-content{display:none}
.tab-content.active{display:block}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.checkbox-group{display:flex;align-items:center;gap:10px}
.checkbox-group input[type="checkbox"]{width:18px;height:18px;accent-color:#3b82f6}
.checkbox-group label{margin-bottom:0;font-size:14px;color:#fff}
</style>
@endsection
@section('content')
<div class="container">
  <div class="form-page">
    <a href="/admin/faq" class="back-link">← Barcha FAQ</a>
    <h1>FAQ tahrirlash</h1>
    <form method="POST" action="/admin/faq/{{ $faq->id }}" class="form-card">
      @csrf
      @method('PUT')
      <div class="tabs">
        <button type="button" class="tab-btn active" onclick="switchTab('uz')">🇺🇿 O'zbek</button>
        <button type="button" class="tab-btn" onclick="switchTab('ru')">🇷🇺 Русский</button>
        <button type="button" class="tab-btn" onclick="switchTab('en')">🇬🇧 English</button>
      </div>

      <div class="tab-content active" id="tab-uz">
        <div class="form-group"><label>Savol (UZ) *</label><input name="question_uz" required value="{{ old('question_uz', $faq->question_uz) }}"></div>
        <div class="form-group"><label>Javob (UZ) *</label><textarea name="answer_uz" required>{{ old('answer_uz', $faq->answer_uz) }}</textarea></div>
      </div>

      <div class="tab-content" id="tab-ru">
        <div class="form-group"><label>Вопрос (RU)</label><input name="question_ru" value="{{ old('question_ru', $faq->question_ru) }}"></div>
        <div class="form-group"><label>Ответ (RU)</label><textarea name="answer_ru">{{ old('answer_ru', $faq->answer_ru) }}</textarea></div>
      </div>

      <div class="tab-content" id="tab-en">
        <div class="form-group"><label>Question (EN)</label><input name="question_en" value="{{ old('question_en', $faq->question_en) }}"></div>
        <div class="form-group"><label>Answer (EN)</label><textarea name="answer_en">{{ old('answer_en', $faq->answer_en) }}</textarea></div>
      </div>

      <div class="form-row">
        <div class="form-group"><label>Tartib raqami</label><input type="number" name="sort_order" value="{{ old('sort_order', $faq->sort_order) }}" min="0"></div>
        <div class="form-group" style="display:flex;align-items:flex-end">
          <div class="checkbox-group">
            <input type="checkbox" name="is_active" value="1" id="is_active" {{ old('is_active', $faq->is_active) ? 'checked' : '' }}>
            <label for="is_active">Faol</label>
          </div>
        </div>
      </div>

      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:14px">Yangilash</button>
    </form>
  </div>
</div>

<script>
function switchTab(lang) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
  event.target.classList.add('active');
  document.getElementById('tab-' + lang).classList.add('active');
}
</script>
@endsection
