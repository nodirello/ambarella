@extends('layouts.app')
@section('title', 'FAQ | Admin')
@section('styles')
<style>
.admin-page{padding:32px 0}
.admin-page-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;flex-wrap:wrap;gap:12px}
.admin-page-header h1{font-size:22px;font-weight:800;color:#fff}
.faq-list{display:flex;flex-direction:column;gap:12px}
.faq-item{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:20px;display:flex;justify-content:space-between;align-items:center;gap:16px;transition:all .2s}
.faq-item:hover{border-color:rgba(37,99,235,.3)}
.faq-item h3{font-size:15px;font-weight:600;color:#fff;margin-bottom:3px}
.faq-item p{font-size:12px;color:var(--muted)}
.faq-meta{display:flex;align-items:center;gap:8px;margin-top:4px}
.sort-badge{background:rgba(37,99,235,.1);color:#93c5fd;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600}
.status-badge{padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600}
.status-active{background:rgba(34,197,94,.1);color:#86efac}
.status-inactive{background:rgba(220,38,38,.1);color:#fca5a5}
.actions-cell{display:flex;gap:6px;flex-shrink:0}
.action-btn{padding:6px 12px;border-radius:6px;font-size:11px;font-weight:600;cursor:pointer;border:none;text-decoration:none;display:inline-block}
.action-edit{background:rgba(37,99,235,.1);color:#93c5fd}
.action-delete{background:rgba(220,38,38,.1);color:#fca5a5}
@media(max-width:768px){.faq-item{flex-direction:column;align-items:flex-start}.actions-cell{align-self:flex-end}}
</style>
@endsection
@section('content')
<div class="container">
  <div class="admin-page">
    <div class="admin-page-header">
      <h1>FAQ ({{ $faqs->total() }})</h1>
      <div style="display:flex;gap:10px">
        <a href="/admin" class="btn btn-outline" style="padding:8px 16px;font-size:12px">← Admin</a>
        <a href="/admin/faq/create" class="btn btn-primary" style="padding:8px 16px;font-size:12px">+ Yangi FAQ</a>
      </div>
    </div>
    <div class="faq-list">
      @foreach($faqs as $faq)
      <div class="faq-item">
        <div>
          <h3>{{ $faq->question_uz }}</h3>
          <p>{{ Str::limit($faq->answer_uz, 80) }}</p>
          <div class="faq-meta">
            <span class="sort-badge">Tartib: {{ $faq->sort_order }}</span>
            <span class="status-badge {{ $faq->is_active ? 'status-active' : 'status-inactive' }}">{{ $faq->is_active ? 'Faol' : 'Nofaol' }}</span>
          </div>
        </div>
        <div class="actions-cell">
          <a href="/admin/faq/{{ $faq->id }}/edit" class="action-btn action-edit">Tahrir</a>
          <form method="POST" action="/admin/faq/{{ $faq->id }}" onsubmit="return confirm('O\'chirilsinmi?')">@csrf @method('DELETE')<button class="action-btn action-delete">🗑️</button></form>
        </div>
      </div>
      @endforeach
    </div>
    <div style="margin-top:16px">{{ $faqs->links() }}</div>
  </div>
</div>
@endsection
