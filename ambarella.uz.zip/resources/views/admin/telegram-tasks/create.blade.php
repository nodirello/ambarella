@extends('layouts.app')
@section('title', 'Yangi Telegram vazifasi | Admin')
@section('content')
<div class="container">
  <div class="page-head" style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px">
    <h1>Yangi Telegram vazifasi</h1>
    <a href="{{ route('admin.telegram-tasks.index') }}" class="btn btn-secondary">Orqaga</a>
  </div>

  <form action="{{ route('admin.telegram-tasks.store') }}" method="POST" style="max-width:720px">
    @csrf
    <div class="mb-4">
      <label class="form-label">Sarlavha</label>
      <input type="text" name="title" value="{{ old('title') }}" class="form-control" required>
    </div>
    <div class="mb-4">
      <label class="form-label">Tavsif</label>
      <textarea name="description" class="form-control" rows="4" required>{{ old('description') }}</textarea>
    </div>
    <div class="grid gap-4 md:grid-cols-2">
      <div class="mb-4">
        <label class="form-label">Vazifa turi</label>
        <select name="task_type" class="form-control" required>
          <option value="action" {{ old('task_type') === 'action' ? 'selected' : '' }}>Eco harakat</option>
          <option value="quiz" {{ old('task_type') === 'quiz' ? 'selected' : '' }}>So'rovnoma / test</option>
          <option value="referral" {{ old('task_type') === 'referral' ? 'selected' : '' }}>Referral</option>
        </select>
      </div>
      <div class="mb-4">
        <label class="form-label">Mukofot (GreenCoin)</label>
        <input type="number" name="reward" value="{{ old('reward') }}" class="form-control" min="0" step="1" required>
      </div>
    </div>
    <div class="grid gap-4 md:grid-cols-2">
      <div class="mb-4">
        <label class="form-label">Faol</label>
        <select name="is_active" class="form-control" required>
          <option value="1" {{ old('is_active') == '1' ? 'selected' : '' }}>Ha</option>
          <option value="0" {{ old('is_active') == '0' ? 'selected' : '' }}>Yo'q</option>
        </select>
      </div>
      <div class="mb-4">
        <label class="form-label">Moderator ko'rib chiqishi kerak</label>
        <select name="requires_approval" class="form-control" required>
          <option value="0" {{ old('requires_approval') == '0' ? 'selected' : '' }}>Yo'q</option>
          <option value="1" {{ old('requires_approval') == '1' ? 'selected' : '' }}>Ha</option>
        </select>
      </div>
    </div>
    <button type="submit" class="btn btn-primary">Saqlash</button>
  </form>
</div>
@endsection
