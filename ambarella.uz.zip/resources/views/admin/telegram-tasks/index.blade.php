@extends('layouts.app')
@section('title', 'Telegram vazifalari | Admin')
@section('styles')
<style>
.page-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px}
.page-head h1{font-size:24px;font-weight:800;color:#fff}
.task-table{width:100%;border-collapse:collapse;font-size:13px}
.task-table th, .task-table td{padding:14px 12px;border-bottom:1px solid var(--border);}
.task-table th{color:var(--muted);text-transform:uppercase;font-size:11px;letter-spacing:.8px}
.task-table tr:hover td{background:rgba(255,255,255,.02)}
.badge{padding:4px 10px;border-radius:999px;font-size:11px}
.badge-active{background:rgba(34,197,94,.15);color:#4ade80}
.badge-no{background:rgba(220,38,38,.12);color:#fca5a5}
</style>
@endsection
@section('content')
<div class="container">
  <div class="page-head">
    <h1>Telegram vazifalari</h1>
    <a href="{{ route('admin.telegram-tasks.create') }}" class="btn btn-primary">Yangi vazifa</a>
  </div>
  <div style="overflow-x:auto;border:1px solid var(--border);border-radius:var(--radius)">
    <table class="task-table">
      <thead>
        <tr><th>ID</th><th>Sarlavha</th><th>Tip</th><th>Mukofot</th><th>Holat</th><th>Amallar</th></tr>
      </thead>
      <tbody>
        @forelse($tasks as $task)
        <tr>
          <td>{{ $task->id }}</td>
          <td>{{ $task->title }}</td>
          <td>{{ $task->task_type }}</td>
          <td>{{ $task->reward }} GC</td>
          <td><span class="badge {{ $task->is_active ? 'badge-active' : 'badge-no' }}">{{ $task->is_active ? 'Faol' : 'Faol emas' }}</span></td>
          <td>
            <a href="{{ route('admin.telegram-tasks.edit', $task) }}" class="btn btn-outline" style="font-size:12px;padding:8px 12px">Tahrir</a>
            <form action="{{ route('admin.telegram-tasks.destroy', $task) }}" method="POST" style="display:inline-block;margin-left:8px" onsubmit="return confirm('O‘chirishni tasdiqlaysizmi?')">
              @csrf
              @method('DELETE')
              <button type="submit" class="btn btn-danger" style="font-size:12px;padding:8px 12px">O‘chirish</button>
            </form>
          </td>
        </tr>
        @empty
        <tr><td colspan="6" style="color:var(--muted);padding:20px;text-align:center">Vazifa topilmadi.</td></tr>
        @endforelse
      </tbody>
    </table>
  </div>
  <div style="margin-top:16px">{{ $tasks->links() }}</div>
</div>
@endsection
