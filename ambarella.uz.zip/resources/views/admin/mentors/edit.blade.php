@extends('layouts.app')
@section('title', 'Mentor tahrirlash | Admin')
@section('styles')
<style>
.form-page{padding:48px 0;max-width:560px;margin:0 auto}
.form-page h1{font-size:22px;font-weight:800;color:#fff;margin-bottom:32px}
.form-group{margin-bottom:20px}
.form-group label{display:block;font-size:13px;font-weight:600;color:#94a3b8;margin-bottom:6px}
.form-group input,.form-group textarea{width:100%;padding:12px 16px;border-radius:var(--radius);border:1px solid var(--border);background:var(--surface);color:#fff;font-size:14px}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.hint{font-size:11px;color:var(--muted);margin-top:4px}
</style>
@endsection
@section('content')
<div class="container"><div class="form-page">
  <h1>Mentorni tahrirlash</h1>
  <form action="/admin/mentors/{{ $mentor->id }}" method="POST">
    @csrf @method('PUT')
    <div class="form-group"><label>Ism</label><input type="text" name="name" required maxlength="255" value="{{ $mentor->name }}"></div>
    <div class="form-row">
      <div class="form-group"><label>Lavozim</label><input type="text" name="role" required maxlength="100" value="{{ $mentor->role }}"></div>
      <div class="form-group"><label>Tajriba</label><input type="text" name="experience" required maxlength="100" value="{{ $mentor->experience }}"></div>
    </div>
    <div class="form-group"><label>Ko'nikmalar</label><input type="text" name="skills" required maxlength="500" value="{{ implode(',', $mentor->skills ?? []) }}"><p class="hint">Vergul bilan ajrating</p></div>
    <div class="form-group"><label>Reyting (1-5)</label><input type="number" name="rating" required min="1" max="5" step="0.1" value="{{ $mentor->rating }}"></div>
    <button type="submit" class="btn btn-success">Saqlash</button>
    <a href="/admin/mentors" class="btn btn-outline">Bekor</a>
  </form>
</div></div>
@endsection
