@extends('layouts.app')
@section('title', 'Mentorlar | Admin')
@section('styles')
<style>
.admin-header{padding:32px 0;display:flex;justify-content:space-between;align-items:center}
.admin-header h1{font-size:22px;font-weight:800;color:#fff}
.admin-table{width:100%;border-collapse:collapse}
.admin-table th{text-align:left;padding:12px 14px;font-size:12px;text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid var(--border)}
.admin-table td{padding:14px;border-bottom:1px solid var(--border);font-size:14px}
.actions-cell{display:flex;gap:6px}
.skills-tags span{padding:2px 6px;border-radius:999px;font-size:10px;background:rgba(124,58,237,.1);color:#a78bfa;margin-right:3px}
</style>
@endsection
@section('content')
<div class="container">
  <div class="admin-header">
    <h1>Mentorlar boshqaruvi</h1>
    <a href="/admin/mentors/create" class="btn btn-primary" style="background:var(--purple)">+ Yangi mentor</a>
  </div>
  <table class="admin-table">
    <thead><tr><th>Ism</th><th>Lavozim</th><th>Tajriba</th><th>Ko'nikmalar</th><th>Reyting</th><th>Amallar</th></tr></thead>
    <tbody>
      @foreach($mentors as $mentor)
      <tr>
        <td style="font-weight:600;color:#fff">{{ $mentor->name }}</td>
        <td>{{ $mentor->role }}</td>
        <td>{{ $mentor->experience }}</td>
        <td><div class="skills-tags">@foreach($mentor->skills ?? [] as $s)<span>{{ $s }}</span>@endforeach</div></td>
        <td style="color:var(--warning);font-weight:600">★ {{ $mentor->rating }}</td>
        <td><div class="actions-cell">
          <a href="/admin/mentors/{{ $mentor->id }}/edit" class="btn btn-outline" style="padding:6px 10px;font-size:11px">Tahrir</a>
          <form action="/admin/mentors/{{ $mentor->id }}" method="POST" onsubmit="return confirm('O\'chirmoqchimisiz?')">@csrf @method('DELETE')<button class="btn" style="padding:6px 10px;font-size:11px;color:var(--danger)">🗑️</button></form>
        </div></td>
      </tr>
      @endforeach
    </tbody>
  </table>
  {{ $mentors->links() }}
</div>
@endsection
