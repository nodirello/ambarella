@extends('layouts.app')
@section('title', 'Bannerni tahrirlash | Admin')
@section('styles')
<style>
.form-page{padding:48px 0;max-width:640px;margin:0 auto}
.form-page h1{font-size:22px;font-weight:800;color:#fff;margin-bottom:32px}
.form-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:32px}
.form-group{margin-bottom:18px}
.form-group label{display:block;font-size:13px;font-weight:600;color:#94a3b8;margin-bottom:6px}
.form-group input,.form-group select,.form-group textarea{width:100%;padding:12px 16px;border:1px solid var(--border);border-radius:var(--radius);font-size:14px;background:rgba(255,255,255,.02);color:#fff;font-family:inherit}
.form-group input::placeholder{color:#475569}
.back-link{display:inline-flex;align-items:center;gap:6px;color:var(--muted);font-size:13px;margin-bottom:20px;transition:color .2s;text-decoration:none}
.back-link:hover{color:#fff}
.form-hint{font-size:11px;color:#475569;margin-top:4px}
.current-img{width:100%;max-height:150px;object-fit:cover;border-radius:8px;margin-bottom:12px;border:1px solid var(--border)}
</style>
@endsection
@section('content')
<div class="container">
  <div class="form-page">
    <a href="{{ route('admin.banners') }}" class="back-link">← Barcha bannerlar</a>
    <h1>✏️ Bannerni tahrirlash</h1>
    @if($errors->any())
    <div style="background:rgba(220,38,38,.1);border:1px solid rgba(220,38,38,.3);border-radius:var(--radius);padding:14px;margin-bottom:20px">
      @foreach($errors->all() as $error)
        <p style="color:#fca5a5;font-size:13px;margin:2px 0">{{ $error }}</p>
      @endforeach
    </div>
    @endif
    <form method="POST" action="{{ route('admin.banners.update', $banner) }}" class="form-card">
      @csrf @method('PUT')
      <div class="form-group">
        <label>Joriy rasm</label>
        <img src="{{ $banner->image_url }}" alt="{{ $banner->title }}" class="current-img">
      </div>
      <div class="form-group">
        <label>Sarlavha *</label>
        <input name="title" required value="{{ old('title', $banner->title) }}">
      </div>
      <div class="form-group">
        <label>Subtitle (ixtiyoriy)</label>
        <input name="subtitle" value="{{ old('subtitle', $banner->subtitle) }}">
      </div>
      <div class="form-group">
        <label>Rasm URL *</label>
        <input name="image_url" required value="{{ old('image_url', $banner->image_url) }}">
      </div>
      <div class="form-group">
        <label>Havola URL (ixtiyoriy)</label>
        <input name="link_url" value="{{ old('link_url', $banner->link_url) }}">
      </div>
      <div class="form-group">
        <label>Tugma matni (ixtiyoriy)</label>
        <input name="button_text" value="{{ old('button_text', $banner->button_text) }}">
      </div>
      <div class="form-group">
        <label>Tartib raqami</label>
        <input name="sort_order" type="number" value="{{ old('sort_order', $banner->sort_order) }}" min="0">
        <p class="form-hint">Kichik raqam — birinchi ko'rsatiladi</p>
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:14px">Yangilash</button>
    </form>
  </div>
</div>
@endsection
