@extends('layouts.app')
@section('title', 'Yangi banner | Admin')
@section('styles')
<style>
.form-page{padding:48px 0;max-width:640px;margin:0 auto}
.form-page h1{font-size:22px;font-weight:800;color:#fff;margin-bottom:32px}
.form-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:32px}
.form-group{margin-bottom:18px}
.form-group label{display:block;font-size:13px;font-weight:600;color:#94a3b8;margin-bottom:6px}
.form-group input,.form-group select,.form-group textarea{width:100%;padding:12px 16px;border:1px solid var(--border);border-radius:var(--radius);font-size:14px;background:rgba(255,255,255,.02);color:#fff;font-family:inherit}
.form-group input::placeholder{color:#475569}
.back-link{display:inline-flex;align-items:center;gap:6px;color:var(--muted);font-size:13px;margin-bottom:20px;transition:color .2s;text-decoration:none}
.back-link:hover{color:#fff}
.form-hint{font-size:11px;color:#475569;margin-top:4px}
</style>
@endsection
@section('content')
<div class="container">
  <div class="form-page">
    <a href="{{ route('admin.banners') }}" class="back-link">← Barcha bannerlar</a>
    <h1>🖼️ Yangi banner qo'shish</h1>
    @if($errors->any())
    <div style="background:rgba(220,38,38,.1);border:1px solid rgba(220,38,38,.3);border-radius:var(--radius);padding:14px;margin-bottom:20px">
      @foreach($errors->all() as $error)
        <p style="color:#fca5a5;font-size:13px;margin:2px 0">{{ $error }}</p>
      @endforeach
    </div>
    @endif
    <form method="POST" action="{{ route('admin.banners.store') }}" class="form-card">
      @csrf
      <div class="form-group">
        <label>Sarlavha *</label>
        <input name="title" required placeholder="Banner sarlavhasi" value="{{ old('title') }}">
      </div>
      <div class="form-group">
        <label>Subtitle (ixtiyoriy)</label>
        <input name="subtitle" placeholder="Qo'shimcha matn" value="{{ old('subtitle') }}">
      </div>
      <div class="form-group">
        <label>Rasm URL *</label>
        <input name="image_url" required placeholder="https://example.com/banner.jpg" value="{{ old('image_url') }}">
      </div>
      <div class="form-group">
        <label>Havola URL (ixtiyoriy)</label>
        <input name="link_url" placeholder="https://..." value="{{ old('link_url') }}">
      </div>
      <div class="form-group">
        <label>Tugma matni (ixtiyoriy)</label>
        <input name="button_text" placeholder="Batafsil" value="{{ old('button_text') }}">
      </div>
      <div class="form-group">
        <label>Tartib raqami</label>
        <input name="sort_order" type="number" value="{{ old('sort_order', 0) }}" min="0">
        <p class="form-hint">Kichik raqam — birinchi ko'rsatiladi</p>
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:14px">Saqlash</button>
    </form>
  </div>
</div>
@endsection
