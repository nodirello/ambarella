@extends('layouts.app')
@section('title', 'Bannerlar | Admin')
@section('styles')
<style>
.admin-page{padding:32px 0}
.admin-page-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;flex-wrap:wrap;gap:12px}
.admin-page-header h1{font-size:22px;font-weight:800;color:#fff}
.banner-list{display:flex;flex-direction:column;gap:12px}
.banner-item{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:18px;display:flex;align-items:center;gap:16px;transition:all .2s}
.banner-item:hover{border-color:rgba(37,99,235,.3)}
.banner-preview{width:80px;height:50px;border-radius:8px;object-fit:cover;background:rgba(255,255,255,.03);flex-shrink:0}
.banner-info{flex:1;min-width:0}
.banner-info h3{font-size:15px;font-weight:600;color:#fff;margin-bottom:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.banner-info p{font-size:12px;color:var(--muted)}
.banner-sort{font-size:12px;color:#64748b;background:rgba(255,255,255,.03);padding:4px 10px;border-radius:6px;font-weight:600}
.status-badge{font-size:11px;font-weight:600;padding:3px 10px;border-radius:12px}
.status-active{background:rgba(34,197,94,.1);color:#86efac}
.status-inactive{background:rgba(239,68,68,.1);color:#fca5a5}
.actions-cell{display:flex;gap:6px;flex-shrink:0}
.action-btn{padding:6px 12px;border-radius:6px;font-size:11px;font-weight:600;cursor:pointer;border:none;text-decoration:none;display:inline-block}
.action-edit{background:rgba(37,99,235,.1);color:#93c5fd}
.action-toggle{background:rgba(234,179,8,.1);color:#fde047}
.action-delete{background:rgba(220,38,38,.1);color:#fca5a5}
@media(max-width:768px){.banner-item{flex-direction:column;align-items:flex-start}.actions-cell{align-self:flex-end}}
</style>
@endsection
@section('content')
<div class="container">
  <div class="admin-page">
    <div class="admin-page-header">
      <h1>🖼️ Bannerlar ({{ $banners->count() }})</h1>
      <div style="display:flex;gap:10px">
        <a href="{{ route('admin.dashboard') }}" class="btn btn-outline" style="padding:8px 16px;font-size:12px">← Admin</a>
        <a href="{{ route('admin.banners.create') }}" class="btn btn-primary" style="padding:8px 16px;font-size:12px">+ Yangi banner</a>
      </div>
    </div>
    @if(session('success'))
    <div style="background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.3);border-radius:var(--radius);padding:12px 16px;margin-bottom:16px;color:#86efac;font-size:13px">{{ session('success') }}</div>
    @endif
    <div class="banner-list">
      @foreach($banners as $banner)
      <div class="banner-item">
        <img src="{{ $banner->image_url }}" alt="{{ $banner->title }}" class="banner-preview">
        <div class="banner-info">
          <h3>{{ $banner->title }}</h3>
          <p>{{ $banner->subtitle ?? 'Subtitle yo\'q' }} · {{ $banner->link_url ?? '#' }}</p>
        </div>
        <span class="banner-sort">#{{ $banner->sort_order }}</span>
        <span class="status-badge {{ $banner->is_active ? 'status-active' : 'status-inactive' }}">
          {{ $banner->is_active ? 'Faol' : 'Nofaol' }}
        </span>
        <div class="actions-cell">
          <form method="POST" action="{{ route('admin.banners.update', $banner) }}" style="display:inline">
            @csrf @method('PUT')
            <input type="hidden" name="title" value="{{ $banner->title }}">
            <input type="hidden" name="image_url" value="{{ $banner->image_url }}">
          </form>
          <a href="{{ route('admin.banners.edit', $banner) }}" class="action-btn action-edit">Tahrir</a>
          <form method="POST" action="{{ route('admin.banners.destroy', $banner) }}" onsubmit="return confirm('O\'chirilsinmi?')" style="display:inline">
            @csrf @method('DELETE')
            <button class="action-btn action-delete">🗑️</button>
          </form>
        </div>
      </div>
      @endforeach
    </div>
    @if($banners->isEmpty())
    <div style="text-align:center;padding:60px 0;color:var(--muted)">
      <p style="font-size:40px;margin-bottom:12px">🖼️</p>
      <p>Bannerlar yo'q</p>
    </div>
    @endif
  </div>
</div>
@endsection
