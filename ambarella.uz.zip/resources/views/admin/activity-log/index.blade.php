@extends('layouts.app')
@section('title', 'Activity Log | Admin')
@section('styles')
<style>
.al-header{padding:32px 0;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:16px}
.al-header h1{font-size:24px;font-weight:800;color:#fff}
.al-filters{display:flex;gap:10px;flex-wrap:wrap}
.al-filters select,.al-filters input{background:var(--surface);border:1px solid var(--border);border-radius:10px;padding:8px 14px;color:#e2e8f0;font-size:13px;outline:none}
.al-filters select:focus,.al-filters input:focus{border-color:var(--primary)}
.al-table-wrap{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden;margin-top:0}
.al-table{width:100%;border-collapse:collapse}
.al-table th{background:rgba(0,0,0,.2);padding:12px 16px;text-align:left;font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;font-weight:600}
.al-table td{padding:12px 16px;border-top:1px solid var(--border);font-size:13px;color:#94a3b8}
.al-table tr:hover td{background:rgba(255,255,255,.02)}
.al-table .user-name{color:#e2e8f0;font-weight:600}
.al-table .action-badge{display:inline-flex;padding:3px 10px;border-radius:999px;font-size:11px;font-weight:600;background:rgba(37,99,235,.1);color:#60a5fa}
.al-table .time{color:var(--muted);font-size:12px}
.al-table .ip{font-family:monospace;font-size:12px;color:var(--muted)}
.pagination-wrap{padding:16px;display:flex;justify-content:center}
.pagination-wrap nav{display:flex;gap:4px}
.empty-state{padding:48px;text-align:center;color:var(--muted)}
@media(max-width:768px){.al-table{font-size:12px}.al-table th,.al-table td{padding:8px 10px}.al-filters{width:100%}.al-filters select,.al-filters input{flex:1}}
</style>
@endsection
@section('content')
<div class="container">
    <div class="al-header">
        <h1>📋 Activity Log</h1>
        <form class="al-filters" method="GET" action="{{ route('admin.activity-log') }}">
            <input type="text" name="user" placeholder="Foydalanuvchi..." value="{{ request('user') }}">
            <select name="action" onchange="this.form.submit()">
                <option value="">Barcha amallar</option>
                @foreach($actions as $action)
                    <option value="{{ $action }}" {{ request('action') == $action ? 'selected' : '' }}>{{ $action }}</option>
                @endforeach
            </select>
        </form>
    </div>

    <div class="al-table-wrap">
        @if($logs->count() > 0)
        <table class="al-table">
            <thead>
                <tr>
                    <th>Foydalanuvchi</th>
                    <th>Amal</th>
                    <th>Tavsif</th>
                    <th>IP</th>
                    <th>Vaqt</th>
                </tr>
            </thead>
            <tbody>
                @foreach($logs as $log)
                <tr>
                    <td class="user-name">{{ $log->user->name ?? 'Tizim' }}</td>
                    <td><span class="action-badge">{{ $log->action }}</span></td>
                    <td>{{ Str::limit($log->description, 60) }}</td>
                    <td class="ip">{{ $log->ip_address ?? '-' }}</td>
                    <td class="time">{{ $log->created_at->diffForHumans() }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
        @else
        <div class="empty-state">
            <p>Hozircha log mavjud emas</p>
        </div>
        @endif
    </div>

    @if($logs->hasPages())
    <div class="pagination-wrap">
        {{ $logs->withQueryString()->links() }}
    </div>
    @endif
</div>
@endsection
