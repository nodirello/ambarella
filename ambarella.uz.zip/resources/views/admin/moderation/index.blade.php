@extends('layouts.app')
@section('title', 'Moderatsiya | Admin')
@section('styles')
<style>
.mod-header{padding:24px 0;border-bottom:1px solid var(--border);margin-bottom:24px;display:flex;align-items:center;justify-content:space-between}
.mod-header h1{font-size:22px;font-weight:800;color:#fff;display:flex;align-items:center;gap:10px}
.mod-header h1 svg{color:#f59e0b}
.mod-tabs{display:flex;gap:4px;margin-bottom:24px;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:4px}
.mod-tab{padding:10px 20px;border-radius:8px;font-size:13px;font-weight:600;color:var(--muted);cursor:pointer;transition:all .2s;border:none;background:transparent}
.mod-tab.active{background:rgba(59,130,246,.1);color:#60a5fa}
.mod-tab:hover:not(.active){color:#cbd5e1}
.mod-tab .badge{display:inline-flex;align-items:center;justify-content:center;min-width:20px;height:20px;padding:0 6px;border-radius:999px;font-size:11px;font-weight:700;margin-left:6px}
.mod-tab .badge-warning{background:rgba(245,158,11,.15);color:#fbbf24}
.mod-tab .badge-info{background:rgba(59,130,246,.15);color:#60a5fa}
.mod-section{display:none}
.mod-section.active{display:block}
.mod-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:20px;margin-bottom:12px;transition:all .2s}
.mod-card:hover{border-color:rgba(59,130,246,.3)}
.mod-card-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}
.mod-card-user{display:flex;align-items:center;gap:10px}
.mod-card-avatar{width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,#3b82f6,#8b5cf6);display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;color:#fff}
.mod-card-name{font-size:14px;font-weight:600;color:#fff}
.mod-card-date{font-size:12px;color:var(--muted)}
.mod-card-body{font-size:14px;color:#cbd5e1;line-height:1.6;padding:12px;background:rgba(255,255,255,.02);border-radius:8px;border:1px solid var(--border);margin-bottom:12px}
.mod-card-actions{display:flex;gap:8px}
.mod-btn{padding:8px 16px;border-radius:6px;font-size:12px;font-weight:600;border:none;cursor:pointer;transition:all .2s;display:inline-flex;align-items:center;gap:6px}
.mod-btn-approve{background:rgba(16,185,129,.15);color:#34d399;border:1px solid rgba(16,185,129,.2)}
.mod-btn-approve:hover{background:rgba(16,185,129,.25)}
.mod-btn-reject{background:rgba(239,68,68,.1);color:#f87171;border:1px solid rgba(239,68,68,.2)}
.mod-btn-reject:hover{background:rgba(239,68,68,.2)}
.mod-product-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:14px}
.mod-product-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:16px;transition:all .2s}
.mod-product-card:hover{border-color:rgba(59,130,246,.3)}
.mod-product-title{font-size:14px;font-weight:600;color:#fff;margin-bottom:4px}
.mod-product-meta{font-size:12px;color:var(--muted);display:flex;gap:12px;margin-bottom:8px}
.mod-product-price{font-size:15px;font-weight:700;color:#4ade80}
.mod-empty{text-align:center;padding:40px;color:var(--muted);font-size:14px}
.mod-empty svg{display:block;margin:0 auto 12px;opacity:.4}
.mod-back{display:inline-flex;align-items:center;gap:6px;font-size:13px;color:var(--muted);text-decoration:none;margin-bottom:16px;transition:color .2s}
.mod-back:hover{color:#fff}
@media(max-width:768px){
    .mod-tabs{flex-direction:column}
    .mod-product-grid{grid-template-columns:1fr}
    .mod-card-header{flex-direction:column;align-items:flex-start;gap:8px}
}
</style>
@endsection
@section('content')
<div class="container">
    <a href="{{ route('admin.dashboard') }}" class="mod-back">
        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
        Admin Panel
    </a>

    <div class="mod-header">
        <h1>
            <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
            Moderatsiya
        </h1>
    </div>

    {{-- Tabs --}}
    <div class="mod-tabs">
        <button class="mod-tab active" onclick="switchModTab('comments')">
            Izohlar <span class="badge badge-warning">{{ $pendingComments->count() }}</span>
        </button>
        <button class="mod-tab" onclick="switchModTab('products')">
            Mahsulotlar <span class="badge badge-info">{{ $recentProducts->count() }}</span>
        </button>
        <button class="mod-tab" onclick="switchModTab('posts')">
            Blog postlar <span class="badge badge-info">{{ $recentPosts->count() }}</span>
        </button>
    </div>

    {{-- COMMENTS SECTION --}}
    <div id="mod-comments" class="mod-section active">
        @forelse($pendingComments as $comment)
        <div class="mod-card">
            <div class="mod-card-header">
                <div class="mod-card-user">
                    <div class="mod-card-avatar">{{ mb_substr($comment->user->name ?? 'U', 0, 1) }}</div>
                    <div>
                        <div class="mod-card-name">{{ $comment->user->name ?? 'Noma\'lum' }}</div>
                        <div class="mod-card-date">{{ $comment->created_at->diffForHumans() }}</div>
                    </div>
                </div>
            </div>
            <div class="mod-card-body">{{ $comment->body }}</div>
            <div class="mod-card-actions">
                <form action="{{ route('admin.moderation.approve', $comment) }}" method="POST" style="display:inline">
                    @csrf
                    <button type="submit" class="mod-btn mod-btn-approve">
                        <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg>
                        Tasdiqlash
                    </button>
                </form>
                <form action="{{ route('admin.moderation.reject', $comment) }}" method="POST" style="display:inline" onsubmit="return confirm('Haqiqatan o\'chirmoqchimisiz?')">
                    @csrf
                    <button type="submit" class="mod-btn mod-btn-reject">
                        <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M18 6L6 18M6 6l12 12"/></svg>
                        O'chirish
                    </button>
                </form>
            </div>
        </div>
        @empty
        <div class="mod-empty">
            <svg width="48" height="48" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            <p>Tasdiqlanmagan izohlar yo'q</p>
        </div>
        @endforelse
    </div>

    {{-- PRODUCTS SECTION --}}
    <div id="mod-products" class="mod-section">
        @if($recentProducts->count())
        <div class="mod-product-grid">
            @foreach($recentProducts as $product)
            <div class="mod-product-card">
                <div class="mod-product-title">{{ $product->name }}</div>
                <div class="mod-product-meta">
                    <span>📍 {{ $product->location ?? 'N/A' }}</span>
                    <span>📅 {{ $product->created_at->format('d.m.Y') }}</span>
                </div>
                <div class="mod-product-price">{{ number_format($product->price ?? 0) }} so'm</div>
            </div>
            @endforeach
        </div>
        @else
        <div class="mod-empty">
            <svg width="48" height="48" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
            <p>Hozircha yangi mahsulotlar yo'q</p>
        </div>
        @endif
    </div>

    {{-- BLOG POSTS SECTION --}}
    <div id="mod-posts" class="mod-section">
        @if($recentPosts->count())
        <div class="mod-product-grid">
            @foreach($recentPosts as $post)
            <div class="mod-product-card">
                <div class="mod-product-title">{{ $post->title }}</div>
                <div class="mod-product-meta">
                    <span>✍️ {{ $post->user->name ?? 'Noma\'lum' }}</span>
                    <span>📅 {{ $post->created_at->format('d.m.Y') }}</span>
                </div>
                @if($post->slug)
                <a href="{{ route('blog.show', $post->slug) }}" style="font-size:12px;color:#60a5fa;text-decoration:none">Ko'rish →</a>
                @endif
            </div>
            @endforeach
        </div>
        @else
        <div class="mod-empty">
            <svg width="48" height="48" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V9a2 2 0 012-2h2a2 2 0 012 2v9a2 2 0 01-2 2h-2z"/></svg>
            <p>Hozircha blog postlar yo'q</p>
        </div>
        @endif
    </div>
</div>

<script>
function switchModTab(tab) {
    document.querySelectorAll('.mod-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.mod-section').forEach(s => s.classList.remove('active'));
    event.currentTarget.classList.add('active');
    document.getElementById('mod-' + tab).classList.add('active');
}
</script>
@endsection
