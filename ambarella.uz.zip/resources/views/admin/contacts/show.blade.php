@extends('layouts.app')
@section('title', 'Xabar: {{ $message->subject }} | Admin')
@section('styles')
<style>
.admin-page{padding:32px 0}
.admin-page-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px}
.admin-page-header h1{font-size:22px;font-weight:800;color:#fff}
.admin-page-header p{font-size:13px;color:var(--muted);margin-top:4px}
.back-link{display:inline-flex;align-items:center;gap:6px;font-size:13px;font-weight:500;color:#94a3b8;text-decoration:none;margin-bottom:16px;transition:color .2s}
.back-link:hover{color:#fff}
.message-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:24px;margin-bottom:24px}
.message-meta{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;margin-bottom:20px;padding-bottom:20px;border-bottom:1px solid var(--border)}
.message-meta-item label{display:block;font-size:11px;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:4px;font-weight:600}
.message-meta-item span{font-size:14px;color:#fff;font-weight:500}
.message-body{font-size:14px;color:#cbd5e1;line-height:1.8;white-space:pre-wrap}
.badge{padding:3px 10px;border-radius:999px;font-size:11px;font-weight:600;display:inline-block}
.badge-new{background:rgba(239,68,68,.15);color:#fca5a5;animation:pulse-badge 2s infinite}
.badge-read{background:rgba(234,179,8,.15);color:#fde047}
.badge-replied{background:rgba(34,197,94,.15);color:#86efac}
@keyframes pulse-badge{0%,100%{opacity:1}50%{opacity:.6}}
.reply-section{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:24px}
.reply-section h3{font-size:16px;font-weight:700;color:#fff;margin-bottom:16px}
.existing-reply{background:rgba(34,197,94,.06);border:1px solid rgba(34,197,94,.15);border-radius:var(--radius);padding:16px;margin-bottom:20px}
.existing-reply label{display:block;font-size:11px;text-transform:uppercase;letter-spacing:.5px;color:#86efac;margin-bottom:8px;font-weight:600}
.existing-reply p{font-size:14px;color:#cbd5e1;line-height:1.7;white-space:pre-wrap}
.form-group{margin-bottom:16px}
.form-group label{display:block;font-size:13px;font-weight:600;color:#94a3b8;margin-bottom:6px}
.form-group textarea{width:100%;border:1px solid var(--border);background:var(--surface);color:#fff;border-radius:var(--radius);padding:12px 16px;font-size:14px;font-family:inherit;min-height:120px;resize:vertical;transition:border-color .2s}
.form-group textarea:focus{outline:none;border-color:var(--primary)}
.btn-reply{padding:10px 20px;font-size:13px;font-weight:600;border-radius:var(--radius);border:none;background:var(--primary);color:#fff;cursor:pointer;transition:opacity .2s}
.btn-reply:hover{opacity:.9}
.alert-success{background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.2);border-radius:var(--radius);padding:12px 16px;font-size:13px;color:#86efac;margin-bottom:20px}
.delete-btn{padding:8px 14px;font-size:12px;font-weight:600;border-radius:var(--radius);border:1px solid rgba(239,68,68,.3);background:transparent;color:#fca5a5;cursor:pointer;transition:all .2s}
.delete-btn:hover{background:rgba(239,68,68,.1)}
</style>
@endsection
@section('content')
<div class="container">
  <div class="admin-page">
    <a href="/admin/contacts" class="back-link">
      <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 8H1"/><path d="M8 15l-7-7 7-7"/></svg>
      Barcha xabarlar
    </a>
    <div class="admin-page-header">
      <div>
        <h1>{{ $message->subject ?: 'Mavzusiz xabar' }}</h1>
        <p>{{ $message->name }} tomonidan yuborilgan</p>
      </div>
      <form action="/admin/contacts/{{ $message->id }}" method="POST" onsubmit="return confirm('Rostdan o\'chirmoqchimisiz?')">
        @csrf
        @method('DELETE')
        <button type="submit" class="delete-btn">🗑 O'chirish</button>
      </form>
    </div>

    @if(session('success'))
    <div class="alert-success">{{ session('success') }}</div>
    @endif

    <div class="message-card">
      <div class="message-meta">
        <div class="message-meta-item">
          <label>Ism</label>
          <span>{{ $message->name }}</span>
        </div>
        <div class="message-meta-item">
          <label>Email</label>
          <span>{{ $message->email }}</span>
        </div>
        <div class="message-meta-item">
          <label>Telefon</label>
          <span>{{ $message->phone ?: '—' }}</span>
        </div>
        <div class="message-meta-item">
          <label>Holati</label>
          <span>
            @if($message->status === 'new')
              <span class="badge badge-new">Yangi</span>
            @elseif($message->status === 'read')
              <span class="badge badge-read">O'qilgan</span>
            @elseif($message->status === 'replied')
              <span class="badge badge-replied">Javob berilgan</span>
            @endif
          </span>
        </div>
        <div class="message-meta-item">
          <label>Sana</label>
          <span>{{ \Carbon\Carbon::parse($message->created_at)->format('d.m.Y H:i') }}</span>
        </div>
      </div>
      <div class="message-body">{{ $message->message }}</div>
    </div>

    <div class="reply-section">
      <h3>Admin javobi</h3>

      @if($message->admin_reply)
      <div class="existing-reply">
        <label>Avvalgi javob</label>
        <p>{{ $message->admin_reply }}</p>
      </div>
      @endif

      <form action="/admin/contacts/{{ $message->id }}/reply" method="POST">
        @csrf
        <div class="form-group">
          <label for="admin_reply">{{ $message->admin_reply ? 'Javobni yangilash' : 'Javob yozing' }}</label>
          <textarea id="admin_reply" name="admin_reply" placeholder="Foydalanuvchiga javob yozing..." required>{{ old('admin_reply', $message->admin_reply) }}</textarea>
          @error('admin_reply')
          <span style="font-size:12px;color:#fca5a5;margin-top:4px;display:block">{{ $message }}</span>
          @enderror
        </div>
        <button type="submit" class="btn-reply">
          <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" style="vertical-align:middle;margin-right:4px"><path d="M14 1l-5 14-3-6-6-3z"/></svg>
          Javob yuborish
        </button>
      </form>
    </div>
  </div>
</div>
@endsection
