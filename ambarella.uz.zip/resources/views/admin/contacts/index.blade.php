@extends('layouts.app')
@section('title', 'Xabarlar | Admin')
@section('styles')
<style>
.admin-page{padding:32px 0}
.admin-page-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px}
.admin-page-header h1{font-size:22px;font-weight:800;color:#fff}
.admin-page-header p{font-size:13px;color:var(--muted);margin-top:4px}
.unread-badge{display:inline-flex;align-items:center;gap:6px;padding:5px 12px;border-radius:20px;font-size:12px;font-weight:600;background:rgba(239,68,68,.12);color:#fca5a5}
.admin-table{width:100%;border-collapse:collapse;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden}
.admin-table th{text-align:left;padding:12px 14px;font-size:11px;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);border-bottom:1px solid var(--border)}
.admin-table td{padding:14px;border-bottom:1px solid var(--border);font-size:14px;color:#cbd5e1}
.admin-table tr:last-child td{border:none}
.admin-table tr:hover td{background:rgba(255,255,255,.02)}
.badge{padding:3px 10px;border-radius:999px;font-size:11px;font-weight:600;display:inline-block}
.badge-new{background:rgba(239,68,68,.15);color:#fca5a5;animation:pulse-badge 2s infinite}
.badge-read{background:rgba(234,179,8,.15);color:#fde047}
.badge-replied{background:rgba(34,197,94,.15);color:#86efac}
@keyframes pulse-badge{0%,100%{opacity:1}50%{opacity:.6}}
.view-btn{padding:5px 12px;font-size:12px;font-weight:600;border-radius:var(--radius);border:1px solid var(--border);background:transparent;color:#94a3b8;text-decoration:none;transition:all .2s}
.view-btn:hover{border-color:var(--primary);color:#fff}
.table-responsive{overflow-x:auto;border-radius:var(--radius)}
@media(max-width:768px){.admin-page-header{flex-direction:column;align-items:flex-start;gap:12px}}
</style>
@endsection
@section('content')
<div class="container">
  <div class="admin-page">
    <div class="admin-page-header">
      <div>
        <h1>Kontakt xabarlar</h1>
        <p>Foydalanuvchilardan kelgan xabarlarni ko'rish va javob berish</p>
      </div>
      @if($unread > 0)
      <div class="unread-badge">
        <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="7" cy="7" r="6"/><path d="M7 4v3l2 2"/></svg>
        {{ $unread }} ta yangi xabar
      </div>
      @endif
    </div>
    <div class="table-responsive">
      <table class="admin-table">
        <thead>
          <tr>
            <th>Ism</th>
            <th>Email</th>
            <th>Mavzu</th>
            <th>Holati</th>
            <th>Sana</th>
            <th>Amal</th>
          </tr>
        </thead>
        <tbody>
          @forelse($messages as $msg)
          <tr>
            <td style="font-weight:600;color:#fff">{{ $msg->name }}</td>
            <td>{{ $msg->email }}</td>
            <td>{{ Str::limit($msg->subject, 30) }}</td>
            <td>
              @if($msg->status === 'new')
                <span class="badge badge-new">Yangi</span>
              @elseif($msg->status === 'read')
                <span class="badge badge-read">O'qilgan</span>
              @elseif($msg->status === 'replied')
                <span class="badge badge-replied">Javob berilgan</span>
              @endif
            </td>
            <td>{{ \Carbon\Carbon::parse($msg->created_at)->format('d.m.Y') }}</td>
            <td>
              <a href="/admin/contacts/{{ $msg->id }}" class="view-btn">Ko'rish</a>
            </td>
          </tr>
          @empty
          <tr><td colspan="6" style="text-align:center;color:var(--muted);padding:32px">Xabarlar topilmadi</td></tr>
          @endforelse
        </tbody>
      </table>
    </div>
    <div style="margin-top:20px">{{ $messages->links() }}</div>
  </div>
</div>
@endsection
