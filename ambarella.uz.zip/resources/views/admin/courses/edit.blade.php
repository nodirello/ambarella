@extends('layouts.app')
@section('title', 'Kurs tahrirlash | Admin')
@section('styles')
<style>
.form-page{padding:48px 0;max-width:560px;margin:0 auto}
.form-page h1{font-size:22px;font-weight:800;color:#fff;margin-bottom:32px}
.form-group{margin-bottom:20px}
.form-group label{display:block;font-size:13px;font-weight:600;color:#94a3b8;margin-bottom:6px}
.form-group input,.form-group select,.form-group textarea{width:100%;padding:12px 16px;border-radius:var(--radius);border:1px solid var(--border);background:var(--surface);color:#fff;font-size:14px}
.form-group textarea{resize:vertical;min-height:80px}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
</style>
@endsection
@section('content')
<div class="container"><div class="form-page">
  <h1>Kursni tahrirlash</h1>
  <form action="/admin/courses/{{ $course->id }}" method="POST">
    @csrf @method('PUT')
    <div class="form-group"><label>Kurs nomi</label><input type="text" name="title" required maxlength="255" value="{{ $course->title }}"></div>
    <div class="form-row">
      <div class="form-group"><label>O'qituvchi</label><input type="text" name="instructor" required maxlength="100" value="{{ $course->instructor }}"></div>
      <div class="form-group"><label>Davomiyligi</label><input type="text" name="duration" required maxlength="50" value="{{ $course->duration }}"></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Narxi (so'm)</label><input type="number" name="price" required min="0" value="{{ $course->price }}"></div>
      <div class="form-group"><label>Daraja</label>
        <select name="level" required>
          @foreach(["Boshlang'ich","O'rta","Yuqori"] as $lvl)
          <option value="{{ $lvl }}" {{ $course->level == $lvl ? 'selected' : '' }}>{{ $lvl }}</option>
          @endforeach
        </select>
      </div>
    </div>
    <div class="form-group"><label>Kategoriya</label><input type="text" name="category" required maxlength="50" value="{{ $course->category }}"></div>
    <div class="form-group"><label>Tavsif</label><textarea name="description" maxlength="2000">{{ $course->description }}</textarea></div>
    <div class="form-group"><label>Rasm URL</label><input type="text" name="image" maxlength="500" value="{{ $course->image }}"></div>
    <button type="submit" class="btn btn-success">Saqlash</button>
    <a href="/admin/courses" class="btn btn-outline">Bekor</a>
  </form>
</div></div>
@endsection
