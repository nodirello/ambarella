@extends('layouts.app')
@section('title', 'Kurslar | Admin')
@section('styles')
<style>
.admin-header{padding:32px 0;display:flex;justify-content:space-between;align-items:center}
.admin-header h1{font-size:22px;font-weight:800;color:#fff}
.admin-table{width:100%;border-collapse:collapse}
.admin-table th{text-align:left;padding:12px 14px;font-size:12px;text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid var(--border)}
.admin-table td{padding:14px;border-bottom:1px solid var(--border);font-size:14px}
.actions-cell{display:flex;gap:6px}
</style>
@endsection
@section('content')
<div class="container">
  <div class="admin-header">
    <h1>Kurslar boshqaruvi</h1>
    <a href="/admin/courses/create" class="btn btn-primary">+ Yangi kurs</a>
  </div>
  <table class="admin-table">
    <thead><tr><th>Nomi</th><th>O'qituvchi</th><th>Daraja</th><th>Narxi</th><th>Kategoriya</th><th>Amallar</th></tr></thead>
    <tbody>
      @foreach($courses as $course)
      <tr>
        <td style="font-weight:600;color:#fff">{{ $course->title }}</td>
        <td>{{ $course->instructor }}</td>
        <td>{{ $course->level }}</td>
        <td style="color:#fbbf24">{{ $course->price > 0 ? number_format($course->price) . ' so\'m' : 'Bepul' }}</td>
        <td>{{ $course->category }}</td>
        <td><div class="actions-cell">
          <a href="/admin/courses/{{ $course->id }}/edit" class="btn btn-outline" style="padding:6px 10px;font-size:11px">Tahrir</a>
          <form action="/admin/courses/{{ $course->id }}" method="POST" onsubmit="return confirm('O\'chirmoqchimisiz?')">@csrf @method('DELETE')<button class="btn" style="padding:6px 10px;font-size:11px;color:var(--danger)">🗑️</button></form>
        </div></td>
      </tr>
      @endforeach
    </tbody>
  </table>
  {{ $courses->links() }}
</div>
@endsection
