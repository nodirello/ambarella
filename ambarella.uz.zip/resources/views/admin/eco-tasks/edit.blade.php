@extends('layouts.app')
@section('title', 'Eko vazifa tahrirlash | Admin')
@section('styles')
<style>
.form-page{padding:48px 0;max-width:560px;margin:0 auto}
.form-page h1{font-size:22px;font-weight:800;color:#fff;margin-bottom:32px}
.form-group{margin-bottom:20px}
.form-group label{display:block;font-size:13px;font-weight:600;color:#94a3b8;margin-bottom:6px}
.form-group input,.form-group select,.form-group textarea{width:100%;padding:12px 16px;border-radius:var(--radius);border:1px solid var(--border);background:var(--surface);color:#fff;font-size:14px}
.form-group textarea{resize:vertical;min-height:80px}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
</style>
@endsection
@section('content')
<div class="container"><div class="form-page">
  <h1>Eko vazifani tahrirlash</h1>
  <form action="/admin/eco-tasks/{{ $task->id }}" method="POST">
    @csrf @method('PUT')
    <div class="form-group"><label>Sarlavha</label><input type="text" name="title" required maxlength="255" value="{{ $task->title }}"></div>
    <div class="form-group"><label>Tavsif</label><textarea name="description" required maxlength="500">{{ $task->description }}</textarea></div>
    <div class="form-row">
      <div class="form-group"><label>Mukofot (GreenCoin)</label><input type="number" name="reward" required min="1" max="100" value="{{ $task->reward }}"></div>
      <div class="form-group"><label>Kategoriya</label>
        <select name="category" required>
          @foreach(['Kundalik','Transport','Energiya','Chiqindi'] as $cat)
          <option value="{{ $cat }}" {{ $task->category == $cat ? 'selected' : '' }}>{{ $cat }}</option>
          @endforeach
        </select>
      </div>
    </div>
    <button type="submit" class="btn btn-success">Saqlash</button>
    <a href="/admin/eco-tasks" class="btn btn-outline">Bekor</a>
  </form>
</div></div>
@endsection
