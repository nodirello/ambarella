@extends('layouts.app')
@section('title', 'Eko vazifalar | Admin')
@section('styles')
<style>
.admin-header{padding:32px 0;display:flex;justify-content:space-between;align-items:center}
.admin-header h1{font-size:22px;font-weight:800;color:#fff}
.admin-table{width:100%;border-collapse:collapse}
.admin-table th{text-align:left;padding:12px 14px;font-size:12px;text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid var(--border)}
.admin-table td{padding:14px;border-bottom:1px solid var(--border);font-size:14px}
.actions-cell{display:flex;gap:6px}
.badge{padding:3px 8px;border-radius:999px;font-size:11px;font-weight:600}
.badge-green{background:rgba(22,163,74,.1);color:#4ade80}
.badge-red{background:rgba(220,38,38,.1);color:#fca5a5}
</style>
@endsection
@section('content')
<div class="container">
  <div class="admin-header">
    <h1>Eko vazifalar</h1>
    <a href="/admin/eco-tasks/create" class="btn btn-success">+ Yangi vazifa</a>
  </div>
  <table class="admin-table">
    <thead><tr><th>Sarlavha</th><th>Tavsif</th><th>Mukofot</th><th>Kategoriya</th><th>Holat</th><th>Amallar</th></tr></thead>
    <tbody>
      @foreach($tasks as $task)
      <tr>
        <td style="font-weight:600;color:#fff">{{ $task->title }}</td>
        <td style="color:var(--muted)">{{ Str::limit($task->description, 50) }}</td>
        <td style="color:#4ade80;font-weight:600">+{{ $task->reward }} GC</td>
        <td>{{ $task->category }}</td>
        <td><span class="badge {{ $task->is_active ? 'badge-green' : 'badge-red' }}">{{ $task->is_active ? 'Faol' : 'Nofaol' }}</span></td>
        <td><div class="actions-cell">
          <a href="/admin/eco-tasks/{{ $task->id }}/edit" class="btn btn-outline" style="padding:6px 10px;font-size:11px">Tahrir</a>
          <form action="/admin/eco-tasks/{{ $task->id }}/toggle" method="POST">@csrf<button class="btn btn-outline" style="padding:6px 10px;font-size:11px">{{ $task->is_active ? 'O\'chirish' : 'Yoqish' }}</button></form>
          <form action="/admin/eco-tasks/{{ $task->id }}" method="POST" onsubmit="return confirm('O\'chirmoqchimisiz?')">@csrf @method('DELETE')<button class="btn" style="padding:6px 10px;font-size:11px;color:var(--danger)">🗑️</button></form>
        </div></td>
      </tr>
      @endforeach
    </tbody>
  </table>
  {{ $tasks->links() }}
</div>
@endsection
