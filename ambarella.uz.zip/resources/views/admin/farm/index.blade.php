@extends('layouts.app')
@section('title', 'Fermer mahsulotlari | Admin')
@section('styles')
<style>
.admin-page{padding:32px 0}
.admin-page-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px}
.admin-page-header h1{font-size:22px;font-weight:800;color:#fff}
.admin-page-header p{font-size:13px;color:var(--muted);margin-top:4px}
.admin-table{width:100%;border-collapse:collapse;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden}
.admin-table th{text-align:left;padding:12px 14px;font-size:11px;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);border-bottom:1px solid var(--border)}
.admin-table td{padding:14px;border-bottom:1px solid var(--border);font-size:14px;color:#cbd5e1}
.admin-table tr:last-child td{border:none}
.badge{padding:3px 10px;border-radius:999px;font-size:11px;font-weight:600;display:inline-block}
.badge-active{background:rgba(34,197,94,.15);color:#86efac}
.badge-inactive{background:rgba(239,68,68,.15);color:#fca5a5}
.actions-cell{display:flex;gap:6px;align-items:center}
.action-btn{padding:6px 10px;font-size:11px;border-radius:var(--radius);border:1px solid var(--border);background:transparent;color:#cbd5e1;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;transition:all .2s}
.action-btn:hover{border-color:rgba(37,99,235,.4);color:#fff}
.action-btn.success{color:#86efac;border-color:rgba(34,197,94,.3)}
.action-btn.success:hover{background:rgba(34,197,94,.1)}
.action-btn.danger{color:var(--danger)}
.action-btn.danger:hover{border-color:rgba(239,68,68,.4)}
.price-cell{color:#fbbf24;font-weight:600}
.table-responsive{overflow-x:auto;border-radius:var(--radius)}
@media(max-width:768px){.admin-page-header{flex-direction:column;align-items:flex-start;gap:12px}}
</style>
@endsection
@section('content')
<div class="container">
  <div class="admin-page">
    <div class="admin-page-header">
      <div>
        <h1>Fermer mahsulotlari</h1>
        <p>Barcha fermer mahsulotlarini ko'rish va boshqarish</p>
      </div>
    </div>
    <div class="table-responsive">
      <table class="admin-table">
        <thead>
          <tr>
            <th>Nomi</th>
            <th>Sotuvchi</th>
            <th>Kategoriya</th>
            <th>Narxi</th>
            <th>Hudud</th>
            <th>Holati</th>
            <th>Amallar</th>
          </tr>
        </thead>
        <tbody>
          @forelse($products as $product)
          <tr>
            <td style="font-weight:600;color:#fff">{{ $product->name }}</td>
            <td>{{ $product->user->name }}</td>
            <td>{{ $product->category }}</td>
            <td class="price-cell">{{ number_format($product->price) }} so'm</td>
            <td>{{ $product->region }}</td>
            <td>
              @if($product->is_active)
                <span class="badge badge-active">Faol</span>
              @else
                <span class="badge badge-inactive">Nofaol</span>
              @endif
            </td>
            <td>
              <div class="actions-cell">
                <form action="/admin/farm/{{ $product->id }}/toggle" method="POST" style="display:inline">
                  @csrf
                  <button type="submit" class="action-btn success">
                    {{ $product->is_active ? '⏸ Nofaol' : '▶ Faol' }}
                  </button>
                </form>
                <form action="/admin/farm/{{ $product->id }}" method="POST" onsubmit="return confirm('O\'chirmoqchimisiz?')" style="display:inline">
                  @csrf
                  @method('DELETE')
                  <button type="submit" class="action-btn danger">🗑️</button>
                </form>
              </div>
            </td>
          </tr>
          @empty
          <tr><td colspan="7" style="text-align:center;color:var(--muted);padding:32px">Mahsulotlar topilmadi</td></tr>
          @endforelse
        </tbody>
      </table>
    </div>
    <div style="margin-top:20px">{{ $products->links() }}</div>
  </div>
</div>
@endsection
