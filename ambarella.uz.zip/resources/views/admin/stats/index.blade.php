@extends('layouts.app')
@section('title', 'Statistika | Admin | AMBARELLA')
@section('styles')
<style>
.stats-page{padding:32px 0}
.stats-header{margin-bottom:32px}
.stats-header h1{font-size:24px;font-weight:800;color:#fff}
.stats-header p{color:var(--muted);font-size:13px;margin-top:4px}
.stats-overview{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;margin-bottom:32px}
.so-card{background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:18px;transition:all .3s}
.so-card:hover{border-color:rgba(37,99,235,.3);transform:translateY(-2px)}
.so-card .so-label{font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;font-weight:600}
.so-card .so-value{font-size:24px;font-weight:800;margin-top:4px}
.charts-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:32px}
.chart-panel{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:24px}
.chart-panel h3{font-size:14px;font-weight:700;color:#fff;margin-bottom:16px}
.chart-panel canvas{width:100%!important;max-height:250px}
.top-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px}
.top-panel{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:24px}
.top-panel h3{font-size:14px;font-weight:700;color:#fff;margin-bottom:16px}
.top-item{display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--border)}
.top-item:last-child{border:none}
.top-rank{width:24px;height:24px;border-radius:50%;background:rgba(37,99,235,.1);display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:800;color:#93c5fd;flex-shrink:0}
.top-name{font-size:12px;color:#fff;font-weight:600;flex:1}
.top-value{font-size:12px;font-weight:700;color:#4ade80}
@media(max-width:768px){.charts-grid,.top-grid{grid-template-columns:1fr}.stats-overview{grid-template-columns:1fr 1fr}}
</style>
@endsection
@section('content')
<div class="container stats-page">
  <div class="stats-header">
    <h1>Platforma Statistikasi</h1>
    <p>Barcha modullar bo'yicha batafsil analitika</p>
  </div>

  {{-- OVERVIEW --}}
  <div class="stats-overview">
    <div class="so-card"><div class="so-label">Foydalanuvchilar</div><div class="so-value" style="color:#60a5fa">{{ number_format($stats['users']) }}</div></div>
    <div class="so-card"><div class="so-label">Bugun yangi</div><div class="so-value" style="color:#4ade80">+{{ $stats['users_today'] }}</div></div>
    <div class="so-card"><div class="so-label">Haftalik</div><div class="so-value" style="color:#22d3ee">+{{ $stats['users_week'] }}</div></div>
    <div class="so-card"><div class="so-label">Oylik</div><div class="so-value" style="color:#a78bfa">+{{ $stats['users_month'] }}</div></div>
    <div class="so-card"><div class="so-label">Bloklangan</div><div class="so-value" style="color:#f87171">{{ $stats['banned_users'] }}</div></div>
    <div class="so-card"><div class="so-label">Ish e'lonlari</div><div class="so-value" style="color:#4ade80">{{ $stats['jobs_active'] }}/{{ $stats['jobs'] }}</div></div>
    <div class="so-card"><div class="so-label">Arizalar</div><div class="so-value" style="color:#fbbf24">{{ $stats['applications'] }}</div></div>
    <div class="so-card"><div class="so-label">Kutilmoqda</div><div class="so-value" style="color:#f59e0b">{{ $stats['applications_pending'] }}</div></div>
    <div class="so-card"><div class="so-label">Qabul qilingan</div><div class="so-value" style="color:#4ade80">{{ $stats['applications_accepted'] }}</div></div>
    <div class="so-card"><div class="so-label">Kurslar</div><div class="so-value" style="color:#fbbf24">{{ $stats['courses'] }}</div></div>
    <div class="so-card"><div class="so-label">Mentorlar</div><div class="so-value" style="color:#a78bfa">{{ $stats['mentors'] }}</div></div>
    <div class="so-card"><div class="so-label">GreenCoin jami</div><div class="so-value" style="color:#4ade80">{{ number_format($stats['greencoin_total']) }}</div></div>
    <div class="so-card"><div class="so-label">GC sarflangan</div><div class="so-value" style="color:#f87171">{{ number_format($stats['greencoin_spent']) }}</div></div>
    <div class="so-card"><div class="so-label">Mahsulotlar</div><div class="so-value" style="color:#84cc16">{{ $stats['farm_active'] }}/{{ $stats['farm_products'] }}</div></div>
    <div class="so-card"><div class="so-label">Faol mentorlik</div><div class="so-value" style="color:#c084fc">{{ $stats['mentorships_active'] }}</div></div>
  </div>

  {{-- CHARTS --}}
  <div class="charts-grid">
    <div class="chart-panel">
      <h3>Foydalanuvchilar o'sishi (30 kun)</h3>
      <canvas id="usersChart"></canvas>
    </div>
    <div class="chart-panel">
      <h3>GreenCoin faoliyati (30 kun)</h3>
      <canvas id="greenCoinChart"></canvas>
    </div>
    <div class="chart-panel">
      <h3>Ish arizalari (30 kun)</h3>
      <canvas id="applicationsChart"></canvas>
    </div>
    <div class="chart-panel">
      <h3>Regionlar bo'yicha</h3>
      <canvas id="regionsChart"></canvas>
    </div>
  </div>

  {{-- TOP USERS & REGIONS --}}
  <div class="top-grid">
    <div class="top-panel">
      <h3>Top 10 — GreenCoin bo'yicha</h3>
      @foreach($topUsers as $i => $u)
      <div class="top-item">
        <span class="top-rank">{{ $i + 1 }}</span>
        <span class="top-name">{{ $u->name }}</span>
        <span class="top-value">{{ number_format($u->greencoin_balance) }} GC</span>
      </div>
      @endforeach
    </div>
    <div class="top-panel">
      <h3>Top regionlar</h3>
      @foreach($topRegions as $i => $region)
      <div class="top-item">
        <span class="top-rank">{{ $i + 1 }}</span>
        <span class="top-name">{{ $region->region }}</span>
        <span class="top-value">{{ $region->count }} ta user</span>
      </div>
      @endforeach
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4/dist/chart.umd.min.js"></script>
<script>
const chartConfig = {responsive:true,plugins:{legend:{display:false}},scales:{x:{grid:{color:'rgba(255,255,255,.05)'},ticks:{color:'#64748b',font:{size:10}}},y:{grid:{color:'rgba(255,255,255,.05)'},ticks:{color:'#64748b',font:{size:10}}}}};

// Users Chart
new Chart(document.getElementById('usersChart'),{
  type:'line',
  data:{
    labels:{!! json_encode($registrations->pluck('date')->map(fn($d)=>\Carbon\Carbon::parse($d)->format('d.m'))) !!},
    datasets:[{data:{!! json_encode($registrations->pluck('count')) !!},borderColor:'#60a5fa',backgroundColor:'rgba(96,165,250,.1)',fill:true,tension:.4,pointRadius:2}]
  },
  options:chartConfig
});

// GreenCoin Chart
new Chart(document.getElementById('greenCoinChart'),{
  type:'bar',
  data:{
    labels:{!! json_encode($greenCoinDaily->pluck('date')->map(fn($d)=>\Carbon\Carbon::parse($d)->format('d.m'))) !!},
    datasets:[{data:{!! json_encode($greenCoinDaily->pluck('total')) !!},backgroundColor:'rgba(74,222,128,.6)',borderRadius:4}]
  },
  options:chartConfig
});

// Applications Chart
new Chart(document.getElementById('applicationsChart'),{
  type:'line',
  data:{
    labels:{!! json_encode($applicationsWeekly->pluck('date')->map(fn($d)=>\Carbon\Carbon::parse($d)->format('d.m'))) !!},
    datasets:[{data:{!! json_encode($applicationsWeekly->pluck('count')) !!},borderColor:'#fbbf24',backgroundColor:'rgba(251,191,36,.1)',fill:true,tension:.4,pointRadius:2}]
  },
  options:chartConfig
});

// Regions Chart
new Chart(document.getElementById('regionsChart'),{
  type:'doughnut',
  data:{
    labels:{!! json_encode($topRegions->pluck('region')) !!},
    datasets:[{data:{!! json_encode($topRegions->pluck('count')) !!},backgroundColor:['#60a5fa','#4ade80','#fbbf24','#a78bfa','#f87171','#22d3ee','#f97316','#ec4899','#84cc16','#6366f1']}]
  },
  options:{responsive:true,plugins:{legend:{position:'bottom',labels:{color:'#94a3b8',font:{size:10}}}}}
});
</script>
@endsection
