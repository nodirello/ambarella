@extends('layouts.app')
@section('title', 'Muvaffaqiyat hikoyalari | Admin')
@section('styles')
<style>
.admin-page{padding:32px 0}
.admin-page-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;flex-wrap:wrap;gap:12px}
.admin-page-header h1{font-size:22px;font-weight:800;color:#fff}
.stories-list{display:flex;flex-direction:column;gap:12px}
.story-item{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:20px;display:flex;justify-content:space-between;align-items:center;gap:16px;transition:all .2s}
.story-item:hover{border-color:rgba(37,99,235,.3)}
.story-info{display:flex;align-items:center;gap:14px;flex:1;min-width:0}
.story-avatar{width:44px;height:44px;border-radius:50%;background:rgba(37,99,235,.15);display:flex;align-items:center;justify-content:center;flex-shrink:0;overflow:hidden}
.story-avatar img{width:100%;height:100%;object-fit:cover}
.story-avatar span{font-size:18px;color:#93c5fd}
.story-details h3{font-size:15px;font-weight:600;color:#fff;margin-bottom:2px}
.story-details p{font-size:12px;color:var(--muted)}
.story-meta{display:flex;align-items:center;gap:8px;margin-top:4px}
.featured-badge{background:rgba(234,179,8,.1);color:#fde047;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600}
.actions-cell{display:flex;gap:6px;flex-shrink:0}
.action-btn{padding:6px 12px;border-radius:6px;font-size:11px;font-weight:600;cursor:pointer;border:none;text-decoration:none;display:inline-block}
.action-delete{background:rgba(220,38,38,.1);color:#fca5a5}
@media(max-width:768px){.story-item{flex-direction:column;align-items:flex-start}.actions-cell{align-self:flex-end}}
</style>
@endsection
@section('content')
<div class="container">
  <div class="admin-page">
    <div class="admin-page-header">
      <h1>Muvaffaqiyat hikoyalari ({{ $stories->total() }})</h1>
      <div style="display:flex;gap:10px">
        <a href="/admin" class="btn btn-outline" style="padding:8px 16px;font-size:12px">← Admin</a>
        <a href="/admin/stories/create" class="btn btn-primary" style="padding:8px 16px;font-size:12px">+ Yangi hikoya</a>
      </div>
    </div>
    <div class="stories-list">
      @foreach($stories as $story)
      <div class="story-item">
        <div class="story-info">
          <div class="story-avatar">
            @if($story->avatar_url)
              <img src="{{ $story->avatar_url }}" alt="{{ $story->user_name }}">
            @else
              <span>👤</span>
            @endif
          </div>
          <div class="story-details">
            <h3>{{ $story->user_name }}</h3>
            <p>{{ $story->user_role }} · {{ Str::limit($story->story, 60) }}</p>
            <div class="story-meta">
              @if($story->is_featured)
                <span class="featured-badge">⭐ Featured</span>
              @endif
              <span style="font-size:11px;color:var(--muted)">{{ $story->created_at->format('d.m.Y') }}</span>
            </div>
          </div>
        </div>
        <div class="actions-cell">
          <form method="POST" action="/admin/stories/{{ $story->id }}" onsubmit="return confirm('O\'chirilsinmi?')">@csrf @method('DELETE')<button class="action-btn action-delete">🗑️ O'chirish</button></form>
        </div>
      </div>
      @endforeach
    </div>
    <div style="margin-top:16px">{{ $stories->links() }}</div>
  </div>
</div>
@endsection
