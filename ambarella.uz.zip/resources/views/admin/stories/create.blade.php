@extends('layouts.app')
@section('title', 'Yangi hikoya | Admin')
@section('styles')
<style>
.form-page{padding:48px 0;max-width:640px;margin:0 auto}
.form-page h1{font-size:22px;font-weight:800;color:#fff;margin-bottom:32px}
.form-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:32px}
.form-group{margin-bottom:18px}
.form-group label{display:block;font-size:13px;font-weight:600;color:#94a3b8;margin-bottom:6px}
.form-group input,.form-group select,.form-group textarea{width:100%;padding:12px 16px;border:1px solid var(--border);border-radius:var(--radius);font-size:14px;background:rgba(255,255,255,.02);color:#fff;font-family:inherit}
.form-group input::placeholder,.form-group textarea::placeholder{color:#475569}
.form-group textarea{resize:vertical;min-height:120px}
.back-link{display:inline-flex;align-items:center;gap:6px;color:var(--muted);font-size:13px;margin-bottom:20px;transition:color .2s}
.back-link:hover{color:#fff}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.checkbox-group{display:flex;align-items:center;gap:10px}
.checkbox-group input[type="checkbox"]{width:18px;height:18px;accent-color:#3b82f6}
.checkbox-group label{margin-bottom:0;font-size:14px;color:#fff}
</style>
@endsection
@section('content')
<div class="container">
  <div class="form-page">
    <a href="/admin/stories" class="back-link">← Barcha hikoyalar</a>
    <h1>Yangi muvaffaqiyat hikoyasi</h1>
    <form method="POST" action="/admin/stories" class="form-card">
      @csrf
      <div class="form-row">
        <div class="form-group"><label>Ism *</label><input name="user_name" required placeholder="Foydalanuvchi ismi" value="{{ old('user_name') }}"></div>
        <div class="form-group"><label>Rol/Lavozim *</label><input name="user_role" required placeholder="masalan: Frontend dasturchi" value="{{ old('user_role') }}"></div>
      </div>
      <div class="form-group"><label>Hikoya *</label><textarea name="story" required placeholder="Muvaffaqiyat hikoyasi...">{{ old('story') }}</textarea></div>
      <div class="form-group"><label>Avatar URL (ixtiyoriy)</label><input name="avatar_url" placeholder="https://..." value="{{ old('avatar_url') }}"></div>
      <div class="form-group">
        <div class="checkbox-group">
          <input type="checkbox" name="is_featured" value="1" id="is_featured" {{ old('is_featured') ? 'checked' : '' }}>
          <label for="is_featured">⭐ Featured (bosh sahifada ko'rsatilsin)</label>
        </div>
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:14px">Saqlash</button>
    </form>
  </div>
</div>
@endsection
