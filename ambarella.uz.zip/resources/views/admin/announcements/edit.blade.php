@extends('layouts.app')
@section('title', 'E\'lon tahrirlash | Admin')
@section('styles')
<style>
.form-page{padding:48px 0;max-width:640px;margin:0 auto}
.form-page h1{font-size:22px;font-weight:800;color:#fff;margin-bottom:32px}
.form-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:32px}
.form-group{margin-bottom:18px}
.form-group label{display:block;font-size:13px;font-weight:600;color:#94a3b8;margin-bottom:6px}
.form-group input,.form-group select,.form-group textarea{width:100%;padding:12px 16px;border:1px solid var(--border);border-radius:var(--radius);font-size:14px;background:rgba(255,255,255,.02);color:#fff;font-family:inherit}
.form-group input::placeholder,.form-group textarea::placeholder{color:#475569}
.form-group textarea{resize:vertical;min-height:100px}
.back-link{display:inline-flex;align-items:center;gap:6px;color:var(--muted);font-size:13px;margin-bottom:20px;transition:color .2s}
.back-link:hover{color:#fff}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.checkbox-group{display:flex;align-items:center;gap:10px}
.checkbox-group input[type="checkbox"]{width:18px;height:18px;accent-color:#3b82f6}
.checkbox-group label{margin-bottom:0;font-size:14px;color:#fff}
</style>
@endsection
@section('content')
<div class="container">
  <div class="form-page">
    <a href="/admin/announcements" class="back-link">← Barcha e'lonlar</a>
    <h1>E'lon tahrirlash</h1>
    <form method="POST" action="/admin/announcements/{{ $announcement->id }}" class="form-card">
      @csrf
      @method('PUT')
      <div class="form-group"><label>Xabar *</label><textarea name="message" required>{{ old('message', $announcement->message) }}</textarea></div>
      <div class="form-row">
        <div class="form-group"><label>Turi *</label>
          <select name="type">
            <option value="info" {{ old('type', $announcement->type) == 'info' ? 'selected' : '' }}>ℹ️ Info</option>
            <option value="warning" {{ old('type', $announcement->type) == 'warning' ? 'selected' : '' }}>⚠️ Warning</option>
            <option value="success" {{ old('type', $announcement->type) == 'success' ? 'selected' : '' }}>✅ Success</option>
          </select>
        </div>
        <div class="form-group" style="display:flex;align-items:flex-end">
          <div class="checkbox-group">
            <input type="checkbox" name="is_active" value="1" id="is_active" {{ old('is_active', $announcement->is_active) ? 'checked' : '' }}>
            <label for="is_active">Faol</label>
          </div>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Boshlanish sanasi</label><input type="datetime-local" name="starts_at" value="{{ old('starts_at', $announcement->starts_at ? $announcement->starts_at->format('Y-m-d\TH:i') : '') }}"></div>
        <div class="form-group"><label>Tugash sanasi</label><input type="datetime-local" name="ends_at" value="{{ old('ends_at', $announcement->ends_at ? $announcement->ends_at->format('Y-m-d\TH:i') : '') }}"></div>
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:14px">Yangilash</button>
    </form>
  </div>
</div>
@endsection
