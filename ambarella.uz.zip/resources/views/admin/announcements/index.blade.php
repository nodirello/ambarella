@extends('layouts.app')
@section('title', 'E\'lonlar | Admin')
@section('styles')
<style>
.admin-page{padding:32px 0}
.admin-page-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;flex-wrap:wrap;gap:12px}
.admin-page-header h1{font-size:22px;font-weight:800;color:#fff}
.ann-list{display:flex;flex-direction:column;gap:12px}
.ann-item{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:20px;display:flex;justify-content:space-between;align-items:center;gap:16px;transition:all .2s}
.ann-item:hover{border-color:rgba(37,99,235,.3)}
.ann-item h3{font-size:15px;font-weight:600;color:#fff;margin-bottom:3px}
.ann-item p{font-size:12px;color:var(--muted)}
.ann-meta{display:flex;align-items:center;gap:8px;margin-top:6px;flex-wrap:wrap}
.type-badge{padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600}
.type-info{background:rgba(37,99,235,.1);color:#93c5fd}
.type-warning{background:rgba(234,179,8,.1);color:#fde047}
.type-success{background:rgba(34,197,94,.1);color:#86efac}
.status-badge{padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600}
.status-active{background:rgba(34,197,94,.1);color:#86efac}
.status-inactive{background:rgba(220,38,38,.1);color:#fca5a5}
.date-text{font-size:11px;color:var(--muted)}
.actions-cell{display:flex;gap:6px;flex-shrink:0}
.action-btn{padding:6px 12px;border-radius:6px;font-size:11px;font-weight:600;cursor:pointer;border:none;text-decoration:none;display:inline-block}
.action-edit{background:rgba(37,99,235,.1);color:#93c5fd}
.action-delete{background:rgba(220,38,38,.1);color:#fca5a5}
@media(max-width:768px){.ann-item{flex-direction:column;align-items:flex-start}.actions-cell{align-self:flex-end}}
</style>
@endsection
@section('content')
<div class="container">
  <div class="admin-page">
    <div class="admin-page-header">
      <h1>E'lonlar ({{ $announcements->total() }})</h1>
      <div style="display:flex;gap:10px">
        <a href="/admin" class="btn btn-outline" style="padding:8px 16px;font-size:12px">← Admin</a>
        <a href="/admin/announcements/create" class="btn btn-primary" style="padding:8px 16px;font-size:12px">+ Yangi e'lon</a>
      </div>
    </div>
    <div class="ann-list">
      @foreach($announcements as $ann)
      <div class="ann-item">
        <div>
          <h3>{{ Str::limit($ann->message, 80) }}</h3>
          <div class="ann-meta">
            <span class="type-badge type-{{ $ann->type }}">{{ $ann->type }}</span>
            <span class="status-badge {{ $ann->is_active ? 'status-active' : 'status-inactive' }}">{{ $ann->is_active ? 'Faol' : 'Nofaol' }}</span>
            @if($ann->starts_at)
              <span class="date-text">{{ $ann->starts_at->format('d.m.Y') }} — {{ $ann->ends_at ? $ann->ends_at->format('d.m.Y') : '∞' }}</span>
            @endif
          </div>
        </div>
        <div class="actions-cell">
          <a href="/admin/announcements/{{ $ann->id }}/edit" class="action-btn action-edit">Tahrir</a>
          <form method="POST" action="/admin/announcements/{{ $ann->id }}" onsubmit="return confirm('O\'chirilsinmi?')">@csrf @method('DELETE')<button class="action-btn action-delete">🗑️</button></form>
        </div>
      </div>
      @endforeach
    </div>
    <div style="margin-top:16px">{{ $announcements->links() }}</div>
  </div>
</div>
@endsection
