@extends('layouts.app')
@section('title', 'Yangi Telegram Vazifa | Admin')
@section('content')
<div class="container" style="padding:28px 28px 80px;max-width:700px">
  <a href="/admin/telegram/tasks" style="display:inline-flex;align-items:center;gap:6px;color:#334155;font-size:13px;margin-bottom:24px;transition:color .2s" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#334155'">
    ← Vazifalar ro'yxati
  </a>

  <h1 style="font-size:20px;font-weight:800;color:#fff;margin-bottom:24px">Yangi Telegram vazifa</h1>

  @if($errors->any())
    <div class="alert alert-error" style="margin-bottom:16px">{{ $errors->first() }}</div>
  @endif

  <div style="background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.05);border-radius:16px;padding:28px">
    <form action="/admin/telegram/tasks" method="POST">
      @csrf
      <div style="margin-bottom:16px">
        <label style="display:block;font-size:12px;font-weight:600;color:#94a3b8;margin-bottom:6px">Vazifa nomi *</label>
        <input type="text" name="title" value="{{ old('title') }}" required style="width:100%;padding:11px 14px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:10px;color:#fff;font-size:13px" placeholder="Masalan: Daraxt ekish" onfocus="this.style.borderColor='var(--primary)'" onblur="this.style.borderColor='rgba(255,255,255,.07)'">
      </div>

      <div style="margin-bottom:16px">
        <label style="display:block;font-size:12px;font-weight:600;color:#94a3b8;margin-bottom:6px">Tavsif</label>
        <textarea name="description" rows="3" style="width:100%;padding:11px 14px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:10px;color:#fff;font-size:13px;resize:vertical;font-family:inherit" placeholder="Foydalanuvchiga ko'rsatiladigan izoh">{{ old('description') }}</textarea>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px">
        <div>
          <label style="display:block;font-size:12px;font-weight:600;color:#94a3b8;margin-bottom:6px">Tur *</label>
          <select name="task_type" required style="width:100%;padding:10px 12px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:10px;color:#94a3b8;font-size:13px">
            <option value="action" {{ old('task_type')=='action' ? 'selected' : '' }}>Action (harakat)</option>
            <option value="referral" {{ old('task_type')=='referral' ? 'selected' : '' }}>Referral</option>
            <option value="subscription" {{ old('task_type')=='subscription' ? 'selected' : '' }}>Subscription</option>
            <option value="custom" {{ old('task_type')=='custom' ? 'selected' : '' }}>Custom</option>
          </select>
        </div>
        <div>
          <label style="display:block;font-size:12px;font-weight:600;color:#94a3b8;margin-bottom:6px">Mukofot (GC) *</label>
          <input type="number" name="reward" value="{{ old('reward', 50) }}" min="1" max="1000" required style="width:100%;padding:10px 14px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:10px;color:#fff;font-size:13px">
        </div>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px">
        <div>
          <label style="display:block;font-size:12px;font-weight:600;color:#94a3b8;margin-bottom:6px">Boshlanish (ixtiyoriy)</label>
          <input type="datetime-local" name="start_at" value="{{ old('start_at') }}" style="width:100%;padding:10px 14px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:10px;color:#94a3b8;font-size:13px">
        </div>
        <div>
          <label style="display:block;font-size:12px;font-weight:600;color:#94a3b8;margin-bottom:6px">Tugash (ixtiyoriy)</label>
          <input type="datetime-local" name="end_at" value="{{ old('end_at') }}" style="width:100%;padding:10px 14px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:10px;color:#94a3b8;font-size:13px">
        </div>
      </div>

      <div style="display:flex;align-items:center;gap:10px;padding:14px;background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.05);border-radius:10px;margin-bottom:20px">
        <input type="checkbox" name="requires_approval" id="req_approval" value="1" {{ old('requires_approval', '1') ? 'checked' : '' }} style="width:16px;height:16px;cursor:pointer">
        <label for="req_approval" style="font-size:13px;color:#94a3b8;cursor:pointer">Moderator tasdiq'i kerak (rasm va matn tekshiriladi)</label>
      </div>

      <div style="display:flex;gap:10px">
        <button type="submit" class="btn btn-primary" style="padding:12px 24px">Vazifani yaratish</button>
        <a href="/admin/telegram/tasks" class="btn btn-outline" style="padding:12px 20px">Bekor qilish</a>
      </div>
    </form>
  </div>
</div>
@endsection
