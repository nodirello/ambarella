@extends('layouts.app')
@section('title', 'Telegram Vazifalar | Admin')
@section('content')
<div class="container" style="padding:28px 28px 80px">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;flex-wrap:wrap;gap:12px">
    <div>
      <h1 style="font-size:20px;font-weight:800;color:#fff">Telegram Vazifalar</h1>
      <p style="font-size:12px;color:#334155;margin-top:3px">Bot orqali beriladigan vazifalar va mukofotlar</p>
    </div>
    <a href="/admin/telegram/tasks/create" class="btn btn-primary" style="padding:10px 18px;font-size:13px">+ Yangi vazifa</a>
  </div>

  @if(session('success'))
    <div class="alert alert-success" style="margin-bottom:16px">{{ session('success') }}</div>
  @endif

  @forelse($tasks as $task)
  <div style="background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.05);border-radius:14px;padding:18px 20px;margin-bottom:10px;display:grid;grid-template-columns:1fr auto;gap:16px;align-items:center;transition:border-color .2s" class="{{ !$task->is_active ? 'opacity-50' : '' }}">
    <div>
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px;flex-wrap:wrap">
        <span style="font-size:14px;font-weight:700;color:#fff">{{ $task->title }}</span>
        <span style="font-size:9px;font-weight:700;padding:2px 8px;border-radius:999px;background:rgba(37,99,235,.1);color:#93c5fd">{{ $task->task_type }}</span>
        @if($task->requires_approval)
          <span style="font-size:9px;font-weight:700;padding:2px 8px;border-radius:999px;background:rgba(245,158,11,.1);color:#fbbf24">Tasdiq kerak</span>
        @else
          <span style="font-size:9px;font-weight:700;padding:2px 8px;border-radius:999px;background:rgba(34,197,94,.1);color:#4ade80">Avtomatik</span>
        @endif
        @if(!$task->is_active)
          <span style="font-size:9px;font-weight:700;padding:2px 8px;border-radius:999px;background:rgba(100,116,139,.1);color:#475569">O'chirilgan</span>
        @endif
      </div>
      @if($task->description)
        <div style="font-size:12px;color:#475569;margin-bottom:6px">{{ $task->description }}</div>
      @endif
      <div style="font-size:11px;color:#1e293b;display:flex;gap:12px;flex-wrap:wrap">
        <span>💰 +{{ $task->reward }} GC</span>
        @if($task->start_at)<span>Boshlanadi: {{ $task->start_at->format('d.m.Y') }}</span>@endif
        @if($task->end_at)<span>Tugaydi: {{ $task->end_at->format('d.m.Y') }}</span>@endif
        <span>{{ $task->submissions()->count() }} ta topshiriq</span>
      </div>
    </div>
    <div style="display:flex;gap:8px">
      <form action="/admin/telegram/tasks/{{ $task->id }}/toggle" method="POST">
        @csrf
        <button type="submit" class="btn btn-outline" style="padding:8px 14px;font-size:11px">
          {{ $task->is_active ? 'O\'chirish' : 'Yoqish' }}
        </button>
      </form>
      <form action="/admin/telegram/tasks/{{ $task->id }}" method="POST" onsubmit="return confirm('O\'chirishni tasdiqlaysizmi?')">
        @csrf @method('DELETE')
        <button type="submit" class="btn btn-danger" style="padding:8px 12px;font-size:11px">✗</button>
      </form>
    </div>
  </div>
  @empty
  <div style="text-align:center;padding:60px;color:#334155">
    <p>Hali vazifalar yo'q. <a href="/admin/telegram/tasks/create" style="color:var(--primary)">Yaratish</a></p>
  </div>
  @endforelse
</div>
@endsection
