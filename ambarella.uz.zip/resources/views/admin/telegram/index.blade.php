@extends('layouts.app')
@section('title', 'Telegram Bot | Admin | AMBARELLA')
@section('styles')
<style>
.tg-page{padding:28px 28px 80px;max-width:1200px}
.tg-header{margin-bottom:28px}
.tg-header h1{font-size:22px;font-weight:800;color:#fff;display:flex;align-items:center;gap:10px}
.tg-header h1 svg{width:24px;height:24px;stroke:#60a5fa;fill:none;stroke-width:2}
.tg-header p{font-size:13px;color:#334155;margin-top:4px}
/* Stats */
.tg-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:14px;margin-bottom:28px}
.tgs{background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.05);border-radius:14px;padding:18px;text-align:center;transition:all .3s}
.tgs:hover{border-color:var(--tc);transform:translateY(-2px)}
.tgs-n{font-size:26px;font-weight:900;color:var(--tc,#60a5fa)}
.tgs-l{font-size:10px;color:#334155;margin-top:4px;font-weight:600;text-transform:uppercase}
/* Nav tabs */
.tg-tabs{display:flex;gap:6px;margin-bottom:24px;flex-wrap:wrap}
.tg-tab{padding:8px 18px;border-radius:10px;font-size:12px;font-weight:600;background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.05);color:#475569;transition:all .2s}
.tg-tab:hover,.tg-tab.active{background:rgba(37,99,235,.08);color:#93c5fd;border-color:rgba(37,99,235,.2)}
/* Grid */
.tg-grid{display:grid;grid-template-columns:2fr 1fr;gap:20px}
.tg-panel{background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.05);border-radius:16px;padding:22px}
.tg-panel-title{font-size:14px;font-weight:700;color:#fff;margin-bottom:16px;display:flex;align-items:center;justify-content:space-between;gap:8px}
.tg-panel-title svg{width:16px;height:16px;stroke:#60a5fa;fill:none;stroke-width:2}
.tg-panel-title a{font-size:11px;color:#334155;transition:color .2s}
.tg-panel-title a:hover{color:#60a5fa}
/* Submissions table */
.sub-tbl{width:100%;border-collapse:collapse;font-size:12px}
.sub-tbl th{text-align:left;padding:8px 10px;color:#1e293b;font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.8px;border-bottom:1px solid rgba(255,255,255,.04)}
.sub-tbl td{padding:10px;color:#64748b;border-bottom:1px solid rgba(255,255,255,.03);vertical-align:middle}
.sub-tbl tr:last-child td{border:none}
.sub-tbl tr:hover td{background:rgba(255,255,255,.015)}
.sub-type{display:inline-flex;align-items:center;gap:4px;padding:2px 8px;border-radius:999px;font-size:9px;font-weight:700}
.t-photo{background:rgba(37,99,235,.12);color:#93c5fd}
.t-text{background:rgba(100,116,139,.1);color:#64748b}
.sub-actions{display:flex;gap:6px}
.sub-btn{display:inline-flex;align-items:center;gap:4px;padding:5px 10px;border-radius:7px;font-size:10px;font-weight:700;border:none;cursor:pointer;transition:all .2s}
.sub-approve{background:rgba(34,197,94,.1);color:#4ade80;border:1px solid rgba(34,197,94,.2)}
.sub-approve:hover{background:rgba(34,197,94,.2)}
.sub-reject{background:rgba(239,68,68,.1);color:#f87171;border:1px solid rgba(239,68,68,.2)}
.sub-reject:hover{background:rgba(239,68,68,.2)}
.pending-badge{display:inline-flex;align-items:center;gap:3px;padding:2px 7px;border-radius:999px;font-size:9px;font-weight:700;background:rgba(245,158,11,.1);color:#fbbf24}
/* Broadcast form */
.bc-form textarea{width:100%;padding:10px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);border-radius:10px;color:#fff;font-size:13px;resize:vertical;min-height:80px;font-family:inherit}
.bc-form textarea:focus{outline:none;border-color:var(--primary)}
.bc-form select{width:100%;padding:9px 12px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);border-radius:8px;color:#94a3b8;font-size:12px;margin:8px 0}
/* Webhook */
.wh-info{padding:12px;background:rgba(34,197,94,.04);border:1px solid rgba(34,197,94,.1);border-radius:10px;font-size:12px;color:#4ade80;margin-bottom:12px;word-break:break-all}
/* Users list */
.tgu-item{display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid rgba(255,255,255,.04)}
.tgu-item:last-child{border:none}
.tgu-av{width:28px;height:28px;border-radius:50%;background:rgba(37,99,235,.15);display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;color:#93c5fd;flex-shrink:0}
.tgu-nm{font-size:12px;color:#fff;font-weight:600}
.tgu-mn{font-size:10px;color:#334155}
.tgu-linked{font-size:9px;padding:2px 6px;border-radius:999px;margin-left:auto}
.tgu-yes{background:rgba(34,197,94,.1);color:#4ade80}
.tgu-no{background:rgba(100,116,139,.08);color:#334155}
@media(max-width:1024px){.tg-grid{grid-template-columns:1fr}}
@media(max-width:640px){.tg-stats{grid-template-columns:1fr 1fr}.tg-tabs{gap:4px}.tg-tab{padding:7px 12px;font-size:11px}}
</style>
@endsection
@section('content')
<div class="container tg-page">
  <div class="tg-header">
    <h1>
      <svg viewBox="0 0 24 24"><path d="M21.2 5L10 13 3.8 9.5"/><path d="M21.2 5L14 21l-4-8-8-4 19.2-4z"/></svg>
      Telegram Bot Boshqaruvi
    </h1>
    <p>@AmbarellaBot — foydalanuvchilar, topshiriqlar va broadcast</p>
  </div>

  @if(session('success'))
    <div class="alert alert-success" style="margin-bottom:16px">{{ session('success') }}</div>
  @endif
  @if($errors->any())
    <div class="alert alert-error" style="margin-bottom:16px">{{ $errors->first() }}</div>
  @endif

  {{-- Stats --}}
  <div class="tg-stats">
    <div class="tgs" style="--tc:#60a5fa"><div class="tgs-n">{{ $stats['total_users'] }}</div><div class="tgs-l">Bot users</div></div>
    <div class="tgs" style="--tc:#4ade80"><div class="tgs-n">{{ $stats['linked_users'] }}</div><div class="tgs-l">Bog'langan</div></div>
    <div class="tgs" style="--tc:#fbbf24"><div class="tgs-n">{{ $stats['pending'] }}</div><div class="tgs-l">Kutilmoqda</div></div>
    <div class="tgs" style="--tc:#a78bfa"><div class="tgs-n">{{ number_format($stats['total_gc_given']) }}</div><div class="tgs-l">GC berildi</div></div>
    <div class="tgs" style="--tc:#22d3ee"><div class="tgs-n">{{ $stats['approved_today'] }}</div><div class="tgs-l">Bugun tasdiqlandi</div></div>
    <div class="tgs" style="--tc:#f97316"><div class="tgs-n">{{ $stats['active_tasks'] }}</div><div class="tgs-l">Faol vazifalar</div></div>
  </div>

  {{-- Tabs --}}
  <div class="tg-tabs">
    <a href="/admin/telegram" class="tg-tab active">Dashboard</a>
    <a href="/admin/telegram/submissions" class="tg-tab">Topshiriqlar</a>
    <a href="/admin/telegram/tasks" class="tg-tab">Vazifalar</a>
    <a href="/admin/telegram/tasks/create" class="tg-tab" style="background:rgba(37,99,235,.08);color:#93c5fd">+ Vazifa qo'shish</a>
  </div>

  <div class="tg-grid">
    {{-- Left: Pending Submissions --}}
    <div>
      <div class="tg-panel">
        <div class="tg-panel-title">
          <span style="display:flex;align-items:center;gap:8px">
            <svg viewBox="0 0 24 24"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></svg>
            Kutayotgan topshiriqlar
            @if($stats['pending'] > 0)
              <span class="pending-badge">{{ $stats['pending'] }}</span>
            @endif
          </span>
          <a href="/admin/telegram/submissions">Hammasi →</a>
        </div>
        @if($pendingSubmissions->isEmpty())
          <p style="color:#334155;font-size:13px;text-align:center;padding:20px">Kutayotgan topshiriq yo'q 🎉</p>
        @else
        <div style="overflow-x:auto">
          <table class="sub-tbl">
            <thead><tr><th>Foydalanuvchi</th><th>Vazifa</th><th>Tur</th><th>GC</th><th>Amal</th></tr></thead>
            <tbody>
              @foreach($pendingSubmissions as $sub)
              <tr>
                <td style="color:#fff;font-weight:600">{{ $sub->user?->name ?? 'N/A' }}</td>
                <td>{{ $sub->task?->title ?? 'Eco action' }}</td>
                <td>
                  <span class="sub-type {{ $sub->media_type === 'photo' ? 't-photo' : 't-text' }}">
                    {{ $sub->media_type === 'photo' ? '📸 Rasm' : '📝 Matn' }}
                  </span>
                </td>
                <td style="color:#4ade80;font-weight:700">+{{ $sub->reward_amount }}</td>
                <td>
                  <div class="sub-actions">
                    <form action="/admin/telegram/submissions/{{ $sub->id }}/approve" method="POST" style="display:inline">
                      @csrf
                      <button type="submit" class="sub-btn sub-approve">✓ Tasdiqlash</button>
                    </form>
                    <form action="/admin/telegram/submissions/{{ $sub->id }}/reject" method="POST" style="display:inline">
                      @csrf
                      <button type="submit" class="sub-btn sub-reject">✗ Rad</button>
                    </form>
                  </div>
                </td>
              </tr>
              @endforeach
            </tbody>
          </table>
        </div>
        @endif
      </div>
    </div>

    {{-- Right --}}
    <div style="display:flex;flex-direction:column;gap:16px">
      {{-- Webhook --}}
      <div class="tg-panel">
        <div class="tg-panel-title"><span style="display:flex;align-items:center;gap:8px"><svg viewBox="0 0 24 24"><path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/></svg>Webhook</span></div>
        <div class="wh-info">{{ url('/webhook/telegram') }}</div>
        <form action="/admin/telegram/set-webhook" method="POST">
          @csrf
          <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:10px;font-size:13px">Webhookni o'rnatish</button>
        </form>
      </div>

      {{-- Broadcast --}}
      <div class="tg-panel">
        <div class="tg-panel-title"><span style="display:flex;align-items:center;gap:8px"><svg viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 12"/></svg>Broadcast</span></div>
        <form action="/admin/telegram/broadcast" method="POST" class="bc-form">
          @csrf
          <textarea name="message" placeholder="Barcha foydalanuvchilarga yuboriladigan xabar..." required></textarea>
          <select name="target">
            <option value="all">Hammaga ({{ $stats['total_users'] }})</option>
            <option value="linked">Bog'langanlar ({{ $stats['linked_users'] }})</option>
            <option value="unlinked">Bog'lanmaganlar ({{ $stats['total_users'] - $stats['linked_users'] }})</option>
          </select>
          <button type="submit" class="btn btn-outline" style="width:100%;justify-content:center;padding:10px;font-size:13px" onclick="return confirm('Xabar yuborilsinmi?')">Yuborish</button>
        </form>
      </div>

      {{-- Recent users --}}
      <div class="tg-panel">
        <div class="tg-panel-title"><span style="display:flex;align-items:center;gap:8px"><svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>So'nggi bot users</span></div>
        @foreach($recentUsers as $tgu)
        <div class="tgu-item">
          <div class="tgu-av">{{ strtoupper(mb_substr($tgu->first_name ?? 'U', 0, 1)) }}</div>
          <div>
            <div class="tgu-nm">{{ $tgu->first_name ?? 'Noma\'lum' }} @if($tgu->username)<span style="color:#334155;font-weight:400">@{{ $tgu->username }}</span>@endif</div>
            <div class="tgu-mn">{{ $tgu->created_at->diffForHumans() }}</div>
          </div>
          <span class="tgu-linked {{ $tgu->user_id ? 'tgu-yes' : 'tgu-no' }}">
            {{ $tgu->user_id ? '✓ Bog\'langan' : 'Bog\'lanmagan' }}
          </span>
        </div>
        @endforeach
      </div>
    </div>
  </div>
</div>
@endsection
