@extends('layouts.app')
@section('title', 'Telegram Topshiriqlar | Admin')
@section('styles')
<style>
.sub-page{padding:28px 28px 80px}
.sub-page h1{font-size:20px;font-weight:800;color:#fff;margin-bottom:4px}
.sub-page p{font-size:12px;color:#334155;margin-bottom:24px}
.sub-filters{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:20px}
.sf-tab{padding:7px 16px;border-radius:10px;font-size:12px;font-weight:600;background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.05);color:#475569;transition:all .2s}
.sf-tab:hover,.sf-tab.on{background:rgba(37,99,235,.08);color:#93c5fd;border-color:rgba(37,99,235,.2)}
.sub-card{background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.05);border-radius:14px;padding:18px 20px;margin-bottom:10px;display:grid;grid-template-columns:1fr auto;gap:16px;align-items:start;transition:border-color .2s}
.sub-card:hover{border-color:rgba(37,99,235,.12)}
.sub-card.pending{border-left:3px solid #fbbf24}
.sub-card.approved{border-left:3px solid #4ade80}
.sub-card.rejected{border-left:3px solid #f87171;opacity:.7}
.sc-top{display:flex;align-items:center;gap:10px;margin-bottom:8px;flex-wrap:wrap}
.sc-user{font-size:13px;font-weight:700;color:#fff}
.sc-task{font-size:12px;color:#475569}
.sc-date{font-size:11px;color:#1e293b}
.sc-body{font-size:13px;color:#64748b;line-height:1.6;background:rgba(255,255,255,.02);border-radius:8px;padding:10px 14px;margin-top:8px}
.sc-body img{max-width:100%;border-radius:8px;margin-top:6px}
.sc-actions{display:flex;flex-direction:column;gap:8px;align-items:flex-end}
.sc-gc{font-size:18px;font-weight:900;color:#4ade80}
.sc-status{font-size:10px;padding:3px 9px;border-radius:999px;font-weight:700}
.ss-pending{background:rgba(245,158,11,.1);color:#fbbf24}
.ss-approved{background:rgba(34,197,94,.1);color:#4ade80}
.ss-rejected{background:rgba(239,68,68,.1);color:#f87171}
.sc-note{font-size:11px;color:#334155;font-style:italic;margin-top:4px}
.sc-reviewer{font-size:10px;color:#1e293b}
@media(max-width:640px){.sub-card{grid-template-columns:1fr}.sc-actions{align-items:flex-start;flex-direction:row;flex-wrap:wrap}}
</style>
@endsection
@section('content')
<div class="container sub-page">
  <h1>Telegram Topshiriqlar</h1>
  <p>Foydalanuvchilardan kelgan barcha eco va vazifa topshiriqlari</p>

  @if(session('success'))
    <div class="alert alert-success" style="margin-bottom:16px">{{ session('success') }}</div>
  @endif

  {{-- Filters --}}
  <div class="sub-filters">
    <a href="/admin/telegram/submissions" class="sf-tab {{ !request('status') ? 'on' : '' }}">Hammasi ({{ $submissions->total() }})</a>
    <a href="?status=pending" class="sf-tab {{ request('status')=='pending' ? 'on' : '' }}">⏳ Kutilmoqda</a>
    <a href="?status=approved" class="sf-tab {{ request('status')=='approved' ? 'on' : '' }}">✅ Tasdiqlangan</a>
    <a href="?status=rejected" class="sf-tab {{ request('status')=='rejected' ? 'on' : '' }}">❌ Rad etilgan</a>
  </div>

  @forelse($submissions as $sub)
  <div class="sub-card {{ $sub->status }}">
    <div>
      <div class="sc-top">
        <span class="sc-user">{{ $sub->user?->name ?? 'N/A' }}</span>
        <span class="sc-task">{{ $sub->task?->title ?? 'Eco action' }}</span>
        <span class="sc-date">{{ $sub->created_at->format('d.m.Y H:i') }}</span>
        <span class="sub-type {{ $sub->media_type === 'photo' ? 't-photo' : 't-text' }}" style="display:inline-flex;align-items:center;gap:3px;padding:2px 7px;border-radius:999px;font-size:9px;font-weight:700;background:rgba(37,99,235,.1);color:#93c5fd">
          {{ $sub->media_type === 'photo' ? '📸 Rasm' : '📝 Matn' }}
        </span>
      </div>

      @if($sub->media_type === 'text' && isset($sub->payload['text']))
      <div class="sc-body">{{ $sub->payload['text'] }}</div>
      @elseif($sub->media_type === 'photo')
      <div class="sc-body">
        📸 Rasm yuborildi
        @if(isset($sub->payload['caption']) && $sub->payload['caption'])
          <div style="color:#94a3b8;margin-top:4px">{{ $sub->payload['caption'] }}</div>
        @endif
        <div style="font-size:10px;color:#334155;margin-top:4px">file_id: {{ $sub->payload['file_id'] ?? 'N/A' }}</div>
      </div>
      @endif

      @if($sub->notes)
        <div class="sc-note">Izoh: {{ $sub->notes }}</div>
      @endif
      @if($sub->reviewer)
        <div class="sc-reviewer">Ko'rib chiqdi: {{ $sub->reviewer->name }} — {{ $sub->reviewed_at?->format('d.m.Y H:i') }}</div>
      @endif
    </div>

    <div class="sc-actions">
      <div class="sc-gc">+{{ $sub->reward_amount }} GC</div>
      <span class="sc-status ss-{{ $sub->status }}">
        @if($sub->status==='pending') ⏳ Kutilmoqda
        @elseif($sub->status==='approved') ✅ Tasdiqlandi
        @else ❌ Rad etildi @endif
      </span>
      @if($sub->status === 'pending')
      <form action="/admin/telegram/submissions/{{ $sub->id }}/approve" method="POST">
        @csrf
        <button type="submit" class="btn btn-success" style="padding:8px 14px;font-size:12px">✓ Tasdiqlash</button>
      </form>
      <form action="/admin/telegram/submissions/{{ $sub->id }}/reject" method="POST">
        @csrf
        <button type="submit" class="btn btn-danger" style="padding:8px 14px;font-size:12px">✗ Rad etish</button>
      </form>
      @endif
    </div>
  </div>
  @empty
  <div style="text-align:center;padding:60px;color:#334155">
    <p>Topshiriqlar yo'q</p>
  </div>
  @endforelse

  @if($submissions->hasPages())
  <div style="display:flex;justify-content:center;margin-top:24px">{{ $submissions->links() }}</div>
  @endif
</div>
@endsection
