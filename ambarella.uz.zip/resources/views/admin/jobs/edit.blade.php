@extends('layouts.app')
@section('title', 'Tahrirlash | Admin')
@section('styles')
<style>
.form-page{padding:48px 0;max-width:640px;margin:0 auto}
.form-page h1{font-size:22px;font-weight:800;color:#fff;margin-bottom:32px}
.form-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:32px}
.form-group{margin-bottom:18px}
.form-group label{display:block;font-size:13px;font-weight:600;color:#94a3b8;margin-bottom:6px}
.form-group input,.form-group select,.form-group textarea{width:100%;padding:12px 16px;border:1px solid var(--border);border-radius:var(--radius);font-size:14px;background:rgba(255,255,255,.02);color:#fff;font-family:inherit}
.form-group textarea{resize:vertical;min-height:100px}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.back-link{display:inline-flex;align-items:center;gap:6px;color:var(--muted);font-size:13px;margin-bottom:20px;transition:color .2s}
.back-link:hover{color:#fff}
@media(max-width:768px){.form-row{grid-template-columns:1fr}}
</style>
@endsection
@section('content')
<div class="container">
  <div class="form-page">
    <a href="/admin/jobs" class="back-link">← Barcha e'lonlar</a>
    <h1>Tahrirlash: {{ $job->title }}</h1>
    <form method="POST" action="/admin/jobs/{{ $job->id }}" class="form-card">
      @csrf @method('PUT')
      <div class="form-group"><label>Lavozim</label><input name="title" value="{{ $job->title }}" required></div>
      <div class="form-group"><label>Kompaniya</label><input name="company" value="{{ $job->company }}" required></div>
      <div class="form-row">
        <div class="form-group"><label>Joylashuv</label><input name="location" value="{{ $job->location }}" required></div>
        <div class="form-group"><label>Ish turi</label>
          <select name="type">
            <option value="toliq" {{ $job->type=='toliq'?'selected':'' }}>To'liq kunlik</option>
            <option value="yarim" {{ $job->type=='yarim'?'selected':'' }}>Yarim kunlik</option>
            <option value="masofaviy" {{ $job->type=='masofaviy'?'selected':'' }}>Masofaviy</option>
          </select>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Min maosh</label><input name="salary_min" type="number" value="{{ $job->salary_min }}" required></div>
        <div class="form-group"><label>Max maosh</label><input name="salary_max" type="number" value="{{ $job->salary_max }}" required></div>
      </div>
      <div class="form-group"><label>Teglar</label><input name="tags" value="{{ implode(', ', $job->tags ?? []) }}"></div>
      <div class="form-group"><label>Tavsif</label><textarea name="description">{{ $job->description }}</textarea></div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:14px">Saqlash</button>
    </form>
  </div>
</div>
@endsection
