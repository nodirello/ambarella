@extends('layouts.app')
@section('title', 'Ish e\'lonlari | Admin')
@section('styles')
<style>
.admin-page{padding:32px 0}
.admin-page-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;flex-wrap:wrap;gap:12px}
.admin-page-header h1{font-size:22px;font-weight:800;color:#fff}
.header-actions{display:flex;gap:10px}
.admin-table{width:100%;border-collapse:collapse;font-size:13px}
.admin-table th{text-align:left;padding:12px 14px;font-size:11px;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);border-bottom:1px solid var(--border);background:var(--surface)}
.admin-table td{padding:12px 14px;border-bottom:1px solid var(--border);color:#cbd5e1}
.admin-table tr:hover td{background:rgba(255,255,255,.02)}
.actions-cell{display:flex;gap:6px;flex-wrap:wrap}
.action-btn{padding:4px 10px;border-radius:6px;font-size:11px;font-weight:600;cursor:pointer;border:none;text-decoration:none;display:inline-block}
.action-edit{background:rgba(37,99,235,.1);color:#93c5fd}
.action-toggle{background:rgba(245,158,11,.1);color:#fbbf24}
.action-delete{background:rgba(220,38,38,.1);color:#fca5a5}
.badge-active{color:#4ade80;font-weight:600;font-size:12px}
.badge-inactive{color:var(--muted);font-size:12px}
@media(max-width:768px){.admin-table th:nth-child(3),.admin-table td:nth-child(3){display:none}}
</style>
@endsection
@section('content')
<div class="container">
  <div class="admin-page">
    <div class="admin-page-header">
      <h1>Ish e'lonlari ({{ $jobs->total() }})</h1>
      <div class="header-actions">
        <a href="/admin" class="btn btn-outline" style="padding:8px 16px;font-size:12px">← Admin</a>
        <a href="/admin/jobs/create" class="btn btn-primary" style="padding:8px 16px;font-size:12px">+ Yangi e'lon</a>
      </div>
    </div>
    <div style="overflow-x:auto;border:1px solid var(--border);border-radius:var(--radius)">
      <table class="admin-table">
        <thead><tr><th>Lavozim</th><th>Kompaniya</th><th>Maosh</th><th>Holat</th><th>Amallar</th></tr></thead>
        <tbody>
          @foreach($jobs as $job)
          <tr>
            <td style="color:#fff;font-weight:600">{{ $job->title }}</td>
            <td>{{ $job->company }} — {{ $job->location }}</td>
            <td style="color:#4ade80;font-weight:600">{{ number_format($job->salary_min/1000000) }}–{{ number_format($job->salary_max/1000000) }} mln</td>
            <td>{!! $job->is_active ? '<span class="badge-active">Faol</span>' : '<span class="badge-inactive">O\'chiq</span>' !!}</td>
            <td>
              <div class="actions-cell">
                <a href="/admin/jobs/{{ $job->id }}/edit" class="action-btn action-edit">Tahrir</a>
                <form method="POST" action="/admin/jobs/{{ $job->id }}/toggle">@csrf<button class="action-btn action-toggle">{{ $job->is_active?'O\'chirish':'Yoqish' }}</button></form>
                <form method="POST" action="/admin/jobs/{{ $job->id }}" onsubmit="return confirm('O\'chirilsinmi?')">@csrf @method('DELETE')<button class="action-btn action-delete">🗑️</button></form>
              </div>
            </td>
          </tr>
          @endforeach
        </tbody>
      </table>
    </div>
    <div style="margin-top:16px">{{ $jobs->links() }}</div>
  </div>
</div>
@endsection
