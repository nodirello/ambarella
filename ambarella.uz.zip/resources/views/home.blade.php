﻿@extends('layouts.app')
@section('title', 'AMBARELLA — O\'zbekiston Yoshlari Platformasi')
@section('description', 'Bandlik, ekologiya, ta\'lim, mentorlik, startup — O\'zbekiston yoshlari uchun 35+ modul bitta platformada.')
@section('styles')
<style>
/* ─── RESET & BASE ─── */
*{box-sizing:border-box}

/* ─── HERO ─── */
.hero-section{
  min-height:100vh;display:flex;align-items:center;
  position:relative;overflow:hidden;
  background:#0a0f1e;
  padding:80px 0 60px;
}
.hero-section::before{
  content:'';position:absolute;inset:0;
  background:
    radial-gradient(ellipse 80% 60% at 20% 50%,rgba(37,99,235,.12) 0%,transparent 70%),
    radial-gradient(ellipse 60% 80% at 80% 30%,rgba(124,58,237,.08) 0%,transparent 70%),
    radial-gradient(ellipse 40% 40% at 60% 80%,rgba(16,185,129,.06) 0%,transparent 60%);
}
/* Animated grid background */
.hero-section::after{
  content:'';position:absolute;inset:0;
  background-image:
    linear-gradient(rgba(37,99,235,.03) 1px,transparent 1px),
    linear-gradient(90deg,rgba(37,99,235,.03) 1px,transparent 1px);
  background-size:60px 60px;
  mask-image:radial-gradient(ellipse at center,black 30%,transparent 80%);
  animation:gridMove 20s linear infinite;
}
@keyframes gridMove{to{background-position:60px 60px}}
.hero-inner{
  position:relative;z-index:2;
  display:grid;grid-template-columns:1fr 1fr;
  gap:64px;align-items:center;
  max-width:1200px;margin:0 auto;padding:0 20px;
}
/* Left */
.hero-tag{
  display:inline-flex;align-items:center;gap:8px;
  padding:6px 14px;border-radius:999px;
  background:rgba(37,99,235,.08);
  border:1px solid rgba(37,99,235,.2);
  font-size:12px;font-weight:700;color:#93c5fd;
  margin-bottom:24px;letter-spacing:.5px;
  animation:fadeUp .6s ease backwards;
}
.hero-tag .live{
  width:8px;height:8px;border-radius:50%;
  background:#4ade80;
  box-shadow:0 0 0 0 rgba(74,222,128,.4);
  animation:livePulse 2s infinite;
}
@keyframes livePulse{
  0%{box-shadow:0 0 0 0 rgba(74,222,128,.4)}
  70%{box-shadow:0 0 0 8px rgba(74,222,128,0)}
  100%{box-shadow:0 0 0 0 rgba(74,222,128,0)}
}
.hero-title{
  font-size:clamp(36px,5vw,62px);
  font-weight:900;line-height:1.1;
  color:#fff;margin-bottom:8px;
  animation:fadeUp .6s ease .1s backwards;
}
.hero-title .grad{
  background:linear-gradient(135deg,#60a5fa 0%,#a78bfa 40%,#ec4899 100%);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;
  background-clip:text;
}
.hero-sub{
  font-size:18px;color:#64748b;
  line-height:1.7;margin:16px 0 36px;
  max-width:480px;
  animation:fadeUp .6s ease .2s backwards;
}
.hero-cta{
  display:flex;gap:14px;flex-wrap:wrap;
  animation:fadeUp .6s ease .3s backwards;
}
.btn-hero-primary{
  display:inline-flex;align-items:center;gap:8px;
  padding:14px 28px;border-radius:12px;
  background:linear-gradient(135deg,#2563eb,#7c3aed);
  color:#fff;font-size:15px;font-weight:700;
  box-shadow:0 4px 24px rgba(37,99,235,.35);
  transition:all .3s;border:none;cursor:pointer;
}
.btn-hero-primary:hover{
  transform:translateY(-2px);
  box-shadow:0 8px 32px rgba(37,99,235,.5);
}
.btn-hero-primary svg{width:18px;height:18px;stroke:currentColor;fill:none;stroke-width:2}
.btn-hero-outline{
  display:inline-flex;align-items:center;gap:8px;
  padding:14px 24px;border-radius:12px;
  background:rgba(255,255,255,.04);
  border:1px solid rgba(255,255,255,.1);
  color:#94a3b8;font-size:15px;font-weight:600;
  transition:all .3s;
}
.btn-hero-outline:hover{
  background:rgba(255,255,255,.07);
  border-color:rgba(255,255,255,.2);
  color:#fff;
}
/* Stats row */
.hero-stats{
  display:flex;gap:32px;margin-top:48px;
  flex-wrap:wrap;
  animation:fadeUp .6s ease .4s backwards;
}
.hs{border-right:1px solid rgba(255,255,255,.06);padding-right:32px}
.hs:last-child{border:none;padding:0}
.hs-num{font-size:28px;font-weight:900;color:#fff;line-height:1}
.hs-num span{font-size:14px;color:#4ade80;font-weight:700}
.hs-lbl{font-size:11px;color:#475569;margin-top:4px;font-weight:500}

/* Right — Visual */
.hero-visual{
  position:relative;
  animation:fadeUp .6s ease .2s backwards;
}
.hero-visual-card{
  background:rgba(255,255,255,.03);
  border:1px solid rgba(255,255,255,.07);
  border-radius:20px;
  padding:24px;
  backdrop-filter:blur(12px);
}
/* Floating cards */
.float-card{
  position:absolute;
  background:rgba(15,23,42,.9);
  border:1px solid rgba(255,255,255,.08);
  border-radius:14px;
  padding:12px 16px;
  backdrop-filter:blur(16px);
  display:flex;align-items:center;gap:10px;
  white-space:nowrap;
  font-size:13px;font-weight:600;
}
.fc-1{top:-20px;right:-10px;animation:float1 4s ease-in-out infinite}
.fc-2{bottom:20px;left:-30px;animation:float2 5s ease-in-out infinite}
.fc-3{top:40%;right:-40px;animation:float1 6s ease-in-out infinite .5s}
@keyframes float1{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}
@keyframes float2{0%,100%{transform:translateY(0)}50%{transform:translateY(8px)}}
.fc-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0}

/* ─── ANIMATIONS ─── */
@keyframes fadeUp{from{opacity:0;transform:translateY(24px)}to{opacity:1;transform:translateY(0)}}

/* ─── SECTION BASE ─── */
.s{padding:100px 0}
.s-sm{padding:72px 0}
.container{max-width:1200px;margin:0 auto;padding:0 20px}
.s-label{
  display:inline-flex;align-items:center;gap:6px;
  padding:5px 14px;border-radius:999px;
  font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:2px;
  margin-bottom:16px;
}
.s-title{font-size:clamp(24px,3.5vw,42px);font-weight:900;color:#fff;margin-bottom:14px;line-height:1.2}
.s-desc{font-size:16px;color:#64748b;line-height:1.7;max-width:560px}
.s-head{text-align:center;margin-bottom:64px}
.s-head .s-desc{margin:0 auto}

/* ─── MARQUEE LOGOS ─── */
.marquee-section{padding:32px 0;border-top:1px solid rgba(255,255,255,.04);border-bottom:1px solid rgba(255,255,255,.04);background:rgba(255,255,255,.01);overflow:hidden}
.marquee-track{display:flex;gap:48px;animation:marquee 20s linear infinite;width:max-content}
.marquee-section:hover .marquee-track{animation-play-state:paused}
.marquee-item{display:flex;align-items:center;gap:10px;padding:10px 20px;background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.05);border-radius:10px;font-size:13px;font-weight:600;color:#475569;white-space:nowrap}
.marquee-item svg{width:18px;height:18px;stroke:currentColor;fill:none;stroke-width:1.8;opacity:.7}
@keyframes marquee{to{transform:translateX(-50%)}}
</style>
<style>
/* ─── HOW IT WORKS ─── */
.steps-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:24px;position:relative}
.steps-grid::before{
  content:'';position:absolute;top:36px;left:10%;right:10%;height:1px;
  background:linear-gradient(90deg,transparent,rgba(37,99,235,.3),rgba(124,58,237,.3),transparent);
}
.step-card{
  background:rgba(255,255,255,.02);
  border:1px solid rgba(255,255,255,.06);
  border-radius:18px;padding:28px 20px;
  text-align:center;position:relative;
  transition:all .3s;
}
.step-card:hover{
  background:rgba(37,99,235,.04);
  border-color:rgba(37,99,235,.2);
  transform:translateY(-4px);
}
.step-num{
  width:52px;height:52px;border-radius:50%;
  background:linear-gradient(135deg,#2563eb,#7c3aed);
  display:flex;align-items:center;justify-content:center;
  font-size:18px;font-weight:900;color:#fff;
  margin:0 auto 18px;
  box-shadow:0 4px 20px rgba(37,99,235,.3);
}
.step-card h3{font-size:15px;font-weight:700;color:#fff;margin-bottom:8px}
.step-card p{font-size:13px;color:#64748b;line-height:1.6}

/* ─── MODULES GRID ─── */
.modules-showcase{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}
.module-tile{
  background:rgba(255,255,255,.02);
  border:1px solid rgba(255,255,255,.06);
  border-radius:16px;
  padding:22px;
  display:flex;align-items:flex-start;gap:14px;
  transition:all .3s;
  position:relative;overflow:hidden;
}
.module-tile:hover{
  background:rgba(255,255,255,.04);
  border-color:var(--tile-color,rgba(37,99,235,.3));
  transform:translateY(-2px);
}
.module-tile::before{
  content:'';position:absolute;
  top:0;left:0;right:0;height:2px;
  background:var(--tile-color,var(--primary));
  transform:scaleX(0);transform-origin:left;
  transition:transform .3s;
}
.module-tile:hover::before{transform:scaleX(1)}
.mt-icon{
  width:40px;height:40px;border-radius:10px;
  display:flex;align-items:center;justify-content:center;
  flex-shrink:0;
}
.mt-icon svg{width:20px;height:20px;stroke:var(--tile-color,#60a5fa);fill:none;stroke-width:1.8}
.mt-body h4{font-size:14px;font-weight:700;color:#fff;margin-bottom:4px}
.mt-body p{font-size:12px;color:#64748b;line-height:1.5}

/* ─── RESULTS ─── */
.results-band{
  display:grid;grid-template-columns:repeat(5,1fr);gap:1px;
  background:rgba(255,255,255,.06);
  border-radius:20px;overflow:hidden;
  border:1px solid rgba(255,255,255,.06);
}
.result-cell{
  background:#0a0f1e;
  padding:32px 20px;text-align:center;
  transition:background .3s;
}
.result-cell:hover{background:rgba(37,99,235,.04)}
.rc-num{
  font-size:clamp(24px,3vw,36px);font-weight:900;
  background:linear-gradient(135deg,#60a5fa,#a78bfa);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;
  background-clip:text;margin-bottom:6px;
}
.rc-lbl{font-size:12px;color:#475569;font-weight:500}

/* ─── BENEFITS ─── */
.benefits-grid{display:grid;grid-template-columns:1fr 1fr;gap:40px;align-items:center}
.benefits-list{display:flex;flex-direction:column;gap:16px}
.benefit-item{
  display:flex;align-items:flex-start;gap:14px;
  padding:18px 20px;
  background:rgba(255,255,255,.02);
  border:1px solid rgba(255,255,255,.06);
  border-radius:14px;
  transition:all .3s;
}
.benefit-item:hover{
  background:rgba(37,99,235,.04);
  border-color:rgba(37,99,235,.2);
}
.bi-icon{
  width:38px;height:38px;border-radius:10px;
  display:flex;align-items:center;justify-content:center;
  flex-shrink:0;
}
.bi-icon svg{width:18px;height:18px;fill:none;stroke-width:2}
.bi-text h4{font-size:14px;font-weight:700;color:#fff;margin-bottom:3px}
.bi-text p{font-size:12px;color:#64748b;line-height:1.5}

/* ─── CTA SECTION ─── */
.cta-section{
  position:relative;overflow:hidden;
  background:linear-gradient(135deg,rgba(37,99,235,.08),rgba(124,58,237,.06));
  border:1px solid rgba(37,99,235,.15);
  border-radius:24px;
  padding:72px 48px;
  text-align:center;
}
.cta-section::before{
  content:'';position:absolute;
  top:-100px;left:50%;transform:translateX(-50%);
  width:600px;height:400px;
  background:radial-gradient(circle,rgba(37,99,235,.15),transparent 70%);
  pointer-events:none;
}
.cta-section h2{font-size:clamp(24px,4vw,44px);font-weight:900;color:#fff;margin-bottom:16px;position:relative}
.cta-section p{font-size:16px;color:#64748b;margin-bottom:36px;max-width:480px;margin-left:auto;margin-right:auto;line-height:1.7;position:relative}

/* ─── JOB CARDS ─── */
.jobs-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:14px}
.job-tile{
  background:rgba(255,255,255,.02);
  border:1px solid rgba(255,255,255,.06);
  border-radius:14px;padding:18px;
  display:flex;justify-content:space-between;align-items:center;gap:12px;
  transition:all .3s;
}
.job-tile:hover{
  border-color:rgba(37,99,235,.25);
  background:rgba(37,99,235,.03);
  transform:translateY(-2px);
}
.jt-logo{
  width:40px;height:40px;border-radius:10px;
  background:rgba(37,99,235,.1);
  display:flex;align-items:center;justify-content:center;
  font-size:15px;font-weight:800;color:#60a5fa;flex-shrink:0;
}
.jt-info h4{font-size:13px;font-weight:700;color:#fff;margin-bottom:2px}
.jt-info p{font-size:11px;color:#475569}
.jt-salary{font-size:13px;font-weight:700;color:#4ade80;white-space:nowrap;text-align:right}
.jt-salary small{display:block;font-size:10px;color:#475569;font-weight:400;margin-top:2px}

/* ─── NEWS CARDS ─── */
.news-row{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}
.news-tile{
  background:rgba(255,255,255,.02);
  border:1px solid rgba(255,255,255,.06);
  border-radius:16px;
  overflow:hidden;transition:all .3s;
}
.news-tile:hover{border-color:rgba(236,72,153,.2);transform:translateY(-3px)}
.nt-body{padding:20px}
.nt-badge{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#f472b6;margin-bottom:10px;display:block}
.nt-title{font-size:14px;font-weight:700;color:#fff;margin-bottom:6px;line-height:1.4}
.nt-excerpt{font-size:12px;color:#475569;line-height:1.6}
.nt-date{font-size:11px;color:#334155;margin-top:12px}

/* ─── RESPONSIVE ─── */
@media(max-width:1024px){
  .hero-inner{grid-template-columns:1fr;gap:40px;text-align:center}
  .hero-visual{display:none}
  .hero-stats{justify-content:center}
  .hero-sub{margin-left:auto;margin-right:auto}
  .hero-cta{justify-content:center}
  .steps-grid{grid-template-columns:1fr 1fr;gap:16px}
  .steps-grid::before{display:none}
  .modules-showcase{grid-template-columns:1fr 1fr}
  .benefits-grid{grid-template-columns:1fr}
  .results-band{grid-template-columns:repeat(3,1fr)}
  .jobs-grid{grid-template-columns:1fr}
}
@media(max-width:768px){
  .hero-section{padding:60px 0 48px;min-height:auto}
  .s{padding:64px 0}
  .s-sm{padding:48px 0}
  .hero-stats{gap:20px}
  .hs{padding-right:20px}
  .hs-num{font-size:22px}
  .steps-grid{grid-template-columns:1fr 1fr}
  .modules-showcase{grid-template-columns:1fr}
  .results-band{grid-template-columns:1fr 1fr}
  .news-row{grid-template-columns:1fr}
  .cta-section{padding:40px 20px;border-radius:16px}
  .s-head{margin-bottom:40px}
}
@media(max-width:480px){
  .hero-title{font-size:clamp(28px,8vw,42px)}
  .hero-sub{font-size:15px}
  .btn-hero-primary,.btn-hero-outline{width:100%;justify-content:center}
  .hero-cta{flex-direction:column}
  .hero-stats{gap:16px}
  .hs{padding-right:16px}
  .steps-grid{grid-template-columns:1fr}
  .results-band{grid-template-columns:1fr 1fr}
  .s-title{font-size:clamp(22px,6vw,32px)}
}
</style>
@endsection
@section('content')

{{-- ═══ HERO ═══ --}}
<section class="hero-section">
  <div class="hero-inner">
    <div>
      <div class="hero-tag"><span class="live"></span> Platforma faol ishlaydi</div>
      <h1 class="hero-title">
        Yoshlar uchun<br>
        <span class="grad">barcha imkoniyat</span><br>
        bitta joyda
      </h1>
      <p class="hero-sub">Bandlik, ekologiya, ta'lim, mentorlik, startup va ko'ngillilik — O'zbekiston yoshlari uchun 35+ modul.</p>
      <div class="hero-cta">
        @auth
          <a href="/dashboard" class="btn-hero-primary">
            <svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
            Dashboardga o'tish
          </a>
        @else
          <a href="/register" class="btn-hero-primary">
            <svg viewBox="0 0 24 24"><path d="M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg>
            Bepul boshlash
          </a>
          <a href="/login" class="btn-hero-outline">Kirish</a>
        @endauth
      </div>
      <div class="hero-stats">
        <div class="hs"><div class="hs-num">{{ number_format($stats['users']) }}<span>+</span></div><div class="hs-lbl">Foydalanuvchilar</div></div>
        <div class="hs"><div class="hs-num">{{ $stats['jobs'] }}<span></span></div><div class="hs-lbl">Ish e'lonlari</div></div>
        <div class="hs"><div class="hs-num">{{ $stats['courses'] }}<span></span></div><div class="hs-lbl">Kurslar</div></div>
        <div class="hs"><div class="hs-num">{{ number_format($stats['total_coins']) }}<span></span></div><div class="hs-lbl">GreenCoin</div></div>
      </div>
    </div>
    <div class="hero-visual">
      <div class="hero-visual-card">
        <svg viewBox="0 0 400 360" style="width:100%;max-width:420px" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <radialGradient id="rg1" cx="50%" cy="50%" r="50%"><stop offset="0%" stop-color="#2563eb" stop-opacity=".15"/><stop offset="100%" stop-color="#2563eb" stop-opacity="0"/></radialGradient>
            <radialGradient id="rg2" cx="50%" cy="50%" r="50%"><stop offset="0%" stop-color="#7c3aed" stop-opacity=".1"/><stop offset="100%" stop-color="#7c3aed" stop-opacity="0"/></radialGradient>
            <filter id="glow"><feGaussianBlur stdDeviation="3" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
          </defs>
          <!-- Orbits -->
          <circle cx="200" cy="180" r="140" fill="url(#rg1)" stroke="rgba(37,99,235,.1)" stroke-width="1"/>
          <circle cx="200" cy="180" r="100" fill="none" stroke="rgba(124,58,237,.08)" stroke-width="1" stroke-dasharray="4 8"/>
          <circle cx="200" cy="180" r="60" fill="none" stroke="rgba(37,99,235,.1)" stroke-width="1"/>
          <!-- Center -->
          <rect x="178" y="158" width="44" height="44" rx="12" fill="rgba(37,99,235,.2)" stroke="rgba(37,99,235,.4)" stroke-width="1"/>
          <text x="200" y="186" text-anchor="middle" fill="#93c5fd" font-size="18" font-weight="900" font-family="Inter,sans-serif">A</text>
          <!-- Nodes with animation -->
          <g filter="url(#glow)">
            <circle cx="200" cy="40" r="10" fill="#2563eb"><animate attributeName="r" values="10;13;10" dur="2s" repeatCount="indefinite"/></circle>
            <circle cx="328" cy="110" r="9" fill="#7c3aed"><animate attributeName="r" values="9;12;9" dur="3s" repeatCount="indefinite"/></circle>
            <circle cx="340" cy="250" r="8" fill="#16a34a"><animate attributeName="r" values="8;11;8" dur="2.5s" repeatCount="indefinite"/></circle>
            <circle cx="260" cy="330" r="10" fill="#f59e0b"><animate attributeName="r" values="10;13;10" dur="3.5s" repeatCount="indefinite"/></circle>
            <circle cx="140" cy="330" r="9" fill="#ec4899"><animate attributeName="r" values="9;12;9" dur="2.8s" repeatCount="indefinite"/></circle>
            <circle cx="60" cy="250" r="8" fill="#14b8a6"><animate attributeName="r" values="8;11;8" dur="3.2s" repeatCount="indefinite"/></circle>
            <circle cx="72" cy="110" r="10" fill="#f97316"><animate attributeName="r" values="10;13;10" dur="2.2s" repeatCount="indefinite"/></circle>
          </g>
          <!-- Labels -->
          <text x="200" y="26" text-anchor="middle" fill="#93c5fd" font-size="9" font-weight="700" font-family="Inter,sans-serif">Bandlik</text>
          <text x="346" y="104" fill="#c084fc" font-size="9" font-weight="700" font-family="Inter,sans-serif">Academy</text>
          <text x="348" y="262" fill="#4ade80" font-size="9" font-weight="700" font-family="Inter,sans-serif">Eco</text>
          <text x="264" y="348" text-anchor="middle" fill="#fbbf24" font-size="9" font-weight="700" font-family="Inter,sans-serif">Startup</text>
          <text x="136" y="348" text-anchor="middle" fill="#f472b6" font-size="9" font-weight="700" font-family="Inter,sans-serif">Forum</text>
          <text x="28" y="262" fill="#2dd4bf" font-size="9" font-weight="700" font-family="Inter,sans-serif">Mentor</text>
          <text x="34" y="104" fill="#fb923c" font-size="9" font-weight="700" font-family="Inter,sans-serif">Farm</text>
          <!-- Connectors -->
          <line x1="200" y1="50" x2="200" y2="158" stroke="rgba(37,99,235,.2)" stroke-width="1" stroke-dasharray="3 4"/>
          <line x1="320" y1="118" x2="234" y2="170" stroke="rgba(124,58,237,.2)" stroke-width="1" stroke-dasharray="3 4"/>
          <line x1="332" y1="242" x2="230" y2="202" stroke="rgba(22,163,74,.2)" stroke-width="1" stroke-dasharray="3 4"/>
          <line x1="252" y1="321" x2="215" y2="220" stroke="rgba(245,158,11,.2)" stroke-width="1" stroke-dasharray="3 4"/>
          <line x1="148" y1="321" x2="185" y2="220" stroke="rgba(236,72,153,.2)" stroke-width="1" stroke-dasharray="3 4"/>
          <line x1="68" y1="242" x2="170" y2="202" stroke="rgba(20,184,166,.2)" stroke-width="1" stroke-dasharray="3 4"/>
          <line x1="80" y1="118" x2="166" y2="170" stroke="rgba(249,115,22,.2)" stroke-width="1" stroke-dasharray="3 4"/>
        </svg>
      </div>
      <!-- Floating cards -->
      <div class="float-card fc-1">
        <span class="fc-dot" style="background:#4ade80"></span>
        <span style="color:#fff">+{{ $stats['eco_actions'] }} eco harakat</span>
      </div>
      <div class="float-card fc-2">
        <span class="fc-dot" style="background:#fbbf24"></span>
        <span style="color:#fff">{{ number_format($stats['total_coins']) }} GreenCoin</span>
      </div>
    </div>
  </div>
</section>

{{-- ═══ MARQUEE ═══ --}}
<div class="marquee-section">
  <div class="marquee-track">
    @php $items = [['icon'=>'<rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/>','text'=>'Bandlik'],['icon'=>'<path d="M12 22c4-2.5 7-6 7-10a7 7 0 00-14 0c0 4 3 7.5 7 10z"/>','text'=>'Ekologiya'],['icon'=>'<path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z"/><path d="M22 3h-6a4 4 0 00-4 4v14a3 3 0 013-3h7z"/>','text'=>'Academy'],['icon'=>'<path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/>','text'=>'Mentorlik'],['icon'=>'<path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>','text'=>'Forum'],['icon'=>'<circle cx="12" cy="12" r="10"/><path d="M12 6v12M8 10h8"/>','text'=>'GreenCoin'],['icon'=>'<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/>','text'=>'Startup'],['icon'=>'<path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/>','text'=>'Qishloq'],['icon'=>'<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>','text'=>'Challenge'],['icon'=>'<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>','text'=>'Pomodoro'],['icon'=>'<polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/>','text'=>'Playground'],['icon'=>'<path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/>','text'=>'Psixologiya']]; @endphp
    @foreach(array_merge($items,$items) as $item)
    <div class="marquee-item"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">{!! $item['icon'] !!}</svg>{{ $item['text'] }}</div>
    @endforeach
  </div>
</div>

{{-- ═══ HOW IT WORKS ═══ --}}
<section class="s" style="background:linear-gradient(180deg,#0a0f1e,#0d1526)">
  <div class="container">
    <div class="s-head">
      <span class="s-label" style="background:rgba(124,58,237,.08);color:#a78bfa;border:1px solid rgba(124,58,237,.15)">Qanday ishlaydi</span>
      <h2 class="s-title">4 bosqichda hayotingizni o'zgartiring</h2>
      <p class="s-desc">Ro'yxatdan o'tishdan tortib ish topishgacha — hammasi shu yerda</p>
    </div>
    <div class="steps-grid">
      <div class="step-card"><div class="step-num">1</div><h3>Ro'yxatdan o'ting</h3><p>30 soniyada profil yarating, qiziqishlaringizni tanlang</p></div>
      <div class="step-card"><div class="step-num">2</div><h3>O'rganing</h3><p>Kurslar, mentorlar, code playground orqali bilim oling</p></div>
      <div class="step-card"><div class="step-num">3</div><h3>Harakat qiling</h3><p>Eco vazifalar, challenge, startuplarda ishtirok eting</p></div>
      <div class="step-card"><div class="step-num">4</div><h3>Natija oling</h3><p>Ish toping, sertifikat oling, GreenCoin yig'ing</p></div>
    </div>
  </div>
</section>

{{-- ═══ MODULES ═══ --}}
<section class="s">
  <div class="container">
    <div class="s-head">
      <span class="s-label" style="background:rgba(34,197,94,.06);color:#4ade80;border:1px solid rgba(34,197,94,.15)">35+ Modul</span>
      <h2 class="s-title">Barcha imkoniyatlar bitta platformada</h2>
      <p class="s-desc">Har bir modul mustaqil ishlaydi va yagona ekotizim hosil qiladi</p>
    </div>
    <div class="modules-showcase">
      @php
      $mods = [
        ['c'=>'#2563eb','icon'=>'<rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/>','t'=>'Ish e\'lonlari','d'=>'IT, marketing, dizayn va boshqa sohalarda vakansiyalar. Filtrlash, ariza, status.','u'=>'/jobs'],
        ['c'=>'#16a34a','icon'=>'<path d="M12 22c4-2.5 7-6 7-10a7 7 0 00-14 0c0 4 3 7.5 7 10z"/>','t'=>'Eco vazifalar','d'=>'Daraxt ekish, chiqindi tozalash — har bir harakatga GreenCoin ishlang.','u'=>'/eco'],
        ['c'=>'#f59e0b','icon'=>'<path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z"/><path d="M22 3h-6a4 4 0 00-4 4v14a3 3 0 013-3h7z"/>','t'=>'Academy','d'=>'Video darslar, modulli kurslar, sertifikatsiya va progress tracking.','u'=>'/academy'],
        ['c'=>'#7c3aed','icon'=>'<path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/>','t'=>'Mentorlik','d'=>'Tajribali mutaxassislardan 1:1 konsultatsiya va sessiyalar.','u'=>'/mentors'],
        ['c'=>'#06b6d4','icon'=>'<path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>','t'=>'Forum','d'=>'Savol-javob, muhokamalar, best answer tizimi.','u'=>'/forum'],
        ['c'=>'#f97316','icon'=>'<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/>','t'=>'Startup Hub','d'=>'G\'oya joylashtirish, jamoa topish, voting va pitch tizimi.','u'=>'/startup'],
        ['c'=>'#84cc16','icon'=>'<path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/>','t'=>'Fermer bozori','d'=>'Eko mahsulotlar, fermer-shahar aloqasi, buyurtma tizimi.','u'=>'/farm'],
        ['c'=>'#ef4444','icon'=>'<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>','t'=>'Musobaqalar','d'=>'Coding, eco, kreativ challenge. Sovrinlar va GreenCoin.','u'=>'/challenges'],
        ['c'=>'#22c55e','icon'=>'<circle cx="12" cy="12" r="10"/><path d="M12 6v12M8 10h8"/>','t'=>'GreenCoin','d'=>'Ishlash, sarflash, transfer, leaderboard va do\'kon.','u'=>'/greencoin'],
        ['c'=>'#a855f7','icon'=>'<path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/>','t'=>'Psixologiya','d'=>'Mental salomatlik testlari, stressni boshqarish mashqlari.','u'=>'/psychology'],
        ['c'=>'#14b8a6','icon'=>'<path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/>','t'=>'Volontyorlik','d'=>'Ijtimoiy loyihalar, soat hisobi, sertifikat va GreenCoin.','u'=>'/volunteer'],
        ['c'=>'#3b82f6','icon'=>'<polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/>','t'=>'Code Playground','d'=>'Brauzerda HTML/CSS/JS yozish va natijani real-time ko\'rish.','u'=>'/code-playground'],
      ];
      @endphp
      @foreach($mods as $m)
      <a href="{{ $m['u'] }}" class="module-tile" style="--tile-color:{{ $m['c'] }}">
        <div class="mt-icon" style="background:color-mix(in srgb,{{ $m['c'] }} 10%,transparent)">
          <svg viewBox="0 0 24 24">{!! $m['icon'] !!}</svg>
        </div>
        <div class="mt-body"><h4>{{ $m['t'] }}</h4><p>{{ $m['d'] }}</p></div>
      </a>
      @endforeach
    </div>
  </div>
</section>

{{-- ═══ RESULTS ═══ --}}
<section class="s-sm" style="background:linear-gradient(180deg,#0d1526,#0a0f1e)">
  <div class="container">
    <div class="s-head">
      <span class="s-label" style="background:rgba(37,99,235,.06);color:#60a5fa;border:1px solid rgba(37,99,235,.12)">Natijalar</span>
      <h2 class="s-title">Raqamlarda AMBARELLA</h2>
    </div>
    <div class="results-band">
      <div class="result-cell"><div class="rc-num">{{ number_format($stats['users']) }}+</div><div class="rc-lbl">Foydalanuvchilar</div></div>
      <div class="result-cell"><div class="rc-num">{{ $stats['jobs'] }}</div><div class="rc-lbl">Ish e'lonlari</div></div>
      <div class="result-cell"><div class="rc-num">{{ $stats['courses'] }}</div><div class="rc-lbl">Kurslar</div></div>
      <div class="result-cell"><div class="rc-num">{{ number_format($stats['eco_actions']) }}</div><div class="rc-lbl">Eco harakatlar</div></div>
      <div class="result-cell"><div class="rc-num">35+</div><div class="rc-lbl">Modullar</div></div>
    </div>
  </div>
</section>

{{-- ═══ BENEFITS ═══ --}}
<section class="s">
  <div class="container">
    <div class="benefits-grid">
      <div>
        <span class="s-label" style="background:rgba(251,191,36,.06);color:#fbbf24;border:1px solid rgba(251,191,36,.12)">Kim uchun</span>
        <h2 class="s-title">Har kimga mos<br>imkoniyatlar</h2>
        <p class="s-desc" style="margin-bottom:28px">Talaba, ekolog, startapchi, fermer, employer — platformada hamma uchun joy bor.</p>
        @auth
          <a href="/dashboard" class="btn-hero-primary" style="display:inline-flex">Dashboardga o'tish</a>
        @else
          <a href="/register" class="btn-hero-primary" style="display:inline-flex">Boshlash — bepul</a>
        @endauth
      </div>
      <div class="benefits-list">
        @php $bens = [
          ['c'=>'#60a5fa','icon'=>'<path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z"/><path d="M22 3h-6a4 4 0 00-4 4v14a3 3 0 013-3h7z"/>','t'=>'Talabalar','d'=>'Bepul kurslar, mentorlik, ish tajribasi va sertifikatlar'],
          ['c'=>'#4ade80','icon'=>'<path d="M12 22c4-2.5 7-6 7-10a7 7 0 00-14 0c0 4 3 7.5 7 10z"/>','t'=>'Ekologlar','d'=>'Eco vazifalar, GreenCoin, jamiyatga real hissa qo\'shish'],
          ['c'=>'#f97316','icon'=>'<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/>','t'=>'Startapchilar','d'=>'G\'oya pitch, jamoa topish, investorlar, vote tizimi'],
          ['c'=>'#a78bfa','icon'=>'<path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/>','t'=>'Mentorlar','d'=>'Tajriba ulashish, shogirdlar topish, real impact yaratish'],
          ['c'=>'#fbbf24','icon'=>'<rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/>','t'=>'Ish beruvchilar','d'=>'Yosh talantlar topish, biznes panel va analitika'],
        ]; @endphp
        @foreach($bens as $b)
        <div class="benefit-item">
          <div class="bi-icon" style="background:color-mix(in srgb,{{ $b['c'] }} 10%,transparent)">
            <svg viewBox="0 0 24 24" stroke="{{ $b['c'] }}">{!! $b['icon'] !!}</svg>
          </div>
          <div class="bi-text"><h4>{{ $b['t'] }}</h4><p>{{ $b['d'] }}</p></div>
        </div>
        @endforeach
      </div>
    </div>
  </div>
</section>

{{-- ═══ JOBS ═══ --}}
@if($jobs->count() > 0)
<section class="s-sm" style="background:linear-gradient(180deg,#0a0f1e,#0d1526)">
  <div class="container">
    <div style="display:flex;justify-content:space-between;align-items:flex-end;margin-bottom:32px;flex-wrap:wrap;gap:16px">
      <div>
        <span class="s-label" style="background:rgba(37,99,235,.06);color:#60a5fa;border:1px solid rgba(37,99,235,.12)">Bandlik</span>
        <h2 class="s-title" style="margin-bottom:0">So'nggi ish e'lonlari</h2>
      </div>
      <a href="/jobs" style="font-size:14px;color:#60a5fa;font-weight:600;display:flex;align-items:center;gap:4px">
        Barchasi <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
      </a>
    </div>
    <div class="jobs-grid">
      @foreach($jobs as $job)
      <a href="/jobs/{{ $job->id }}" class="job-tile">
        <div style="display:flex;align-items:center;gap:12px;flex:1;min-width:0">
          <div class="jt-logo">{{ strtoupper(substr($job->company ?? 'C', 0, 1)) }}</div>
          <div class="jt-info">
            <h4>{{ $job->title }}</h4>
            <p>{{ $job->company }} · {{ $job->location ?? 'Remote' }}</p>
          </div>
        </div>
        @if($job->salary_min)
        <div class="jt-salary">
          {{ number_format($job->salary_min/1000000,0) }}–{{ number_format($job->salary_max/1000000,0) }}M
          <small>so'm/oy</small>
        </div>
        @endif
      </a>
      @endforeach
    </div>
  </div>
</section>
@endif

{{-- ═══ NEWS ═══ --}}
@if($news->count() > 0)
<section class="s-sm">
  <div class="container">
    <div style="display:flex;justify-content:space-between;align-items:flex-end;margin-bottom:32px;flex-wrap:wrap;gap:16px">
      <div>
        <span class="s-label" style="background:rgba(236,72,153,.06);color:#f472b6;border:1px solid rgba(236,72,153,.12)">Yangiliklar</span>
        <h2 class="s-title" style="margin-bottom:0">So'nggi maqolalar</h2>
      </div>
      <a href="/news" style="font-size:14px;color:#f472b6;font-weight:600;display:flex;align-items:center;gap:4px">
        Barchasi <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
      </a>
    </div>
    <div class="news-row">
      @foreach($news as $item)
      <a href="/news/{{ $item->slug ?? $item->id }}" class="news-tile">
        <div class="nt-body">
          <span class="nt-badge">Yangilik</span>
          <div class="nt-title">{{ $item->title }}</div>
          <div class="nt-excerpt">{{ Str::limit($item->content ?? $item->description ?? '', 100) }}</div>
          <div class="nt-date">{{ $item->created_at->format('d M Y') }}</div>
        </div>
      </a>
      @endforeach
    </div>
  </div>
</section>
@endif

{{-- ═══ CTA ═══ --}}
<section class="s">
  <div class="container">
    <div class="cta-section">
      <h2>Kelajagingizni bugun boshlang</h2>
      <p>35+ modul, AI yordamchi, GreenCoin — barchasi bepul va hoziroq mavjud.</p>
      <div style="display:flex;gap:14px;justify-content:center;flex-wrap:wrap;position:relative">
        @auth
          <a href="/dashboard" class="btn-hero-primary">Dashboardga o'tish</a>
        @else
          <a href="/register" class="btn-hero-primary">Bepul ro'yxatdan o'tish</a>
          <a href="/login" class="btn-hero-outline">Kirish</a>
        @endauth
      </div>
    </div>
  </div>
</section>

@endsection
