@extends('layouts.app')
@section('title', 'Referal dasturi | AMBARELLA')
@section('styles')
<style>
.referral-header{padding:32px 0;text-align:center}
.referral-header h1{font-size:28px;font-weight:800;color:#fff}
.referral-header p{color:var(--muted);font-size:14px;margin-top:6px}
.ref-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:32px;margin-top:24px;transition:all .3s}
.ref-card:hover{border-color:rgba(37,99,235,.3)}
.ref-card h3{font-size:16px;font-weight:700;color:#fff;margin-bottom:12px}
.ref-link-box{display:flex;align-items:center;gap:10px;background:rgba(0,0,0,.2);border:1px solid var(--border);border-radius:12px;padding:14px 18px;margin-top:12px}
.ref-link-box input{flex:1;background:none;border:none;color:#e2e8f0;font-size:14px;font-family:monospace;outline:none}
.ref-link-box button{background:var(--primary);color:#fff;border:none;padding:8px 16px;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;transition:all .2s;white-space:nowrap}
.ref-link-box button:hover{background:#1d4ed8;transform:scale(1.02)}
.ref-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;margin-top:24px}
.ref-stat{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:24px;text-align:center;transition:all .3s}
.ref-stat:hover{border-color:rgba(74,222,128,.3);transform:translateY(-2px)}
.ref-stat .number{font-size:36px;font-weight:800;color:#4ade80}
.ref-stat .label{font-size:12px;color:var(--muted);margin-top:4px;text-transform:uppercase;letter-spacing:.5px}
.reward-info{background:linear-gradient(135deg,rgba(37,99,235,.1),rgba(74,222,128,.1));border:1px solid rgba(74,222,128,.2);border-radius:var(--radius);padding:24px;margin-top:24px;display:flex;align-items:center;gap:16px}
.reward-info .icon{font-size:40px}
.reward-info .text h4{color:#4ade80;font-size:15px;font-weight:700}
.reward-info .text p{color:#94a3b8;font-size:13px;margin-top:4px}
.how-it-works{margin-top:24px}
.how-it-works h3{font-size:16px;font-weight:700;color:#fff;margin-bottom:16px}
.steps{display:grid;gap:12px}
.step{display:flex;align-items:center;gap:14px;padding:16px;background:var(--surface);border:1px solid var(--border);border-radius:12px}
.step-num{width:32px;height:32px;border-radius:50%;background:var(--primary);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:14px;flex-shrink:0}
.step p{color:#94a3b8;font-size:13px}
.copied-toast{position:fixed;bottom:24px;left:50%;transform:translateX(-50%) translateY(100px);background:#4ade80;color:#000;padding:10px 20px;border-radius:8px;font-size:13px;font-weight:600;transition:transform .3s;z-index:999}
.copied-toast.show{transform:translateX(-50%) translateY(0)}
@media(max-width:768px){.ref-stats{grid-template-columns:1fr}.reward-info{flex-direction:column;text-align:center}}
</style>
@endsection
@section('content')
<section class="referral-header"><div class="container">
    <h1>👥 Referal dasturi</h1>
    <p>Do'stlaringizni taklif qiling va har bir referal uchun +50 GreenCoin oling!</p>
</div></section>

<div class="container">
    <div class="ref-card">
        <h3>Sizning referal havolangiz</h3>
        <div class="ref-link-box">
            <input type="text" id="refLink" value="{{ $link }}" readonly>
            <button onclick="copyLink()">Nusxalash</button>
        </div>
        <p style="color:var(--muted);font-size:12px;margin-top:8px">Kod: <strong style="color:#e2e8f0">{{ $code }}</strong></p>
    </div>

    <div class="ref-stats">
        <div class="ref-stat">
            <div class="number">{{ $count }}</div>
            <div class="label">Taklif qilinganlar</div>
        </div>
        <div class="ref-stat">
            <div class="number" style="color:#fbbf24">{{ $count * 50 }}</div>
            <div class="label">Ishlangan GC</div>
        </div>
        <div class="ref-stat">
            <div class="number" style="color:#60a5fa">∞</div>
            <div class="label">Limit yo'q</div>
        </div>
    </div>

    <div class="reward-info">
        <div class="icon">🎁</div>
        <div class="text">
            <h4>Har bir referal uchun +50 GreenCoin</h4>
            <p>Do'stingiz ro'yxatdan o'tganda siz avtomatik ravishda 50 GreenCoin olasiz. Limitlar yo'q!</p>
        </div>
    </div>

    <div class="how-it-works">
        <h3>Qanday ishlaydi?</h3>
        <div class="steps">
            <div class="step">
                <div class="step-num">1</div>
                <p>Referal havolangizni do'stlaringizga yuboring</p>
            </div>
            <div class="step">
                <div class="step-num">2</div>
                <p>Do'stingiz havola orqali ro'yxatdan o'tadi</p>
            </div>
            <div class="step">
                <div class="step-num">3</div>
                <p>Siz avtomatik +50 GreenCoin olasiz!</p>
            </div>
        </div>
    </div>
</div>

<div class="copied-toast" id="toast">✓ Nusxalandi!</div>

@endsection
@section('scripts')
<script>
function copyLink(){
    const input=document.getElementById('refLink');
    input.select();
    document.execCommand('copy');
    const toast=document.getElementById('toast');
    toast.classList.add('show');
    setTimeout(()=>toast.classList.remove('show'),2000);
}
</script>
@endsection
