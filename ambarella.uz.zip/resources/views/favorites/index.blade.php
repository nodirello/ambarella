@extends('layouts.app')
@section('title', 'Sevimlilar | AMBARELLA')
@section('styles')
<style>
.page-hero{padding:56px 0 40px}
.page-hero h1{font-size:clamp(28px,4vw,38px);font-weight:800;color:#fff;margin-bottom:8px}
.page-hero p{color:var(--muted);font-size:15px;max-width:500px}
.fav-tabs{display:flex;gap:8px;margin:32px 0 24px;flex-wrap:wrap}
.fav-tab{padding:10px 20px;border-radius:var(--radius);font-size:13px;font-weight:600;background:var(--surface);border:1px solid var(--border);color:var(--muted);cursor:pointer;transition:all .2s}
.fav-tab.active{background:rgba(37,99,235,.1);color:#93c5fd;border-color:rgba(37,99,235,.3)}
.fav-section{display:none}.fav-section.active{display:block}
.fav-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:16px}
.fav-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:20px;transition:all .3s;display:flex;align-items:center;justify-content:space-between;gap:16px}
.fav-card:hover{border-color:rgba(37,99,235,.4);transform:translateY(-2px)}
.fav-card-info h3{font-size:15px;font-weight:700;color:#fff;margin-bottom:4px}
.fav-card-info p{font-size:13px;color:var(--muted)}
.fav-remove{width:36px;height:36px;border-radius:10px;display:flex;align-items:center;justify-content:center;background:rgba(220,38,38,.08);border:1px solid rgba(220,38,38,.15);color:#fca5a5;cursor:pointer;transition:all .2s;flex-shrink:0}
.fav-remove:hover{background:rgba(220,38,38,.2);color:#fff}
.empty-state{text-align:center;padding:64px 24px;color:var(--muted);font-size:15px}
.fav-count{background:rgba(37,99,235,.15);color:#93c5fd;font-size:11px;padding:2px 8px;border-radius:99px;margin-left:6px}
@media(max-width:768px){.fav-grid{grid-template-columns:1fr}}
</style>
@endsection
@section('content')
<section class="page-hero"><div class="container">
  <h1>⭐ Sevimlilar</h1>
  <p>Siz yoqtirgan ish e'lonlari, kurslar va mentorlar</p>
</div></section>
<div class="container">
  <div class="fav-tabs">
    <button class="fav-tab active" onclick="showTab('jobs')">Ish e'lonlari <span class="fav-count">{{ $jobFavorites->count() }}</span></button>
    <button class="fav-tab" onclick="showTab('courses')">Kurslar <span class="fav-count">{{ $courseFavorites->count() }}</span></button>
    <button class="fav-tab" onclick="showTab('mentors')">Mentorlar <span class="fav-count">{{ $mentorFavorites->count() }}</span></button>
  </div>

  <div class="fav-section active" id="tab-jobs">
    @if($jobFavorites->count())
    <div class="fav-grid">
      @foreach($jobFavorites as $job)
      <div class="fav-card">
        <a href="/jobs/{{ $job->id }}" class="fav-card-info">
          <h3>{{ $job->title }}</h3>
          <p>{{ $job->company }} — {{ $job->location }}</p>
        </a>
        <form action="/favorites/toggle" method="POST">
          @csrf
          <input type="hidden" name="type" value="job">
          <input type="hidden" name="id" value="{{ $job->id }}">
          <button type="submit" class="fav-remove" title="Olib tashlash">✕</button>
        </form>
      </div>
      @endforeach
    </div>
    @else
    <div class="empty-state">Sevimli ish e'lonlari yo'q</div>
    @endif
  </div>

  <div class="fav-section" id="tab-courses">
    @if($courseFavorites->count())
    <div class="fav-grid">
      @foreach($courseFavorites as $course)
      <div class="fav-card">
        <a href="/academy/{{ $course->id }}" class="fav-card-info">
          <h3>{{ $course->title }}</h3>
          <p>{{ $course->instructor }} — {{ $course->level }}</p>
        </a>
        <form action="/favorites/toggle" method="POST">
          @csrf
          <input type="hidden" name="type" value="course">
          <input type="hidden" name="id" value="{{ $course->id }}">
          <button type="submit" class="fav-remove" title="Olib tashlash">✕</button>
        </form>
      </div>
      @endforeach
    </div>
    @else
    <div class="empty-state">Sevimli kurslar yo'q</div>
    @endif
  </div>

  <div class="fav-section" id="tab-mentors">
    @if($mentorFavorites->count())
    <div class="fav-grid">
      @foreach($mentorFavorites as $mentor)
      <div class="fav-card">
        <a href="/mentor/{{ $mentor->id }}" class="fav-card-info">
          <h3>{{ $mentor->name }}</h3>
          <p>{{ $mentor->role }}</p>
        </a>
        <form action="/favorites/toggle" method="POST">
          @csrf
          <input type="hidden" name="type" value="mentor">
          <input type="hidden" name="id" value="{{ $mentor->id }}">
          <button type="submit" class="fav-remove" title="Olib tashlash">✕</button>
        </form>
      </div>
      @endforeach
    </div>
    @else
    <div class="empty-state">Sevimli mentorlar yo'q</div>
    @endif
  </div>
</div>

<script>
function showTab(tab){
  document.querySelectorAll('.fav-section').forEach(s=>s.classList.remove('active'));
  document.querySelectorAll('.fav-tab').forEach(t=>t.classList.remove('active'));
  document.getElementById('tab-'+tab).classList.add('active');
  event.currentTarget.classList.add('active');
}
</script>
@endsection
