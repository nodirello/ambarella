@extends('layouts.app')
@section('title', 'Kurslarni solishtirish | AMBARELLA')
@section('styles')
<style>
.page-hero{padding:56px 0 40px;text-align:center;position:relative}
.page-hero h1{font-size:clamp(28px,4vw,38px);font-weight:800;color:#fff;margin-bottom:8px}
.page-hero p{color:var(--muted);font-size:15px}
.compare-section{padding:40px 0}
.compare-controls{display:flex;flex-wrap:wrap;gap:12px;margin-bottom:24px;align-items:center}
.compare-controls .info-text{font-size:13px;color:var(--muted);flex:1}
.compare-table-wrap{overflow-x:auto;border-radius:var(--radius);border:1px solid var(--border)}
.compare-table{width:100%;border-collapse:collapse;min-width:600px}
.compare-table th{background:rgba(37,99,235,.05);padding:14px 18px;font-size:13px;font-weight:600;color:#93c5fd;text-align:left;border-bottom:1px solid var(--border)}
.compare-table td{padding:14px 18px;font-size:13px;color:#cbd5e1;border-bottom:1px solid var(--border);vertical-align:middle}
.compare-table tr:last-child td{border-bottom:none}
.compare-table .label-cell{font-weight:600;color:#94a3b8;width:140px;background:rgba(255,255,255,.01)}
.compare-table .remove-btn{background:rgba(220,38,38,.1);color:#fca5a5;border:none;padding:4px 10px;border-radius:6px;font-size:11px;cursor:pointer;font-weight:600}
.compare-table .remove-btn:hover{background:rgba(220,38,38,.2)}
.add-card{background:var(--surface);border:2px dashed var(--border);border-radius:var(--radius);padding:24px;text-align:center;cursor:pointer;transition:all .2s}
.add-card:hover{border-color:rgba(37,99,235,.4)}
.add-card p{color:var(--muted);font-size:13px;margin-top:6px}
.empty-compare{text-align:center;padding:80px 0;color:var(--muted)}
.empty-compare .icon{font-size:48px;margin-bottom:12px}
.modal-overlay{display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.7);z-index:1000;align-items:center;justify-content:center;padding:20px}
.modal-overlay.active{display:flex}
.modal-box{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:32px;max-width:400px;width:100%}
.modal-box h3{color:#fff;font-size:16px;font-weight:700;margin-bottom:16px}
.modal-box .form-group{margin-bottom:14px}
.modal-box .form-group label{display:block;font-size:12px;color:#94a3b8;margin-bottom:4px;font-weight:600}
.modal-box .form-group input,.modal-box .form-group select{width:100%;padding:10px 14px;border:1px solid var(--border);border-radius:var(--radius);font-size:13px;background:rgba(255,255,255,.02);color:#fff;font-family:inherit}
.modal-box .form-group select option{background:#1e293b}
.modal-btns{display:flex;gap:10px;margin-top:18px}
</style>
@endsection
@section('content')
<section class="page-hero"><div class="container">
  <h1>Kurslarni solishtirish</h1>
  <p>2-3 kursni yonma-yon taqqoslang</p>
</div></section>
<div class="container">
  <div class="compare-section">
    <div class="compare-controls">
      <span class="info-text" id="compareCount">Solishtirish uchun kurs qo'shing (max 3)</span>
      <button class="btn btn-primary" style="padding:8px 16px;font-size:12px" onclick="openModal()">+ Kurs qo'shish</button>
      <button class="btn btn-outline" style="padding:8px 16px;font-size:12px" onclick="clearAll()">🗑️ Tozalash</button>
    </div>

    <div id="compareContent"></div>
  </div>
</div>

<!-- Add Modal -->
<div class="modal-overlay" id="addModal">
  <div class="modal-box">
    <h3>📚 Kurs ma'lumotlari</h3>
    <div class="form-group"><label>Nomi *</label><input id="cTitle" placeholder="Kurs nomi"></div>
    <div class="form-group"><label>O'qituvchi</label><input id="cInstructor" placeholder="O'qituvchi ismi"></div>
    <div class="form-group"><label>Davomiylik</label><input id="cDuration" placeholder="masalan: 3 oy"></div>
    <div class="form-group"><label>Narxi</label><input id="cPrice" placeholder="masalan: 500,000 so'm"></div>
    <div class="form-group"><label>Daraja</label>
      <select id="cLevel"><option>Boshlang'ich</option><option>O'rta</option><option>Yuqori</option></select>
    </div>
    <div class="form-group"><label>Reyting (1-5)</label><input id="cRating" type="number" min="1" max="5" step="0.1" placeholder="4.5"></div>
    <div class="modal-btns">
      <button class="btn btn-primary" style="padding:10px 20px;font-size:13px;flex:1" onclick="addCourse()">Qo'shish</button>
      <button class="btn btn-outline" style="padding:10px 20px;font-size:13px" onclick="closeModal()">Bekor</button>
    </div>
  </div>
</div>

<script>
let courses = JSON.parse(localStorage.getItem('compare_courses') || '[]');

function save() { localStorage.setItem('compare_courses', JSON.stringify(courses)); }
function openModal() {
  if (courses.length >= 3) { alert('Maksimum 3 ta kurs qo\'shish mumkin!'); return; }
  document.getElementById('addModal').classList.add('active');
}
function closeModal() { document.getElementById('addModal').classList.remove('active'); }

function addCourse() {
  const title = document.getElementById('cTitle').value.trim();
  if (!title) { alert('Kurs nomini kiriting!'); return; }
  courses.push({
    title,
    instructor: document.getElementById('cInstructor').value.trim() || '-',
    duration: document.getElementById('cDuration').value.trim() || '-',
    price: document.getElementById('cPrice').value.trim() || '-',
    level: document.getElementById('cLevel').value,
    rating: document.getElementById('cRating').value || '-'
  });
  save(); render(); closeModal();
  ['cTitle','cInstructor','cDuration','cPrice','cRating'].forEach(id => document.getElementById(id).value = '');
}

function removeCourse(i) { courses.splice(i, 1); save(); render(); }
function clearAll() { courses = []; save(); render(); }

function render() {
  const el = document.getElementById('compareContent');
  document.getElementById('compareCount').textContent = courses.length + '/3 kurs tanlangan';
  if (courses.length === 0) {
    el.innerHTML = '<div class="empty-compare"><div class="icon">⚖️</div><p>Solishtirish uchun kamida 2 ta kurs qo\'shing</p></div>';
    return;
  }
  let html = '<div class="compare-table-wrap"><table class="compare-table"><thead><tr><th></th>';
  courses.forEach((c, i) => { html += `<th>${c.title} <button class="remove-btn" onclick="removeCourse(${i})">✕</button></th>`; });
  html += '</tr></thead><tbody>';
  const rows = [
    ['O\'qituvchi', 'instructor'],
    ['Davomiylik', 'duration'],
    ['Narxi', 'price'],
    ['Daraja', 'level'],
    ['Reyting', 'rating']
  ];
  rows.forEach(([label, key]) => {
    html += `<tr><td class="label-cell">${label}</td>`;
    courses.forEach(c => { html += `<td>${c[key]}</td>`; });
    html += '</tr>';
  });
  html += '</tbody></table></div>';
  el.innerHTML = html;
}

render();
</script>
@endsection
