@extends('layouts.app')
@section('title', 'Arizalar | Biznes Panel | AMBARELLA')
@section('styles')
<style>
.page-hero{padding:56px 0 40px}
.page-hero h1{font-size:clamp(28px,4vw,38px);font-weight:800;color:#fff;margin-bottom:8px}
.page-hero p{color:var(--muted);font-size:15px}
.biz-nav{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:32px;padding:12px;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius)}
.biz-nav a{padding:8px 16px;border-radius:10px;font-size:13px;font-weight:500;color:var(--muted);transition:all .2s}
.biz-nav a:hover,.biz-nav a.active{background:rgba(37,99,235,.1);color:#60a5fa}
.stats-row{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:14px;margin-bottom:32px}
.stat-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:20px 24px;text-align:center;transition:all .3s}
.stat-card:hover{border-color:rgba(37,99,235,.3);transform:translateY(-2px)}
.stat-card .stat-num{font-size:28px;font-weight:800;color:#fff}
.stat-card .stat-label{font-size:12px;color:var(--muted);margin-top:4px}
.stat-card.yellow{border-color:rgba(245,158,11,.2)}.stat-card.yellow .stat-num{color:#fbbf24}
.stat-card.green{border-color:rgba(22,163,74,.2)}.stat-card.green .stat-num{color:#4ade80}
.stat-card.red{border-color:rgba(220,38,38,.2)}.stat-card.red .stat-num{color:#fca5a5}
.biz-table{width:100%;border-collapse:collapse;margin-top:8px}
.biz-table th{text-align:left;padding:12px 16px;font-size:12px;font-weight:600;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid var(--border)}
.biz-table td{padding:14px 16px;font-size:14px;color:#cbd5e1;border-bottom:1px solid var(--border);vertical-align:middle}
.biz-table tr:hover td{background:rgba(255,255,255,.02)}
.biz-table .applicant-name{font-weight:600;color:#fff}
.biz-table .applicant-email{font-size:12px;color:var(--muted)}
.badge{display:inline-block;padding:4px 12px;border-radius:99px;font-size:11px;font-weight:600}
.badge-pending{background:rgba(245,158,11,.1);color:#fbbf24;border:1px solid rgba(245,158,11,.2)}
.badge-accepted{background:rgba(22,163,74,.1);color:#4ade80;border:1px solid rgba(22,163,74,.2)}
.badge-rejected{background:rgba(220,38,38,.1);color:#fca5a5;border:1px solid rgba(220,38,38,.2)}
.action-btns{display:flex;gap:6px}
.action-btns form{display:inline}
.action-btns button{padding:6px 12px;border-radius:8px;font-size:11px;font-weight:600;cursor:pointer;border:none;transition:all .2s}
.btn-accept{background:rgba(22,163,74,.15);color:#4ade80;border:1px solid rgba(22,163,74,.2)}.btn-accept:hover{background:rgba(22,163,74,.25)}
.btn-reject{background:rgba(220,38,38,.1);color:#fca5a5;border:1px solid rgba(220,38,38,.2)}.btn-reject:hover{background:rgba(220,38,38,.2)}
.table-wrap{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);overflow-x:auto}
.empty-state{text-align:center;padding:64px 24px;color:var(--muted);font-size:15px}
.empty-state .empty-icon{font-size:48px;margin-bottom:16px;opacity:.5}
.pagination-wrap{padding:24px 0;display:flex;justify-content:center}
@media(max-width:768px){.stats-row{grid-template-columns:1fr 1fr}.biz-table{font-size:13px}.biz-table th,.biz-table td{padding:10px 12px}.action-btns{flex-direction:column}}
</style>
@endsection
@section('content')
<section class="page-hero"><div class="container">
  <h1>📋 Arizalar</h1>
  <p>{{ $business->company_name }} — kelgan barcha arizalar</p>
</div></section>
<div class="container">
  <div class="biz-nav">
    <a href="/business">Dashboard</a>
    <a href="/business/jobs">Ish e'lonlari</a>
    <a href="/business/applications" class="active">Arizalar</a>
    <a href="/business/products">Mahsulotlar</a>
    <a href="/business/analytics">Analitika</a>
    <a href="/business/settings">Sozlamalar</a>
  </div>

  <div class="stats-row">
    <div class="stat-card">
      <div class="stat-num">{{ $stats['total'] }}</div>
      <div class="stat-label">Jami arizalar</div>
    </div>
    <div class="stat-card yellow">
      <div class="stat-num">{{ $stats['pending'] }}</div>
      <div class="stat-label">Kutilmoqda</div>
    </div>
    <div class="stat-card green">
      <div class="stat-num">{{ $stats['accepted'] }}</div>
      <div class="stat-label">Qabul qilingan</div>
    </div>
    <div class="stat-card red">
      <div class="stat-num">{{ $stats['rejected'] }}</div>
      <div class="stat-label">Rad etilgan</div>
    </div>
  </div>

  @if($applications->count())
  <div class="table-wrap">
    <table class="biz-table">
      <thead>
        <tr>
          <th>Ariza beruvchi</th>
          <th>Ish e'loni</th>
          <th>Holat</th>
          <th>Sana</th>
          <th>Amallar</th>
        </tr>
      </thead>
      <tbody>
        @foreach($applications as $app)
        <tr>
          <td>
            <div class="applicant-name">{{ $app->user->name ?? 'Noma\'lum' }}</div>
            <div class="applicant-email">{{ $app->user->email ?? '' }}</div>
          </td>
          <td>{{ $app->job->title ?? '—' }}</td>
          <td>
            @if($app->status === 'pending')
              <span class="badge badge-pending">Kutilmoqda</span>
            @elseif($app->status === 'accepted')
              <span class="badge badge-accepted">Qabul qilingan</span>
            @elseif($app->status === 'rejected')
              <span class="badge badge-rejected">Rad etilgan</span>
            @endif
          </td>
          <td style="font-size:13px;color:var(--muted)">{{ $app->created_at->format('d.m.Y') }}</td>
          <td>
            @if($app->status === 'pending')
            <div class="action-btns">
              <form method="POST" action="/business/applications/{{ $app->id }}/status">
                @csrf
                <input type="hidden" name="status" value="accepted">
                <button type="submit" class="btn-accept">✓ Qabul</button>
              </form>
              <form method="POST" action="/business/applications/{{ $app->id }}/status">
                @csrf
                <input type="hidden" name="status" value="rejected">
                <button type="submit" class="btn-reject">✕ Rad</button>
              </form>
            </div>
            @else
              <span style="font-size:12px;color:var(--muted)">—</span>
            @endif
          </td>
        </tr>
        @endforeach
      </tbody>
    </table>
  </div>
  <div class="pagination-wrap">{{ $applications->links() }}</div>
  @else
  <div class="empty-state">
    <div class="empty-icon">📭</div>
    <p>Hali arizalar kelmagan</p>
    <p style="font-size:13px;margin-top:8px">Ish e'lonlaringizga ariza tushganda bu yerda ko'rinadi</p>
  </div>
  @endif
</div>
@endsection