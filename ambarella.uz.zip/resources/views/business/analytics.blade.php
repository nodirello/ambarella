@extends('layouts.app')
@section('title', 'Analitika | Biznes Panel | AMBARELLA')
@section('styles')
<style>
.page-hero{padding:56px 0 40px}
.page-hero h1{font-size:clamp(28px,4vw,38px);font-weight:800;color:#fff;margin-bottom:8px}
.page-hero p{color:var(--muted);font-size:15px}
.biz-nav{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:32px;padding:12px;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius)}
.biz-nav a{padding:8px 16px;border-radius:10px;font-size:13px;font-weight:500;color:var(--muted);transition:all .2s}
.biz-nav a:hover,.biz-nav a.active{background:rgba(37,99,235,.1);color:#60a5fa}
.analytics-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:40px}
.a-stat{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:24px;text-align:center;transition:all .3s}
.a-stat:hover{border-color:rgba(37,99,235,.3);transform:translateY(-2px)}
.a-stat .a-num{font-size:30px;font-weight:800;color:#fff}
.a-stat .a-label{font-size:12px;color:var(--muted);margin-top:4px}
.a-stat .a-icon{font-size:24px;margin-bottom:8px}
.section-title{font-size:18px;font-weight:700;color:#fff;margin-bottom:20px;display:flex;align-items:center;gap:8px}
.chart-section{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:28px;margin-bottom:32px}
.bar-chart{display:flex;align-items:flex-end;gap:8px;height:180px;padding-top:20px}
.bar-col{display:flex;flex-direction:column;align-items:center;flex:1;gap:8px;height:100%;justify-content:flex-end}
.bar-col .bar{width:100%;max-width:48px;background:linear-gradient(180deg,#2563eb,#1d4ed8);border-radius:6px 6px 0 0;min-height:4px;transition:all .3s}
.bar-col .bar:hover{background:linear-gradient(180deg,#3b82f6,#2563eb)}
.bar-col .bar-label{font-size:11px;color:var(--muted);white-space:nowrap}
.bar-col .bar-value{font-size:11px;color:#93c5fd;font-weight:600}
.top-jobs-table{width:100%;border-collapse:collapse}
.top-jobs-table th{text-align:left;padding:12px 16px;font-size:12px;font-weight:600;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid var(--border)}
.top-jobs-table td{padding:14px 16px;font-size:14px;color:#cbd5e1;border-bottom:1px solid var(--border)}
.top-jobs-table tr:hover td{background:rgba(255,255,255,.02)}
.job-bar-wrap{display:flex;align-items:center;gap:10px}
.job-bar{height:8px;background:linear-gradient(90deg,#2563eb,#7c3aed);border-radius:4px;min-width:8px;transition:width .3s}
.job-bar-count{font-size:12px;color:var(--muted);white-space:nowrap}
@media(max-width:768px){.analytics-grid{grid-template-columns:1fr 1fr}.bar-chart{height:140px;gap:4px}}
@media(max-width:480px){.analytics-grid{grid-template-columns:1fr}}
</style>
@endsection
@section('content')
<section class="page-hero"><div class="container">
  <h1>📊 Analitika</h1>
  <p>{{ $business->company_name }} — biznes statistikasi</p>
</div></section>
<div class="container">
  <div class="biz-nav">
    <a href="/business">Dashboard</a>
    <a href="/business/jobs">Ish e'lonlari</a>
    <a href="/business/applications">Arizalar</a>
    <a href="/business/products">Mahsulotlar</a>
    <a href="/business/analytics" class="active">Analitika</a>
    <a href="/business/settings">Sozlamalar</a>
  </div>

  <div class="analytics-grid">
    <div class="a-stat">
      <div class="a-icon">💼</div>
      <div class="a-num">{{ $stats['total_jobs'] }}</div>
      <div class="a-label">Jami ish e'lonlari</div>
    </div>
    <div class="a-stat">
      <div class="a-icon">✅</div>
      <div class="a-num">{{ $stats['active_jobs'] }}</div>
      <div class="a-label">Faol e'lonlar</div>
    </div>
    <div class="a-stat">
      <div class="a-icon">📋</div>
      <div class="a-num">{{ $stats['total_applications'] }}</div>
      <div class="a-label">Jami arizalar</div>
    </div>
    <div class="a-stat">
      <div class="a-icon">⏳</div>
      <div class="a-num">{{ $stats['pending_applications'] }}</div>
      <div class="a-label">Kutilayotgan arizalar</div>
    </div>
    <div class="a-stat">
      <div class="a-icon">📦</div>
      <div class="a-num">{{ $stats['total_products'] }}</div>
      <div class="a-label">Jami mahsulotlar</div>
    </div>
    <div class="a-stat">
      <div class="a-icon">🟢</div>
      <div class="a-num">{{ $stats['active_products'] }}</div>
      <div class="a-label">Faol mahsulotlar</div>
    </div>
  </div>

  {{-- Haftalik arizalar chart --}}
  <div class="chart-section">
    <div class="section-title">📈 Haftalik arizalar</div>
    @if($weeklyApps->count())
    @php $maxCount = $weeklyApps->max('count') ?: 1; @endphp
    <div class="bar-chart">
      @foreach($weeklyApps as $day)
      <div class="bar-col">
        <div class="bar-value">{{ $day->count }}</div>
        <div class="bar" style="height:{{ ($day->count / $maxCount) * 100 }}%"></div>
        <div class="bar-label">{{ \Carbon\Carbon::parse($day->date)->format('d/m') }}</div>
      </div>
      @endforeach
    </div>
    @else
    <p style="color:var(--muted);font-size:14px;text-align:center;padding:32px 0">Hali ma'lumot yetarli emas</p>
    @endif
  </div>

  {{-- Eng mashhur ish e'lonlari --}}
  <div class="chart-section">
    <div class="section-title">🏆 Eng mashhur ish e'lonlari</div>
    @if($topJobs->count())
    @php $maxApps = $topJobs->max('applications_count') ?: 1; @endphp
    <table class="top-jobs-table">
      <thead>
        <tr>
          <th>Ish e'loni</th>
          <th>Arizalar soni</th>
          <th style="width:40%">Ko'rsatkich</th>
        </tr>
      </thead>
      <tbody>
        @foreach($topJobs as $job)
        <tr>
          <td style="font-weight:600;color:#fff">{{ $job->title }}</td>
          <td>{{ $job->applications_count }}</td>
          <td>
            <div class="job-bar-wrap">
              <div class="job-bar" style="width:{{ ($job->applications_count / $maxApps) * 100 }}%"></div>
              <span class="job-bar-count">{{ $job->applications_count }}</span>
            </div>
          </td>
        </tr>
        @endforeach
      </tbody>
    </table>
    @else
    <p style="color:var(--muted);font-size:14px;text-align:center;padding:32px 0">Hali ish e'lonlari yo'q</p>
    @endif
  </div>
</div>
@endsection