@extends('layouts.app')
@section('title', 'Sozlamalar | Biznes Panel | AMBARELLA')
@section('styles')
<style>
.page-hero{padding:56px 0 40px}
.page-hero h1{font-size:clamp(28px,4vw,38px);font-weight:800;color:#fff;margin-bottom:8px}
.page-hero p{color:var(--muted);font-size:15px}
.biz-nav{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:32px;padding:12px;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius)}
.biz-nav a{padding:8px 16px;border-radius:10px;font-size:13px;font-weight:500;color:var(--muted);transition:all .2s}
.biz-nav a:hover,.biz-nav a.active{background:rgba(37,99,235,.1);color:#60a5fa}
.settings-grid{display:grid;grid-template-columns:1fr 360px;gap:24px;align-items:start}
.settings-form{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:32px}
.settings-form h2{font-size:18px;font-weight:700;color:#fff;margin-bottom:24px}
.form-group{display:flex;flex-direction:column;gap:6px;margin-bottom:20px}
.form-group label{font-size:13px;font-weight:600;color:#94a3b8}
.form-group input,.form-group select,.form-group textarea{padding:14px 18px;border:1px solid var(--border);border-radius:var(--radius);font-size:14px;font-family:inherit;background:rgba(255,255,255,.02);color:#fff;transition:border-color .2s}
.form-group input:focus,.form-group select:focus,.form-group textarea:focus{outline:none;border-color:rgba(37,99,235,.5)}
.form-group input::placeholder,.form-group textarea::placeholder{color:#475569}
.form-group textarea{min-height:100px;resize:vertical}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.logo-upload{display:flex;align-items:center;gap:16px}
.logo-preview{width:64px;height:64px;border-radius:12px;background:var(--surface);border:1px solid var(--border);display:flex;align-items:center;justify-content:center;overflow:hidden;flex-shrink:0}
.logo-preview img{width:100%;height:100%;object-fit:cover}
.logo-preview .placeholder{font-size:24px;color:var(--muted)}
.file-input-wrap{flex:1}
.file-input-wrap input[type="file"]{padding:10px;font-size:13px}
.sidebar-cards{display:flex;flex-direction:column;gap:16px}
.side-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:24px}
.side-card h3{font-size:15px;font-weight:700;color:#fff;margin-bottom:12px}
.plan-badge{display:inline-block;padding:4px 14px;border-radius:99px;font-size:12px;font-weight:700;text-transform:uppercase}
.plan-free{background:rgba(100,116,139,.1);color:#94a3b8;border:1px solid rgba(100,116,139,.2)}
.plan-basic{background:rgba(37,99,235,.1);color:#93c5fd;border:1px solid rgba(37,99,235,.2)}
.plan-premium{background:rgba(234,179,8,.1);color:#fbbf24;border:1px solid rgba(234,179,8,.2)}
.plan-features{margin-top:16px;display:flex;flex-direction:column;gap:8px}
.plan-features li{font-size:13px;color:#94a3b8;display:flex;align-items:center;gap:8px}
.plan-features li::before{content:'✓';color:#4ade80;font-weight:700;font-size:12px}
.verification-status{display:flex;align-items:center;gap:10px;padding:14px;border-radius:12px;margin-top:12px}
.verification-status.verified{background:rgba(22,163,74,.08);border:1px solid rgba(22,163,74,.2);color:#4ade80}
.verification-status.unverified{background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.2);color:#fbbf24}
.verification-status .v-icon{font-size:20px}
.verification-status .v-text{font-size:13px;font-weight:500}
@media(max-width:900px){.settings-grid{grid-template-columns:1fr}.form-row{grid-template-columns:1fr}}
</style>
@endsection
@section('content')
<section class="page-hero"><div class="container">
  <h1>⚙️ Sozlamalar</h1>
  <p>Kompaniya profilingizni boshqaring</p>
</div></section>
<div class="container">
  <div class="biz-nav">
    <a href="/business">Dashboard</a>
    <a href="/business/jobs">Ish e'lonlari</a>
    <a href="/business/applications">Arizalar</a>
    <a href="/business/products">Mahsulotlar</a>
    <a href="/business/analytics">Analitika</a>
    <a href="/business/settings" class="active">Sozlamalar</a>
  </div>

  <div class="settings-grid">
    <div class="settings-form">
      <h2>Kompaniya profili</h2>
      <form method="POST" action="/business/settings" enctype="multipart/form-data">
        @csrf

        <div class="form-group">
          <label for="company_name">Kompaniya nomi *</label>
          <input type="text" id="company_name" name="company_name" value="{{ old('company_name', $business->company_name) }}" placeholder="Kompaniya nomi" required>
        </div>

        <div class="form-group">
          <label for="description">Tavsif</label>
          <textarea id="description" name="description" placeholder="Kompaniya faoliyati haqida qisqacha...">{{ old('description', $business->description) }}</textarea>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="website">Veb-sayt</label>
            <input type="url" id="website" name="website" value="{{ old('website', $business->website) }}" placeholder="https://example.com">
          </div>
          <div class="form-group">
            <label for="phone">Telefon</label>
            <input type="tel" id="phone" name="phone" value="{{ old('phone', $business->phone) }}" placeholder="+998 90 123 45 67">
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" value="{{ old('email', $business->email) }}" placeholder="info@company.uz">
          </div>
          <div class="form-group">
            <label for="region">Hudud</label>
            <select id="region" name="region">
              <option value="">Tanlang</option>
              @foreach(['Toshkent','Samarqand','Buxoro','Andijon','Farg\'ona','Namangan','Qashqadaryo','Surxondaryo','Xorazm','Navoiy','Jizzax','Sirdaryo','Qoraqalpog\'iston'] as $r)
                <option value="{{ $r }}" {{ old('region', $business->region) == $r ? 'selected' : '' }}>{{ $r }}</option>
              @endforeach
            </select>
          </div>
        </div>

        <div class="form-group">
          <label>Logo</label>
          <div class="logo-upload">
            <div class="logo-preview">
              @if($business->logo)
                <img src="{{ asset('storage/' . $business->logo) }}" alt="Logo">
              @else
                <span class="placeholder">🏢</span>
              @endif
            </div>
            <div class="file-input-wrap">
              <input type="file" name="logo" accept="image/*">
              <p style="font-size:11px;color:var(--muted);margin-top:4px">JPG, PNG — max 2MB</p>
            </div>
          </div>
        </div>

        <button type="submit" class="btn btn-primary" style="padding:14px 32px;font-size:15px;margin-top:8px">Saqlash</button>
      </form>
    </div>

    <div class="sidebar-cards">
      {{-- Plan info --}}
      <div class="side-card">
        <h3>Tarif rejasi</h3>
        <span class="plan-badge plan-{{ $business->plan ?? 'free' }}">{{ strtoupper($business->plan ?? 'FREE') }}</span>
        <ul class="plan-features">
          @if(($business->plan ?? 'free') === 'free')
            <li>3 ta ish e'loni</li>
            <li>5 ta mahsulot</li>
            <li>Asosiy analitika</li>
          @elseif($business->plan === 'basic')
            <li>15 ta ish e'loni</li>
            <li>50 ta mahsulot</li>
            <li>Kengaytirilgan analitika</li>
            <li>Prioritet ko'rsatilishi</li>
          @elseif($business->plan === 'premium')
            <li>Cheksiz ish e'lonlari</li>
            <li>Cheksiz mahsulotlar</li>
            <li>To'liq analitika</li>
            <li>Shaxsiy menejer</li>
            <li>API integratsiya</li>
          @endif
        </ul>
      </div>

      {{-- Verification --}}
      <div class="side-card">
        <h3>Tekshiruv holati</h3>
        @if($business->is_verified)
          <div class="verification-status verified">
            <span class="v-icon">✓</span>
            <span class="v-text">Kompaniyangiz tasdiqlangan</span>
          </div>
        @else
          <div class="verification-status unverified">
            <span class="v-icon">⏳</span>
            <span class="v-text">Tekshiruv jarayonida yoki tasdiqlanmagan</span>
          </div>
          <p style="font-size:12px;color:var(--muted);margin-top:12px">Tasdiqlash uchun kompaniya hujjatlarini yuborishingiz kerak. Bog'lanish: info@ambarella.uz</p>
        @endif
      </div>
    </div>
  </div>
</div>
@endsection