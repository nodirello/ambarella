@extends('layouts.app')
@section('title', 'Mahsulotlar | Biznes Panel | AMBARELLA')
@section('styles')
<style>
.page-hero{padding:56px 0 40px}
.page-hero h1{font-size:clamp(28px,4vw,38px);font-weight:800;color:#fff;margin-bottom:8px}
.page-hero p{color:var(--muted);font-size:15px}
.biz-nav{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:32px;padding:12px;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius)}
.biz-nav a{padding:8px 16px;border-radius:10px;font-size:13px;font-weight:500;color:var(--muted);transition:all .2s}
.biz-nav a:hover,.biz-nav a.active{background:rgba(37,99,235,.1);color:#60a5fa}
.page-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;flex-wrap:wrap;gap:12px}
.page-header h2{font-size:20px;font-weight:700;color:#fff}
.table-wrap{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);overflow-x:auto}
.biz-table{width:100%;border-collapse:collapse}
.biz-table th{text-align:left;padding:12px 16px;font-size:12px;font-weight:600;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid var(--border)}
.biz-table td{padding:14px 16px;font-size:14px;color:#cbd5e1;border-bottom:1px solid var(--border);vertical-align:middle}
.biz-table tr:hover td{background:rgba(255,255,255,.02)}
.biz-table .product-name{font-weight:600;color:#fff}
.badge{display:inline-block;padding:4px 12px;border-radius:99px;font-size:11px;font-weight:600}
.badge-active{background:rgba(22,163,74,.1);color:#4ade80;border:1px solid rgba(22,163,74,.2)}
.badge-inactive{background:rgba(100,116,139,.1);color:#94a3b8;border:1px solid rgba(100,116,139,.2)}
.table-actions{display:flex;gap:6px;align-items:center}
.table-actions a{padding:6px 12px;border-radius:8px;font-size:11px;font-weight:600;transition:all .2s;border:1px solid var(--border);color:#94a3b8;background:var(--surface)}
.table-actions a:hover{border-color:rgba(37,99,235,.4);color:#60a5fa}
.empty-state{text-align:center;padding:64px 24px;color:var(--muted);font-size:15px}
.empty-state .empty-icon{font-size:48px;margin-bottom:16px;opacity:.5}
.pagination-wrap{padding:24px 0;display:flex;justify-content:center}
.price-tag{font-weight:600;color:#fbbf24}
@media(max-width:768px){.biz-table{font-size:13px}.biz-table th,.biz-table td{padding:10px 12px}.table-actions{flex-direction:column}}
</style>
@endsection
@section('content')
<section class="page-hero"><div class="container">
  <h1>📦 Mahsulotlar</h1>
  <p>Qishloq xo'jalik mahsulotlarini boshqaring</p>
</div></section>
<div class="container">
  <div class="biz-nav">
    <a href="/business">Dashboard</a>
    <a href="/business/jobs">Ish e'lonlari</a>
    <a href="/business/applications">Arizalar</a>
    <a href="/business/products" class="active">Mahsulotlar</a>
    <a href="/business/analytics">Analitika</a>
    <a href="/business/settings">Sozlamalar</a>
  </div>

  <div class="page-header">
    <h2>Barcha mahsulotlar</h2>
    <a href="/farm/create" class="btn btn-primary">+ Yangi mahsulot</a>
  </div>

  @if($products->count())
  <div class="table-wrap">
    <table class="biz-table">
      <thead>
        <tr>
          <th>Nomi</th>
          <th>Kategoriya</th>
          <th>Narx</th>
          <th>Hudud</th>
          <th>Holat</th>
          <th>Amallar</th>
        </tr>
      </thead>
      <tbody>
        @foreach($products as $product)
        <tr>
          <td class="product-name">{{ $product->name }}</td>
          <td>{{ $product->category ?? '—' }}</td>
          <td><span class="price-tag">{{ number_format($product->price, 0, '', ' ') }} so'm/{{ $product->unit }}</span></td>
          <td>{{ $product->region ?? '—' }}</td>
          <td>
            @if($product->is_active)
              <span class="badge badge-active">Faol</span>
            @else
              <span class="badge badge-inactive">Nofaol</span>
            @endif
          </td>
          <td>
            <div class="table-actions">
              <a href="/farm/{{ $product->id }}/edit">✏️ Tahrirlash</a>
            </div>
          </td>
        </tr>
        @endforeach
      </tbody>
    </table>
  </div>
  <div class="pagination-wrap">{{ $products->links() }}</div>
  @else
  <div class="empty-state">
    <div class="empty-icon">🌾</div>
    <p>Hali mahsulotlar qo'shilmagan</p>
    <a href="/farm/create" class="btn btn-primary" style="margin-top:16px">Birinchi mahsulotni qo'shing</a>
  </div>
  @endif
</div>
@endsection