@extends('layouts.app')
@section('title', 'Biznes Panel | AMBARELLA')
@section('styles')
<style>
.page-hero{padding:56px 0 40px}
.page-hero h1{font-size:clamp(28px,4vw,38px);font-weight:800;color:#fff;margin-bottom:8px}
.page-hero p{color:var(--muted);font-size:15px}
.biz-nav{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:32px;padding:12px;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius)}
.biz-nav a{padding:8px 16px;border-radius:10px;font-size:13px;font-weight:500;color:var(--muted);transition:all .2s}
.biz-nav a:hover,.biz-nav a.active{background:rgba(37,99,235,.1);color:#60a5fa}
.biz-stats{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:16px;margin-top:32px}
.stat-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:24px;text-align:center;transition:all .3s}
.stat-card:hover{border-color:rgba(37,99,235,.3);transform:translateY(-2px)}
.stat-card .stat-icon{font-size:28px;margin-bottom:10px}
.stat-card .stat-num{font-size:32px;font-weight:800;color:#fff}
.stat-card .stat-label{font-size:13px;color:var(--muted);margin-top:4px}
.quick-links{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px;margin-top:32px}
.quick-link{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:18px 20px;display:flex;align-items:center;gap:12px;color:#fff;font-size:14px;font-weight:600;transition:all .3s}
.quick-link:hover{border-color:rgba(37,99,235,.4);transform:translateY(-2px)}
.quick-link .ql-icon{width:40px;height:40px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px;background:rgba(37,99,235,.1);flex-shrink:0}
.plan-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:28px;margin-top:32px}
.plan-card h3{font-size:16px;font-weight:700;color:#fff;margin-bottom:12px}
.plan-badge{display:inline-block;padding:4px 14px;border-radius:99px;font-size:12px;font-weight:700;text-transform:uppercase}
.plan-free{background:rgba(100,116,139,.1);color:#94a3b8;border:1px solid rgba(100,116,139,.2)}
.plan-basic{background:rgba(37,99,235,.1);color:#93c5fd;border:1px solid rgba(37,99,235,.2)}
.plan-premium{background:rgba(234,179,8,.1);color:#fbbf24;border:1px solid rgba(234,179,8,.2)}
.plan-info{font-size:13px;color:var(--muted);margin-top:12px}
.company-header{display:flex;align-items:center;gap:16px;margin-bottom:8px}
.company-header .verified{color:#4ade80;font-size:12px;display:flex;align-items:center;gap:4px}
@media(max-width:768px){.biz-stats{grid-template-columns:1fr}.quick-links{grid-template-columns:1fr}}
</style>
@endsection
@section('content')
<section class="page-hero"><div class="container">
  <div class="company-header">
    <h1><x-icon name="building" :size="28" class="float" style="display:inline"/> {{ $business->company_name }}</h1>
    @if($business->is_verified)<span class="verified">✓ Tasdiqlangan</span>@endif
  </div>
  <p>Biznes panelingizga xush kelibsiz</p>
</div></section>
<div class="container">
  <div class="biz-nav">
    <a href="/business" class="active">Dashboard</a>
    <a href="/business/jobs">Ish e'lonlari</a>
    <a href="/business/applications">Arizalar</a>
    <a href="/business/products">Mahsulotlar</a>
    <a href="/business/analytics">Analitika</a>
    <a href="/business/settings">Sozlamalar</a>
  </div>

  <div class="biz-stats">
    <div class="stat-card">
      <div class="stat-icon-wrap blue"><x-icon name="briefcase" :size="24" class="pulse"/></div>
      <div class="stat-num">{{ $myJobsCount }}</div>
      <div class="stat-label">Ish e'lonlarim</div>
    </div>
    <div class="stat-card">
      <div class="stat-icon-wrap green"><x-icon name="package" :size="24" class="bounce"/></div>
      <div class="stat-num">{{ $myProductsCount }}</div>
      <div class="stat-label">Mahsulotlarim</div>
    </div>
    <div class="stat-card">
      <div class="stat-icon-wrap yellow"><x-icon name="clipboard" :size="24" class="float"/></div>
      <div class="stat-num">{{ $applicationsCount }}</div>
      <div class="stat-label">Kelgan arizalar</div>
    </div>
  </div>

  <div class="quick-links">
    <a href="/business/jobs/create" class="quick-link">
      <div class="ql-icon"><x-icon name="plus" :size="20"/></div>
      Yangi ish e'lon qo'shish
    </a>
    <a href="/farm/create" class="quick-link">
      <div class="ql-icon"><x-icon name="cart" :size="20"/></div>
      Yangi mahsulot qo'shish
    </a>
    <a href="/business/applications" class="quick-link">
      <div class="ql-icon"><x-icon name="file" :size="20"/></div>
      Arizalarni ko'rish
    </a>
    <a href="/business/settings" class="quick-link">
      <div class="ql-icon"><x-icon name="settings" :size="20" class="spin"/></div>
      Profil sozlamalari
    </a>
  </div>

  <div class="plan-card">
    <h3>Joriy tarif rejasi</h3>
    <span class="plan-badge plan-{{ $business->plan }}">{{ strtoupper($business->plan) }}</span>
    @if($business->plan_expires_at)
      <p class="plan-info">Amal qilish muddati: {{ $business->plan_expires_at->format('d.m.Y') }}</p>
    @else
      <p class="plan-info">Bepul rejada cheksiz foydalaning. Kengaytirilgan funksiyalar uchun tarifni oshiring.</p>
    @endif
  </div>
</div>
@endsection
