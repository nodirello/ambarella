@extends('layouts.app')
@section('title', 'Ish e\'lonlari | Biznes Panel | AMBARELLA')
@section('styles')
<style>
.page-hero{padding:56px 0 40px}
.page-hero h1{font-size:clamp(28px,4vw,38px);font-weight:800;color:#fff;margin-bottom:8px}
.page-hero p{color:var(--muted);font-size:15px}
.biz-nav{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:32px;padding:12px;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius)}
.biz-nav a{padding:8px 16px;border-radius:10px;font-size:13px;font-weight:500;color:var(--muted);transition:all .2s}
.biz-nav a:hover,.biz-nav a.active{background:rgba(37,99,235,.1);color:#60a5fa}
.page-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;flex-wrap:wrap;gap:12px}
.page-header h2{font-size:20px;font-weight:700;color:#fff}
.table-wrap{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);overflow-x:auto}
.biz-table{width:100%;border-collapse:collapse}
.biz-table th{text-align:left;padding:12px 16px;font-size:12px;font-weight:600;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid var(--border)}
.biz-table td{padding:14px 16px;font-size:14px;color:#cbd5e1;border-bottom:1px solid var(--border);vertical-align:middle}
.biz-table tr:hover td{background:rgba(255,255,255,.02)}
.biz-table .job-title{font-weight:600;color:#fff}
.badge{display:inline-block;padding:4px 12px;border-radius:99px;font-size:11px;font-weight:600}
.badge-active{background:rgba(22,163,74,.1);color:#4ade80;border:1px solid rgba(22,163,74,.2)}
.badge-inactive{background:rgba(100,116,139,.1);color:#94a3b8;border:1px solid rgba(100,116,139,.2)}
.app-count{display:inline-flex;align-items:center;gap:4px;padding:4px 10px;border-radius:8px;font-size:12px;font-weight:600;background:rgba(37,99,235,.1);color:#93c5fd;border:1px solid rgba(37,99,235,.15)}
.table-actions{display:flex;gap:6px;align-items:center}
.table-actions a,.table-actions button{padding:6px 12px;border-radius:8px;font-size:11px;font-weight:600;transition:all .2s;border:1px solid var(--border);color:#94a3b8;background:var(--surface);cursor:pointer}
.table-actions a:hover,.table-actions button:hover{border-color:rgba(37,99,235,.4);color:#60a5fa}
.table-actions form{display:inline}
.salary-range{font-size:12px;color:#fbbf24;font-weight:500}
.empty-state{text-align:center;padding:64px 24px;color:var(--muted);font-size:15px}
.empty-state .empty-icon{font-size:48px;margin-bottom:16px;opacity:.5}
.pagination-wrap{padding:24px 0;display:flex;justify-content:center}
@media(max-width:768px){.biz-table{font-size:13px}.biz-table th,.biz-table td{padding:10px 12px}.table-actions{flex-direction:column}}
</style>
@endsection
@section('content')
<section class="page-hero"><div class="container">
  <h1>💼 Ish e'lonlari</h1>
  <p>{{ $business->company_name ?? 'Biznes' }} — barcha ish e'lonlari</p>
</div></section>
<div class="container">
  <div class="biz-nav">
    <a href="/business">Dashboard</a>
    <a href="/business/jobs" class="active">Ish e'lonlari</a>
    <a href="/business/applications">Arizalar</a>
    <a href="/business/products">Mahsulotlar</a>
    <a href="/business/analytics">Analitika</a>
    <a href="/business/settings">Sozlamalar</a>
  </div>

  <div class="page-header">
    <h2>Barcha e'lonlar</h2>
    <a href="/business/jobs/create" class="btn btn-primary">+ Yangi e'lon</a>
  </div>

  @if($jobs->count())
  <div class="table-wrap">
    <table class="biz-table">
      <thead>
        <tr>
          <th>Lavozim</th>
          <th>Joylashuv</th>
          <th>Turi</th>
          <th>Maosh</th>
          <th>Holat</th>
          <th>Arizalar</th>
          <th>Amallar</th>
        </tr>
      </thead>
      <tbody>
        @foreach($jobs as $job)
        <tr>
          <td class="job-title">{{ $job->title }}</td>
          <td>{{ $job->location ?? '—' }}</td>
          <td>{{ $job->type ?? '—' }}</td>
          <td>
            @if($job->salary_min || $job->salary_max)
              <span class="salary-range">
                {{ $job->salary_min ? number_format($job->salary_min, 0, '', ' ') : '—' }}
                —
                {{ $job->salary_max ? number_format($job->salary_max, 0, '', ' ') : '—' }}
              </span>
            @else
              <span style="color:var(--muted)">Kelishiladi</span>
            @endif
          </td>
          <td>
            @if($job->is_active)
              <span class="badge badge-active">Faol</span>
            @else
              <span class="badge badge-inactive">Nofaol</span>
            @endif
          </td>
          <td>
            <span class="app-count">📋 {{ $job->applications_count ?? $job->applications()->count() ?? 0 }}</span>
          </td>
          <td>
            <div class="table-actions">
              <a href="/jobs/{{ $job->id }}">👁 Ko'rish</a>
              <form method="POST" action="/business/jobs/{{ $job->id }}/toggle">
                @csrf
                <button type="submit">{{ $job->is_active ? '⏸ To\'xtatish' : '▶ Faollashtirish' }}</button>
              </form>
            </div>
          </td>
        </tr>
        @endforeach
      </tbody>
    </table>
  </div>
  <div class="pagination-wrap">{{ $jobs->links() }}</div>
  @else
  <div class="empty-state">
    <div class="empty-icon">💼</div>
    <p>Hali ish e'lonlari yo'q</p>
    <a href="/business/jobs/create" class="btn btn-primary" style="margin-top:16px">Birinchi e'lonni yarating</a>
  </div>
  @endif
</div>
@endsection