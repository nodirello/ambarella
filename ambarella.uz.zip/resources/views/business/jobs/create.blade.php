@extends('layouts.app')
@section('title', 'Yangi ish e\'loni | Biznes Panel | AMBARELLA')
@section('styles')
<style>
.page-hero{padding:56px 0 40px}
.page-hero h1{font-size:clamp(28px,4vw,38px);font-weight:800;color:#fff;margin-bottom:8px}
.page-hero p{color:var(--muted);font-size:15px}
.biz-nav{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:32px;padding:12px;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius)}
.biz-nav a{padding:8px 16px;border-radius:10px;font-size:13px;font-weight:500;color:var(--muted);transition:all .2s}
.biz-nav a:hover,.biz-nav a.active{background:rgba(37,99,235,.1);color:#60a5fa}
.form-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:36px;max-width:680px}
.form-card h2{font-size:18px;font-weight:700;color:#fff;margin-bottom:28px;padding-bottom:16px;border-bottom:1px solid var(--border)}
.form-group{display:flex;flex-direction:column;gap:6px;margin-bottom:22px}
.form-group label{font-size:13px;font-weight:600;color:#94a3b8}
.form-group input,.form-group select,.form-group textarea{padding:14px 18px;border:1px solid var(--border);border-radius:var(--radius);font-size:14px;font-family:inherit;background:rgba(255,255,255,.02);color:#fff;transition:border-color .2s}
.form-group input:focus,.form-group select:focus,.form-group textarea:focus{outline:none;border-color:rgba(37,99,235,.5);box-shadow:0 0 0 3px rgba(37,99,235,.08)}
.form-group input::placeholder,.form-group textarea::placeholder{color:#475569}
.form-group textarea{min-height:140px;resize:vertical}
.form-group select{appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%2364748b' d='M6 8L1 3h10z'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 16px center}
.form-group select option{background:#1e293b;color:#fff}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.form-hint{font-size:11px;color:var(--muted);margin-top:4px}
.form-actions{display:flex;gap:12px;margin-top:28px;padding-top:20px;border-top:1px solid var(--border)}
.required-note{font-size:12px;color:var(--muted);margin-bottom:24px}
@media(max-width:768px){.form-row{grid-template-columns:1fr}.form-card{padding:24px}}
</style>
@endsection
@section('content')
<section class="page-hero"><div class="container">
  <h1>➕ Yangi ish e'loni</h1>
  <p>Vakansiya ma'lumotlarini to'ldiring</p>
</div></section>
<div class="container">
  <div class="biz-nav">
    <a href="/business">Dashboard</a>
    <a href="/business/jobs" class="active">Ish e'lonlari</a>
    <a href="/business/applications">Arizalar</a>
    <a href="/business/products">Mahsulotlar</a>
    <a href="/business/analytics">Analitika</a>
    <a href="/business/settings">Sozlamalar</a>
  </div>

  <div class="form-card">
    <h2>Yangi vakansiya qo'shish</h2>
    <p class="required-note">* — majburiy maydonlar</p>

    <form method="POST" action="/business/jobs">
      @csrf

      <div class="form-group">
        <label for="title">Lavozim nomi *</label>
        <input type="text" id="title" name="title" value="{{ old('title') }}" placeholder="Frontend Developer, Marketing Manager..." required>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label for="location">Joylashuv *</label>
          <input type="text" id="location" name="location" value="{{ old('location') }}" placeholder="Toshkent" required>
        </div>
        <div class="form-group">
          <label for="type">Ish turi *</label>
          <select id="type" name="type" required>
            <option value="">Tanlang</option>
            <option value="toliq" {{ old('type')=='toliq'?'selected':'' }}>To'liq kunlik</option>
            <option value="yarim" {{ old('type')=='yarim'?'selected':'' }}>Yarim kunlik</option>
            <option value="masofaviy" {{ old('type')=='masofaviy'?'selected':'' }}>Masofaviy</option>
            <option value="amaliyot" {{ old('type')=='amaliyot'?'selected':'' }}>Amaliyot (Internship)</option>
            <option value="freelance" {{ old('type')=='freelance'?'selected':'' }}>Freelance</option>
          </select>
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label for="salary_min">Minimal maosh (so'm)</label>
          <input type="number" id="salary_min" name="salary_min" value="{{ old('salary_min') }}" placeholder="3 000 000">
        </div>
        <div class="form-group">
          <label for="salary_max">Maksimal maosh (so'm)</label>
          <input type="number" id="salary_max" name="salary_max" value="{{ old('salary_max') }}" placeholder="8 000 000">
        </div>
      </div>

      <div class="form-group">
        <label for="tags">Teglar</label>
        <input type="text" id="tags" name="tags" value="{{ old('tags') }}" placeholder="PHP, Laravel, Backend, Remote">
        <span class="form-hint">Teglarni vergul bilan ajrating. Bu qidiruv natijalarida yordam beradi.</span>
      </div>

      <div class="form-group">
        <label for="description">Tavsif *</label>
        <textarea id="description" name="description" placeholder="Vakansiya haqida batafsil: talablar, mas'uliyatlar, imtiyozlar..." required>{{ old('description') }}</textarea>
        <span class="form-hint">Batafsil tavsif ko'proq sifatli arizalar olishga yordam beradi</span>
      </div>

      <div class="form-actions">
        <button type="submit" class="btn btn-primary" style="padding:14px 32px;font-size:15px">E'lonni joylashtirish</button>
        <a href="/business/jobs" class="btn btn-outline" style="padding:14px 24px;font-size:15px">Bekor qilish</a>
      </div>
    </form>
  </div>
</div>
@endsection