@extends('layouts.app')
@section('title', 'Biznes ro\'yxatdan o\'tish | AMBARELLA')
@section('styles')
<style>
.page-hero{padding:56px 0 40px}
.page-hero h1{font-size:clamp(28px,4vw,38px);font-weight:800;color:#fff;margin-bottom:8px}
.page-hero p{color:var(--muted);font-size:15px;max-width:500px}
.biz-form{max-width:600px;margin:32px 0 64px;display:flex;flex-direction:column;gap:20px}
.form-group{display:flex;flex-direction:column;gap:6px}
.form-group label{font-size:13px;font-weight:600;color:#94a3b8}
.form-group input,.form-group select,.form-group textarea{padding:14px 18px;border:1px solid var(--border);border-radius:var(--radius);font-size:14px;font-family:inherit;background:var(--surface);color:#fff;transition:border-color .2s}
.form-group input:focus,.form-group select:focus,.form-group textarea:focus{outline:none;border-color:rgba(37,99,235,.5)}
.form-group input::placeholder,.form-group textarea::placeholder{color:#475569}
.form-group textarea{min-height:100px;resize:vertical}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.form-hint{font-size:11px;color:var(--muted);margin-top:2px}
@media(max-width:768px){.form-row{grid-template-columns:1fr}}
</style>
@endsection
@section('content')
<section class="page-hero"><div class="container">
  <h1>🏢 Biznes ro'yxatdan o'tish</h1>
  <p>Kompaniyangizni ro'yxatdan o'tkazing va ish e'lonlari, mahsulotlar joylashtiring</p>
</div></section>
<div class="container">
  <form class="biz-form" method="POST" action="/business/register">
    @csrf

    <div class="form-group">
      <label for="company_name">Kompaniya nomi *</label>
      <input type="text" id="company_name" name="company_name" value="{{ old('company_name') }}" placeholder="Kompaniya nomini kiriting" required>
    </div>

    <div class="form-group">
      <label for="company_type">Kompaniya turi *</label>
      <select id="company_type" name="company_type" required>
        <option value="">Tanlang</option>
        <option value="employer" {{ old('company_type')=='employer'?'selected':'' }}>Ish beruvchi</option>
        <option value="seller" {{ old('company_type')=='seller'?'selected':'' }}>Sotuvchi / Fermer</option>
        <option value="startup" {{ old('company_type')=='startup'?'selected':'' }}>Startup</option>
      </select>
    </div>

    <div class="form-group">
      <label for="description">Tavsif</label>
      <textarea id="description" name="description" placeholder="Kompaniya haqida qisqacha ma'lumot...">{{ old('description') }}</textarea>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label for="phone">Telefon *</label>
        <input type="tel" id="phone" name="phone" value="{{ old('phone') }}" placeholder="+998 90 123 45 67" required>
      </div>
      <div class="form-group">
        <label for="email">Email *</label>
        <input type="email" id="email" name="email" value="{{ old('email') }}" placeholder="info@kompaniya.uz" required>
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label for="website">Veb-sayt</label>
        <input type="url" id="website" name="website" value="{{ old('website') }}" placeholder="https://kompaniya.uz">
      </div>
      <div class="form-group">
        <label for="region">Hudud</label>
        <input type="text" id="region" name="region" value="{{ old('region') }}" placeholder="Toshkent">
      </div>
    </div>

    <div style="margin-top:8px">
      <button type="submit" class="btn btn-primary" style="padding:14px 32px;font-size:15px">Ro'yxatdan o'tish</button>
    </div>
    <p class="form-hint">* — majburiy maydonlar. Ro'yxatdan o'tganingizdan keyin ish e'lonlari va mahsulotlar joylashtirishingiz mumkin.</p>
  </form>
</div>
@endsection
