@extends('layouts.app')
@section('title', 'Haftalik challenge | AMBARELLA')
@section('styles')
<style>
.wc-header{padding:32px 0;text-align:center}
.wc-header h1{font-size:28px;font-weight:800;color:#fff}
.wc-header p{color:var(--muted);font-size:14px;margin-top:6px}
.challenge-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:32px;margin-top:24px;position:relative;overflow:hidden}
.challenge-card::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,var(--primary),#4ade80,#fbbf24)}
.challenge-card h2{font-size:20px;font-weight:800;color:#fff;margin-bottom:8px}
.challenge-card .subtitle{color:var(--muted);font-size:14px;margin-bottom:24px}
.reward-badge{display:inline-flex;align-items:center;gap:6px;background:rgba(74,222,128,.1);border:1px solid rgba(74,222,128,.3);color:#4ade80;padding:6px 14px;border-radius:999px;font-size:13px;font-weight:700;margin-bottom:20px}
.tasks-list{display:grid;gap:12px}
.task-item{display:flex;align-items:center;gap:14px;padding:16px;background:rgba(0,0,0,.15);border:1px solid var(--border);border-radius:12px;transition:all .3s}
.task-item:hover{border-color:rgba(37,99,235,.3)}
.task-check{width:24px;height:24px;border-radius:50%;border:2px solid var(--border);display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all .3s}
.task-item.done .task-check{background:#4ade80;border-color:#4ade80;color:#000;font-size:12px}
.task-item .task-text{flex:1;font-size:14px;color:#e2e8f0}
.task-item.done .task-text{text-decoration:line-through;color:var(--muted)}
.task-item .task-count{font-size:12px;color:var(--muted);background:rgba(255,255,255,.05);padding:4px 10px;border-radius:8px}
.timer-section{display:flex;align-items:center;justify-content:center;gap:24px;margin-top:28px;padding:24px;background:rgba(0,0,0,.2);border-radius:var(--radius)}
.timer-block{text-align:center}
.timer-block .num{font-size:32px;font-weight:800;color:#fff}
.timer-block .unit{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.5px}
.timer-sep{font-size:24px;color:var(--muted);font-weight:300}
.progress-section{margin-top:24px}
.progress-section h4{font-size:14px;color:#fff;font-weight:600;margin-bottom:10px}
.overall-bar{width:100%;height:12px;background:rgba(255,255,255,.06);border-radius:99px;overflow:hidden}
.overall-fill{height:100%;background:linear-gradient(90deg,var(--primary),#4ade80);border-radius:99px;transition:width .8s ease}
.overall-text{display:flex;justify-content:space-between;margin-top:6px;font-size:12px;color:var(--muted)}
.tips-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:24px;margin-top:24px}
.tips-card h3{font-size:15px;font-weight:700;color:#fff;margin-bottom:12px}
.tips-card ul{list-style:none;padding:0}
.tips-card li{padding:8px 0;color:#94a3b8;font-size:13px;display:flex;align-items:center;gap:8px}
.tips-card li::before{content:'💡';font-size:14px}
@media(max-width:768px){.timer-section{gap:16px}.timer-block .num{font-size:24px}}
</style>
@endsection
@section('content')
<section class="wc-header"><div class="container">
    <h1>🏅 Haftalik Challenge</h1>
    <p>Haftaning barcha vazifalarini bajaring va bonus GreenCoin yutib oling</p>
</div></section>

<div class="container">
    <div class="challenge-card">
        <h2>Bu haftaning vazifasi</h2>
        <p class="subtitle">3 eco vazifa + 2 kundalik task + 1 kurs = 100 bonus GC</p>
        <div class="reward-badge">🎁 Mukofot: 100 GreenCoin</div>

        <div class="tasks-list">
            <div class="task-item">
                <div class="task-check"></div>
                <span class="task-text">3 ta eco vazifani bajaring</span>
                <span class="task-count">0/3</span>
            </div>
            <div class="task-item">
                <div class="task-check"></div>
                <span class="task-text">2 ta kundalik vazifa yarating va bajaring</span>
                <span class="task-count">0/2</span>
            </div>
            <div class="task-item">
                <div class="task-check"></div>
                <span class="task-text">1 ta kursga yoziling</span>
                <span class="task-count">0/1</span>
            </div>
        </div>

        <div class="progress-section">
            <h4>Umumiy progress</h4>
            <div class="overall-bar">
                <div class="overall-fill" style="width:0%"></div>
            </div>
            <div class="overall-text">
                <span>0/6 vazifa</span>
                <span>0%</span>
            </div>
        </div>
    </div>

    {{-- Timer --}}
    <div class="timer-section">
        <div class="timer-block">
            <div class="num" id="days">0</div>
            <div class="unit">Kun</div>
        </div>
        <div class="timer-sep">:</div>
        <div class="timer-block">
            <div class="num" id="hours">0</div>
            <div class="unit">Soat</div>
        </div>
        <div class="timer-sep">:</div>
        <div class="timer-block">
            <div class="num" id="minutes">0</div>
            <div class="unit">Daqiqa</div>
        </div>
        <div class="timer-sep">:</div>
        <div class="timer-block">
            <div class="num" id="seconds">0</div>
            <div class="unit">Soniya</div>
        </div>
    </div>

    <div class="tips-card">
        <h3>Maslahatlar</h3>
        <ul>
            <li>Har kuni kamida 1 ta vazifa bajaring</li>
            <li>Eco vazifalar "Ekologiya" bo'limida mavjud</li>
            <li>Akademiya kurslaridan birini tanlang</li>
            <li>Challenge har dushanba yangilanadi</li>
        </ul>
    </div>
</div>
@endsection
@section('scripts')
<script>
function getNextMonday(){
    const now=new Date();
    const day=now.getDay();
    const diff=day===0?1:(8-day);
    const next=new Date(now);
    next.setDate(now.getDate()+diff);
    next.setHours(0,0,0,0);
    return next;
}
function updateTimer(){
    const end=getNextMonday();
    const now=new Date();
    let diff=Math.max(0,Math.floor((end-now)/1000));
    const d=Math.floor(diff/86400);diff%=86400;
    const h=Math.floor(diff/3600);diff%=3600;
    const m=Math.floor(diff/60);
    const s=diff%60;
    document.getElementById('days').textContent=d;
    document.getElementById('hours').textContent=h;
    document.getElementById('minutes').textContent=m;
    document.getElementById('seconds').textContent=s;
}
updateTimer();
setInterval(updateTimer,1000);
</script>
@endsection
