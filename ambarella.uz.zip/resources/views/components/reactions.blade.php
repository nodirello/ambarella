{{-- Reactions Component (Like/Dislike) --}}
{{-- Usage: @include('components.reactions', ['reactable' => $model, 'type' => 'App\Models\BlogPost']) --}}

@php
    $likes = \App\Models\Reaction::where('reactable_type', $type)
        ->where('reactable_id', $reactable->id)
        ->where('type', 'like')
        ->count();
    $dislikes = \App\Models\Reaction::where('reactable_type', $type)
        ->where('reactable_id', $reactable->id)
        ->where('type', 'dislike')
        ->count();
    $userReaction = null;
    if (auth()->check()) {
        $userReaction = \App\Models\Reaction::where('user_id', auth()->id())
            ->where('reactable_type', $type)
            ->where('reactable_id', $reactable->id)
            ->value('type');
    }
@endphp

<div class="reactions-wrapper" id="reactions-{{ $reactable->id }}">
    <button 
        class="reaction-btn reaction-like {{ $userReaction === 'like' ? 'active' : '' }}" 
        onclick="toggleReaction('{{ $type }}', {{ $reactable->id }}, 'like', {{ $reactable->id }})"
        title="Yoqdi"
    >
        <svg width="18" height="18" fill="{{ $userReaction === 'like' ? 'currentColor' : 'none' }}" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path d="M14 9V5a3 3 0 00-3-3l-4 9v11h11.28a2 2 0 002-1.7l1.38-9a2 2 0 00-2-2.3H14zM7 22H4a2 2 0 01-2-2v-7a2 2 0 012-2h3"/>
        </svg>
        <span class="reaction-count like-count">{{ $likes }}</span>
    </button>
    <button 
        class="reaction-btn reaction-dislike {{ $userReaction === 'dislike' ? 'active' : '' }}" 
        onclick="toggleReaction('{{ $type }}', {{ $reactable->id }}, 'dislike', {{ $reactable->id }})"
        title="Yoqmadi"
    >
        <svg width="18" height="18" fill="{{ $userReaction === 'dislike' ? 'currentColor' : 'none' }}" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path d="M10 15v4a3 3 0 003 3l4-9V2H5.72a2 2 0 00-2 1.7l-1.38 9a2 2 0 002 2.3H10zM17 2h2.67A2.31 2.31 0 0122 4v7a2.31 2.31 0 01-2.33 2H17"/>
        </svg>
        <span class="reaction-count dislike-count">{{ $dislikes }}</span>
    </button>
</div>

<style>
.reactions-wrapper{display:inline-flex;gap:6px;align-items:center}
.reaction-btn{display:inline-flex;align-items:center;gap:6px;padding:8px 14px;border-radius:8px;border:1px solid var(--border);background:rgba(255,255,255,.02);color:#94a3b8;cursor:pointer;font-size:14px;font-weight:600;transition:all .2s}
.reaction-btn:hover{background:rgba(255,255,255,.05);border-color:rgba(255,255,255,.1)}
.reaction-like.active{background:rgba(34,197,94,.1);border-color:rgba(34,197,94,.3);color:#86efac}
.reaction-dislike.active{background:rgba(239,68,68,.1);border-color:rgba(239,68,68,.3);color:#fca5a5}
.reaction-count{font-size:13px}
</style>

<script>
function toggleReaction(reactableType, reactableId, type, id){
    @auth
    fetch('{{ route("reactions.toggle") }}', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
            'Accept': 'application/json'
        },
        body: JSON.stringify({
            reactable_type: reactableType,
            reactable_id: reactableId,
            type: type
        })
    })
    .then(r => r.json())
    .then(data => {
        const wrapper = document.getElementById('reactions-' + id);
        const likeBtn = wrapper.querySelector('.reaction-like');
        const dislikeBtn = wrapper.querySelector('.reaction-dislike');
        
        wrapper.querySelector('.like-count').textContent = data.likes;
        wrapper.querySelector('.dislike-count').textContent = data.dislikes;
        
        likeBtn.classList.toggle('active', data.user_reaction === 'like');
        dislikeBtn.classList.toggle('active', data.user_reaction === 'dislike');
        
        // Update SVG fill
        likeBtn.querySelector('svg').setAttribute('fill', data.user_reaction === 'like' ? 'currentColor' : 'none');
        dislikeBtn.querySelector('svg').setAttribute('fill', data.user_reaction === 'dislike' ? 'currentColor' : 'none');
    });
    @else
    window.location.href = '{{ route("login") }}';
    @endauth
}
</script>
