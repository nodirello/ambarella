{{-- Video Player Component --}}
{{-- Usage: @include('components.video-player', ['url' => $videoUrl]) --}}

@php
    $isYoutube = false;
    $youtubeId = null;
    
    if (preg_match('/(?:youtube\.com\/(?:watch\?v=|embed\/|v\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/', $url, $matches)) {
        $isYoutube = true;
        $youtubeId = $matches[1];
    }
@endphp

<div class="video-player-wrapper">
    @if($isYoutube)
        <div class="video-responsive">
            <iframe 
                src="https://www.youtube.com/embed/{{ $youtubeId }}" 
                frameborder="0" 
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
                allowfullscreen
                loading="lazy"
                title="Video player"
            ></iframe>
        </div>
    @else
        <div class="video-responsive video-html5">
            <video controls preload="metadata" playsinline>
                <source src="{{ $url }}" type="video/mp4">
                Brauzeringiz video formatini qo'llab-quvvatlamaydi.
            </video>
        </div>
    @endif
</div>

<style>
.video-player-wrapper{background:var(--surface);border:1px solid var(--border);border-radius:12px;overflow:hidden;box-shadow:0 8px 30px rgba(0,0,0,.3)}
.video-responsive{position:relative;padding-bottom:56.25%;height:0;overflow:hidden}
.video-responsive iframe,.video-responsive video{position:absolute;top:0;left:0;width:100%;height:100%;border:none;border-radius:0}
.video-html5 video{background:#000;object-fit:contain}
</style>
