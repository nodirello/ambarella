{{-- Share Buttons Component --}}
{{-- Usage: @include('components.share-buttons', ['title' => $title, 'url' => $url]) --}}

@php
    $shareUrl = $url ?? request()->url();
    $shareTitle = $title ?? config('app.name');
@endphp

<div class="share-buttons">
    <span class="share-label">Ulashish:</span>
    <button type="button" onclick="shareToTelegram('{{ $shareTitle }}', '{{ $shareUrl }}')" class="share-btn share-telegram" title="Telegram">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
            <path d="M11.944 0A12 12 0 000 12a12 12 0 0012 12 12 12 0 0012-12A12 12 0 0012 0a12 12 0 00-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 01.171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.479.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/>
        </svg>
    </button>
    <button type="button" onclick="shareToTwitter('{{ $shareTitle }}', '{{ $shareUrl }}')" class="share-btn share-twitter" title="Twitter/X">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
            <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
        </svg>
    </button>
    <button type="button" onclick="copyLink('{{ $shareUrl }}')" class="share-btn share-copy" title="Havolani nusxalash">
        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
            <path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/>
        </svg>
    </button>
</div>

<style>
.share-buttons{display:inline-flex;align-items:center;gap:8px}
.share-label{font-size:13px;color:var(--muted);font-weight:500}
.share-btn{width:32px;height:32px;border-radius:8px;border:1px solid var(--border);background:var(--surface);color:var(--muted);display:inline-flex;align-items:center;justify-content:center;cursor:pointer;transition:all .2s}
.share-btn:hover{border-color:var(--primary);color:var(--primary);transform:translateY(-1px)}
.share-telegram:hover{color:#0088cc;border-color:#0088cc}
.share-twitter:hover{color:#fff;border-color:#fff}
.share-copy:hover{color:#10b981;border-color:#10b981}
</style>
