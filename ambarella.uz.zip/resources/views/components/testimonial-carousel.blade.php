@props(['testimonials' => []])

@if(count($testimonials) > 0)
<div class="testimonial-carousel" id="testimonialCarousel">
  <div class="testimonial-wrapper">
    @foreach($testimonials as $index => $testimonial)
      <div class="testimonial-slide {{ $index === 0 ? 'active' : '' }}" data-index="{{ $index }}">
        <div class="testimonial-card">
          <div class="testimonial-quote">
            <svg width="32" height="32" fill="rgba(37,99,235,.3)" viewBox="0 0 24 24"><path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10H14.017zm-14.017 0v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10H0z"/></svg>
          </div>
          <p class="testimonial-text">{{ $testimonial['text'] }}</p>
          <div class="testimonial-author">
            <div class="testimonial-avatar">{{ mb_substr($testimonial['name'], 0, 1) }}</div>
            <div>
              <strong class="testimonial-name">{{ $testimonial['name'] }}</strong>
              <span class="testimonial-role">{{ $testimonial['role'] }}</span>
            </div>
          </div>
        </div>
      </div>
    @endforeach
  </div>
  <!-- Dots -->
  @if(count($testimonials) > 1)
  <div class="testimonial-dots">
    @foreach($testimonials as $index => $t)
      <span class="testimonial-dot {{ $index === 0 ? 'active' : '' }}" data-index="{{ $index }}"></span>
    @endforeach
  </div>
  @endif
</div>

<style>
.testimonial-carousel{position:relative;max-width:700px;margin:0 auto;padding:40px 0;overflow:hidden}
.testimonial-wrapper{position:relative;min-height:200px}
.testimonial-slide{position:absolute;inset:0;opacity:0;transform:translateY(10px);transition:all .6s ease;pointer-events:none}
.testimonial-slide.active{opacity:1;transform:translateY(0);pointer-events:auto;position:relative}
.testimonial-card{padding:32px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);border-radius:20px;text-align:center}
.testimonial-quote{margin-bottom:16px}
.testimonial-text{font-size:16px;line-height:1.8;color:#cbd5e1;font-style:italic;margin-bottom:24px}
.testimonial-author{display:flex;align-items:center;justify-content:center;gap:12px}
.testimonial-avatar{width:40px;height:40px;border-radius:50%;background:linear-gradient(135deg,#2563eb,#7c3aed);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:16px;color:#fff}
.testimonial-name{display:block;font-size:14px;color:#e2e8f0;font-weight:600}
.testimonial-role{font-size:12px;color:#64748b}
.testimonial-dots{display:flex;justify-content:center;gap:8px;margin-top:20px}
.testimonial-dot{width:8px;height:8px;border-radius:50%;background:rgba(255,255,255,.15);cursor:pointer;transition:all .3s}
.testimonial-dot.active{background:#2563eb;transform:scale(1.3)}
</style>

<script>
(function(){
  const slides = document.querySelectorAll('.testimonial-slide');
  const dots = document.querySelectorAll('.testimonial-dot');
  if(slides.length <= 1) return;
  let current = 0;
  let autoPlay;

  function goTo(index){
    slides[current].classList.remove('active');
    dots[current].classList.remove('active');
    current = index;
    slides[current].classList.add('active');
    dots[current].classList.add('active');
  }

  function next(){
    goTo((current + 1) % slides.length);
  }

  // Dots click
  dots.forEach(function(dot){
    dot.addEventListener('click', function(){
      clearInterval(autoPlay);
      goTo(parseInt(this.getAttribute('data-index')));
      autoPlay = setInterval(next, 5000);
    });
  });

  // Auto play every 5s
  autoPlay = setInterval(next, 5000);
})();
</script>
@endif
