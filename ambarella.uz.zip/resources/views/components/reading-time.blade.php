@php
  $words = str_word_count(strip_tags($content ?? ''));
  $minutes = max(1, ceil($words / 200));
@endphp
<span class="reading-time">
  <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
  ~{{ $minutes }} daqiqa o'qish
</span>
<style>.reading-time{display:inline-flex;align-items:center;gap:5px;font-size:12px;color:var(--muted);font-weight:500}</style>
