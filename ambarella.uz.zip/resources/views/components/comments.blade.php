{{-- Comments Component --}}
{{-- Usage: @include('components.comments', ['commentable' => $model, 'type' => 'App\Models\News']) --}}

@php
    $comments = \App\Models\Comment::where('commentable_type', $type)
        ->where('commentable_id', $commentable->id)
        ->where('is_approved', true)
        ->with('user')
        ->latest()
        ->get();
@endphp

<div class="comments-section">
    <h3 class="comments-title">
        <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>
        </svg>
        Izohlar ({{ $comments->count() }})
    </h3>

    {{-- Izoh qo'shish formasi --}}
    @auth
    <form action="{{ route('comments.store') }}" method="POST" class="comment-form">
        @csrf
        <input type="hidden" name="commentable_type" value="{{ $type }}">
        <input type="hidden" name="commentable_id" value="{{ $commentable->id }}">
        <div class="comment-input-row">
            <div class="comment-avatar">
                {{ mb_substr(auth()->user()->name, 0, 1) }}
            </div>
            <textarea name="body" placeholder="Izoh yozing..." rows="3" required minlength="2" maxlength="1000" class="comment-textarea">{{ old('body') }}</textarea>
        </div>
        <div class="comment-form-actions">
            <button type="submit" class="btn btn-primary btn-sm">Yuborish</button>
        </div>
    </form>
    @else
    <div class="comment-login-notice">
        <a href="{{ route('login') }}">Tizimga kiring</a> izoh qoldirish uchun.
    </div>
    @endauth

    {{-- Izohlar ro'yxati --}}
    <div class="comments-list">
        @forelse($comments as $comment)
        <div class="comment-item">
            <div class="comment-avatar">
                {{ mb_substr($comment->user->name ?? 'U', 0, 1) }}
            </div>
            <div class="comment-body">
                <div class="comment-meta">
                    <span class="comment-author">{{ $comment->user->name ?? 'Foydalanuvchi' }}</span>
                    <span class="comment-date">{{ $comment->created_at->diffForHumans() }}</span>
                </div>
                <p class="comment-text">{{ $comment->body }}</p>
            </div>
        </div>
        @empty
        <div class="comments-empty">
            <p>Hali izohlar yo'q. Birinchi bo'lib izoh qoldiring!</p>
        </div>
        @endforelse
    </div>
</div>

<style>
.comments-section{margin-top:40px;padding-top:32px;border-top:1px solid var(--border)}
.comments-title{font-size:18px;font-weight:700;color:#fff;margin-bottom:20px;display:flex;align-items:center;gap:8px}
.comments-title svg{color:var(--primary)}
.comment-form{margin-bottom:24px}
.comment-input-row{display:flex;gap:12px;align-items:flex-start}
.comment-avatar{width:36px;height:36px;min-width:36px;border-radius:50%;background:linear-gradient(135deg,var(--primary),#8b5cf6);display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:700;color:#fff;text-transform:uppercase}
.comment-textarea{flex:1;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:12px;color:#fff;font-size:14px;resize:vertical;min-height:80px;transition:border-color .2s}
.comment-textarea:focus{outline:none;border-color:var(--primary)}
.comment-textarea::placeholder{color:var(--muted)}
.comment-form-actions{display:flex;justify-content:flex-end;margin-top:10px}
.comment-login-notice{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:16px;text-align:center;color:var(--muted);font-size:14px;margin-bottom:24px}
.comment-login-notice a{color:var(--primary);font-weight:600}
.comments-list{display:flex;flex-direction:column;gap:16px}
.comment-item{display:flex;gap:12px;padding:16px;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);transition:border-color .2s}
.comment-item:hover{border-color:rgba(59,130,246,.3)}
.comment-body{flex:1}
.comment-meta{display:flex;align-items:center;gap:8px;margin-bottom:6px}
.comment-author{font-size:14px;font-weight:600;color:#fff}
.comment-date{font-size:12px;color:var(--muted)}
.comment-text{font-size:14px;color:#cbd5e1;line-height:1.6;margin:0}
.comments-empty{text-align:center;padding:24px;color:var(--muted);font-size:14px}
</style>
