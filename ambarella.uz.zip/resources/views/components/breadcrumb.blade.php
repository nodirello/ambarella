@props(['items' => []])

<nav class="breadcrumb-nav" aria-label="Breadcrumb">
  <ol class="breadcrumb-list">
    <li class="breadcrumb-item">
      <a href="{{ route('home') }}" class="breadcrumb-link">
        <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
        Bosh sahifa
      </a>
    </li>
    @foreach($items as $index => $item)
      <li class="breadcrumb-separator">
        <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"/></svg>
      </li>
      <li class="breadcrumb-item">
        @if($index === count($items) - 1)
          <span class="breadcrumb-active">{{ $item['name'] }}</span>
        @else
          <a href="{{ $item['url'] }}" class="breadcrumb-link">{{ $item['name'] }}</a>
        @endif
      </li>
    @endforeach
  </ol>
</nav>

<style>
.breadcrumb-nav{margin-bottom:24px}
.breadcrumb-list{display:flex;align-items:center;gap:6px;flex-wrap:wrap;list-style:none;padding:0;margin:0}
.breadcrumb-item{display:flex;align-items:center}
.breadcrumb-link{display:inline-flex;align-items:center;gap:5px;font-size:13px;color:#64748b;font-weight:500;transition:color .2s;text-decoration:none}
.breadcrumb-link:hover{color:#2563eb}
.breadcrumb-separator{display:flex;align-items:center;color:#475569}
.breadcrumb-active{font-size:13px;color:#e2e8f0;font-weight:600}
</style>
