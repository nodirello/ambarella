{{-- Calendar Widget Component --}}
{{-- Usage: @include('components.calendar', ['events' => $events]) --}}
{{-- $events = [['date' => '2025-01-15', 'title' => 'Event name'], ...] --}}

@php
    $events = $events ?? [];
@endphp

<div class="calendar-widget" id="calendarWidget">
    <div class="calendar-header">
        <button class="cal-nav-btn" onclick="calendarPrev()">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M15 19l-7-7 7-7"/></svg>
        </button>
        <h3 class="cal-month-title" id="calMonthTitle"></h3>
        <button class="cal-nav-btn" onclick="calendarNext()">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 5l7 7-7 7"/></svg>
        </button>
    </div>
    <div class="calendar-days-header">
        <span>Du</span><span>Se</span><span>Cho</span><span>Pa</span><span>Ju</span><span>Sha</span><span>Ya</span>
    </div>
    <div class="calendar-grid" id="calendarGrid"></div>
</div>

<style>
.calendar-widget{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:20px;width:100%;max-width:340px}
.calendar-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px}
.cal-month-title{font-size:15px;font-weight:700;color:#fff;margin:0}
.cal-nav-btn{background:rgba(255,255,255,.05);border:1px solid var(--border);border-radius:6px;padding:6px;cursor:pointer;color:#94a3b8;transition:all .2s;display:flex;align-items:center;justify-content:center}
.cal-nav-btn:hover{background:rgba(59,130,246,.1);color:#93c5fd;border-color:rgba(59,130,246,.3)}
.calendar-days-header{display:grid;grid-template-columns:repeat(7,1fr);text-align:center;margin-bottom:8px}
.calendar-days-header span{font-size:11px;font-weight:600;color:#64748b;padding:4px 0;text-transform:uppercase}
.calendar-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:2px}
.cal-day{position:relative;aspect-ratio:1;display:flex;align-items:center;justify-content:center;font-size:13px;color:#94a3b8;border-radius:8px;cursor:default;transition:all .2s}
.cal-day:hover{background:rgba(255,255,255,.03)}
.cal-day.today{background:rgba(59,130,246,.15);color:#93c5fd;font-weight:700;border:1px solid rgba(59,130,246,.3)}
.cal-day.has-event::after{content:'';position:absolute;bottom:4px;left:50%;transform:translateX(-50%);width:5px;height:5px;border-radius:50%;background:#d4af37}
.cal-day.other-month{color:#334155;opacity:.5}
</style>

<script>
(function(){
    const events = @json($events);
    let currentDate = new Date();
    
    const months = ['Yanvar','Fevral','Mart','Aprel','May','Iyun','Iyul','Avgust','Sentabr','Oktabr','Noyabr','Dekabr'];
    
    function renderCalendar(){
        const year = currentDate.getFullYear();
        const month = currentDate.getMonth();
        const today = new Date();
        
        document.getElementById('calMonthTitle').textContent = months[month] + ' ' + year;
        
        const firstDay = new Date(year, month, 1);
        let startDay = firstDay.getDay() - 1;
        if(startDay < 0) startDay = 6;
        
        const daysInMonth = new Date(year, month+1, 0).getDate();
        const daysInPrevMonth = new Date(year, month, 0).getDate();
        
        let html = '';
        
        // Previous month days
        for(let i = startDay - 1; i >= 0; i--){
            html += '<div class="cal-day other-month">' + (daysInPrevMonth - i) + '</div>';
        }
        
        // Current month days
        for(let d = 1; d <= daysInMonth; d++){
            const dateStr = year + '-' + String(month+1).padStart(2,'0') + '-' + String(d).padStart(2,'0');
            const isToday = (d === today.getDate() && month === today.getMonth() && year === today.getFullYear());
            const hasEvent = events.some(e => e.date === dateStr);
            
            let classes = 'cal-day';
            if(isToday) classes += ' today';
            if(hasEvent) classes += ' has-event';
            
            const eventTitle = hasEvent ? events.find(e => e.date === dateStr).title : '';
            html += '<div class="' + classes + '" ' + (eventTitle ? 'title="'+eventTitle+'"' : '') + '>' + d + '</div>';
        }
        
        // Next month days
        const totalCells = startDay + daysInMonth;
        const remaining = totalCells % 7 === 0 ? 0 : 7 - (totalCells % 7);
        for(let i = 1; i <= remaining; i++){
            html += '<div class="cal-day other-month">' + i + '</div>';
        }
        
        document.getElementById('calendarGrid').innerHTML = html;
    }
    
    window.calendarPrev = function(){
        currentDate.setMonth(currentDate.getMonth() - 1);
        renderCalendar();
    };
    
    window.calendarNext = function(){
        currentDate.setMonth(currentDate.getMonth() + 1);
        renderCalendar();
    };
    
    renderCalendar();
})();
</script>
