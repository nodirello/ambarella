@props(['url' => null])

@php $qrUrl = $url ?? request()->url(); @endphp

<div class="qr-code-widget">
  <div class="qr-code-inner">
    <img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data={{ urlencode($qrUrl) }}&bgcolor=0f172a&color=ffffff" 
         alt="QR Code" 
         class="qr-img"
         loading="lazy">
    <p class="qr-label">QR kodni skanerlang</p>
    <a href="https://api.qrserver.com/v1/create-qr-code/?size=400x400&data={{ urlencode($qrUrl) }}&bgcolor=0f172a&color=ffffff" 
       download="qr-code.png" 
       class="qr-download">
      <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" fill="none" stroke-width="2">
        <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/>
        <polyline points="7 10 12 15 17 10"/>
        <line x1="12" y1="15" x2="12" y2="3"/>
      </svg>
      Yuklab olish
    </a>
  </div>
</div>

<style>
.qr-code-widget {
  display: inline-block;
}
.qr-code-inner {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
  padding: 24px;
  background: rgba(255,255,255,.02);
  border: 1px solid var(--border);
  border-radius: 16px;
  text-align: center;
}
.qr-img {
  width: 160px;
  height: 160px;
  border-radius: 12px;
  border: 2px solid rgba(255,255,255,.06);
}
.qr-label {
  font-size: 13px;
  color: var(--muted);
  font-weight: 500;
}
.qr-download {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 8px 16px;
  background: rgba(37,99,235,.1);
  border: 1px solid rgba(37,99,235,.2);
  border-radius: 10px;
  color: #93c5fd;
  font-size: 13px;
  font-weight: 600;
  transition: all .3s;
}
.qr-download:hover {
  background: rgba(37,99,235,.2);
  transform: translateY(-1px);
  color: #bfdbfe;
}
</style>
