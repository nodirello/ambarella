@props(['tasks' => collect()])

@php
  $pending = $tasks->where('status', 'pending');
  $inProgress = $tasks->where('status', 'in_progress');
  $completed = $tasks->where('status', 'completed');
@endphp

<div class="kanban-board">
  <div class="kanban-column kanban-pending">
    <div class="kanban-col-header red">
      <span class="kanban-col-icon">🔴</span>
      <span class="kanban-col-title">Bajarilmagan</span>
      <span class="kanban-col-count">{{ $pending->count() }}</span>
    </div>
    <div class="kanban-cards">
      @forelse($pending as $task)
        <div class="kanban-card">
          <div class="kanban-card-title">{{ $task->title ?? $task->name ?? 'Vazifa' }}</div>
          @if(isset($task->description))
            <div class="kanban-card-desc">{{ Str::limit($task->description, 60) }}</div>
          @endif
          <div class="kanban-card-meta">
            @if(isset($task->created_at))
              <span>{{ $task->created_at->format('d.m') }}</span>
            @endif
          </div>
        </div>
      @empty
        <div class="kanban-empty">Vazifa yo'q</div>
      @endforelse
    </div>
  </div>

  <div class="kanban-column kanban-progress">
    <div class="kanban-col-header yellow">
      <span class="kanban-col-icon">🟡</span>
      <span class="kanban-col-title">Jarayonda</span>
      <span class="kanban-col-count">{{ $inProgress->count() }}</span>
    </div>
    <div class="kanban-cards">
      @forelse($inProgress as $task)
        <div class="kanban-card">
          <div class="kanban-card-title">{{ $task->title ?? $task->name ?? 'Vazifa' }}</div>
          @if(isset($task->description))
            <div class="kanban-card-desc">{{ Str::limit($task->description, 60) }}</div>
          @endif
          <div class="kanban-card-meta">
            @if(isset($task->created_at))
              <span>{{ $task->created_at->format('d.m') }}</span>
            @endif
          </div>
        </div>
      @empty
        <div class="kanban-empty">Vazifa yo'q</div>
      @endforelse
    </div>
  </div>

  <div class="kanban-column kanban-done">
    <div class="kanban-col-header green">
      <span class="kanban-col-icon">🟢</span>
      <span class="kanban-col-title">Tugallangan</span>
      <span class="kanban-col-count">{{ $completed->count() }}</span>
    </div>
    <div class="kanban-cards">
      @forelse($completed as $task)
        <div class="kanban-card done">
          <div class="kanban-card-title">{{ $task->title ?? $task->name ?? 'Vazifa' }}</div>
          @if(isset($task->description))
            <div class="kanban-card-desc">{{ Str::limit($task->description, 60) }}</div>
          @endif
          <div class="kanban-card-meta">
            @if(isset($task->created_at))
              <span>{{ $task->created_at->format('d.m') }}</span>
            @endif
          </div>
        </div>
      @empty
        <div class="kanban-empty">Vazifa yo'q</div>
      @endforelse
    </div>
  </div>
</div>

<style>
.kanban-board {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 20px;
  margin: 24px 0;
}
.kanban-column {
  background: rgba(255,255,255,.02);
  border: 1px solid var(--border);
  border-radius: 16px;
  overflow: hidden;
  min-height: 300px;
}
.kanban-col-header {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 16px 20px;
  font-weight: 700;
  font-size: 14px;
  border-bottom: 1px solid var(--border);
}
.kanban-col-header.red {
  background: rgba(239,68,68,.06);
  color: #fca5a5;
  border-bottom-color: rgba(239,68,68,.15);
}
.kanban-col-header.yellow {
  background: rgba(245,158,11,.06);
  color: #fcd34d;
  border-bottom-color: rgba(245,158,11,.15);
}
.kanban-col-header.green {
  background: rgba(22,163,74,.06);
  color: #4ade80;
  border-bottom-color: rgba(22,163,74,.15);
}
.kanban-col-icon { font-size: 14px; }
.kanban-col-title { flex: 1; }
.kanban-col-count {
  width: 24px;
  height: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
  font-size: 12px;
  font-weight: 700;
  background: rgba(255,255,255,.06);
}
.kanban-cards {
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.kanban-card {
  padding: 14px 16px;
  background: rgba(255,255,255,.03);
  border: 1px solid var(--border);
  border-radius: 12px;
  transition: all .3s;
}
.kanban-card:hover {
  transform: translateY(-2px);
  border-color: rgba(59,130,246,.2);
  box-shadow: 0 4px 16px rgba(0,0,0,.2);
}
.kanban-card.done {
  opacity: .7;
  border-color: rgba(22,163,74,.2);
}
.kanban-card.done .kanban-card-title {
  text-decoration: line-through;
  color: var(--muted);
}
.kanban-card-title {
  font-size: 14px;
  font-weight: 600;
  color: #e2e8f0;
  margin-bottom: 4px;
}
.kanban-card-desc {
  font-size: 12px;
  color: var(--muted);
  line-height: 1.5;
}
.kanban-card-meta {
  margin-top: 8px;
  font-size: 11px;
  color: #475569;
}
.kanban-empty {
  text-align: center;
  padding: 24px;
  color: #374151;
  font-size: 13px;
}
@media(max-width: 768px) {
  .kanban-board {
    grid-template-columns: 1fr;
  }
  .kanban-column { min-height: auto; }
}
</style>
