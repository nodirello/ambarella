{{-- Infinite Scroll Component --}}
{{-- Usage: @include('components.infinite-scroll', ['url' => '/api/jobs?page=']) --}}
{{-- The container where new items are appended should have id="infinite-scroll-container" --}}
{{-- Items will be fetched as HTML from the given URL with page number appended --}}

@php
    $url = $url ?? '';
@endphp

<div id="infinite-scroll-loader" class="infinite-scroll-loader" style="display:none">
    <div class="infinite-scroll-spinner">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>
        </svg>
    </div>
    <span>Yuklanmoqda...</span>
</div>

<div id="infinite-scroll-end" class="infinite-scroll-end" style="display:none">
    <span>Barchasi ko'rsatildi ✓</span>
</div>

<style>
.infinite-scroll-loader{display:flex;align-items:center;justify-content:center;gap:10px;padding:24px;color:var(--muted);font-size:14px}
.infinite-scroll-spinner svg{animation:infiniteSpin 1s linear infinite;color:#3b82f6}
@keyframes infiniteSpin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
.infinite-scroll-end{text-align:center;padding:20px;color:var(--muted);font-size:13px;opacity:.6}
</style>

<script>
(function() {
    let infinitePage = 2;
    let infiniteLoading = false;
    let infiniteEnded = false;
    const infiniteUrl = @json($url);
    const loader = document.getElementById('infinite-scroll-loader');
    const endEl = document.getElementById('infinite-scroll-end');
    const container = document.getElementById('infinite-scroll-container');

    if (!container || !infiniteUrl) return;

    function loadMore() {
        if (infiniteLoading || infiniteEnded) return;
        infiniteLoading = true;
        loader.style.display = 'flex';

        fetch(infiniteUrl + infinitePage, {
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'text/html'
            }
        })
        .then(response => {
            if (!response.ok) throw new Error('Network error');
            return response.text();
        })
        .then(html => {
            const trimmed = html.trim();
            if (!trimmed || trimmed.length < 10) {
                infiniteEnded = true;
                loader.style.display = 'none';
                endEl.style.display = 'block';
                return;
            }
            container.insertAdjacentHTML('beforeend', trimmed);
            infinitePage++;
            infiniteLoading = false;
            loader.style.display = 'none';

            // Re-init stagger reveal for new items
            if (typeof initStaggerReveal === 'function') {
                initStaggerReveal();
            }
        })
        .catch(() => {
            infiniteLoading = false;
            loader.style.display = 'none';
        });
    }

    // Intersection Observer for bottom detection
    const sentinel = document.createElement('div');
    sentinel.id = 'infinite-scroll-sentinel';
    sentinel.style.height = '1px';
    container.parentNode.insertBefore(sentinel, container.nextSibling);

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                loadMore();
            }
        });
    }, { rootMargin: '200px' });

    observer.observe(sentinel);
})();
</script>
