{{-- Banner Slider Component --}}
{{-- Usage: @include('components.banner-slider', ['banners' => $banners]) --}}
{{-- Each banner: title, subtitle, image_url, link_url, button_text --}}

@php
    $banners = $banners ?? collect();
    $count = $banners->count();
@endphp

@if($count > 0)
<div class="banner-slider" style="--slide-count: {{ $count }}">
    <div class="banner-slider__track">
        @foreach($banners as $index => $banner)
        <div class="banner-slider__slide">
            @if($banner->image_url)
            <img src="{{ $banner->image_url }}" alt="{{ $banner->title }}" class="banner-slider__img" loading="lazy">
            @endif
            <div class="banner-slider__overlay"></div>
            <div class="banner-slider__content">
                <h2 class="banner-slider__title">{{ $banner->title }}</h2>
                @if($banner->subtitle)
                <p class="banner-slider__subtitle">{{ $banner->subtitle }}</p>
                @endif
                @if($banner->link_url && $banner->button_text)
                <a href="{{ $banner->link_url }}" class="banner-slider__btn">
                    {{ $banner->button_text }}
                    <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                </a>
                @endif
            </div>
        </div>
        @endforeach
    </div>
    {{-- Navigation dots --}}
    @if($count > 1)
    <div class="banner-slider__dots">
        @for($i = 0; $i < $count; $i++)
        <span class="banner-slider__dot {{ $i === 0 ? 'active' : '' }}"></span>
        @endfor
    </div>
    @endif
</div>

<style>
.banner-slider{position:relative;width:100%;height:320px;border-radius:var(--radius, 12px);overflow:hidden;margin-bottom:32px;background:#0f172a}
.banner-slider__track{display:flex;width:calc(100% * var(--slide-count));height:100%;animation:bannerSlide calc(5s * var(--slide-count)) ease-in-out infinite}
.banner-slider__slide{position:relative;width:calc(100% / var(--slide-count));height:100%;flex-shrink:0}
.banner-slider__img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
.banner-slider__overlay{position:absolute;inset:0;background:linear-gradient(135deg,rgba(15,23,42,.85) 0%,rgba(15,23,42,.4) 50%,rgba(15,23,42,.7) 100%);z-index:1}
.banner-slider__content{position:absolute;inset:0;display:flex;flex-direction:column;justify-content:center;padding:40px 48px;z-index:2}
.banner-slider__title{font-size:28px;font-weight:800;color:#fff;margin:0 0 8px;line-height:1.2;text-shadow:0 2px 8px rgba(0,0,0,.3)}
.banner-slider__subtitle{font-size:15px;color:#94a3b8;margin:0 0 20px;max-width:500px;line-height:1.5}
.banner-slider__btn{display:inline-flex;align-items:center;gap:8px;padding:12px 24px;background:linear-gradient(135deg,#2563eb,#3b82f6);color:#fff;font-size:14px;font-weight:600;border-radius:8px;text-decoration:none;transition:all .3s;box-shadow:0 4px 16px rgba(37,99,235,.3)}
.banner-slider__btn:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(37,99,235,.4)}
.banner-slider__dots{position:absolute;bottom:16px;left:50%;transform:translateX(-50%);display:flex;gap:8px;z-index:3}
.banner-slider__dot{width:8px;height:8px;border-radius:50%;background:rgba(255,255,255,.3);transition:all .3s}
.banner-slider__dot.active{background:#3b82f6;width:24px;border-radius:4px}

/* Auto-slide keyframes - generated dynamically based on count */
@keyframes bannerSlide{
    0%,18%{transform:translateX(0)}
    20%,38%{transform:translateX(calc(-100% / var(--slide-count)))}
    40%,58%{transform:translateX(calc(-200% / var(--slide-count)))}
    60%,78%{transform:translateX(calc(-300% / var(--slide-count)))}
    80%,98%{transform:translateX(calc(-400% / var(--slide-count)))}
    100%{transform:translateX(0)}
}

/* Dot animation sync */
.banner-slider__dots .banner-slider__dot{animation:dotPulse calc(5s * var(--slide-count)) ease-in-out infinite}
.banner-slider__dots .banner-slider__dot:nth-child(1){animation-delay:0s}
.banner-slider__dots .banner-slider__dot:nth-child(2){animation-delay:5s}
.banner-slider__dots .banner-slider__dot:nth-child(3){animation-delay:10s}
.banner-slider__dots .banner-slider__dot:nth-child(4){animation-delay:15s}
.banner-slider__dots .banner-slider__dot:nth-child(5){animation-delay:20s}

@keyframes dotPulse{
    0%,15%{background:#3b82f6;width:24px;border-radius:4px}
    20%,100%{background:rgba(255,255,255,.3);width:8px;border-radius:50%}
}

/* Shimmer effect on slide transition */
.banner-slider__slide::after{content:'';position:absolute;inset:0;background:linear-gradient(90deg,transparent,rgba(59,130,246,.05),transparent);animation:bannerShimmer 3s ease-in-out infinite;z-index:1}
@keyframes bannerShimmer{0%{transform:translateX(-100%)}100%{transform:translateX(100%)}}

@media(max-width:768px){
    .banner-slider{height:200px;border-radius:8px}
    .banner-slider__content{padding:20px 24px}
    .banner-slider__title{font-size:20px}
    .banner-slider__subtitle{font-size:13px;margin-bottom:14px}
    .banner-slider__btn{padding:10px 18px;font-size:13px}
}
</style>
@else
{{-- Fallback: no banners --}}
<div class="banner-slider-fallback">
    <div class="banner-slider-fallback__content">
        <h2>AMBARELLA.UZ</h2>
        <p>Yoshlar uchun eng yaxshi platforma</p>
    </div>
</div>
<style>
.banner-slider-fallback{width:100%;height:320px;border-radius:var(--radius, 12px);overflow:hidden;margin-bottom:32px;background:linear-gradient(135deg,#0f172a 0%,#1e293b 50%,#0f172a 100%);display:flex;align-items:center;justify-content:center;position:relative;border:1px solid var(--border)}
.banner-slider-fallback::before{content:'';position:absolute;inset:0;background:radial-gradient(circle at 30% 50%,rgba(59,130,246,.08),transparent 60%)}
.banner-slider-fallback__content{text-align:center;z-index:1}
.banner-slider-fallback__content h2{font-size:32px;font-weight:800;color:#fff;margin:0 0 8px}
.banner-slider-fallback__content p{font-size:15px;color:var(--muted)}
@media(max-width:768px){.banner-slider-fallback{height:200px}.banner-slider-fallback__content h2{font-size:24px}}
</style>
@endif
