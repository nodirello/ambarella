@props(['stats' => []])

<div class="stats-counter-grid" id="statsCounterSection">
  @foreach($stats as $stat)
    <div class="stats-counter-item">
      <div class="stats-counter-value" data-count="{{ $stat['value'] }}" style="color:{{ $stat['color'] ?? '#2563eb' }}">0</div>
      <div class="stats-counter-label">{{ $stat['label'] }}</div>
    </div>
  @endforeach
</div>

<style>
.stats-counter-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:24px;padding:32px 0}
.stats-counter-item{text-align:center;padding:24px 16px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);border-radius:16px;transition:all .3s}
.stats-counter-item:hover{transform:translateY(-4px);border-color:rgba(37,99,235,.2);box-shadow:0 8px 24px rgba(0,0,0,.2)}
.stats-counter-value{font-size:36px;font-weight:800;letter-spacing:-1px;margin-bottom:4px;font-variant-numeric:tabular-nums}
.stats-counter-label{font-size:13px;color:#64748b;font-weight:500}
@media(max-width:480px){.stats-counter-value{font-size:28px}}
</style>

<script>
(function(){
  function animateCounter(el){
    const target = parseInt(el.getAttribute('data-count'));
    const duration = 2000;
    const start = performance.now();
    function update(now){
      const elapsed = now - start;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      el.textContent = Math.floor(target * eased).toLocaleString();
      if(progress < 1) requestAnimationFrame(update);
      else el.textContent = target.toLocaleString();
    }
    requestAnimationFrame(update);
  }

  const observer = new IntersectionObserver(function(entries){
    entries.forEach(function(entry){
      if(entry.isIntersecting){
        const counters = entry.target.querySelectorAll('[data-count]');
        counters.forEach(animateCounter);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.3 });

  const section = document.getElementById('statsCounterSection');
  if(section) observer.observe(section);
})();
</script>
