<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Models\Job;
use App\Models\Course;
use App\Models\News;
use App\Models\Mentor;
use App\Models\FarmProduct;

/*
|--------------------------------------------------------------------------
| AMBARELLA REST API v1
|--------------------------------------------------------------------------
| Mobile app va tashqi integratsiya uchun
| Base URL: /api/v1/
|--------------------------------------------------------------------------
*/

Route::prefix('v1')->middleware('throttle:60,1')->group(function () {

    // ===== PUBLIC ENDPOINTS =====

    // Telegram Web App API
    Route::prefix('tg')->group(function () {
        Route::get('/me',         [\App\Http\Controllers\TelegramWebAppController::class, 'me']);
        Route::get('/eco-tasks',  [\App\Http\Controllers\TelegramWebAppController::class, 'ecoTasks']);
        Route::get('/eco-stats',  [\App\Http\Controllers\TelegramWebAppController::class, 'ecoStats']);
    });

    // Ish e'lonlari
    Route::get('/jobs', function (Request $request) {
        $query = Job::where('is_active', true);

        if ($request->filled('search')) {
            $s = strip_tags($request->search);
            $query->where(function ($q) use ($s) {
                $q->where('title', 'like', "%{$s}%")
                  ->orWhere('company', 'like', "%{$s}%");
            });
        }
        if ($request->filled('type')) {
            $query->where('type', $request->type);
        }

        return response()->json([
            'success' => true,
            'data' => $query->latest()->paginate($request->input('per_page', 15)),
        ]);
    });

    Route::get('/jobs/{job}', function (Job $job) {
        return response()->json(['success' => true, 'data' => $job]);
    });

    // Kurslar
    Route::get('/courses', function () {
        return response()->json([
            'success' => true,
            'data' => Course::paginate(15),
        ]);
    });

    Route::get('/courses/{course}', function (Course $course) {
        return response()->json(['success' => true, 'data' => $course]);
    });

    // Yangiliklar
    Route::get('/news', function () {
        return response()->json([
            'success' => true,
            'data' => News::latest()->paginate(15),
        ]);
    });

    // Mentorlar
    Route::get('/mentors', function () {
        return response()->json([
            'success' => true,
            'data' => Mentor::where('is_available', true)->paginate(15),
        ]);
    });

    // Mahsulotlar
    Route::get('/products', function (Request $request) {
        $query = FarmProduct::where('is_active', true);
        if ($request->filled('category')) {
            $query->where('category', $request->category);
        }
        return response()->json([
            'success' => true,
            'data' => $query->latest()->paginate(15),
        ]);
    });

    // Platform stats
    Route::get('/stats', function () {
        return response()->json([
            'success' => true,
            'data' => [
                'users' => \App\Models\User::count(),
                'jobs' => Job::where('is_active', true)->count(),
                'courses' => Course::count(),
                'mentors' => Mentor::where('is_available', true)->count(),
            ],
        ]);
    });

    // ===== AUTHENTICATED ENDPOINTS =====
    Route::middleware('auth:sanctum')->group(function () {

        // Current user
        Route::get('/me', function (Request $request) {
            $user = $request->user();
            return response()->json([
                'success' => true,
                'data' => [
                    'id' => $user->id,
                    'name' => $user->name,
                    'email' => $user->email,
                    'greencoin_balance' => $user->greencoin_balance,
                    'avatar' => $user->avatar ? asset('storage/' . $user->avatar) : null,
                    'login_streak' => $user->login_streak,
                    'role' => $user->role,
                ],
            ]);
        });

        // GreenCoin balance
        Route::get('/greencoin', function (Request $request) {
            $transactions = $request->user()->transactions()->latest()->paginate(20);
            return response()->json([
                'success' => true,
                'balance' => $request->user()->greencoin_balance,
                'transactions' => $transactions,
            ]);
        });

        // My applications
        Route::get('/my-applications', function (Request $request) {
            return response()->json([
                'success' => true,
                'data' => $request->user()->applications()->with('job')->latest()->get(),
            ]);
        });
    });
});

/*
|--------------------------------------------------------------------------
| WEBHOOKS (CSRF himoyasidan tashqari)
|--------------------------------------------------------------------------
*/
Route::post('/telegram-webhook', [\App\Http\Controllers\TelegramBotController::class, 'webhook']);
