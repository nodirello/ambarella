<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\JobController;
use App\Http\Controllers\EcoController;
use App\Http\Controllers\CourseController;
use App\Http\Controllers\MentorController;
use App\Http\Controllers\MentorshipController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DailyTaskController;
use App\Http\Controllers\HabitController;
use App\Http\Controllers\FarmProductController;
use App\Http\Controllers\NewsController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\PasswordResetController;
use App\Http\Controllers\TelegramAuthController;
use App\Http\Controllers\TelegramBotController;
use App\Http\Controllers\GreenCoinController;
use App\Http\Controllers\StartupController;
use App\Http\Controllers\VolunteerController;
use App\Http\Controllers\EventController;
use App\Http\Controllers\ChallengeController;
use App\Http\Controllers\PsychologyController;
use App\Http\Controllers\SettingsController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\MyCoursesController;
use App\Http\Controllers\MyApplicationsController;
use App\Http\Controllers\OnboardingController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\Admin\AdminDashboardController;
use App\Http\Controllers\Admin\AdminUserController;
use App\Http\Controllers\Admin\AdminJobController;
use App\Http\Controllers\Admin\AdminNewsController;
use App\Http\Controllers\Admin\AdminEcoTaskController;
use App\Http\Controllers\Admin\AdminCourseController;
use App\Http\Controllers\Admin\AdminMentorController;
use App\Http\Controllers\Admin\AdminEventController;
use App\Http\Controllers\Admin\AdminStatsController;
use App\Http\Controllers\Admin\AdminGreenCoinController;
use App\Http\Controllers\Admin\AdminFarmController;
use App\Http\Controllers\Admin\AdminApplicationController;
use App\Http\Controllers\Admin\AdminContactController;
use App\Http\Controllers\SearchController;
use App\Http\Controllers\FavoriteController;
use App\Http\Controllers\SitemapController;
use App\Http\Controllers\ReferralController;
use App\Http\Controllers\AchievementController;
use App\Http\Controllers\UserProfileController;
use App\Http\Controllers\Admin\AdminActivityLogController;
use App\Http\Controllers\Admin\AdminExportController;
use App\Http\Controllers\Admin\AdminFaqController;
use App\Http\Controllers\Admin\AdminAnnouncementController;
use App\Http\Controllers\Admin\AdminSuccessStoryController;
use App\Http\Controllers\Admin\AdminBannerController;
use App\Http\Controllers\CommentController;
use App\Http\Controllers\Business\BusinessRegisterController;
use App\Http\Controllers\Business\BusinessJobController;
use App\Http\Controllers\Business\BusinessAnalyticsController;
use App\Http\Controllers\Business\BusinessApplicationController;
use App\Http\Controllers\Business\BusinessProductController;
use App\Http\Controllers\Business\BusinessSettingsController;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\LastViewedController;
use App\Http\Controllers\StreakController;
use App\Http\Controllers\PollController;
use App\Http\Controllers\CertificateController;
use App\Http\Controllers\ReactionController;
use App\Http\Controllers\Admin\AdminPollController;
use App\Http\Controllers\ForumController;
use App\Http\Controllers\NoteController;
use App\Http\Controllers\LiveCountController;
use App\Http\Controllers\NotificationApiController;
use App\Http\Controllers\Admin\AdminModerationController;
use Illuminate\Support\Facades\Route;

// ==================== OMMAVIY ====================
Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/offline', fn() => view('offline'))->name('offline');
Route::get('/jobs', [JobController::class, 'index'])->name('jobs');
Route::get('/jobs/{job}', [JobController::class, 'show'])->name('jobs.show');
Route::get('/eco', [EcoController::class, 'index'])->name('eco');
Route::get('/academy', [CourseController::class, 'index'])->name('academy');
Route::get('/academy/{course}', [CourseController::class, 'show'])->name('academy.show');
Route::get('/mentor', [MentorController::class, 'index'])->name('mentor');
Route::get('/farm', [FarmProductController::class, 'index'])->name('farm');
Route::get('/news', [NewsController::class, 'index'])->name('news');
Route::get('/news/{news}', [NewsController::class, 'show'])->name('news.show');
Route::get('/startup', [StartupController::class, 'index'])->name('startup');
Route::get('/startup/{id}', [StartupController::class, 'show'])->name('startup.show');
Route::get('/volunteer', [VolunteerController::class, 'index'])->name('volunteer');
Route::get('/events', [EventController::class, 'index'])->name('events');
Route::get('/challenges', [ChallengeController::class, 'index'])->name('challenges');
Route::get('/psychology', [PsychologyController::class, 'index'])->name('psychology');
Route::get('/psychology/{slug}', [PsychologyController::class, 'test'])->name('psychology.test');
Route::post('/psychology/{slug}', [PsychologyController::class, 'submit'])->name('psychology.submit')->middleware(['auth', 'throttle:10,1']);
Route::get('/about', [PageController::class, 'about'])->name('about');
Route::get('/contact', [PageController::class, 'contact'])->name('contact');
Route::post('/contact', [ContactController::class, 'store'])->name('contact.store')->middleware('throttle:3,1');
Route::get('/modules', [PageController::class, 'modules'])->name('modules');

// Blog
Route::get('/blog', [BlogController::class, 'index'])->name('blog');
Route::get('/blog/create', [BlogController::class, 'create'])->name('blog.create')->middleware(['auth', 'banned', 'profile.complete']);
Route::post('/blog', [BlogController::class, 'store'])->name('blog.store')->middleware(['auth', 'banned', 'profile.complete']);
Route::get('/blog/{slug}', [BlogController::class, 'show'])->name('blog.show');

// Last Viewed
Route::get('/last-viewed', [LastViewedController::class, 'index'])->name('last-viewed');

// Compare
Route::get('/compare', fn() => view('compare.index'))->name('compare');

// Global Search
Route::get('/search', [SearchController::class, 'index'])->name('search');

// Sertifikat tekshirish (ommaviy)
Route::get('/certificate/verify/{id}', [CertificateController::class, 'verify'])->name('certificate.verify');

// Sitemap
Route::get('/sitemap.xml', [SitemapController::class, 'index'])->name('sitemap');

// ==================== PUBLIC API ====================
Route::get('/api/online-count', [LiveCountController::class, 'count'])->middleware('throttle:30,1');
Route::get('/api/notifications/unread-count', [NotificationApiController::class, 'unreadCount'])->middleware('throttle:30,1');
Route::get('/api/health', [\App\Http\Controllers\HealthController::class, 'check'])->middleware('throttle:10,1');

// ==================== AUTH ====================
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'loginForm'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:5,1');
    Route::get('/register', [AuthController::class, 'registerForm'])->name('register');
    Route::post('/register', [AuthController::class, 'register'])->middleware('throttle:3,1');

    // Parol tiklash
    Route::get('/forgot-password', [PasswordResetController::class, 'showForm'])->name('password.request');
    Route::post('/forgot-password', [PasswordResetController::class, 'requestReset'])->middleware('throttle:3,1');
    Route::post('/reset-password', [PasswordResetController::class, 'resetPassword']);
});

Route::post('/logout', [AuthController::class, 'logout'])->name('logout')->middleware('auth');

// Email Verification
Route::middleware('auth')->group(function () {
    Route::get('/email/verify', [\App\Http\Controllers\EmailVerificationController::class, 'notice'])->name('verification.notice');
    Route::get('/email/verify/{id}/{hash}', [\App\Http\Controllers\EmailVerificationController::class, 'verify'])->middleware('signed')->name('verification.verify');
    Route::post('/email/verification-notification', [\App\Http\Controllers\EmailVerificationController::class, 'resend'])->middleware('throttle:3,1')->name('verification.send');
});

// 2FA (Two-Factor Authentication)
Route::middleware('auth')->group(function () {
    Route::get('/2fa/verify', [\App\Http\Controllers\TwoFactorController::class, 'showVerify'])->name('2fa.verify');
    Route::post('/2fa/verify', [\App\Http\Controllers\TwoFactorController::class, 'verify']);
    Route::post('/2fa/resend', [\App\Http\Controllers\TwoFactorController::class, 'resend'])->middleware('throttle:3,1');
});

// Telegram Auth
Route::get('/auth/telegram/callback', [TelegramAuthController::class, 'telegramCallback'])->name('telegram.callback');
Route::post('/auth/telegram/send-code', [TelegramAuthController::class, 'sendCode'])->middleware('throttle:3,1')->name('telegram.send-code');
Route::post('/auth/telegram/verify-code', [TelegramAuthController::class, 'verifyCode'])->middleware('throttle:5,1')->name('telegram.verify-code');

// Telegram Bot Webhook — CSRF'dan mustasno (bootstrap/app.php da sozlangan)
Route::post('/webhook/telegram', [TelegramBotController::class, 'webhook']);

// ==================== AUTH KERAK ====================
Route::middleware(['auth', 'banned'])->group(function () {
    // Onboarding (profil to'ldirish) — middleware'dan mustasno
    Route::get('/onboarding', [OnboardingController::class, 'show'])->name('onboarding');
    Route::post('/onboarding', [OnboardingController::class, 'store'])->name('onboarding.store');
});

Route::middleware(['auth', 'banned', 'profile.complete'])->group(function () {
    // Dashboard
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // Profil
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::post('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::post('/profile/password', [ProfileController::class, 'changePassword'])->name('profile.password');

    // GreenCoin hamyon
    Route::get('/greencoin', [GreenCoinController::class, 'index'])->name('greencoin');
    Route::post('/greencoin/transfer', [GreenCoinController::class, 'transfer'])->name('greencoin.transfer')->middleware('throttle:5,1');
    Route::get('/greencoin/shop', [\App\Http\Controllers\GreenCoinShopController::class, 'index'])->name('greencoin.shop');
    Route::post('/greencoin/shop/purchase', [\App\Http\Controllers\GreenCoinShopController::class, 'purchase'])->name('greencoin.purchase')->middleware('throttle:5,1');
    Route::get('/greencoin/leaderboard', [\App\Http\Controllers\LeaderboardController::class, 'index'])->name('greencoin.leaderboard');

    // Sozlamalar
    Route::get('/settings', [SettingsController::class, 'index'])->name('settings');
    Route::post('/settings/profile', [SettingsController::class, 'updateProfile'])->name('settings.profile');
    Route::post('/settings/password', [SettingsController::class, 'updatePassword'])->name('settings.password');
    Route::post('/settings/2fa', [SettingsController::class, 'toggle2FA'])->name('settings.2fa');
    Route::post('/settings/delete-account', [SettingsController::class, 'deleteAccount'])->name('settings.delete');
    Route::get('/settings/export', [SettingsController::class, 'exportData'])->name('settings.export');

    // Bildirishnomalar
    Route::get('/notifications', [NotificationController::class, 'index'])->name('notifications');
    Route::post('/notifications/{id}/read', [NotificationController::class, 'markAsRead'])->name('notifications.read');
    Route::post('/notifications/mark-all-read', [NotificationController::class, 'markAllRead'])->name('notifications.mark-all');

    // Mening kurslarim
    Route::get('/my-courses', [MyCoursesController::class, 'index'])->name('my-courses');

    // Mening arizalarim
    Route::get('/my-applications', [MyApplicationsController::class, 'index'])->name('my-applications');

    // Kundalik vazifalar
    Route::get('/daily-tasks', [DailyTaskController::class, 'index'])->name('daily-tasks');
    Route::post('/daily-tasks', [DailyTaskController::class, 'store'])->name('daily-tasks.store');
    Route::post('/daily-tasks/{task}/toggle', [DailyTaskController::class, 'toggle'])->name('daily-tasks.toggle');
    Route::delete('/daily-tasks/{task}', [DailyTaskController::class, 'destroy'])->name('daily-tasks.destroy');

    // Odatlar (habits)
    Route::get('/habits', [HabitController::class, 'index'])->name('habits');
    Route::post('/habits', [HabitController::class, 'store'])->name('habits.store');
    Route::post('/habits/{habit}/complete', [HabitController::class, 'complete'])->name('habits.complete');
    Route::delete('/habits/{habit}', [HabitController::class, 'destroy'])->name('habits.destroy');

    // Mentorship (shogird-ustoz tizimi)
    Route::get('/mentorship', [MentorshipController::class, 'index'])->name('mentorship');
    Route::get('/mentorship/create', [MentorshipController::class, 'create'])->name('mentorship.create');
    Route::post('/mentorship', [MentorshipController::class, 'store'])->name('mentorship.store');
    Route::post('/mentorship/{mentorship}/accept', [MentorshipController::class, 'accept'])->name('mentorship.accept');
    Route::post('/mentorship/{mentorship}/reject', [MentorshipController::class, 'reject'])->name('mentorship.reject');
    Route::post('/mentorship/{mentorship}/task', [MentorshipController::class, 'addTask'])->name('mentorship.task');
    Route::post('/mentorship/task/{task}/complete', [MentorshipController::class, 'completeTask'])->name('mentorship.task.complete');

    // Qishloq mahsulotlari
    Route::get('/farm/create', [FarmProductController::class, 'create'])->name('farm.create');
    Route::post('/farm', [FarmProductController::class, 'store'])->name('farm.store');
    Route::get('/farm/my-products', [FarmProductController::class, 'myProducts'])->name('farm.my-products');
    Route::get('/farm/{product}/edit', [FarmProductController::class, 'edit'])->name('farm.edit');
    Route::put('/farm/{product}', [FarmProductController::class, 'update'])->name('farm.update');
    Route::delete('/farm/{product}', [FarmProductController::class, 'destroy'])->name('farm.destroy');
    Route::post('/farm/{product}/toggle', [FarmProductController::class, 'toggleActive'])->name('farm.toggle');

    // Modullar bilan ishlash
    Route::post('/jobs/{job}/apply', [JobController::class, 'apply'])->name('jobs.apply');
    Route::post('/jobs/{job}/save', [JobController::class, 'saveJob'])->name('jobs.save');
    Route::post('/eco/tasks/{task}/complete', [EcoController::class, 'complete'])->name('eco.complete')->middleware('throttle:10,1');
    Route::post('/academy/{course}/enroll', [CourseController::class, 'enroll'])->name('academy.enroll');
    Route::post('/mentor/{mentor}/request', [MentorController::class, 'request'])->name('mentor.request');

    // Sevimlilar
    Route::get('/favorites', [FavoriteController::class, 'index'])->name('favorites');
    Route::post('/favorites/toggle', [FavoriteController::class, 'toggle'])->name('favorites.toggle');

    // Referal
    Route::get('/referral', [ReferralController::class, 'index'])->name('referral');

    // Yutuqlar
    Route::get('/achievements', [AchievementController::class, 'index'])->name('achievements');

    // Haftalik challenge
    Route::get('/weekly-challenge', fn() => view('weekly-challenge.index'))->name('weekly-challenge');

    // Omad g'ildiragi
    Route::get('/lucky-wheel', fn() => view('lucky-wheel.index'))->name('lucky-wheel');

    // Biznes panel
    Route::get('/business', [BusinessDashboardController::class, 'index'])->name('business.dashboard');
    Route::get('/business/register', [BusinessRegisterController::class, 'show'])->name('business.register');
    Route::post('/business/register', [BusinessRegisterController::class, 'store'])->name('business.register.store');
    Route::get('/business/jobs', [BusinessJobController::class, 'index'])->name('business.jobs');
    Route::get('/business/jobs/create', [BusinessJobController::class, 'create'])->name('business.jobs.create');
    Route::post('/business/jobs', [BusinessJobController::class, 'store'])->name('business.jobs.store');
    Route::get('/business/applications', [BusinessApplicationController::class, 'index'])->name('business.applications');
    Route::post('/business/applications/{application}/status', [BusinessApplicationController::class, 'updateStatus'])->name('business.applications.status');
    Route::get('/business/products', [BusinessProductController::class, 'index'])->name('business.products');
    Route::get('/business/analytics', [BusinessAnalyticsController::class, 'index'])->name('business.analytics');
    Route::get('/business/settings', [BusinessSettingsController::class, 'index'])->name('business.settings');
    Route::post('/business/settings', [BusinessSettingsController::class, 'update'])->name('business.settings.update');
    Route::post('/business/jobs/{job}/toggle', [BusinessJobController::class, 'toggle'])->name('business.jobs.toggle');

    // Streak
    Route::post('/streak/check', [StreakController::class, 'check'])->name('streak.check');

    // Startup (authenticated)
    Route::get('/startup/create', [StartupController::class, 'create'])->name('startup.create');
    Route::post('/startup', [StartupController::class, 'store'])->name('startup.store');
    Route::post('/startup/{id}/vote', [StartupController::class, 'vote'])->name('startup.vote')->middleware('throttle:10,1');

    // Comments
    Route::post('/comments', [CommentController::class, 'store'])->name('comments.store')->middleware('throttle:10,1');

    // Polls
    Route::get('/polls/{poll}', [PollController::class, 'show'])->name('polls.show');
    Route::post('/polls/{poll}/vote', [PollController::class, 'vote'])->name('polls.vote')->middleware('throttle:5,1');

    // Sertifikat
    Route::get('/certificate/{course}', [CertificateController::class, 'generate'])->name('certificate.generate');

    // Reactions (like/dislike)
    Route::post('/reactions/toggle', [ReactionController::class, 'toggle'])->name('reactions.toggle')->middleware('throttle:30,1');

    // Code Playground
    Route::get('/playground', fn() => view('code-playground.index'))->name('playground');

    // Forum
    Route::get('/forum', [ForumController::class, 'index'])->name('forum');
    Route::get('/forum/create', [ForumController::class, 'create'])->name('forum.create');
    Route::post('/forum', [ForumController::class, 'store'])->name('forum.store');
    Route::get('/forum/{topic}', [ForumController::class, 'show'])->name('forum.show');
    Route::post('/forum/{topic}/reply', [ForumController::class, 'reply'])->name('forum.reply');
    Route::post('/forum/reply/{reply}/best', [ForumController::class, 'markBest'])->name('forum.best');

    // Notes
    Route::get('/notes', [NoteController::class, 'index'])->name('notes');
    Route::post('/notes', [NoteController::class, 'store'])->name('notes.store');
    Route::put('/notes/{note}', [NoteController::class, 'update'])->name('notes.update');
    Route::delete('/notes/{note}', [NoteController::class, 'destroy'])->name('notes.destroy');
    Route::post('/notes/{note}/pin', [NoteController::class, 'togglePin'])->name('notes.pin');

    // Pomodoro Timer
    Route::get('/pomodoro', fn() => view('pomodoro.index'))->name('pomodoro');
});

// Farm product sahifasi (ommaviy)
Route::get('/farm/{product}', [FarmProductController::class, 'show'])->name('farm.show');

// Foydalanuvchi profili (ommaviy)
Route::get('/user/{user}', [UserProfileController::class, 'show'])->name('user.profile');

// ==================== ADMIN PANEL ====================
Route::prefix('admin')->middleware(['auth', 'admin', '2fa'])->group(function () {
    Route::get('/', [AdminDashboardController::class, 'index'])->name('admin.dashboard');

    // Foydalanuvchilar
    Route::get('/users', [AdminUserController::class, 'index'])->name('admin.users');
    Route::post('/users/{user}/ban', [AdminUserController::class, 'toggleBan'])->name('admin.users.ban');
    Route::post('/users/{user}/admin', [AdminUserController::class, 'makeAdmin'])->name('admin.users.admin');
    Route::post('/users/{user}/remove-admin', [AdminUserController::class, 'removeAdmin'])->name('admin.users.remove-admin');

    // Ish e'lonlari
    Route::get('/jobs', [AdminJobController::class, 'index'])->name('admin.jobs');
    Route::get('/jobs/create', [AdminJobController::class, 'create'])->name('admin.jobs.create');
    Route::post('/jobs', [AdminJobController::class, 'store'])->name('admin.jobs.store');
    Route::get('/jobs/{job}/edit', [AdminJobController::class, 'edit'])->name('admin.jobs.edit');
    Route::put('/jobs/{job}', [AdminJobController::class, 'update'])->name('admin.jobs.update');
    Route::delete('/jobs/{job}', [AdminJobController::class, 'destroy'])->name('admin.jobs.destroy');
    Route::post('/jobs/{job}/toggle', [AdminJobController::class, 'toggleActive'])->name('admin.jobs.toggle');

    // Yangiliklar
    Route::get('/news', [AdminNewsController::class, 'index'])->name('admin.news');
    Route::get('/news/create', [AdminNewsController::class, 'create'])->name('admin.news.create');
    Route::post('/news', [AdminNewsController::class, 'store'])->name('admin.news.store');
    Route::get('/news/{news}/edit', [AdminNewsController::class, 'edit'])->name('admin.news.edit');
    Route::put('/news/{news}', [AdminNewsController::class, 'update'])->name('admin.news.update');
    Route::delete('/news/{news}', [AdminNewsController::class, 'destroy'])->name('admin.news.destroy');

    // Eko vazifalar
    Route::get('/eco-tasks', [AdminEcoTaskController::class, 'index'])->name('admin.eco-tasks');
    Route::get('/eco-tasks/create', [AdminEcoTaskController::class, 'create'])->name('admin.eco-tasks.create');
    Route::post('/eco-tasks', [AdminEcoTaskController::class, 'store'])->name('admin.eco-tasks.store');
    Route::get('/eco-tasks/{task}/edit', [AdminEcoTaskController::class, 'edit'])->name('admin.eco-tasks.edit');
    Route::put('/eco-tasks/{task}', [AdminEcoTaskController::class, 'update'])->name('admin.eco-tasks.update');
    Route::delete('/eco-tasks/{task}', [AdminEcoTaskController::class, 'destroy'])->name('admin.eco-tasks.destroy');
    Route::post('/eco-tasks/{task}/toggle', [AdminEcoTaskController::class, 'toggle'])->name('admin.eco-tasks.toggle');

    // Kurslar
    Route::get('/courses', [AdminCourseController::class, 'index'])->name('admin.courses');
    Route::get('/courses/create', [AdminCourseController::class, 'create'])->name('admin.courses.create');
    Route::post('/courses', [AdminCourseController::class, 'store'])->name('admin.courses.store');
    Route::get('/courses/{course}/edit', [AdminCourseController::class, 'edit'])->name('admin.courses.edit');
    Route::put('/courses/{course}', [AdminCourseController::class, 'update'])->name('admin.courses.update');
    Route::delete('/courses/{course}', [AdminCourseController::class, 'destroy'])->name('admin.courses.destroy');

    // Mentorlar
    Route::get('/mentors', [AdminMentorController::class, 'index'])->name('admin.mentors');
    Route::get('/mentors/create', [AdminMentorController::class, 'create'])->name('admin.mentors.create');
    Route::post('/mentors', [AdminMentorController::class, 'store'])->name('admin.mentors.store');
    Route::get('/mentors/{mentor}/edit', [AdminMentorController::class, 'edit'])->name('admin.mentors.edit');
    Route::put('/mentors/{mentor}', [AdminMentorController::class, 'update'])->name('admin.mentors.update');
    Route::delete('/mentors/{mentor}', [AdminMentorController::class, 'destroy'])->name('admin.mentors.destroy');

    // Tadbirlar (Events)
    Route::get('/events', [AdminEventController::class, 'index'])->name('admin.events');
    Route::get('/events/create', [AdminEventController::class, 'create'])->name('admin.events.create');
    Route::post('/events', [AdminEventController::class, 'store'])->name('admin.events.store');
    Route::get('/events/{id}/edit', [AdminEventController::class, 'edit'])->name('admin.events.edit');
    Route::put('/events/{id}', [AdminEventController::class, 'update'])->name('admin.events.update');
    Route::delete('/events/{id}', [AdminEventController::class, 'destroy'])->name('admin.events.destroy');

    // Arizalar (Job Applications)
    Route::get('/applications', [AdminApplicationController::class, 'index'])->name('admin.applications');
    Route::post('/applications/{application}/status', [AdminApplicationController::class, 'updateStatus'])->name('admin.applications.status');

    // GreenCoin boshqaruvi
    Route::get('/greencoin', [AdminGreenCoinController::class, 'index'])->name('admin.greencoin');
    Route::post('/greencoin/users/{user}/adjust', [AdminGreenCoinController::class, 'adjustBalance'])->name('admin.greencoin.adjust');

    // Farm mahsulotlar
    Route::get('/farm', [AdminFarmController::class, 'index'])->name('admin.farm');
    Route::post('/farm/{product}/toggle', [AdminFarmController::class, 'toggleActive'])->name('admin.farm.toggle');
    Route::delete('/farm/{product}', [AdminFarmController::class, 'destroy'])->name('admin.farm.destroy');

    // Statistika
    Route::get('/stats', [AdminStatsController::class, 'index'])->name('admin.stats');

    // Murojaatlar (contact)
    Route::get('/contacts', [AdminContactController::class, 'index'])->name('admin.contacts');
    Route::get('/contacts/{message}', [AdminContactController::class, 'show'])->name('admin.contacts.show');
    Route::post('/contacts/{message}/reply', [AdminContactController::class, 'reply'])->name('admin.contacts.reply');
    Route::delete('/contacts/{message}', [AdminContactController::class, 'destroy'])->name('admin.contacts.destroy');

    // Activity Log
    Route::get('/activity-log', [AdminActivityLogController::class, 'index'])->name('admin.activity-log');

    // Export
    Route::get('/export/users', [AdminExportController::class, 'users'])->name('admin.export.users');
    Route::get('/export/applications', [AdminExportController::class, 'applications'])->name('admin.export.applications');

    // FAQ
    Route::get('/faq', [AdminFaqController::class, 'index'])->name('admin.faq');
    Route::get('/faq/create', [AdminFaqController::class, 'create'])->name('admin.faq.create');
    Route::post('/faq', [AdminFaqController::class, 'store'])->name('admin.faq.store');
    Route::get('/faq/{faq}/edit', [AdminFaqController::class, 'edit'])->name('admin.faq.edit');
    Route::put('/faq/{faq}', [AdminFaqController::class, 'update'])->name('admin.faq.update');
    Route::delete('/faq/{faq}', [AdminFaqController::class, 'destroy'])->name('admin.faq.destroy');

    // Announcements
    Route::get('/announcements', [AdminAnnouncementController::class, 'index'])->name('admin.announcements');
    Route::get('/announcements/create', [AdminAnnouncementController::class, 'create'])->name('admin.announcements.create');
    Route::post('/announcements', [AdminAnnouncementController::class, 'store'])->name('admin.announcements.store');
    Route::get('/announcements/{announcement}/edit', [AdminAnnouncementController::class, 'edit'])->name('admin.announcements.edit');
    Route::put('/announcements/{announcement}', [AdminAnnouncementController::class, 'update'])->name('admin.announcements.update');
    Route::delete('/announcements/{announcement}', [AdminAnnouncementController::class, 'destroy'])->name('admin.announcements.destroy');

    // Success Stories
    Route::get('/stories', [AdminSuccessStoryController::class, 'index'])->name('admin.stories');
    Route::get('/stories/create', [AdminSuccessStoryController::class, 'create'])->name('admin.stories.create');
    Route::post('/stories', [AdminSuccessStoryController::class, 'store'])->name('admin.stories.store');
    Route::delete('/stories/{story}', [AdminSuccessStoryController::class, 'destroy'])->name('admin.stories.destroy');

    // Bannerlar
    Route::get('/banners', [AdminBannerController::class, 'index'])->name('admin.banners');
    Route::get('/banners/create', [AdminBannerController::class, 'create'])->name('admin.banners.create');
    Route::post('/banners', [AdminBannerController::class, 'store'])->name('admin.banners.store');
    Route::get('/banners/{banner}/edit', [AdminBannerController::class, 'edit'])->name('admin.banners.edit');
    Route::put('/banners/{banner}', [AdminBannerController::class, 'update'])->name('admin.banners.update');
    Route::delete('/banners/{banner}', [AdminBannerController::class, 'destroy'])->name('admin.banners.destroy');
    Route::post('/banners/{banner}/toggle', [AdminBannerController::class, 'toggle'])->name('admin.banners.toggle');

    // So'rovnomalar (Polls)
    Route::get('/polls', [AdminPollController::class, 'index'])->name('admin.polls');
    Route::get('/polls/create', [AdminPollController::class, 'create'])->name('admin.polls.create');
    Route::post('/polls', [AdminPollController::class, 'store'])->name('admin.polls.store');
    Route::delete('/polls/{poll}', [AdminPollController::class, 'destroy'])->name('admin.polls.destroy');

    // Moderatsiya
    Route::get('/moderation', [AdminModerationController::class, 'index'])->name('admin.moderation');
    Route::post('/moderation/comment/{comment}/approve', [AdminModerationController::class, 'approveComment'])->name('admin.moderation.approve');
    Route::post('/moderation/comment/{comment}/reject', [AdminModerationController::class, 'rejectComment'])->name('admin.moderation.reject');

    // Telegram Bot boshqaruvi (birlashtirilgan)
    Route::prefix('telegram')->name('admin.telegram.')->group(function () {
        Route::get('/',                                     [\App\Http\Controllers\Admin\AdminTelegramController::class, 'index'])->name('index');
        Route::get('/submissions',                          [\App\Http\Controllers\Admin\AdminTelegramController::class, 'submissions'])->name('submissions');
        Route::post('/submissions/{submission}/approve',    [\App\Http\Controllers\Admin\AdminTelegramController::class, 'approve'])->name('approve');
        Route::post('/submissions/{submission}/reject',     [\App\Http\Controllers\Admin\AdminTelegramController::class, 'reject'])->name('reject');
        Route::get('/tasks',                                [\App\Http\Controllers\Admin\AdminTelegramController::class, 'tasks'])->name('tasks');
        Route::get('/tasks/create',                         [\App\Http\Controllers\Admin\AdminTelegramController::class, 'createTask'])->name('tasks.create');
        Route::post('/tasks',                               [\App\Http\Controllers\Admin\AdminTelegramController::class, 'storeTask'])->name('tasks.store');
        Route::post('/tasks/{task}/toggle',                 [\App\Http\Controllers\Admin\AdminTelegramController::class, 'toggleTask'])->name('tasks.toggle');
        Route::delete('/tasks/{task}',                      [\App\Http\Controllers\Admin\AdminTelegramController::class, 'destroyTask'])->name('tasks.destroy');
        Route::post('/broadcast',                           [\App\Http\Controllers\Admin\AdminTelegramController::class, 'broadcast'])->name('broadcast')->middleware('throttle:5,1');
        Route::post('/set-webhook',                         [\App\Http\Controllers\Admin\AdminTelegramController::class, 'setWebhook'])->name('set-webhook');
    });
});
