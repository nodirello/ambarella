<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

// ==================== SCHEDULED TASKS ====================

// Kundalik backup (har kuni 3:00 da)
Schedule::command('app:backup')->dailyAt('03:00');

// Telegram kundalik push (har kuni 8:00 da Toshkent vaqti)
Schedule::command('telegram:daily-push')->dailyAt('08:00')->timezone('Asia/Tashkent');

// Telegram haftalik hisobot (har dushanba 9:00 da)
Schedule::command('telegram:weekly-report')->weeklyOn(1, '09:00')->timezone('Asia/Tashkent');

// Haftalik digest email (har dushanba 9:00 da)
Schedule::command('app:weekly-digest')->weeklyOn(1, '09:00');

// Haftalik cache tozalash
Schedule::command('cache:clear')->weekly();

// Expired sessions tozalash
Schedule::command('session:gc')->daily();
