
<?php $__env->startSection('title', '429 — Juda ko\'p so\'rov | AMBARELLA'); ?>
<?php $__env->startSection('styles'); ?>
<style>
.error-page{min-height:60vh;display:flex;align-items:center;justify-content:center;text-align:center;padding:60px 24px}
.error-icon{width:120px;height:120px;margin:0 auto 24px}
.error-icon svg{width:100%;height:100%;stroke:#f59e0b;fill:none;stroke-width:1}
.error-code{font-size:72px;font-weight:900;color:#f59e0b;margin-bottom:8px}
.error-msg{font-size:18px;color:#fff;font-weight:700;margin-bottom:8px}
.error-desc{font-size:14px;color:var(--muted);margin-bottom:32px;max-width:400px;margin-left:auto;margin-right:auto}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="error-page">
  <div>
    <div class="error-icon">
      <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
    </div>
    <div class="error-code">429</div>
    <p class="error-msg">Juda ko'p so'rov</p>
    <p class="error-desc">Siz juda ko'p so'rov yubordingiz. Iltimos, 1 daqiqa kutib qayta urinib ko'ring.</p>
    <div style="display:flex;gap:12px;justify-content:center">
      <a href="javascript:history.back()" class="btn btn-primary">Orqaga</a>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/6a4e91db8a003/data/www/ambarella.uz/resources/views/errors/429.blade.php ENDPATH**/ ?>