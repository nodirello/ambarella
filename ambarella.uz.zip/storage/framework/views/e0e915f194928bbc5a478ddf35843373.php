

<?php $__env->startSection('title', 'Pomodoro Timer — AMBARELLA'); ?>
<?php $__env->startSection('description', 'Pomodoro texnikasi bilan vaqtingizni samarali boshqaring'); ?>

<?php $__env->startSection('content'); ?>
<section style="min-height:80vh;display:flex;align-items:center;justify-content:center;padding:40px 24px">
  <div style="text-align:center;max-width:500px;width:100%">
    <!-- Header -->
    <h1 style="font-size:28px;font-weight:800;margin-bottom:8px;background:linear-gradient(135deg,#2563eb,#7c3aed);-webkit-background-clip:text;-webkit-text-fill-color:transparent">🍅 Pomodoro Timer</h1>
    <p style="color:#64748b;font-size:14px;margin-bottom:32px">Diqqatni jamlang, samarali ishlang</p>

    <!-- Mode Tabs -->
    <div id="modeTabs" style="display:flex;gap:8px;justify-content:center;margin-bottom:32px">
      <button onclick="setMode('work')" class="pomo-tab active" data-mode="work">Ish (25 min)</button>
      <button onclick="setMode('break')" class="pomo-tab" data-mode="break">Dam (5 min)</button>
      <button onclick="setMode('longbreak')" class="pomo-tab" data-mode="longbreak">Uzun dam (15 min)</button>
    </div>

    <!-- Timer Circle -->
    <div style="position:relative;width:280px;height:280px;margin:0 auto 32px">
      <svg width="280" height="280" viewBox="0 0 280 280" id="timerSvg">
        <!-- Background circle -->
        <circle cx="140" cy="140" r="125" fill="none" stroke="rgba(255,255,255,.05)" stroke-width="12"/>
        <!-- Progress circle -->
        <circle id="progressCircle" cx="140" cy="140" r="125" fill="none" stroke="url(#progressGradient)" stroke-width="12" stroke-linecap="round" stroke-dasharray="785.4" stroke-dashoffset="0" transform="rotate(-90 140 140)" style="transition:stroke-dashoffset .5s ease"/>
        <!-- Gradient -->
        <defs>
          <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style="stop-color:#2563eb"/>
            <stop offset="100%" style="stop-color:#7c3aed"/>
          </linearGradient>
        </defs>
      </svg>
      <!-- Time Display -->
      <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center">
        <span id="timerDisplay" style="font-size:56px;font-weight:800;font-variant-numeric:tabular-nums;letter-spacing:-2px">25:00</span>
        <span id="modeLabel" style="font-size:13px;color:#64748b;margin-top:4px">Ish vaqti</span>
      </div>
    </div>

    <!-- Controls -->
    <div style="display:flex;gap:12px;justify-content:center;margin-bottom:24px">
      <button onclick="startTimer()" id="startBtn" class="pomo-btn pomo-btn-primary">
        <svg width="18" height="18" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
        Boshlash
      </button>
      <button onclick="pauseTimer()" id="pauseBtn" class="pomo-btn pomo-btn-warning" style="display:none">
        <svg width="18" height="18" fill="currentColor" viewBox="0 0 24 24"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>
        Pauza
      </button>
      <button onclick="resetTimer()" class="pomo-btn pomo-btn-outline">
        <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M1 4v6h6M23 20v-6h-6"/><path d="M20.49 9A9 9 0 0 0 5.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 0 1 3.51 15"/></svg>
        Qayta
      </button>
    </div>

    <!-- Session Counter -->
    <div style="display:flex;align-items:center;justify-content:center;gap:8px;padding:12px 20px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);border-radius:12px;display:inline-flex">
      <svg width="16" height="16" fill="none" stroke="#16a34a" stroke-width="2" viewBox="0 0 24 24"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
      <span style="font-size:14px;color:#94a3b8">Sessiya: <strong id="sessionCount" style="color:#e2e8f0">0</strong> / <strong>4</strong></span>
    </div>

    <!-- Daily Stats -->
    <div style="margin-top:20px;display:flex;gap:16px;justify-content:center;flex-wrap:wrap">
      <div style="padding:10px 16px;background:rgba(37,99,235,.08);border:1px solid rgba(37,99,235,.2);border-radius:10px">
        <span style="font-size:12px;color:#64748b;display:block">Bugun</span>
        <strong id="todaySessions" style="color:#2563eb;font-size:18px">0</strong> <span style="font-size:11px;color:#64748b">sessiya</span>
      </div>
      <div style="padding:10px 16px;background:rgba(22,163,74,.08);border:1px solid rgba(22,163,74,.2);border-radius:10px">
        <span style="font-size:12px;color:#64748b;display:block">Jami vaqt</span>
        <strong id="totalMinutes" style="color:#16a34a;font-size:18px">0</strong> <span style="font-size:11px;color:#64748b">daqiqa</span>
      </div>
    </div>
  </div>
</section>

<style>
.pomo-tab{padding:8px 16px;border-radius:10px;font-size:13px;font-weight:600;color:#64748b;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);transition:all .3s}
.pomo-tab:hover{color:#e2e8f0;border-color:rgba(255,255,255,.15)}
.pomo-tab.active{background:rgba(37,99,235,.15);color:#60a5fa;border-color:rgba(37,99,235,.3)}
.pomo-btn{display:inline-flex;align-items:center;gap:8px;padding:12px 24px;border-radius:12px;font-weight:600;font-size:14px;transition:all .3s;border:none;cursor:pointer}
.pomo-btn-primary{background:#2563eb;color:#fff;box-shadow:0 4px 14px rgba(37,99,235,.3)}
.pomo-btn-primary:hover{background:#1d4ed8;transform:translateY(-2px);box-shadow:0 8px 25px rgba(37,99,235,.4)}
.pomo-btn-warning{background:#f59e0b;color:#fff;box-shadow:0 4px 14px rgba(245,158,11,.3)}
.pomo-btn-warning:hover{background:#d97706;transform:translateY(-2px)}
.pomo-btn-outline{background:rgba(255,255,255,.03);color:#94a3b8;border:1px solid rgba(255,255,255,.1)}
.pomo-btn-outline:hover{color:#e2e8f0;border-color:rgba(255,255,255,.2);transform:translateY(-1px)}
@media(max-width:480px){
  #timerDisplay{font-size:42px!important}
  .pomo-btn{padding:10px 18px;font-size:13px}
}
</style>

<script>
(function(){
  // Timer state
  let mode = 'work';
  let totalSeconds = 25 * 60;
  let remainingSeconds = totalSeconds;
  let isRunning = false;
  let interval = null;
  let sessionCount = 0;
  let todaySessions = parseInt(localStorage.getItem('pomo_today_sessions') || '0');
  let totalMinutes = parseInt(localStorage.getItem('pomo_total_minutes') || '0');
  const CIRCLE_LENGTH = 785.4;

  // Check if today's date matches stored date
  const today = new Date().toDateString();
  if(localStorage.getItem('pomo_date') !== today){
    localStorage.setItem('pomo_date', today);
    localStorage.setItem('pomo_today_sessions', '0');
    todaySessions = 0;
  }

  // DOM elements
  const display = document.getElementById('timerDisplay');
  const progressCircle = document.getElementById('progressCircle');
  const modeLabel = document.getElementById('modeLabel');
  const startBtn = document.getElementById('startBtn');
  const pauseBtn = document.getElementById('pauseBtn');
  const sessionCountEl = document.getElementById('sessionCount');
  const todaySessionsEl = document.getElementById('todaySessions');
  const totalMinutesEl = document.getElementById('totalMinutes');

  // Initialize display
  todaySessionsEl.textContent = todaySessions;
  totalMinutesEl.textContent = totalMinutes;

  const modes = {
    work: { seconds: 25 * 60, label: 'Ish vaqti' },
    break: { seconds: 5 * 60, label: 'Dam olish' },
    longbreak: { seconds: 15 * 60, label: 'Uzun dam' }
  };

  function updateDisplay(){
    const m = Math.floor(remainingSeconds / 60);
    const s = remainingSeconds % 60;
    display.textContent = `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
    // Update progress
    const progress = 1 - (remainingSeconds / totalSeconds);
    progressCircle.style.strokeDashoffset = CIRCLE_LENGTH * (1 - progress);
  }

  window.setMode = function(m){
    mode = m;
    totalSeconds = modes[m].seconds;
    remainingSeconds = totalSeconds;
    isRunning = false;
    clearInterval(interval);
    modeLabel.textContent = modes[m].label;
    startBtn.style.display = 'inline-flex';
    pauseBtn.style.display = 'none';
    // Update tabs
    document.querySelectorAll('.pomo-tab').forEach(t => t.classList.remove('active'));
    document.querySelector(`.pomo-tab[data-mode="${m}"]`).classList.add('active');
    updateDisplay();
  };

  window.startTimer = function(){
    if(isRunning) return;
    isRunning = true;
    startBtn.style.display = 'none';
    pauseBtn.style.display = 'inline-flex';
    interval = setInterval(function(){
      remainingSeconds--;
      updateDisplay();
      if(remainingSeconds <= 0){
        clearInterval(interval);
        isRunning = false;
        onTimerEnd();
      }
    }, 1000);
  };

  window.pauseTimer = function(){
    isRunning = false;
    clearInterval(interval);
    startBtn.style.display = 'inline-flex';
    pauseBtn.style.display = 'none';
  };

  window.resetTimer = function(){
    isRunning = false;
    clearInterval(interval);
    remainingSeconds = totalSeconds;
    startBtn.style.display = 'inline-flex';
    pauseBtn.style.display = 'none';
    updateDisplay();
  };

  function onTimerEnd(){
    playSound();
    if(mode === 'work'){
      sessionCount++;
      todaySessions++;
      totalMinutes += 25;
      localStorage.setItem('pomo_today_sessions', todaySessions);
      localStorage.setItem('pomo_total_minutes', totalMinutes);
      sessionCountEl.textContent = sessionCount;
      todaySessionsEl.textContent = todaySessions;
      totalMinutesEl.textContent = totalMinutes;
      // Auto switch to break
      if(sessionCount % 4 === 0){
        setMode('longbreak');
      } else {
        setMode('break');
      }
    } else {
      setMode('work');
    }
    // Show notification if supported
    if('Notification' in window && Notification.permission === 'granted'){
      new Notification('⏰ Pomodoro', { body: mode === 'work' ? 'Dam olish vaqti!' : 'Ishga qaytish vaqti!', icon: '/assets/icons/icon-192.png' });
    }
  }

  function playSound(){
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.frequency.value = 800;
      osc.type = 'sine';
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.8);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.8);
      // Second beep
      setTimeout(() => {
        const osc2 = ctx.createOscillator();
        const gain2 = ctx.createGain();
        osc2.connect(gain2);
        gain2.connect(ctx.destination);
        osc2.frequency.value = 1000;
        osc2.type = 'sine';
        gain2.gain.setValueAtTime(0.3, ctx.currentTime);
        gain2.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.6);
        osc2.start(ctx.currentTime);
        osc2.stop(ctx.currentTime + 0.6);
      }, 300);
    } catch(e){}
  }

  // Request notification permission
  if('Notification' in window && Notification.permission === 'default'){
    Notification.requestPermission();
  }

  updateDisplay();
})();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/6a4e91db8a003/data/www/ambarella.uz/resources/views/pomodoro/index.blade.php ENDPATH**/ ?>