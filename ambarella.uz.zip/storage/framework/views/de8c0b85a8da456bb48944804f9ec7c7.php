
<?php $__env->startSection('title', 'Qishloq mahsulotlari | AMBARELLA'); ?>
<?php $__env->startSection('styles'); ?>
<style>
.page-hero{padding:48px 0}
.page-hero h1{font-size:clamp(28px,4vw,36px);font-weight:800;color:#fff;margin-bottom:8px}
.page-hero p{color:var(--muted);font-size:15px;max-width:500px}
.filters{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:24px;align-items:center}
.filters select,.filters input{padding:10px 14px;border-radius:var(--radius);border:1px solid var(--border);background:var(--surface);color:#fff;font-size:13px}
.products-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(270px,1fr));gap:16px}
.product-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:22px;transition:all .2s}
.product-card:hover{border-color:rgba(22,163,74,.3);transform:translateY(-2px)}
.product-category{font-size:11px;font-weight:600;color:var(--success);text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px}
.product-card h3{font-size:16px;font-weight:700;color:#fff;margin-bottom:6px}
.product-card p{font-size:13px;color:var(--muted);margin-bottom:12px}
.product-price{font-size:18px;font-weight:800;color:#4ade80;margin-bottom:4px}
.product-meta{display:flex;justify-content:space-between;align-items:center;font-size:12px;color:var(--muted);margin-top:12px;padding-top:12px;border-top:1px solid var(--border)}
.hero-actions{display:flex;gap:10px;margin-top:16px}
.empty-state{text-align:center;padding:48px;color:var(--muted);font-size:14px;grid-column:1/-1}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="page-hero"><div class="container">
  <h1>Qishloq mahsulotlari</h1>
  <p>Fermerlardan to'g'ridan-to'g'ri yangi mahsulotlar sotib oling</p>
  <div class="hero-actions">
    <?php if(auth()->guard()->check()): ?>
      <a href="/farm/create" class="btn btn-success">+ Mahsulot qo'shish</a>
      <a href="/farm/my-products" class="btn btn-outline">Mening mahsulotlarim</a>
    <?php else: ?>
      <a href="/login" class="btn btn-primary">Kirish</a>
    <?php endif; ?>
  </div>
</div></section>
<div class="container">
  <form class="filters" method="GET" action="/farm">
    <input type="text" name="search" placeholder="Qidirish..." value="<?php echo e(request('search')); ?>">
    <select name="category" onchange="this.form.submit()">
      <option value="">Barcha kategoriyalar</option>
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($cat); ?>" <?php echo e(request('category') == $cat ? 'selected' : ''); ?>><?php echo e($cat); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <select name="region" onchange="this.form.submit()">
      <option value="">Barcha hududlar</option>
      <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($reg); ?>" <?php echo e(request('region') == $reg ? 'selected' : ''); ?>><?php echo e($reg); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <button type="submit" class="btn btn-outline" style="padding:10px 16px;font-size:13px">Filtr</button>
  </form>

  <div class="products-grid">
    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <a href="/farm/<?php echo e($product->id); ?>" class="product-card">
      <span class="product-category"><?php echo e($product->category); ?></span>
      <h3><?php echo e($product->name); ?></h3>
      <p><?php echo e(Str::limit($product->description, 80)); ?></p>
      <div class="product-price"><?php echo e(number_format($product->price)); ?> so'm/<?php echo e($product->unit); ?></div>
      <div class="product-meta">
        <span>📍 <?php echo e($product->region); ?></span>
        <span><?php echo e($product->user->name ?? 'Fermer'); ?></span>
      </div>
    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="empty-state">Hozircha mahsulotlar yo'q.</div>
    <?php endif; ?>
  </div>

  <div style="margin-top:24px"><?php echo e($products->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/6a4e91db8a003/data/www/ambarella.uz/resources/views/farm/index.blade.php ENDPATH**/ ?>