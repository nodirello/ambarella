
<?php $__env->startSection('title', 'Aloqa — AMBARELLA'); ?>
<?php $__env->startSection('description', 'Biz bilan bog\'laning — telefon, email, Telegram va boshqalar.'); ?>

<?php $__env->startSection('styles'); ?>
<style>
.contact-hero{padding:64px 0 48px;text-align:center}
.contact-hero h1{font-size:clamp(28px,5vw,42px);font-weight:800;color:#fff;margin-bottom:12px}
.contact-hero p{color:var(--muted);font-size:16px;max-width:560px;margin:0 auto;line-height:1.8}
.contact-badge{display:inline-flex;align-items:center;gap:6px;padding:6px 14px;border-radius:20px;font-size:12px;font-weight:600;background:rgba(22,163,74,.1);color:#4ade80;margin-bottom:20px}
.contact-grid{display:grid;grid-template-columns:1fr 1.4fr;gap:28px;margin:48px 0}
.contact-info{display:flex;flex-direction:column;gap:16px}
.contact-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:22px;display:flex;align-items:center;gap:16px;transition:all .2s}
.contact-card:hover{border-color:rgba(37,99,235,.2);transform:translateY(-1px)}
.contact-card .icon{width:44px;height:44px;border-radius:11px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.contact-card:nth-child(1) .icon{background:rgba(37,99,235,.12)}
.contact-card:nth-child(2) .icon{background:rgba(22,163,74,.12)}
.contact-card:nth-child(3) .icon{background:rgba(56,189,248,.12)}
.contact-card .info h4{font-size:13px;color:var(--muted);font-weight:500;margin-bottom:4px}
.contact-card .info a,.contact-card .info span{font-size:15px;font-weight:600;color:#fff}
.contact-card .info a:hover{color:var(--primary)}
.contact-form-wrap{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:28px}
.contact-form-wrap h3{font-size:18px;font-weight:700;color:#fff;margin-bottom:6px}
.contact-form-wrap>p{font-size:13px;color:var(--muted);margin-bottom:20px}
.contact-form{display:flex;flex-direction:column;gap:14px}
.form-group{display:flex;flex-direction:column;gap:6px}
.form-group label{font-size:13px;font-weight:600;color:#94a3b8}
.form-group input,.form-group textarea{border:1px solid var(--border);background:var(--surface);color:#fff;border-radius:var(--radius);padding:12px 16px;font-size:14px;font-family:inherit;transition:border-color .2s;resize:vertical}
.form-group input:focus,.form-group textarea:focus{outline:none;border-color:var(--primary)}
.form-group textarea{min-height:110px}
.form-group .optional{font-size:11px;color:var(--muted);font-weight:400;margin-left:4px}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.alert-success{background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.2);border-radius:var(--radius);padding:12px 16px;font-size:13px;color:#86efac;margin-bottom:20px}
.alert-danger{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.2);border-radius:var(--radius);padding:12px 16px;font-size:13px;color:#fca5a5;margin-bottom:20px}
.contact-social{text-align:center;margin:48px 0}
.contact-social h3{font-size:18px;font-weight:700;color:#fff;margin-bottom:16px}
.contact-social-links{display:flex;justify-content:center;gap:12px;flex-wrap:wrap}
.contact-social-links a{display:flex;align-items:center;gap:8px;padding:10px 18px;background:var(--surface);border:1px solid var(--border);border-radius:10px;font-size:13px;font-weight:500;color:#94a3b8;transition:all .2s}
.contact-social-links a:hover{border-color:var(--primary);color:#fff}
@media(max-width:768px){.contact-grid{grid-template-columns:1fr}.form-row{grid-template-columns:1fr}}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="contact-hero">
  <div class="container">
    <div class="contact-badge">
      <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M2 4l5 4 5-4"/><rect x="1" y="3" width="12" height="9" rx="1"/></svg>
      Aloqa
    </div>
    <h1>Biz bilan bog'laning</h1>
    <p>Savollar, takliflar yoki hamkorlik uchun — biz doim aloqadamiz.</p>
  </div>
</section>

<section class="container">
  <?php if(session('success')): ?>
  <div class="alert-success"><?php echo e(session('success')); ?></div>
  <?php endif; ?>

  <?php if($errors->any()): ?>
  <div class="alert-danger">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div><?php echo e($error); ?></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <?php endif; ?>

  <div class="contact-grid">
    <div class="contact-info">
      <div class="contact-card">
        <div class="icon">
          <svg width="20" height="20" fill="none" stroke="#60a5fa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91"/></svg>
        </div>
        <div class="info">
          <h4>Telefon</h4>
          <a href="tel:+998900741070">+998 90 074 10 70</a>
        </div>
      </div>
      <div class="contact-card">
        <div class="icon">
          <svg width="20" height="20" fill="none" stroke="#4ade80" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22 6 12 13 2 6"/></svg>
        </div>
        <div class="info">
          <h4>Email</h4>
          <a href="mailto:info@ambarella.uz">info@ambarella.uz</a>
        </div>
      </div>
      <div class="contact-card">
        <div class="icon">
          <svg width="20" height="20" fill="none" stroke="#38bdf8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>
        </div>
        <div class="info">
          <h4>Telegram</h4>
          <a href="https://t.me/AmbarellaBot" target="_blank">@AmbarellaBot</a>
        </div>
      </div>
    </div>

    <div class="contact-form-wrap">
      <h3>Xabar yuborish</h3>
      <p>Formani to'ldiring, biz tez orada javob beramiz.</p>
      <form class="contact-form" action="/contact" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-row">
          <div class="form-group">
            <label for="name">Ismingiz</label>
            <input type="text" id="name" name="name" placeholder="To'liq ismingiz" value="<?php echo e(old('name')); ?>" required>
          </div>
          <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" placeholder="sizning@email.com" value="<?php echo e(old('email')); ?>" required>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label for="phone">Telefon <span class="optional">(ixtiyoriy)</span></label>
            <input type="tel" id="phone" name="phone" placeholder="+998 XX XXX XX XX" value="<?php echo e(old('phone')); ?>">
          </div>
          <div class="form-group">
            <label for="subject">Mavzu</label>
            <input type="text" id="subject" name="subject" placeholder="Xabar mavzusi" value="<?php echo e(old('subject')); ?>" required>
          </div>
        </div>
        <div class="form-group">
          <label for="message">Xabar</label>
          <textarea id="message" name="message" placeholder="Xabaringizni yozing..." required><?php echo e(old('message')); ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary" style="align-self:flex-start">
          <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:4px"><path d="M14 1l-5 14-3-6-6-3z"/></svg>
          Yuborish
        </button>
      </form>
    </div>
  </div>
</section>

<section class="container">
  <div class="contact-social">
    <h3>Ijtimoiy tarmoqlar</h3>
    <div class="contact-social-links">
      <a href="https://t.me/AmbarellaBot" target="_blank">
        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 2l-13 8 5 2 2 6 3-4 4 3 4-15z"/></svg>
        Telegram
      </a>
      <a href="#">
        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="2" y="2" width="12" height="12" rx="3"/><circle cx="8" cy="8" r="3"/><circle cx="11.5" cy="4.5" r=".5"/></svg>
        Instagram
      </a>
      <a href="#">
        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M16 4a4 4 0 0 0-4-4H4a4 4 0 0 0-4 4v8a4 4 0 0 0 4 4h8a4 4 0 0 0 4-4z"/><polygon points="6 10 6 4 11 7"/></svg>
        YouTube
      </a>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/6a4e91db8a003/data/www/ambarella.uz/resources/views/pages/contact.blade.php ENDPATH**/ ?>