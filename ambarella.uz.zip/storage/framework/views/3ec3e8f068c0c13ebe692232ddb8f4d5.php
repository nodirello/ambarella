
<?php $__env->startSection('title', 'Yangi savol — Forum | AMBARELLA'); ?>

<?php $__env->startSection('styles'); ?>
<style>
.create-hero{padding:48px 0 32px;text-align:center}
.create-hero h1{font-size:28px;font-weight:800;color:#fff;margin-bottom:8px}
.create-hero p{color:var(--muted);font-size:14px}
.create-form{max-width:700px;margin:0 auto;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:32px}
.form-group{margin-bottom:20px}
.form-group label{display:block;font-size:13px;font-weight:600;color:#cbd5e1;margin-bottom:8px}
.form-group input,.form-group select,.form-group textarea{width:100%;padding:12px 16px;border-radius:12px;border:1px solid var(--border);background:rgba(255,255,255,.02);color:#fff;font-size:14px;font-family:inherit;transition:border-color .2s}
.form-group input:focus,.form-group select:focus,.form-group textarea:focus{outline:none;border-color:var(--primary)}
.form-group select{appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%2394a3b8' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 14px center}
.form-group select option{background:#1e293b;color:#fff}
.form-group textarea{min-height:180px;resize:vertical;line-height:1.6}
.form-actions{display:flex;gap:12px;justify-content:flex-end}
.form-hint{font-size:11px;color:var(--muted);margin-top:6px}
.back-link{display:inline-flex;align-items:center;gap:6px;color:var(--muted);font-size:13px;margin-bottom:24px;transition:color .2s}
.back-link:hover{color:#93c5fd}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="create-hero">
    <h1>❓ Yangi savol berish</h1>
    <p>Savolingizni aniq yozing va to'g'ri kategoriyani tanlang</p>
  </div>

  <div class="create-form">
    <a href="<?php echo e(route('forum')); ?>" class="back-link">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
      Forumga qaytish
    </a>

    <form action="<?php echo e(route('forum.store')); ?>" method="POST">
      <?php echo csrf_field(); ?>

      <div class="form-group">
        <label for="title">Savol sarlavhasi *</label>
        <input type="text" id="title" name="title" value="<?php echo e(old('title')); ?>" placeholder="Masalan: Laravel'da middleware qanday ishlaydi?" required>
        <div class="form-hint">Qisqa va tushunarli sarlavha yozing</div>
      </div>

      <div class="form-group">
        <label for="category">Kategoriya *</label>
        <select id="category" name="category" required>
          <option value="" disabled <?php echo e(!old('category') ? 'selected' : ''); ?>>Kategoriyani tanlang</option>
          <option value="Dasturlash" <?php echo e(old('category') == 'Dasturlash' ? 'selected' : ''); ?>>💻 Dasturlash</option>
          <option value="Dizayn" <?php echo e(old('category') == 'Dizayn' ? 'selected' : ''); ?>>🎨 Dizayn</option>
          <option value="Biznes" <?php echo e(old('category') == 'Biznes' ? 'selected' : ''); ?>>📈 Biznes</option>
          <option value="Boshqa" <?php echo e(old('category') == 'Boshqa' ? 'selected' : ''); ?>>📌 Boshqa</option>
        </select>
      </div>

      <div class="form-group">
        <label for="body">Savol matni *</label>
        <textarea id="body" name="body" placeholder="Savolingizni batafsil yozing. Kod bo'lsa ham kiritishingiz mumkin..." required><?php echo e(old('body')); ?></textarea>
        <div class="form-hint">Kamida 10 ta belgi bo'lishi kerak</div>
      </div>

      <div class="form-actions">
        <a href="<?php echo e(route('forum')); ?>" class="btn btn-outline">Bekor qilish</a>
        <button type="submit" class="btn btn-primary">Savolni yuborish</button>
      </div>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/6a4e91db8a003/data/www/ambarella.uz/resources/views/forum/create.blade.php ENDPATH**/ ?>