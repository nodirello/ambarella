
<?php $__env->startSection('title', 'Ro\'yxatdan o\'tish | AMBARELLA'); ?>
<?php $__env->startSection('styles'); ?>
<style>
.auth-page{min-height:calc(100vh - 140px);display:flex;align-items:center;justify-content:center;padding:48px 24px}
.auth-card{width:100%;max-width:440px}
.auth-card h1{font-size:28px;font-weight:800;margin-bottom:8px}
.auth-card>p{color:var(--muted);margin-bottom:32px}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.form-group{margin-bottom:16px}.form-group label{display:block;font-size:14px;font-weight:500;margin-bottom:6px}
.form-group input{width:100%;padding:14px 16px;border:1.5px solid var(--border);border-radius:10px;font-size:15px;font-family:inherit}
.form-group input:focus{outline:none;border-color:var(--primary);box-shadow:0 0 0 3px rgba(37,99,235,.1)}
.auth-footer{margin-top:20px;text-align:center;font-size:14px;color:var(--muted)}.auth-footer a{color:var(--primary);font-weight:600}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="auth-page">
  <form class="auth-card" method="POST" action="/register">
    <?php echo csrf_field(); ?>
    <?php if(request('ref')): ?><input type="hidden" name="ref" value="<?php echo e(request('ref')); ?>"><?php endif; ?>
    <h1>Ro'yxatdan o'tish</h1>
    <p>Hisob yarating va platformadan foydalaning</p>
    <div class="form-group"><label>Ism</label><input type="text" name="name" required placeholder="To'liq ismingiz" value="<?php echo e(old('name')); ?>"></div>
    <div class="form-group"><label>Email</label><input type="email" name="email" required placeholder="email@misol.uz" value="<?php echo e(old('email')); ?>"></div>
    <div class="form-group"><label>Telefon (ixtiyoriy)</label><input type="tel" name="phone" placeholder="+998 90 000 00 00" value="<?php echo e(old('phone')); ?>"></div>
    <div class="form-group"><label>Parol</label><input type="password" name="password" required placeholder="Kamida 8 belgi" minlength="8"></div>
    <div class="form-group"><label>Parolni tasdiqlang</label><input type="password" name="password_confirmation" required placeholder="Parolni takrorlang" minlength="8"></div>
    <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:14px">Ro'yxatdan o'tish</button>
    <p class="auth-footer">Hisobingiz bormi? <a href="/login">Tizimga kiring</a></p>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/6a4e91db8a003/data/www/ambarella.uz/resources/views/auth/register.blade.php ENDPATH**/ ?>