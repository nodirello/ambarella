
<?php $__env->startSection('title', 'Odatlar | AMBARELLA'); ?>
<?php $__env->startSection('styles'); ?>
<style>
.page-hero{padding:48px 0}
.page-hero h1{font-size:clamp(24px,4vw,32px);font-weight:800;color:#fff;margin-bottom:8px}
.page-hero p{color:var(--muted);font-size:14px}
.add-form{display:flex;gap:10px;margin-bottom:24px}
.add-form input{flex:1;padding:12px 16px;border-radius:var(--radius);border:1px solid var(--border);background:var(--surface);color:#fff;font-size:14px}
.habits-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:14px}
.habit-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:22px;transition:all .2s}
.habit-card:hover{border-color:rgba(124,58,237,.3);transform:translateY(-1px)}
.habit-card h3{font-size:15px;font-weight:600;color:#fff;margin-bottom:8px}
.habit-streak{display:inline-flex;align-items:center;gap:4px;font-size:13px;font-weight:600;color:#fbbf24;margin-bottom:12px}
.habit-streak svg{width:14px;height:14px}
.habit-status{font-size:12px;color:var(--muted);margin-bottom:14px}
.habit-actions{display:flex;gap:8px}
.empty-state{text-align:center;padding:48px;color:var(--muted);font-size:14px}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="page-hero"><div class="container">
  <h1>Odatlar</h1>
  <p>Yaxshi odatlar shakllantiring va streakni ushlab turing</p>
</div></section>
<div class="container">
  <form action="/habits" method="POST" class="add-form">
    <?php echo csrf_field(); ?>
    <input type="text" name="name" placeholder="Yangi odat (masalan: Ertalab yugurish)..." required maxlength="255">
    <button type="submit" class="btn btn-primary">Qo'shish</button>
  </form>

  <div class="habits-grid">
    <?php $__empty_1 = true; $__currentLoopData = $habits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $habit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="habit-card">
      <h3><?php echo e($habit->name); ?></h3>
      <div class="habit-streak">
        <svg viewBox="0 0 24 24" fill="#fbbf24"><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
        <?php echo e($habit->streak); ?> kunlik streak
      </div>
      <p class="habit-status">
        <?php if($habit->last_completed && $habit->last_completed->isToday()): ?>
          ✅ Bugun bajarilgan
        <?php else: ?>
          ⏳ Bugun hali bajarilmagan
        <?php endif; ?>
      </p>
      <div class="habit-actions">
        <?php if(!$habit->last_completed || !$habit->last_completed->isToday()): ?>
        <form action="/habits/<?php echo e($habit->id); ?>/complete" method="POST"><?php echo csrf_field(); ?>
          <button type="submit" class="btn btn-success" style="padding:8px 16px;font-size:12px">Bajarish</button>
        </form>
        <?php endif; ?>
        <form action="/habits/<?php echo e($habit->id); ?>" method="POST"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
          <button type="submit" class="btn btn-outline" style="padding:8px 16px;font-size:12px;color:var(--danger)">O'chirish</button>
        </form>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="empty-state" style="grid-column:1/-1">Hali odatlar yo'q. Birinchi odatingizni qo'shing!</div>
    <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/6a4e91db8a003/data/www/ambarella.uz/resources/views/habits/index.blade.php ENDPATH**/ ?>