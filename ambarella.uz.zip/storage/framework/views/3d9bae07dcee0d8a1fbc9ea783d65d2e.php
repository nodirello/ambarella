
<?php $__env->startSection('title', 'Psixologiya — AMBARELLA'); ?>
<?php $__env->startSection('description', 'Yoshlar uchun ruhiy salomatlik, stress boshqarish, motivatsiya va anonim yordam.'); ?>

<?php $__env->startSection('styles'); ?>
<style>
.psy-hero{padding:64px 0 48px;text-align:center}
.psy-hero h1{font-size:clamp(28px,5vw,42px);font-weight:800;color:#fff;margin-bottom:12px}
.psy-hero p{color:var(--muted);font-size:16px;max-width:620px;margin:0 auto;line-height:1.8}
.psy-badge{display:inline-flex;align-items:center;gap:6px;padding:6px 14px;border-radius:20px;font-size:12px;font-weight:600;background:rgba(236,72,153,.1);color:#f472b6;margin-bottom:20px}
.psy-resources{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:20px;margin:48px 0}
.psy-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:28px;transition:all .2s}
.psy-card:hover{border-color:rgba(236,72,153,.2);transform:translateY(-2px)}
.psy-card .icon{width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center;margin-bottom:16px}
.psy-card:nth-child(1) .icon{background:rgba(236,72,153,.12)}
.psy-card:nth-child(2) .icon{background:rgba(37,99,235,.12)}
.psy-card:nth-child(3) .icon{background:rgba(245,158,11,.12)}
.psy-card h3{font-size:16px;font-weight:700;color:#fff;margin-bottom:8px}
.psy-card p{font-size:14px;color:var(--muted);line-height:1.7}
.psy-card ul{margin-top:12px;display:flex;flex-direction:column;gap:8px}
.psy-card ul li{display:flex;align-items:center;gap:8px;font-size:13px;color:#94a3b8}
.psy-card ul li svg{flex-shrink:0}
.psy-anon{margin:64px 0;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:48px;display:flex;align-items:center;gap:32px;flex-wrap:wrap}
.psy-anon-icon{width:80px;height:80px;border-radius:20px;background:rgba(124,58,237,.1);display:flex;align-items:center;justify-content:center;flex-shrink:0}
.psy-anon-content{flex:1;min-width:250px}
.psy-anon-content h2{font-size:22px;font-weight:700;color:#fff;margin-bottom:8px}
.psy-anon-content p{font-size:14px;color:var(--muted);line-height:1.7;margin-bottom:16px}
.psy-anon-features{display:flex;flex-wrap:wrap;gap:10px}
.psy-anon-features span{display:inline-flex;align-items:center;gap:6px;padding:6px 12px;border-radius:8px;font-size:12px;font-weight:500;background:rgba(255,255,255,.04);color:#94a3b8;border:1px solid var(--border)}
.psy-tips{margin:48px 0}
.psy-tips h2{font-size:24px;font-weight:700;color:#fff;margin-bottom:24px;text-align:center}
.psy-tips-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px}
.psy-tip{padding:20px;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);display:flex;gap:12px;align-items:flex-start}
.psy-tip .num{width:28px;height:28px;border-radius:50%;background:rgba(236,72,153,.1);color:#f472b6;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;flex-shrink:0}
.psy-tip p{font-size:13px;color:#94a3b8;line-height:1.6}
.psy-cta{text-align:center;padding:64px 24px;margin:48px 0;background:linear-gradient(135deg,rgba(124,58,237,.05),rgba(236,72,153,.05));border:1px solid var(--border);border-radius:var(--radius)}
.psy-cta h2{font-size:clamp(20px,4vw,28px);font-weight:800;color:#fff;margin-bottom:12px}
.psy-cta p{color:var(--muted);font-size:15px;margin-bottom:24px;max-width:480px;margin-left:auto;margin-right:auto}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="psy-hero">
  <div class="container">
    <div class="psy-badge">
      <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M7 13C10.3 13 13 10.3 13 7S10.3 1 7 1 1 3.7 1 7s2.7 6 6 6z"/><path d="M5 9s.7 1 2 1 2-1 2-1"/><line x1="5" y1="5.5" x2="5" y2="5.5"/><line x1="9" y1="5.5" x2="9" y2="5.5"/></svg>
      Ruhiy salomatlik
    </div>
    <h1>Ruhiy salomatligingiz muhim</h1>
    <p>Stressni boshqarish, motivatsiyani oshirish va hissiy intellektni rivojlantirish uchun resurslar va anonim yordam.</p>
  </div>
</section>

<section class="container">
  <div class="psy-resources">
    <div class="psy-card">
      <div class="icon">
        <svg width="24" height="24" fill="none" stroke="#f472b6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
      </div>
      <h3>Stress boshqarish</h3>
      <p>Kundalik hayotdagi stress va tashvishlarni boshqarish usullari.</p>
      <ul>
        <li><svg width="12" height="12" fill="none" stroke="#4ade80" stroke-width="2"><polyline points="1 7 4 10 11 3"/></svg> Nafas olish texnikalari</li>
        <li><svg width="12" height="12" fill="none" stroke="#4ade80" stroke-width="2"><polyline points="1 7 4 10 11 3"/></svg> Meditatsiya qo'llanma</li>
        <li><svg width="12" height="12" fill="none" stroke="#4ade80" stroke-width="2"><polyline points="1 7 4 10 11 3"/></svg> Vaqt rejalashtirish</li>
      </ul>
    </div>
    <div class="psy-card">
      <div class="icon">
        <svg width="24" height="24" fill="none" stroke="#2563eb" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26"/></svg>
      </div>
      <h3>Motivatsiya</h3>
      <p>Maqsadlarga erishish va o'z-o'zini rivojlantirish uchun maslahatlar.</p>
      <ul>
        <li><svg width="12" height="12" fill="none" stroke="#4ade80" stroke-width="2"><polyline points="1 7 4 10 11 3"/></svg> Maqsad qo'yish san'ati</li>
        <li><svg width="12" height="12" fill="none" stroke="#4ade80" stroke-width="2"><polyline points="1 7 4 10 11 3"/></svg> Odatlarni shakllantirish</li>
        <li><svg width="12" height="12" fill="none" stroke="#4ade80" stroke-width="2"><polyline points="1 7 4 10 11 3"/></svg> Muvaffaqiyat hikoyalari</li>
      </ul>
    </div>
    <div class="psy-card">
      <div class="icon">
        <svg width="24" height="24" fill="none" stroke="#f59e0b" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
      </div>
      <h3>Munosabatlar</h3>
      <p>Oila, do'stlar va hamkasblar bilan sog'lom munosabatlar qurish.</p>
      <ul>
        <li><svg width="12" height="12" fill="none" stroke="#4ade80" stroke-width="2"><polyline points="1 7 4 10 11 3"/></svg> Muloqot ko'nikmalari</li>
        <li><svg width="12" height="12" fill="none" stroke="#4ade80" stroke-width="2"><polyline points="1 7 4 10 11 3"/></svg> Konfliktni hal qilish</li>
        <li><svg width="12" height="12" fill="none" stroke="#4ade80" stroke-width="2"><polyline points="1 7 4 10 11 3"/></svg> Empatsiya rivojlantirish</li>
      </ul>
    </div>
  </div>
</section>

<section class="container">
  <div class="psy-anon">
    <div class="psy-anon-icon">
      <svg width="36" height="36" fill="none" stroke="#a78bfa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s-4-2-4-6V8l8-4 8 4v8c0 4-4 6-4 6"/><path d="M12 22H8"/><circle cx="16" cy="14" r="2"/></svg>
    </div>
    <div class="psy-anon-content">
      <h2>🔒 Anonim yordam</h2>
      <p>Hech qanday shaxsiy ma'lumot talab qilinmaydi. Xavfsiz va maxfiy muhitda o'z tashvishlaringizni baham ko'ring va professional maslahat oling.</p>
      <div class="psy-anon-features">
        <span>
          <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="5" width="8" height="6" rx="1"/><path d="M4 5V3a2 2 0 0 1 4 0v2"/></svg>
          Maxfiy
        </span>
        <span>
          <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><circle cx="6" cy="6" r="5"/><path d="M6 3v3l2 1"/></svg>
          24/7
        </span>
        <span>
          <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 12l10 5 10-5"/></svg>
          Bepul
        </span>
        <span>
          <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><polyline points="1 7 4 10 11 3"/></svg>
          Professional
        </span>
      </div>
    </div>
  </div>
</section>

<section class="container">
  <div class="psy-tips">
    <h2>Kundalik maslahatlar</h2>
    <div class="psy-tips-grid">
      <div class="psy-tip">
        <div class="num">1</div>
        <p>Har kuni kamida 7-8 soat uxlang. Yaxshi uyqu — ruhiy salomatlik asosidir.</p>
      </div>
      <div class="psy-tip">
        <div class="num">2</div>
        <p>Jismoniy mashqlar bajaring. 30 daqiqalik yurish ham kayfiyatni yaxshilaydi.</p>
      </div>
      <div class="psy-tip">
        <div class="num">3</div>
        <p>Kundalik yozing. O'z his-tuyg'ularingizni qog'ozga tushirish xotirjamlik beradi.</p>
      </div>
      <div class="psy-tip">
        <div class="num">4</div>
        <p>Ijtimoiy aloqalarni saqlang. Yaqinlaringiz bilan muntazam muloqot qiling.</p>
      </div>
    </div>
  </div>
</section>

<section class="container">
  <div class="psy-cta">
    <h2>Yordamga muhtojmisiz?</h2>
    <p>Hech narsa uyaltiradigan emas. Professional psixologlar bilan anonim tarzda bog'laning.</p>
    <a href="/register" class="btn btn-primary">Yordam olish</a>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/6a4e91db8a003/data/www/ambarella.uz/resources/views/psychology/index.blade.php ENDPATH**/ ?>