
<?php $__env->startSection('title', $course->title . ' | AMBARELLA Academy'); ?>
<?php $__env->startSection('description', Str::limit($course->description ?? '', 160)); ?>
<?php $__env->startSection('styles'); ?>
<style>
.course-page{padding:48px 0 80px}
.cp-back{display:inline-flex;align-items:center;gap:6px;color:var(--muted);font-size:13px;margin-bottom:28px;transition:color .2s}
.cp-back:hover{color:#fff}
.cp-back svg{width:16px;height:16px;stroke:currentColor;fill:none;stroke-width:2}
.cp-layout{display:grid;grid-template-columns:1fr 340px;gap:32px;align-items:start}
/* Main */
.cp-hero{background:linear-gradient(135deg,rgba(245,158,11,.06),rgba(249,115,22,.04));border:1px solid rgba(245,158,11,.15);border-radius:20px;padding:32px;margin-bottom:20px;position:relative;overflow:hidden}
.cp-hero::before{content:'';position:absolute;top:-50px;right:-50px;width:200px;height:200px;border-radius:50%;background:rgba(245,158,11,.04)}
.cp-category{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;color:#fbbf24;margin-bottom:10px}
.cp-title{font-size:clamp(22px,3.5vw,30px);font-weight:800;color:#fff;margin-bottom:12px;line-height:1.3}
.cp-badges{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px}
.cpb{padding:5px 14px;border-radius:999px;font-size:11px;font-weight:600}
.cpb-level{background:rgba(245,158,11,.1);color:#fbbf24;border:1px solid rgba(245,158,11,.15)}
.cpb-duration{background:rgba(37,99,235,.1);color:#93c5fd;border:1px solid rgba(37,99,235,.15)}
.cpb-price-free{background:rgba(34,197,94,.1);color:#4ade80;border:1px solid rgba(34,197,94,.15)}
.cpb-price-paid{background:rgba(139,92,246,.1);color:#a78bfa;border:1px solid rgba(139,92,246,.15)}
.cp-instructor{display:flex;align-items:center;gap:10px;margin-bottom:16px}
.cp-instructor-avatar{width:36px;height:36px;border-radius:50%;background:rgba(245,158,11,.15);display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:700;color:#fbbf24}
.cp-instructor-name{font-size:13px;color:#94a3b8}
.cp-instructor-name strong{color:#fff;display:block;font-size:14px}
.cp-rating{display:flex;align-items:center;gap:6px;font-size:14px}
.cp-rating .stars{color:#fbbf24;font-size:16px}
.cp-rating span{color:var(--muted);font-size:12px}
/* Content panels */
.cp-panel{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:24px;margin-bottom:16px}
.cp-panel h3{font-size:15px;font-weight:700;color:#fff;margin-bottom:14px;display:flex;align-items:center;gap:8px}
.cp-panel h3 svg{width:16px;height:16px;stroke:var(--primary);fill:none;stroke-width:2}
.cp-panel p{font-size:14px;color:#94a3b8;line-height:1.8;white-space:pre-line}
.cp-panel ul{list-style:none;display:flex;flex-direction:column;gap:8px}
.cp-panel ul li{display:flex;align-items:flex-start;gap:8px;font-size:13px;color:#94a3b8}
.cp-panel ul li svg{width:14px;height:14px;stroke:#4ade80;fill:none;stroke-width:2;flex-shrink:0;margin-top:2px}
/* Sidebar */
.cp-sidebar{display:flex;flex-direction:column;gap:16px;position:sticky;top:90px}
.cps-card{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:24px}
.cps-card h3{font-size:14px;font-weight:700;color:#fff;margin-bottom:16px}
.cps-enroll-btn{width:100%;padding:14px;border-radius:12px;font-size:15px;font-weight:700;text-align:center;display:flex;align-items:center;justify-content:center;gap:8px}
.cps-enroll-btn svg{width:18px;height:18px;stroke:currentColor;fill:none;stroke-width:2}
.cps-info-row{display:flex;justify-content:space-between;align-items:center;padding:9px 0;border-bottom:1px solid var(--border);font-size:12px}
.cps-info-row:last-child{border:none}
.cps-info-row .lbl{color:var(--muted)}
.cps-info-row .val{color:#fff;font-weight:600}
.enrolled-badge{display:flex;align-items:center;justify-content:center;gap:8px;padding:14px;background:rgba(34,197,94,.06);border:1px solid rgba(34,197,94,.15);border-radius:12px;color:#4ade80;font-size:14px;font-weight:600;margin-bottom:10px}
.enrolled-badge svg{width:16px;height:16px;stroke:currentColor;fill:none;stroke-width:2}
/* Related */
.cp-related{margin-top:32px}
.cp-related h3{font-size:16px;font-weight:700;color:#fff;margin-bottom:14px}
.cp-related-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
.cpr-card{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:16px;transition:all .2s}
.cpr-card:hover{border-color:rgba(245,158,11,.25);transform:translateY(-2px)}
.cpr-card h4{font-size:13px;font-weight:600;color:#fff;margin-bottom:4px;line-height:1.3}
.cpr-card p{font-size:11px;color:var(--muted)}
@media(max-width:1024px){.cp-layout{grid-template-columns:1fr}.cp-sidebar{position:static}.cp-related-grid{grid-template-columns:1fr 1fr}}
@media(max-width:768px){.cp-related-grid{grid-template-columns:1fr}.cp-hero{padding:20px}.cp-panel{padding:18px}}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container course-page">
  <a href="/academy" class="cp-back"><svg viewBox="0 0 24 24"><path d="M19 12H5M12 19l-7-7 7-7"/></svg> Barcha kurslar</a>

  <div class="cp-layout">
    
    <div>
      <div class="cp-hero">
        <?php if($course->category): ?><div class="cp-category"><?php echo e($course->category); ?></div><?php endif; ?>
        <h1 class="cp-title"><?php echo e($course->title); ?></h1>

        <div class="cp-instructor">
          <div class="cp-instructor-avatar"><?php echo e(strtoupper(substr($course->instructor ?? 'M', 0, 1))); ?></div>
          <div class="cp-instructor-name">
            <strong><?php echo e($course->instructor); ?></strong>
            Muallif / Mentor
          </div>
        </div>

        <div class="cp-badges">
          <span class="cpb cpb-level"><?php echo e($course->level ?? "Boshlang'ich"); ?></span>
          <span class="cpb cpb-duration"><?php echo e($course->duration); ?></span>
          <span class="cpb <?php echo e($course->price == 0 ? 'cpb-price-free' : 'cpb-price-paid'); ?>">
            <?php echo e($course->price == 0 ? 'Bepul' : number_format($course->price) . ' so\'m'); ?>

          </span>
        </div>

        <div class="cp-rating">
          <span class="stars">★★★★<?php echo e($course->rating >= 4.5 ? '★' : '☆'); ?></span>
          <strong style="color:#fff"><?php echo e($course->rating ?? '4.5'); ?></strong>
          <span>(<?php echo e($studentsCount); ?> o'quvchi)</span>
        </div>
      </div>

      
      <div class="cp-panel">
        <h3><svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>Kurs haqida</h3>
        <p><?php echo e($course->description ?? 'Kurs haqida batafsil ma\'lumot tez orada qo\'shiladi.'); ?></p>
      </div>

      
      <div class="cp-panel">
        <h3><svg viewBox="0 0 24 24"><polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></svg>Nimalar o'rganasiz</h3>
        <ul>
          <li><svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg><?php echo e($course->category ?? 'Asosiy'); ?> sohasida mustahkam bilim va ko'nikmalar</li>
          <li><svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>Amaliy loyihalar orqali tajriba orttirish</li>
          <li><svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>Sertifikat olish va portfoilga qo'shish imkoniyati</li>
          <li><svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>Muallif bilan to'g'ridan-to'g'ri muloqot</li>
        </ul>
      </div>

      
      <?php if($related->count() > 0): ?>
      <div class="cp-related">
        <h3>O'xshash kurslar</h3>
        <div class="cp-related-grid">
          <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="/academy/<?php echo e($r->id); ?>" class="cpr-card">
            <h4><?php echo e($r->title); ?></h4>
            <p><?php echo e($r->instructor); ?> · <?php echo e($r->duration); ?></p>
          </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
      <?php endif; ?>
    </div>

    
    <div class="cp-sidebar">
      <div class="cps-card">
        <h3>Kursga yozilish</h3>

        <?php if(session('success')): ?>
          <div class="alert alert-success" style="margin-bottom:12px;font-size:13px"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <?php if($isEnrolled): ?>
          <div class="enrolled-badge">
            <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
            Kursga yozilgansiz
          </div>
          <a href="/my-courses" class="btn btn-outline" style="width:100%;justify-content:center">Mening kurslarim</a>
        <?php else: ?>
          <div style="text-align:center;margin-bottom:16px">
            <?php if($course->price == 0): ?>
              <div style="font-size:28px;font-weight:900;color:#4ade80">Bepul</div>
            <?php else: ?>
              <div style="font-size:28px;font-weight:900;color:#a78bfa"><?php echo e(number_format($course->price)); ?> so'm</div>
            <?php endif; ?>
          </div>
          <?php if(auth()->guard()->check()): ?>
            <form action="/academy/<?php echo e($course->id); ?>/enroll" method="POST">
              <?php echo csrf_field(); ?>
              <button type="submit" class="btn btn-primary cps-enroll-btn">
                <svg viewBox="0 0 24 24"><path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z"/><path d="M22 3h-6a4 4 0 00-4 4v14a3 3 0 013-3h7z"/></svg>
                Kursga yozilish
              </button>
            </form>
            <p style="font-size:11px;color:var(--muted);text-align:center;margin-top:8px">Yozilsangiz +10 GreenCoin olasiz</p>
          <?php else: ?>
            <a href="/login" class="btn btn-primary cps-enroll-btn">
              <svg viewBox="0 0 24 24"><path d="M15 3h4a2 2 0 012 2v14a2 2 0 01-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/></svg>
              Kirish va yozilish
            </a>
          <?php endif; ?>
        <?php endif; ?>
      </div>

      <div class="cps-card">
        <h3>Kurs ma'lumotlari</h3>
        <div class="cps-info-row"><span class="lbl">Daraja</span><span class="val"><?php echo e($course->level ?? "Boshlang'ich"); ?></span></div>
        <div class="cps-info-row"><span class="lbl">Davomiyligi</span><span class="val"><?php echo e($course->duration ?? '—'); ?></span></div>
        <div class="cps-info-row"><span class="lbl">Kategoriya</span><span class="val"><?php echo e($course->category ?? 'Umumiy'); ?></span></div>
        <div class="cps-info-row"><span class="lbl">Reyting</span><span class="val" style="color:#fbbf24">★ <?php echo e($course->rating ?? '4.5'); ?></span></div>
        <div class="cps-info-row"><span class="lbl">O'quvchilar</span><span class="val"><?php echo e($studentsCount); ?></span></div>
        <div class="cps-info-row"><span class="lbl">Sertifikat</span><span class="val" style="color:#4ade80">✓ Ha</span></div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/6a4e91db8a003/data/www/ambarella.uz/resources/views/academy/show.blade.php ENDPATH**/ ?>