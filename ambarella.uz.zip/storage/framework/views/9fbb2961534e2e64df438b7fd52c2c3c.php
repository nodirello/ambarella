
<?php $__env->startSection('title', 'Telegram Vazifalar | Admin'); ?>
<?php $__env->startSection('content'); ?>
<div class="container" style="padding:28px 28px 80px">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;flex-wrap:wrap;gap:12px">
    <div>
      <h1 style="font-size:20px;font-weight:800;color:#fff">Telegram Vazifalar</h1>
      <p style="font-size:12px;color:#334155;margin-top:3px">Bot orqali beriladigan vazifalar va mukofotlar</p>
    </div>
    <a href="/admin/telegram/tasks/create" class="btn btn-primary" style="padding:10px 18px;font-size:13px">+ Yangi vazifa</a>
  </div>

  <?php if(session('success')): ?>
    <div class="alert alert-success" style="margin-bottom:16px"><?php echo e(session('success')); ?></div>
  <?php endif; ?>

  <?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <div style="background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.05);border-radius:14px;padding:18px 20px;margin-bottom:10px;display:grid;grid-template-columns:1fr auto;gap:16px;align-items:center;transition:border-color .2s" class="<?php echo e(!$task->is_active ? 'opacity-50' : ''); ?>">
    <div>
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px;flex-wrap:wrap">
        <span style="font-size:14px;font-weight:700;color:#fff"><?php echo e($task->title); ?></span>
        <span style="font-size:9px;font-weight:700;padding:2px 8px;border-radius:999px;background:rgba(37,99,235,.1);color:#93c5fd"><?php echo e($task->task_type); ?></span>
        <?php if($task->requires_approval): ?>
          <span style="font-size:9px;font-weight:700;padding:2px 8px;border-radius:999px;background:rgba(245,158,11,.1);color:#fbbf24">Tasdiq kerak</span>
        <?php else: ?>
          <span style="font-size:9px;font-weight:700;padding:2px 8px;border-radius:999px;background:rgba(34,197,94,.1);color:#4ade80">Avtomatik</span>
        <?php endif; ?>
        <?php if(!$task->is_active): ?>
          <span style="font-size:9px;font-weight:700;padding:2px 8px;border-radius:999px;background:rgba(100,116,139,.1);color:#475569">O'chirilgan</span>
        <?php endif; ?>
      </div>
      <?php if($task->description): ?>
        <div style="font-size:12px;color:#475569;margin-bottom:6px"><?php echo e($task->description); ?></div>
      <?php endif; ?>
      <div style="font-size:11px;color:#1e293b;display:flex;gap:12px;flex-wrap:wrap">
        <span>💰 +<?php echo e($task->reward); ?> GC</span>
        <?php if($task->start_at): ?><span>Boshlanadi: <?php echo e($task->start_at->format('d.m.Y')); ?></span><?php endif; ?>
        <?php if($task->end_at): ?><span>Tugaydi: <?php echo e($task->end_at->format('d.m.Y')); ?></span><?php endif; ?>
        <span><?php echo e($task->submissions()->count()); ?> ta topshiriq</span>
      </div>
    </div>
    <div style="display:flex;gap:8px">
      <form action="/admin/telegram/tasks/<?php echo e($task->id); ?>/toggle" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-outline" style="padding:8px 14px;font-size:11px">
          <?php echo e($task->is_active ? 'O\'chirish' : 'Yoqish'); ?>

        </button>
      </form>
      <form action="/admin/telegram/tasks/<?php echo e($task->id); ?>" method="POST" onsubmit="return confirm('O\'chirishni tasdiqlaysizmi?')">
        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
        <button type="submit" class="btn btn-danger" style="padding:8px 12px;font-size:11px">✗</button>
      </form>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  <div style="text-align:center;padding:60px;color:#334155">
    <p>Hali vazifalar yo'q. <a href="/admin/telegram/tasks/create" style="color:var(--primary)">Yaratish</a></p>
  </div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/6a4e91db8a003/data/www/ambarella.uz/resources/views/admin/telegram/tasks.blade.php ENDPATH**/ ?>