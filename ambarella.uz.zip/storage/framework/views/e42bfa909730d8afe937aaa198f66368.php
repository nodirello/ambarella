﻿
<?php $__env->startSection('title', 'Dashboard | AMBARELLA'); ?>
<?php $__env->startSection('styles'); ?>
<style>
*{box-sizing:border-box}
/* ── Layout ── */
.db-wrap{display:flex;min-height:calc(100vh - 70px);background:#080e1c}
/* ── Sidebar ── */
.db-sidebar{
  width:240px;flex-shrink:0;
  background:rgba(255,255,255,.015);
  border-right:1px solid rgba(255,255,255,.06);
  padding:20px 0;
  position:sticky;top:70px;
  height:calc(100vh - 70px);
  overflow-y:auto;
}
.db-sidebar::-webkit-scrollbar{width:0}
.db-prof{padding:16px 18px 20px;margin:0 10px 16px;border-radius:14px;background:linear-gradient(135deg,rgba(37,99,235,.08),rgba(124,58,237,.05));border:1px solid rgba(37,99,235,.12);text-align:center}
.db-av{width:52px;height:52px;border-radius:50%;background:linear-gradient(135deg,#2563eb,#7c3aed);display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:900;color:#fff;margin:0 auto 10px;box-shadow:0 0 0 3px rgba(37,99,235,.2)}
.db-nm{font-size:13px;font-weight:700;color:#fff}
.db-rl{font-size:10px;color:#475569;margin-top:2px}
.db-gc{display:inline-flex;align-items:center;gap:4px;margin-top:8px;padding:3px 10px;border-radius:999px;background:rgba(34,197,94,.08);border:1px solid rgba(34,197,94,.15);font-size:11px;font-weight:700;color:#4ade80}
/* Nav */
.db-nav{padding:0 10px}
.db-sec-t{font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:2px;color:#334155;padding:8px 12px;margin-top:8px}
.db-nl{display:flex;align-items:center;gap:9px;padding:9px 12px;border-radius:10px;font-size:12px;font-weight:500;color:#475569;transition:all .2s;margin-bottom:1px}
.db-nl:hover{background:rgba(255,255,255,.04);color:#cbd5e1}
.db-nl.on{background:linear-gradient(135deg,rgba(37,99,235,.1),rgba(124,58,237,.07));color:#93c5fd;border:1px solid rgba(37,99,235,.15)}
.db-nl svg{width:16px;height:16px;stroke:currentColor;fill:none;stroke-width:1.8;flex-shrink:0}
/* ── Main ── */
.db-main{flex:1;min-width:0;padding:28px 28px 80px}
/* ── Top strip ── */
.db-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:28px;flex-wrap:wrap;gap:12px}
.db-greet h1{font-size:clamp(18px,3vw,24px);font-weight:900;color:#fff}
.db-greet p{font-size:13px;color:#334155;margin-top:3px}
.db-top-actions{display:flex;gap:8px}
.db-top-btn{display:flex;align-items:center;gap:6px;padding:8px 14px;border-radius:10px;font-size:12px;font-weight:600;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);color:#94a3b8;transition:all .2s}
.db-top-btn:hover{background:rgba(255,255,255,.07);color:#fff}
.db-top-btn svg{width:14px;height:14px;stroke:currentColor;fill:none;stroke-width:2}
/* ── Stats ── */
.db-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:24px}
.dst{background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.06);border-radius:16px;padding:18px;position:relative;overflow:hidden;transition:all .3s}
.dst:hover{border-color:var(--dc);background:color-mix(in srgb,var(--dc) 4%,transparent);transform:translateY(-2px)}
.dst::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:var(--dc);transform:scaleX(0);transform-origin:left;transition:transform .3s}
.dst:hover::before{transform:scaleX(1)}
.dst-ic{width:36px;height:36px;border-radius:10px;display:flex;align-items:center;justify-content:center;margin-bottom:10px;background:color-mix(in srgb,var(--dc) 10%,transparent)}
.dst-ic svg{width:18px;height:18px;stroke:var(--dc);fill:none;stroke-width:2}
.dst-n{font-size:26px;font-weight:900;color:var(--dc);line-height:1}
.dst-l{font-size:10px;color:#334155;margin-top:4px;font-weight:600;text-transform:uppercase;letter-spacing:.5px}
</style>
<style>
/* ── Quick modules ── */
.db-mods{display:grid;grid-template-columns:repeat(8,1fr);gap:10px;margin-bottom:24px}
.dbm{display:flex;flex-direction:column;align-items:center;gap:5px;padding:14px 8px;background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.05);border-radius:12px;transition:all .25s;text-align:center}
.dbm:hover{background:rgba(255,255,255,.05);border-color:var(--dm);transform:translateY(-3px)}
.dbm svg{width:20px;height:20px;stroke:var(--dm,#60a5fa);fill:none;stroke-width:1.8;transition:filter .2s}
.dbm:hover svg{filter:drop-shadow(0 2px 6px var(--dm,#60a5fa))}
.dbm span{font-size:9px;font-weight:600;color:#334155;white-space:nowrap}
.dbm:hover span{color:#94a3b8}
/* ── Grid ── */
.db-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px}
.db-panel{background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.05);border-radius:16px;padding:20px;transition:border-color .3s}
.db-panel:hover{border-color:rgba(37,99,235,.12)}
.dbp-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px}
.dbp-head h3{font-size:13px;font-weight:700;color:#fff;display:flex;align-items:center;gap:7px}
.dbp-head h3 svg{width:15px;height:15px;stroke:#60a5fa;fill:none;stroke-width:2}
.dbp-head a{font-size:11px;color:#334155;transition:color .2s}
.dbp-head a:hover{color:#60a5fa}
/* items */
.dbi{display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid rgba(255,255,255,.04);transition:background .2s}
.dbi:last-child{border:none}
.dbi-dot{width:7px;height:7px;border-radius:50%;flex-shrink:0}
.dbi-txt{font-size:12px;color:#475569;flex:1}
.dbi-meta{font-size:11px;font-weight:600}
/* Progress */
.db-prog{background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.05);border-radius:16px;padding:20px;margin-bottom:16px}
.db-prog h3{font-size:13px;font-weight:700;color:#fff;margin-bottom:14px;display:flex;align-items:center;gap:7px}
.db-prog h3 svg{width:15px;height:15px;stroke:#4ade80;fill:none;stroke-width:2}
.prog-bar{height:7px;background:rgba(255,255,255,.04);border-radius:4px;overflow:hidden}
.prog-fill{height:100%;border-radius:4px;background:linear-gradient(90deg,#4ade80,#22d3ee);transition:width 1s ease}
.prog-levels{display:flex;justify-content:space-between;margin-top:8px;flex-wrap:wrap;gap:4px}
.prog-lv{font-size:9px;font-weight:700;padding:2px 8px;border-radius:999px}
/* Streak */
.db-streak{background:linear-gradient(135deg,rgba(245,158,11,.06),rgba(249,115,22,.04));border:1px solid rgba(245,158,11,.12);border-radius:16px;padding:20px;display:flex;align-items:center;gap:16px;flex-wrap:wrap}
.streak-fire{font-size:36px;line-height:1}
.streak-info h4{font-size:22px;font-weight:900;color:#fbbf24}
.streak-info p{font-size:12px;color:#92400e;margin-top:2px}
/* Responsive */
@media(max-width:1200px){.db-sidebar{width:220px}}
@media(max-width:1024px){.db-wrap{flex-direction:column}.db-sidebar{display:none}.db-main{padding:20px 16px 80px}.db-stats{grid-template-columns:1fr 1fr}.db-mods{grid-template-columns:repeat(4,1fr)}.db-grid{grid-template-columns:1fr}}
@media(max-width:640px){.db-stats{grid-template-columns:1fr 1fr}.db-mods{grid-template-columns:repeat(4,1fr)}.db-grid{grid-template-columns:1fr}}
@media(max-width:400px){.db-mods{grid-template-columns:repeat(3,1fr)}}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="db-wrap">

<aside class="db-sidebar">
  <div class="db-prof">
    <div class="db-av"><?php echo e(strtoupper(mb_substr(auth()->user()->name,0,1))); ?></div>
    <div class="db-nm"><?php echo e(auth()->user()->name); ?></div>
    <div class="db-rl"><?php echo e(ucfirst(auth()->user()->role ?? 'Foydalanuvchi')); ?></div>
    <div class="db-gc"><?php echo e(number_format($data['greencoin'])); ?> GC</div>
  </div>
  <div class="db-nav">
    <div class="db-sec-t">Asosiy</div>
    <a href="/dashboard" class="db-nl on"><svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>Dashboard</a>
    <a href="/profile" class="db-nl"><svg viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>Profil</a>
    <a href="/notifications" class="db-nl"><svg viewBox="0 0 24 24"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>Xabarnomalar</a>
    <a href="/settings" class="db-nl"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4"/></svg>Sozlamalar</a>
    <div class="db-sec-t">Produktivlik</div>
    <a href="/daily-tasks" class="db-nl"><svg viewBox="0 0 24 24"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></svg>Vazifalar</a>
    <a href="/habits" class="db-nl"><svg viewBox="0 0 24 24"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>Odatlar</a>
    <a href="/pomodoro" class="db-nl"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>Pomodoro</a>
    <a href="/notes" class="db-nl"><svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>Eslatmalar</a>
    <div class="db-sec-t">O'sish</div>
    <a href="/my-courses" class="db-nl"><svg viewBox="0 0 24 24"><path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z"/><path d="M22 3h-6a4 4 0 00-4 4v14a3 3 0 013-3h7z"/></svg>Kurslarim</a>
    <a href="/mentorship" class="db-nl"><svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/></svg>Mentorlik</a>
    <a href="/achievements" class="db-nl"><svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="7"/><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/></svg>Yutuqlar</a>
    <div class="db-sec-t">Bandlik</div>
    <a href="/my-applications" class="db-nl"><svg viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/></svg>Arizalarim</a>
    <a href="/jobs" class="db-nl"><svg viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/></svg>Ish qidirish</a>
    <div class="db-sec-t">Ekotizim</div>
    <a href="/greencoin" class="db-nl"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 6v12M8 10h8"/></svg>GreenCoin</a>
    <a href="/eco" class="db-nl"><svg viewBox="0 0 24 24"><path d="M12 22c4-2.5 7-6 7-10a7 7 0 00-14 0c0 4 3 7.5 7 10z"/></svg>Eco vazifalar</a>
    <a href="/referral" class="db-nl"><svg viewBox="0 0 24 24"><path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/></svg>Referral</a>
  </div>
</aside>


<main class="db-main">
  
  <div class="db-top">
    <div class="db-greet">
      <h1>Salom, <?php echo e(auth()->user()->name); ?>! 👋</h1>
      <p><?php echo e(now()->format('l, d F Y')); ?> — Bugun ham yaxshi kun bo'lsin</p>
    </div>
    <div class="db-top-actions">
      <a href="/eco" class="db-top-btn"><svg viewBox="0 0 24 24"><path d="M12 22c4-2.5 7-6 7-10a7 7 0 00-14 0c0 4 3 7.5 7 10z"/></svg>Eco</a>
      <a href="/greencoin" class="db-top-btn"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 6v12M8 10h8"/></svg><?php echo e(number_format($data['greencoin'])); ?> GC</a>
      <?php if(auth()->user()->isAdmin()): ?>
      <a href="/admin" class="db-top-btn" style="color:#f87171;border-color:rgba(248,113,113,.2)"><svg viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>Admin</a>
      <?php endif; ?>
    </div>
  </div>

  <?php if(session('success')): ?>
    <div class="alert alert-success" style="margin-bottom:16px"><?php echo e(session('success')); ?></div>
  <?php endif; ?>

  
  <div class="db-stats">
    <div class="dst" style="--dc:#4ade80">
      <div class="dst-ic"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 6v12M8 10h8"/></svg></div>
      <div class="dst-n"><?php echo e(number_format($data['greencoin'])); ?></div>
      <div class="dst-l">GreenCoin</div>
    </div>
    <div class="dst" style="--dc:#60a5fa">
      <div class="dst-ic"><svg viewBox="0 0 24 24"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg></div>
      <div class="dst-n"><?php echo e($data['tasks_done']); ?></div>
      <div class="dst-l">Eco harakatlar</div>
    </div>
    <div class="dst" style="--dc:#fbbf24">
      <div class="dst-ic"><svg viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/></svg></div>
      <div class="dst-n"><?php echo e($data['applications']); ?></div>
      <div class="dst-l">Ish arizalari</div>
    </div>
    <div class="dst" style="--dc:#a78bfa">
      <div class="dst-ic"><svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/></svg></div>
      <div class="dst-n"><?php echo e($mentorships->count()); ?></div>
      <div class="dst-l">Mentorliklar</div>
    </div>
  </div>

  
  <div class="db-mods">
    <?php $qm = [
      ['/daily-tasks','#4ade80','<path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/>','Vazifalar'],
      ['/habits','#f59e0b','<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>','Odatlar'],
      ['/pomodoro','#ef4444','<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>','Pomodoro'],
      ['/greencoin','#4ade80','<circle cx="12" cy="12" r="10"/><path d="M12 6v12M8 10h8"/>','GreenCoin'],
      ['/eco','#22d3ee','<path d="M12 22c4-2.5 7-6 7-10a7 7 0 00-14 0c0 4 3 7.5 7 10z"/>','Eco'],
      ['/my-courses','#fbbf24','<path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z"/><path d="M22 3h-6a4 4 0 00-4 4v14a3 3 0 013-3h7z"/>','Kurslar'],
      ['/forum','#06b6d4','<path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>','Forum'],
      ['/challenges','#e11d48','<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>','Challenge'],
    ]; ?>
    <?php $__currentLoopData = $qm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e($m[0]); ?>" class="dbm" style="--dm:<?php echo e($m[1]); ?>">
      <svg viewBox="0 0 24 24"><?php echo $m[2]; ?></svg>
      <span><?php echo e($m[3]); ?></span>
    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

  
  <?php if(($data['login_streak'] ?? 0) > 0): ?>
  <div class="db-streak" style="margin-bottom:16px">
    <div class="streak-fire">🔥</div>
    <div class="streak-info">
      <h4><?php echo e($data['login_streak']); ?> kunlik streak!</h4>
      <p>Shunday davom eting — har kun kirish bonus beradi</p>
    </div>
    <div style="margin-left:auto">
      <a href="/eco" class="db-top-btn" style="border-color:rgba(245,158,11,.2);color:#fbbf24">GC ishlash &rarr;</a>
    </div>
  </div>
  <?php endif; ?>

  
  <div class="db-grid">
    
    <div class="db-panel">
      <div class="dbp-head">
        <h3><svg viewBox="0 0 24 24"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></svg>Bugungi vazifalar</h3>
        <a href="/daily-tasks">Hammasi →</a>
      </div>
      <?php $__empty_1 = true; $__currentLoopData = $dailyTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <div class="dbi">
        <span class="dbi-dot" style="background:<?php echo e($t->is_done ? '#4ade80' : 'rgba(255,255,255,.1)'); ?>"></span>
        <span class="dbi-txt" style="<?php echo e($t->is_done ? 'text-decoration:line-through;opacity:.5' : ''); ?>"><?php echo e($t->text); ?></span>
        <?php if($t->is_done): ?><span class="dbi-meta" style="color:#4ade80">✓</span><?php endif; ?>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <div style="text-align:center;padding:20px 0">
        <p style="color:#334155;font-size:12px;margin-bottom:10px">Bugun vazifa yo'q</p>
        <a href="/daily-tasks" style="font-size:12px;color:#60a5fa;font-weight:600">+ Qo'shish</a>
      </div>
      <?php endif; ?>
    </div>

    
    <div class="db-panel">
      <div class="dbp-head">
        <h3><svg viewBox="0 0 24 24"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>Odatlar</h3>
        <a href="/habits">Hammasi →</a>
      </div>
      <?php $__empty_1 = true; $__currentLoopData = $habits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <div class="dbi">
        <span class="dbi-dot" style="background:<?php echo e($h->last_completed && $h->last_completed->isToday() ? '#4ade80' : '#fbbf24'); ?>"></span>
        <span class="dbi-txt"><?php echo e($h->name); ?></span>
        <span class="dbi-meta" style="color:#f59e0b">🔥<?php echo e($h->streak); ?></span>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <div style="text-align:center;padding:20px 0">
        <p style="color:#334155;font-size:12px;margin-bottom:10px">Odatlar yo'q</p>
        <a href="/habits" style="font-size:12px;color:#60a5fa;font-weight:600">+ Qo'shish</a>
      </div>
      <?php endif; ?>
    </div>

    
    <div class="db-panel">
      <div class="dbp-head">
        <h3><svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>Mentorlik</h3>
        <a href="/mentorship">Hammasi →</a>
      </div>
      <?php $__empty_1 = true; $__currentLoopData = $mentorships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <div class="dbi">
        <span class="dbi-dot" style="background:#a78bfa"></span>
        <span class="dbi-txt"><?php if($m->mentor_id===auth()->id()): ?>Shogird: <?php echo e($m->student->name ?? 'N/A'); ?><?php else: ?> Ustoz: <?php echo e($m->mentor->name ?? 'N/A'); ?><?php endif; ?></span>
        <span style="font-size:10px;padding:2px 8px;background:rgba(124,58,237,.1);color:#a78bfa;border-radius:999px"><?php echo e($m->status); ?></span>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <div style="text-align:center;padding:20px 0">
        <p style="color:#334155;font-size:12px;margin-bottom:10px">Faol mentorlik yo'q</p>
        <a href="/mentors" style="font-size:12px;color:#a78bfa;font-weight:600">Mentor topish</a>
      </div>
      <?php endif; ?>
    </div>

    
    <div class="db-panel">
      <div class="dbp-head"><h3><svg viewBox="0 0 24 24"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>Faoliyat</h3></div>
      <div class="dbi"><span class="dbi-dot" style="background:#4ade80"></span><span class="dbi-txt"><?php echo e($data['tasks_done']); ?> eco vazifa bajarildi</span></div>
      <div class="dbi"><span class="dbi-dot" style="background:#60a5fa"></span><span class="dbi-txt"><?php echo e($data['applications']); ?> ish arizasi topshirildi</span></div>
      <div class="dbi"><span class="dbi-dot" style="background:#fbbf24"></span><span class="dbi-txt"><?php echo e(number_format($data['greencoin'])); ?> GreenCoin ishlangan</span></div>
      <div class="dbi"><span class="dbi-dot" style="background:#a78bfa"></span><span class="dbi-txt"><?php echo e($mentorships->count()); ?> faol mentorlik</span></div>
      <?php if(!empty($data['courses_enrolled'])): ?><div class="dbi"><span class="dbi-dot" style="background:#fbbf24"></span><span class="dbi-txt"><?php echo e($data['courses_enrolled']); ?> kursga yozilgan</span></div><?php endif; ?>
    </div>
  </div>

  
  <div class="db-prog">
    <h3><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 6v12M8 10h8"/></svg>GreenCoin Daraja <a href="/greencoin" style="margin-left:auto;font-size:11px;color:#334155;font-weight:600;transition:color .2s" onmouseover="this.style.color='#4ade80'" onmouseout="this.style.color='#334155'">Batafsil →</a></h3>
    <?php
      $gc = $data['greencoin'];
      $levels = [['n'=>'Starter','min'=>0,'c'=>'#64748b'],['n'=>'Bronze','min'=>100,'c'=>'#cd7f32'],['n'=>'Silver','min'=>500,'c'=>'#94a3b8'],['n'=>'Gold','min'=>1000,'c'=>'#fbbf24'],['n'=>'Platinum','min'=>5000,'c'=>'#a78bfa']];
      $cur = collect($levels)->last(fn($l)=>$gc>=$l['min']);
      $nxt = collect($levels)->first(fn($l)=>$gc<$l['min']);
      $pct = $nxt ? min(round(($gc-$cur['min'])/($nxt['min']-$cur['min'])*100),100) : 100;
    ?>
    <div style="display:flex;justify-content:space-between;margin-bottom:8px;align-items:center">
      <span style="font-size:13px;font-weight:700;color:<?php echo e($cur['c']); ?>"><?php echo e($cur['n']); ?></span>
      <?php if($nxt): ?><span style="font-size:11px;color:#334155">Keyingi: <?php echo e($nxt['n']); ?> — <?php echo e(number_format($nxt['min'])); ?> GC</span><?php endif; ?>
    </div>
    <div class="prog-bar">
      <div class="prog-fill" style="width:<?php echo e($pct); ?>%;background:linear-gradient(90deg,<?php echo e($cur['c']); ?>,<?php echo e($nxt['c'] ?? $cur['c']); ?>)"></div>
    </div>
    <div class="prog-levels">
      <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <span class="prog-lv" style="color:<?php echo e($lv['c']); ?>;background:color-mix(in srgb,<?php echo e($lv['c']); ?> 8%,transparent);border:1px solid color-mix(in srgb,<?php echo e($lv['c']); ?> 20%,transparent)"><?php echo e($lv['n']); ?></span>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</main>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/6a4e91db8a003/data/www/ambarella.uz/resources/views/dashboard.blade.php ENDPATH**/ ?>