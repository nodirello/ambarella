
<?php $__env->startSection('title', '403 — Ruxsat yo\'q | AMBARELLA'); ?>
<?php $__env->startSection('styles'); ?>
<style>
.error-page{min-height:60vh;display:flex;align-items:center;justify-content:center;text-align:center;padding:60px 24px}
.error-icon{width:120px;height:120px;margin:0 auto 24px}
.error-icon svg{width:100%;height:100%;stroke:#fbbf24;fill:none;stroke-width:1;animation:shake-err 3s ease-in-out infinite}
@keyframes shake-err{0%,100%{transform:rotate(0)}10%{transform:rotate(-5deg)}20%{transform:rotate(5deg)}30%{transform:rotate(0)}}
.error-code{font-size:72px;font-weight:900;background:linear-gradient(135deg,#fbbf24,#f97316);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;margin-bottom:8px}
.error-msg{font-size:18px;color:#fff;font-weight:700;margin-bottom:8px}
.error-desc{font-size:14px;color:var(--muted);margin-bottom:32px;max-width:400px;margin-left:auto;margin-right:auto}
.error-actions{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="error-page">
  <div>
    <div class="error-icon">
      <svg viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><line x1="9" y1="9" x2="15" y2="15"/><line x1="15" y1="9" x2="9" y2="15"/></svg>
    </div>
    <div class="error-code">403</div>
    <p class="error-msg">Ruxsat berilmagan</p>
    <p class="error-desc">Sizda bu sahifaga kirish huquqi yo'q. Agar bu xato deb hisoblasangiz, admin bilan bog'laning.</p>
    <div class="error-actions">
      <a href="/" class="btn btn-primary">Bosh sahifa</a>
      <a href="/dashboard" class="btn btn-outline">Dashboard</a>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/6a4e91db8a003/data/www/ambarella.uz/resources/views/errors/403.blade.php ENDPATH**/ ?>