
<?php $__env->startSection('title', 'Qidiruv: ' . $q . ' | AMBARELLA'); ?>
<?php $__env->startSection('styles'); ?>
<style>
.page-hero{padding:56px 0 40px}
.page-hero h1{font-size:clamp(28px,4vw,38px);font-weight:800;color:#fff;margin-bottom:8px}
.page-hero p{color:var(--muted);font-size:15px;max-width:500px}
.search-box{display:flex;gap:10px;margin-top:24px;max-width:560px}
.search-box input{flex:1;padding:14px 18px;border:1px solid var(--border);border-radius:var(--radius);font-size:15px;font-family:inherit;background:var(--surface);color:#fff}
.search-box input::placeholder{color:#475569}
.results-section{margin-top:40px;margin-bottom:32px}
.results-section h2{font-size:18px;font-weight:700;color:#fff;margin-bottom:16px;display:flex;align-items:center;gap:10px}
.results-section h2 span{font-size:12px;padding:3px 10px;border-radius:99px;background:rgba(37,99,235,.1);color:#93c5fd;border:1px solid rgba(37,99,235,.2)}
.result-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:12px}
.result-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:18px;transition:all .3s;display:block}
.result-card:hover{border-color:rgba(37,99,235,.4);transform:translateY(-2px)}
.result-card h3{font-size:15px;font-weight:700;color:#fff;margin-bottom:4px}
.result-card p{font-size:13px;color:var(--muted)}
.empty-state{text-align:center;padding:64px 24px;color:var(--muted);font-size:15px}
@media(max-width:768px){.search-box{flex-direction:column}.result-grid{grid-template-columns:1fr}}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="page-hero"><div class="container">
  <h1>🔍 Qidiruv</h1>
  <p>Platforma bo'ylab ish, kurs, mentor, yangilik va mahsulotlarni qidiring</p>
  <form class="search-box" method="GET" action="/search">
    <input type="text" name="q" value="<?php echo e($q); ?>" placeholder="Qidiruv so'zini kiriting..." autofocus>
    <button type="submit" class="btn btn-primary">Qidirish</button>
  </form>
</div></section>
<div class="container">
  <?php if(strlen($q) < 2 && strlen($q) > 0): ?>
    <div class="empty-state">Kamida 2 ta belgi kiriting</div>
  <?php elseif(strlen($q) >= 2): ?>
    <?php
      $totalResults = $jobs->count() + $courses->count() + $mentors->count() + $news->count() + $products->count();
    ?>

    <?php if($totalResults === 0): ?>
      <div class="empty-state">
        <p>«<?php echo e($q); ?>» bo'yicha hech narsa topilmadi</p>
        <p style="margin-top:8px;font-size:13px">Boshqa so'zlar bilan qidiring</p>
      </div>
    <?php else: ?>
      <?php if($jobs->count()): ?>
      <div class="results-section">
        <h2>Ish e'lonlari <span><?php echo e($jobs->count()); ?></span></h2>
        <div class="result-grid">
          <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="/jobs/<?php echo e($job->id); ?>" class="result-card">
            <h3><?php echo e($job->title); ?></h3>
            <p><?php echo e($job->company); ?> — <?php echo e($job->location); ?></p>
          </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
      <?php endif; ?>

      <?php if($courses->count()): ?>
      <div class="results-section">
        <h2>Kurslar <span><?php echo e($courses->count()); ?></span></h2>
        <div class="result-grid">
          <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="/academy/<?php echo e($course->id); ?>" class="result-card">
            <h3><?php echo e($course->title); ?></h3>
            <p><?php echo e($course->instructor); ?> — <?php echo e($course->level); ?></p>
          </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
      <?php endif; ?>

      <?php if($mentors->count()): ?>
      <div class="results-section">
        <h2>Mentorlar <span><?php echo e($mentors->count()); ?></span></h2>
        <div class="result-grid">
          <?php $__currentLoopData = $mentors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mentor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="/mentor/<?php echo e($mentor->id); ?>" class="result-card">
            <h3><?php echo e($mentor->name); ?></h3>
            <p><?php echo e($mentor->role); ?></p>
          </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
      <?php endif; ?>

      <?php if($news->count()): ?>
      <div class="results-section">
        <h2>Yangiliklar <span><?php echo e($news->count()); ?></span></h2>
        <div class="result-grid">
          <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="/news/<?php echo e($item->id); ?>" class="result-card">
            <h3><?php echo e($item->title); ?></h3>
            <p><?php echo e($item->category); ?> — <?php echo e($item->author); ?></p>
          </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
      <?php endif; ?>

      <?php if($products->count()): ?>
      <div class="results-section">
        <h2>Mahsulotlar <span><?php echo e($products->count()); ?></span></h2>
        <div class="result-grid">
          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="/farm/<?php echo e($product->id); ?>" class="result-card">
            <h3><?php echo e($product->name); ?></h3>
            <p><?php echo e($product->region); ?> — <?php echo e(number_format($product->price)); ?> so'm</p>
          </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
      <?php endif; ?>
    <?php endif; ?>
  <?php else: ?>
    <div class="empty-state">Qidiruv so'zini kiriting</div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/6a4e91db8a003/data/www/ambarella.uz/resources/views/search/index.blade.php ENDPATH**/ ?>