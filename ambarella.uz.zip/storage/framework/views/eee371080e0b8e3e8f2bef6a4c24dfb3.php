
<?php $__env->startSection('title', 'Academy — Onlayn Kurslar | AMBARELLA'); ?>
<?php $__env->startSection('description', 'IT, dizayn, marketing va boshqa sohalarda bepul va pullik onlayn kurslar. Sertifikat oling.'); ?>
<?php $__env->startSection('styles'); ?>
<style>
.academy-hero{padding:60px 0 48px;position:relative;overflow:hidden}
.academy-hero::before{content:'';position:absolute;inset:0;background:radial-gradient(ellipse at 60% 30%,rgba(245,158,11,.07),transparent 60%)}
.ah-inner{display:grid;grid-template-columns:1fr 340px;gap:48px;align-items:center}
.academy-hero h1{font-size:clamp(28px,4vw,40px);font-weight:900;color:#fff;margin-bottom:12px}
.academy-hero h1 span{background:linear-gradient(135deg,#fbbf24,#f97316);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.academy-hero p{font-size:15px;color:#94a3b8;line-height:1.7;max-width:460px}
/* Stats mini */
.ah-stats{display:flex;gap:24px;margin-top:24px;flex-wrap:wrap}
.ahs{display:flex;align-items:center;gap:8px;font-size:13px;color:#94a3b8}
.ahs strong{color:#fff;font-weight:700}
/* Search Card */
.academy-search-card{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:22px}
.acs-input{display:flex;gap:8px;margin-bottom:14px}
.acs-input input{flex:1;padding:11px 14px;background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:10px;color:#fff;font-size:13px}
.acs-input input:focus{outline:none;border-color:var(--primary)}
.acs-input input::placeholder{color:#475569}
.acs-filters{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.acs-filters select{padding:9px 12px;background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:8px;color:#94a3b8;font-size:12px}
/* Filter tabs */
.academy-tabs{display:flex;gap:6px;flex-wrap:wrap;margin:28px 0 20px}
.at-tab{padding:8px 18px;border-radius:999px;font-size:12px;font-weight:600;background:var(--surface);border:1px solid var(--border);color:var(--muted);transition:all .2s;text-decoration:none}
.at-tab:hover{color:#fff;border-color:rgba(245,158,11,.3)}
.at-tab.active{background:rgba(245,158,11,.1);color:#fbbf24;border-color:rgba(245,158,11,.2)}
/* Courses Grid */
.courses-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:20px;padding-bottom:64px}
.course-card{background:var(--surface);border:1px solid var(--border);border-radius:18px;overflow:hidden;transition:all .35s cubic-bezier(.4,0,.2,1);display:flex;flex-direction:column;position:relative}
.course-card:hover{border-color:rgba(245,158,11,.3);transform:translateY(-4px);box-shadow:0 14px 36px rgba(0,0,0,.14)}
.cc-image{height:160px;background:linear-gradient(135deg,rgba(245,158,11,.15),rgba(249,115,22,.08));display:flex;align-items:center;justify-content:center;position:relative;overflow:hidden}
.cc-image::after{content:'';position:absolute;inset:0;background:linear-gradient(180deg,transparent 60%,rgba(15,23,42,.8))}
.cc-image-icon{font-size:48px;position:relative;z-index:1;animation:float-y 4s ease-in-out infinite}
.cc-level-badge{position:absolute;top:12px;left:12px;z-index:2;padding:4px 10px;border-radius:999px;font-size:10px;font-weight:700}
.level-beginner{background:rgba(34,197,94,.15);color:#4ade80;border:1px solid rgba(34,197,94,.2)}
.level-intermediate{background:rgba(245,158,11,.15);color:#fbbf24;border:1px solid rgba(245,158,11,.2)}
.level-advanced{background:rgba(239,68,68,.15);color:#f87171;border:1px solid rgba(239,68,68,.2)}
.cc-price-badge{position:absolute;top:12px;right:12px;z-index:2;padding:4px 10px;border-radius:999px;font-size:10px;font-weight:700}
.price-free{background:rgba(22,163,74,.15);color:#4ade80;border:1px solid rgba(22,163,74,.2)}
.price-paid{background:rgba(37,99,235,.15);color:#93c5fd;border:1px solid rgba(37,99,235,.2)}
.cc-body{padding:20px;flex:1;display:flex;flex-direction:column}
.cc-category{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#fbbf24;margin-bottom:8px}
.cc-title{font-size:15px;font-weight:700;color:#fff;margin-bottom:6px;line-height:1.4}
.cc-instructor{font-size:12px;color:var(--muted);display:flex;align-items:center;gap:5px;margin-bottom:12px}
.cc-instructor svg{width:13px;height:13px;stroke:currentColor;fill:none;stroke-width:2}
.cc-meta{display:flex;gap:14px;margin-top:auto;padding-top:12px;border-top:1px solid var(--border)}
.cc-meta-item{display:flex;align-items:center;gap:4px;font-size:11px;color:var(--muted)}
.cc-meta-item svg{width:12px;height:12px;stroke:currentColor;fill:none;stroke-width:2}
.cc-rating{color:#fbbf24;font-weight:700}
/* Empty */
.empty-courses{text-align:center;padding:80px 24px;color:var(--muted)}
/* Toolbar */
.courses-toolbar{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;flex-wrap:wrap;gap:10px}
.ct-count{font-size:14px;color:var(--muted)}
.ct-count strong{color:#fff}
@media(max-width:1024px){.ah-inner{grid-template-columns:1fr}.academy-search-card{display:none}}
@media(max-width:768px){.courses-grid{grid-template-columns:1fr 1fr}.academy-tabs{gap:4px}.at-tab{padding:6px 12px;font-size:11px}}
@media(max-width:480px){.courses-grid{grid-template-columns:1fr}}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="academy-hero">
  <div class="container">
    <div class="ah-inner">
      <div>
        <h1>O'zbekistondagi eng <span>sifatli kurslar</span></h1>
        <p>IT, dizayn, marketing, biznes — 50+ onlayn kurs. Sertifikat oling va karyerangizni boshlang.</p>
        <div class="ah-stats">
          <span class="ahs"><strong><?php echo e($stats['total']); ?></strong> kurs</span>
          <span class="ahs"><strong><?php echo e($stats['free']); ?></strong> bepul</span>
          <span class="ahs"><strong><?php echo e(number_format($stats['enrolled'])); ?></strong> o'quvchi</span>
        </div>
      </div>
      <div class="academy-search-card">
        <form method="GET" action="/academy">
          <div class="acs-input">
            <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Kurs yoki muallif izlash...">
            <button type="submit" class="btn btn-primary" style="padding:11px 16px">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
            </button>
          </div>
          <div class="acs-filters">
            <select name="level" onchange="this.form.submit()">
              <option value="">Daraja</option>
              <option value="Boshlang'ich" <?php echo e(request('level')=="Boshlang'ich"?'selected':''); ?>>Boshlang'ich</option>
              <option value="O'rta" <?php echo e(request('level')=="O'rta"?'selected':''); ?>>O'rta</option>
              <option value="Yuqori" <?php echo e(request('level')=="Yuqori"?'selected':''); ?>>Yuqori</option>
            </select>
            <select name="category" onchange="this.form.submit()">
              <option value="">Kategoriya</option>
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($cat); ?>" <?php echo e(request('category')==$cat?'selected':''); ?>><?php echo e($cat); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>

<div class="container">
  
  <div class="academy-tabs">
    <a href="/academy" class="at-tab <?php echo e(!request()->anyFilled(['level','category','free','search']) ? 'active' : ''); ?>">Barchasi</a>
    <a href="/academy?free=1" class="at-tab <?php echo e(request('free') ? 'active' : ''); ?>">Bepul kurslar</a>
    <?php $__currentLoopData = $categories->take(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="/academy?category=<?php echo e(urlencode($cat)); ?>" class="at-tab <?php echo e(request('category')==$cat ? 'active' : ''); ?>"><?php echo e($cat); ?></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

  <?php if(session('success')): ?>
    <div class="alert alert-success" style="margin-bottom:20px"><?php echo e(session('success')); ?></div>
  <?php endif; ?>

  
  <div class="courses-toolbar">
    <p class="ct-count"><strong><?php echo e($courses->total()); ?></strong> ta kurs topildi</p>
    <?php if(request()->anyFilled(['level','category','free','search'])): ?>
    <a href="/academy" style="font-size:12px;color:var(--muted)">Filtrlarni tozalash</a>
    <?php endif; ?>
  </div>

  
  <?php
  $icons = ['💻','🎨','📊','🚀','🔐','📱','🌐','🎯','⚙️','📈','🎓','🔬'];
  ?>
  <div class="courses-grid">
    <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <a href="/academy/<?php echo e($course->id); ?>" class="course-card">
      <div class="cc-image">
        <span class="cc-image-icon"><?php echo e($icons[$i % count($icons)]); ?></span>
        <span class="cc-level-badge <?php echo e($course->level === 'Yuqori' ? 'level-advanced' : ($course->level === "O'rta" ? 'level-intermediate' : 'level-beginner')); ?>">
          <?php echo e($course->level ?? "Boshlang'ich"); ?>

        </span>
        <span class="cc-price-badge <?php echo e($course->price == 0 ? 'price-free' : 'price-paid'); ?>">
          <?php echo e($course->price == 0 ? 'Bepul' : number_format($course->price/1000).'K'); ?>

        </span>
      </div>
      <div class="cc-body">
        <?php if($course->category): ?><div class="cc-category"><?php echo e($course->category); ?></div><?php endif; ?>
        <div class="cc-title"><?php echo e($course->title); ?></div>
        <div class="cc-instructor">
          <svg viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
          <?php echo e($course->instructor); ?>

        </div>
        <div class="cc-meta">
          <span class="cc-meta-item cc-rating">
            <svg viewBox="0 0 24 24" fill="#fbbf24" stroke="none"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
            <?php echo e($course->rating ?? '4.5'); ?>

          </span>
          <span class="cc-meta-item">
            <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
            <?php echo e($course->duration ?? '—'); ?>

          </span>
          <span class="cc-meta-item">
            <svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
            <?php echo e($course->users()->count()); ?> o'quvchi
          </span>
        </div>
      </div>
    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="empty-courses" style="grid-column:1/-1">
      <svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.06)" stroke-width="1" style="margin:0 auto 16px"><path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z"/><path d="M22 3h-6a4 4 0 00-4 4v14a3 3 0 013-3h7z"/></svg>
      <p>Kurs topilmadi. Boshqa parametrlar bilan qidiring.</p>
      <a href="/academy" class="btn btn-outline" style="margin-top:16px">Filtrlarni tozalash</a>
    </div>
    <?php endif; ?>
  </div>

  <?php if($courses->hasPages()): ?>
  <div style="display:flex;justify-content:center;padding:16px 0 48px"><?php echo e($courses->links()); ?></div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/6a4e91db8a003/data/www/ambarella.uz/resources/views/academy/index.blade.php ENDPATH**/ ?>