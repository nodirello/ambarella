<!DOCTYPE html>
<html lang="uz">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo $__env->yieldContent('title', 'AMBARELLA — O\'zbekiston Yoshlari Platformasi'); ?></title>
  <meta name="description" content="<?php echo $__env->yieldContent('description', 'AMBARELLA — O\'zbekiston yoshlari uchun bandlik, ekologiya, ta\'lim va AI yordamchi platformasi.'); ?>">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <meta name="theme-color" content="#0f172a">
  <!-- OG Meta Tags -->
  <meta property="og:title" content="<?php echo $__env->yieldContent('title', 'AMBARELLA — O\'zbekiston Yoshlari Platformasi'); ?>">
  <meta property="og:description" content="<?php echo $__env->yieldContent('description', 'AMBARELLA — O\'zbekiston yoshlari uchun bandlik, ekologiya, ta\'lim va AI yordamchi platformasi.'); ?>">
  <meta property="og:type" content="website">
  <meta property="og:url" content="<?php echo e(url()->current()); ?>">
  <meta property="og:image" content="<?php echo e(asset('assets/icons/icon-512.png')); ?>">
  <meta property="og:site_name" content="AMBARELLA">
  <meta property="og:locale" content="uz_UZ">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="<?php echo $__env->yieldContent('title', 'AMBARELLA'); ?>">
  <meta name="twitter:description" content="<?php echo $__env->yieldContent('description', 'O\'zbekiston yoshlari uchun platforma'); ?>">
  <link rel="icon" type="image/svg+xml" href="/assets/icons/favicon.svg">
  <link rel="apple-touch-icon" href="/assets/icons/apple-touch-icon.png">
  <link rel="manifest" href="/manifest.json">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/css/effects.css">
  <script src="/js/lang.js" defer></script>
  <script src="/js/effects.js" defer></script>
  <style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',sans-serif;color:#e2e8f0;line-height:1.7;background:#0f172a}
img{max-width:100%;display:block}a{text-decoration:none;color:inherit}ul{list-style:none}
button{border:none;background:none;cursor:pointer;font:inherit}
/* Custom Scrollbar */
::-webkit-scrollbar{width:8px;height:8px}
::-webkit-scrollbar-track{background:rgba(15,23,42,.5)}
::-webkit-scrollbar-thumb{background:linear-gradient(180deg,#2563eb,#7c3aed);border-radius:10px;border:2px solid transparent;background-clip:padding-box}
::-webkit-scrollbar-thumb:hover{background:linear-gradient(180deg,#3b82f6,#8b5cf6);border:1px solid transparent;background-clip:padding-box}
::-webkit-scrollbar-corner{background:transparent}
/* Firefox scrollbar */
html{scrollbar-width:thin;scrollbar-color:#2563eb rgba(15,23,42,.5)}
:root{--primary:#2563eb;--primary-dark:#1d4ed8;--success:#16a34a;--warning:#f59e0b;--danger:#dc2626;--purple:#7c3aed;--dark:#0f172a;--surface:rgba(255,255,255,.03);--border:rgba(255,255,255,.08);--muted:#64748b;--radius:16px;--container:1200px}
.container{max-width:var(--container);margin:0 auto;padding:0 16px}
@media(min-width:640px){.container{padding:0 20px}}
@media(min-width:1024px){.container{padding:0 24px}}
/* Buttons with glow */
.btn{display:inline-flex;align-items:center;gap:8px;padding:12px 24px;border-radius:var(--radius);font-weight:600;font-size:14px;transition:all .3s cubic-bezier(.4,0,.2,1);position:relative}
.btn-primary{background:var(--primary);color:#fff;box-shadow:0 4px 14px rgba(37,99,235,.25)}.btn-primary:hover{background:var(--primary-dark);transform:translateY(-2px);box-shadow:0 8px 25px rgba(37,99,235,.35)}
.btn-outline{border:1px solid var(--border);color:#94a3b8;background:var(--surface)}.btn-outline:hover{border-color:var(--primary);color:#fff;background:rgba(37,99,235,.05);transform:translateY(-1px)}
.btn-success{background:var(--success);color:#fff;box-shadow:0 4px 14px rgba(22,163,74,.25)}.btn-success:hover{background:#15803d;transform:translateY(-2px)}
.btn-danger{background:var(--danger);color:#fff}.btn-danger:hover{background:#b91c1c}
/* Global page transitions */
@keyframes pageIn{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
main{animation:pageIn .5s ease}
/* Smooth scroll indicator */
body::before{content:'';position:fixed;top:0;left:0;width:var(--scroll-pct,0%);height:3px;background:linear-gradient(90deg,var(--primary),var(--purple),#ec4899);z-index:9999;transition:width .1s}
/* Glowing card borders on hover */
.glow-card{position:relative;overflow:hidden;transition:all .4s cubic-bezier(.4,0,.2,1)}
.glow-card:hover{transform:translateY(-4px);box-shadow:0 20px 40px rgba(37,99,235,.06)}
.glow-card::before{content:'';position:absolute;inset:-1px;border-radius:inherit;background:linear-gradient(135deg,rgba(37,99,235,.3),rgba(139,92,246,.2),rgba(236,72,153,.2));opacity:0;transition:opacity .4s;z-index:-1}
.glow-card:hover::before{opacity:1}
/* Particle dots background */
body::after{content:'';position:fixed;inset:0;background-image:radial-gradient(rgba(255,255,255,.015) 1px,transparent 1px);background-size:40px 40px;pointer-events:none;z-index:-1}
.header{position:sticky;top:0;z-index:100;background:rgba(15,23,42,.9);backdrop-filter:blur(20px) saturate(180%);border-bottom:1px solid var(--border);padding:14px 0;transition:all .3s}
.header .container{display:flex;align-items:center;justify-content:space-between}
.logo{display:flex;align-items:center;gap:10px;font-size:18px;font-weight:800;color:#fff;transition:transform .2s}
.logo:hover{transform:scale(1.02)}
.logo-icon{width:36px;height:36px;background:linear-gradient(135deg,#2563eb,#7c3aed);border-radius:9px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;font-size:15px;box-shadow:0 4px 12px rgba(37,99,235,.3)}
.nav{display:flex;align-items:center;gap:24px}.nav a{font-size:13px;font-weight:500;color:var(--muted);transition:all .2s;position:relative}.nav a:hover,.nav a.active{color:#fff}
.nav a.active::after{content:'';position:absolute;bottom:-4px;left:50%;transform:translateX(-50%);width:16px;height:2px;background:var(--primary);border-radius:2px}
.header-actions{display:flex;align-items:center;gap:10px}
.lang-switch{display:flex;gap:3px;margin-right:6px}
.lang-btn{padding:4px 8px;border-radius:6px;font-size:11px;font-weight:600;background:var(--surface);color:var(--muted);border:1px solid var(--border);cursor:pointer;transition:all .2s}
.lang-btn.active{background:rgba(37,99,235,.15);color:#93c5fd;border-color:rgba(37,99,235,.3)}
.footer{background:linear-gradient(180deg,#020617 0%,#0a0f1f 100%);border-top:1px solid var(--border);color:var(--muted);padding:40px 0;margin-top:64px;text-align:center;font-size:13px;position:relative}
.footer::before{content:'';position:absolute;top:0;left:50%;transform:translateX(-50%);width:200px;height:1px;background:linear-gradient(90deg,transparent,var(--primary),transparent)}
.alert{padding:12px 20px;border-radius:var(--radius);margin-bottom:16px;font-size:14px}
.alert-success{background:rgba(22,163,74,.06);color:#4ade80;border:1px solid rgba(22,163,74,.15)}
.alert-error{background:rgba(220,38,38,.06);color:#fca5a5;border:1px solid rgba(220,38,38,.15)}
.announcement-bar{padding:10px 0;font-size:13px;font-weight:500;text-align:center}
.announcement-info{background:rgba(37,99,235,.08);color:#93c5fd;border-bottom:1px solid rgba(37,99,235,.15)}
.announcement-warning{background:rgba(245,158,11,.08);color:#fbbf24;border-bottom:1px solid rgba(245,158,11,.15)}
.announcement-success{background:rgba(22,163,74,.08);color:#4ade80;border-bottom:1px solid rgba(22,163,74,.15)}
.skip-link{position:absolute;top:-40px;left:0;background:var(--primary);color:#fff;padding:8px 16px;z-index:1000;transition:top .2s}
.skip-link:focus{top:0}
/* Animated SVG Icons */
.icon-svg{transition:transform .3s,color .3s}
.icon-svg.pulse{animation:icon-pulse 2s ease-in-out infinite}
.icon-svg.bounce{animation:icon-bounce 1s ease infinite}
.icon-svg.spin{animation:icon-spin 3s linear infinite}
.icon-svg.float{animation:icon-float 3s ease-in-out infinite}
@keyframes icon-pulse{0%,100%{transform:scale(1);opacity:1}50%{transform:scale(1.15);opacity:.8}}
@keyframes icon-bounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-4px)}}
@keyframes icon-spin{to{transform:rotate(360deg)}}
@keyframes icon-float{0%,100%{transform:translateY(0)}50%{transform:translateY(-6px)}}
.stat-icon-wrap{width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center;margin-bottom:10px}
.stat-icon-wrap.blue{background:rgba(37,99,235,.12);color:#60a5fa}
.stat-icon-wrap.green{background:rgba(22,163,74,.12);color:#4ade80}
.stat-icon-wrap.yellow{background:rgba(245,158,11,.12);color:#fbbf24}
.stat-icon-wrap.purple{background:rgba(124,58,237,.12);color:#a78bfa}
.stat-icon-wrap.red{background:rgba(220,38,38,.12);color:#f87171}
.stat-icon-wrap.cyan{background:rgba(8,145,178,.12);color:#22d3ee}
/* Mobile handled via horizontal scroll nav */
.menu-btn{display:none;width:40px;height:40px;flex-direction:column;gap:5px;align-items:center;justify-content:center;cursor:pointer;border-radius:10px;border:1px solid var(--border);background:var(--surface);flex-shrink:0}
.menu-btn span{display:block;width:18px;height:2px;background:#e2e8f0;border-radius:2px;transition:all .3s}
.menu-btn.open span:nth-child(1){transform:translateY(7px) rotate(45deg)}
.menu-btn.open span:nth-child(2){opacity:0;transform:scaleX(0)}
.menu-btn.open span:nth-child(3){transform:translateY(-7px) rotate(-45deg)}
/* Mobile drawer */
.overlay{position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:199;opacity:0;visibility:hidden;transition:all .3s}
.overlay.open{opacity:1;visibility:visible}
.mobile-nav{position:fixed;top:0;left:0;bottom:0;width:min(280px,80vw);background:#080f1e;border-right:1px solid var(--border);z-index:200;transform:translateX(-100%);transition:transform .3s cubic-bezier(.4,0,.2,1);display:flex;flex-direction:column;overflow-y:auto}
.mobile-nav.open{transform:translateX(0)}
.mn-header{display:flex;align-items:center;justify-content:space-between;padding:18px 20px;border-bottom:1px solid var(--border)}
.mn-close{width:36px;height:36px;display:flex;align-items:center;justify-content:center;color:var(--muted);font-size:22px;cursor:pointer;background:none;border:none}
.mn-links{padding:12px;flex:1}
.mn-link{display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:10px;font-size:14px;font-weight:500;color:#94a3b8;transition:all .2s;margin-bottom:2px}
.mn-link:hover,.mn-link.active{background:rgba(37,99,235,.08);color:#fff}
.mn-link svg{width:18px;height:18px;stroke:currentColor;fill:none;stroke-width:1.8;flex-shrink:0}
.mn-divider{height:1px;background:var(--border);margin:8px 4px}
.mn-section{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;color:var(--muted);padding:8px 14px;margin-top:4px}
.mn-footer{padding:16px;border-top:1px solid var(--border)}
/* Desktop */
@media(min-width:769px){.menu-btn{display:none!important}}
/* Mobile */
@media(max-width:768px){
  .nav{display:none}
  .menu-btn{display:flex!important}
  .header-actions .lang-switch,.header-actions .theme-toggle-btn{display:none}
  .header-actions .btn{font-size:12px;padding:8px 14px}
}
/* ===== GLOBAL MOBILE HELPERS ===== */
@media(max-width:480px){
  .btn{padding:10px 16px;font-size:13px}
  .btn-primary,.btn-outline,.btn-success{min-height:44px}
}

/* ===== GLOBAL RESPONSIVE GRID UTILS ===== */
/* 2-col grid → 1-col on mobile */
@media(max-width:640px){
  [class*="grid-cols-2"],[class*="grid-2"]{grid-template-columns:1fr!important}
  [class*="grid-cols-3"],[class*="grid-3"]{grid-template-columns:1fr!important}
  [class*="grid-cols-4"],[class*="grid-4"]{grid-template-columns:1fr 1fr!important}
}
/* Font sizes mobile */
@media(max-width:480px){
  h1{font-size:clamp(22px,7vw,32px)!important}
  h2{font-size:clamp(18px,6vw,26px)!important}
}
/* Tables — horizontal scroll on mobile */
.table-wrap{overflow-x:auto;-webkit-overflow-scrolling:touch}
/* Forms mobile */
@media(max-width:480px){
  input,select,textarea{font-size:16px!important} /* prevents iOS zoom */
}
/* Sidebar layouts → stack on mobile */
.dash-layout,.admin-layout{display:block!important}
.dash-sidebar,.admin-sidebar{display:none!important}
@media(min-width:1024px){
  .dash-layout{display:grid!important;grid-template-columns:260px 1fr}
  .dash-sidebar{display:flex!important;flex-direction:column}
  .admin-layout{display:grid!important;grid-template-columns:270px 1fr}
  .admin-sidebar{display:flex!important;flex-direction:column}
}
/* Dashboard main padding */
@media(max-width:768px){
  .dash-main{padding:20px 16px!important}
  .admin-main{padding:20px 16px!important}
}
/* Module cards min-width */
@media(max-width:640px){
  .mod-grid{grid-template-columns:1fr!important}
  .mod-card{padding:18px!important}
}
/* Job cards */
@media(max-width:640px){
  .job-card{grid-template-columns:1fr!important}
  .jc-right{flex-direction:row!important;flex-wrap:wrap;align-items:flex-start!important;text-align:left!important}
  .job-layout{grid-template-columns:1fr!important}
  .job-sidebar{position:static!important}
}
/* Academy */
@media(max-width:640px){
  .courses-grid{grid-template-columns:1fr 1fr!important}
  .cp-layout{grid-template-columns:1fr!important}
  .cp-sidebar{position:static!important}
  .ah-inner{grid-template-columns:1fr!important}
  .academy-search-card{display:block!important}
}
@media(max-width:400px){
  .courses-grid{grid-template-columns:1fr!important}
}
/* Eco */
@media(max-width:768px){
  .eco-layout{grid-template-columns:1fr!important}
  .eco-hero-inner{grid-template-columns:1fr!important}
  .eco-global-stats{grid-template-columns:1fr 1fr!important}
  .eco-categories{flex-direction:row!important;flex-wrap:wrap;position:static!important;gap:6px}
  .eco-user-banner{flex-wrap:wrap;gap:12px}
  .eub-divider{display:none}
}
@media(max-width:480px){
  .eco-global-stats{grid-template-columns:1fr 1fr!important}
  .etc-main{grid-template-columns:1fr!important}
  .etc-right{flex-direction:row!important;flex-wrap:wrap;align-items:center}
}
/* Mentor */
@media(max-width:640px){
  .mentors-grid{grid-template-columns:1fr!important}
  .mh-inner{grid-template-columns:1fr!important}
}
/* GreenCoin */
@media(max-width:640px){
  .gc-hero{grid-template-columns:1fr!important}
  .gc-stats{grid-template-columns:1fr 1fr!important}
  .gc-actions{grid-template-columns:1fr!important}
}
/* Hero sections */
@media(max-width:768px){
  .hero-content{grid-template-columns:1fr!important;text-align:center}
  .hero-visual{display:none!important}
  .hero-desc{margin-left:auto!important;margin-right:auto!important}
  .hero-btns{justify-content:center!important}
  .hero-stats-bar{grid-template-columns:repeat(3,1fr)!important}
  .jobs-hero-inner{grid-template-columns:1fr!important}
  .search-box{display:block!important}
  .jobs-stats-mini{justify-content:center}
  .mh-inner{grid-template-columns:1fr!important}
  .mentor-filters{display:none}
  .concept-row{grid-template-columns:1fr!important}
  .panel-preview{grid-template-columns:1fr!important}
  .flow-grid{grid-template-columns:1fr 1fr!important}
  .flow-step::after{display:none}
  .results-row{grid-template-columns:1fr 1fr 1fr!important}
  .ben-grid{grid-template-columns:1fr!important}
}
@media(max-width:480px){
  .hero-stats-bar{grid-template-columns:1fr 1fr!important}
  .results-row{grid-template-columns:1fr 1fr!important}
  .flow-grid{grid-template-columns:1fr!important}
}
/* Admin stats */
@media(max-width:768px){
  .crm-stats{grid-template-columns:1fr 1fr!important}
  .qa-grid{grid-template-columns:1fr 1fr 1fr!important}
  .admin-grid{grid-template-columns:1fr!important}
}
@media(max-width:480px){
  .crm-stats{grid-template-columns:1fr 1fr!important}
  .qa-grid{grid-template-columns:1fr 1fr!important}
}
/* Dash stats */
@media(max-width:640px){
  .dash-stats{grid-template-columns:1fr 1fr!important}
  .dash-grid{grid-template-columns:1fr!important}
  .dash-modules{grid-template-columns:repeat(4,1fr)!important}
}
@media(max-width:400px){
  .dash-modules{grid-template-columns:repeat(3,1fr)!important}
  .dash-stats{grid-template-columns:1fr 1fr!important}
}
/* Settings */
@media(max-width:640px){
  .settings-content{grid-template-columns:1fr!important}
  .s-row{grid-template-columns:1fr!important}
}
/* Forum */
@media(max-width:640px){
  .forum-page{padding:20px 0 60px!important;max-width:100%}
  .q-header,.q-body{padding:16px!important}
  .reply-card{padding:16px!important}
}
/* Mobile bottom nav safe area */
@media(max-width:768px){
  .footer{margin-bottom:72px}
  main{padding-bottom:4px}
}
/* Dark theme native - no overrides needed */
.theme-toggle-btn{background:none;border:1px solid var(--border);border-radius:8px;padding:6px;color:var(--muted);cursor:pointer;display:flex;align-items:center;transition:all .2s;margin-right:6px}
.theme-toggle-btn:hover{color:#fbbf24;border-color:rgba(245,158,11,.3)}
.light-mode .theme-icon-dark{display:none}
.light-mode .theme-icon-light{display:block!important}
/* Light Mode Full Override */
.light-mode{--surface:rgba(0,0,0,.02);--border:rgba(0,0,0,.08);--muted:#64748b;--dark:#f8fafc}
.light-mode .header{background:rgba(255,255,255,.95);border-bottom-color:rgba(0,0,0,.06)}
.light-mode .nav a{color:#475569}.light-mode .nav a:hover,.light-mode .nav a.active{color:#0f172a}
.light-mode .logo{color:#0f172a}
.light-mode .footer{background:linear-gradient(180deg,#f1f5f9,#e2e8f0);color:#64748b}
.light-mode .alert-success{background:rgba(22,163,74,.04);border-color:rgba(22,163,74,.12)}
.light-mode .alert-error{background:rgba(220,38,38,.04);border-color:rgba(220,38,38,.12)}
/* MOBILE BOTTOM NAV */
.mobile-bottom-nav{display:none;position:fixed;bottom:0;left:0;right:0;z-index:100;background:rgba(15,23,42,.95);backdrop-filter:blur(16px);border-top:1px solid var(--border);padding:6px 0 env(safe-area-inset-bottom,6px);justify-content:space-around}
.mobile-bottom-nav a{display:flex;flex-direction:column;align-items:center;gap:3px;padding:6px 12px;color:var(--muted);font-size:10px;font-weight:500;transition:color .2s;text-decoration:none}
.mobile-bottom-nav a.active{color:#60a5fa}
.mobile-bottom-nav a svg{width:22px;height:22px;stroke:currentColor;stroke-width:1.8;fill:none}
/* AI FAB */
.ai-fab{position:fixed;bottom:80px;right:20px;width:52px;height:52px;border-radius:50%;background:linear-gradient(135deg,#2563eb,#7c3aed);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;z-index:90;box-shadow:0 4px 20px rgba(37,99,235,.4);transition:all .3s}
.ai-fab:hover{transform:scale(1.1);box-shadow:0 6px 28px rgba(37,99,235,.5)}
.ai-fab.hidden{display:none}
.ai-fab svg{width:24px;height:24px;stroke:#fff;stroke-width:2;fill:none}
/* AI CHAT BOX */
.ai-chat-box{position:fixed;bottom:80px;right:20px;width:340px;max-height:480px;background:rgba(15,23,42,.98);backdrop-filter:blur(16px);border:1px solid var(--border);border-radius:var(--radius);z-index:95;display:none;flex-direction:column;box-shadow:0 12px 48px rgba(0,0,0,.5)}
.ai-chat-box.open{display:flex}
.ai-chat-header{display:flex;justify-content:space-between;align-items:center;padding:14px 16px;border-bottom:1px solid var(--border)}
.ai-chat-title{display:flex;align-items:center;gap:8px;font-size:14px;font-weight:600;color:#fff}
.ai-chat-body{flex:1;overflow-y:auto;padding:16px;display:flex;flex-direction:column;gap:10px;max-height:320px}
.ai-msg{padding:10px 14px;border-radius:12px;font-size:13px;line-height:1.6;max-width:85%}
.ai-msg-bot{background:var(--surface);border:1px solid var(--border);color:#cbd5e1;align-self:flex-start}
.ai-msg-user{background:rgba(37,99,235,.15);color:#fff;align-self:flex-end;border:1px solid rgba(37,99,235,.2)}
.ai-chat-input{display:flex;gap:8px;padding:12px 14px;border-top:1px solid var(--border)}
.ai-chat-input input{flex:1;padding:10px 14px;border:1px solid var(--border);border-radius:10px;background:var(--surface);color:#fff;font-size:13px}
.ai-chat-input input::placeholder{color:#475569}
.ai-chat-input button{width:36px;height:36px;border-radius:10px;background:var(--primary);border:none;display:flex;align-items:center;justify-content:center;cursor:pointer}
@media(max-width:768px){
  .mobile-bottom-nav{display:flex}
  .footer{margin-bottom:60px}
  .ai-fab{bottom:76px;right:16px;width:46px;height:46px}
  .ai-fab svg{width:20px;height:20px}
  .ai-chat-box{bottom:76px;right:10px;left:10px;width:auto;max-height:60vh}
}
@media(min-width:769px){
  .ai-fab{bottom:24px;right:24px}
  .ai-chat-box{bottom:24px;right:24px}
}
  </style>
  <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
  <a href="#main-content" class="skip-link">Asosiy kontentga o'tish</a>

  <header class="header"><div class="container">
    <a href="/" class="logo"><div class="logo-icon">A</div>AMBARELLA</a>
    <nav class="nav">
      <a href="/" class="<?php echo e(request()->is('/') ? 'active' : ''); ?>">Bosh sahifa</a>
      <a href="/jobs" class="<?php echo e(request()->is('jobs*') ? 'active' : ''); ?>">Bandlik</a>
      <a href="/eco" class="<?php echo e(request()->is('eco*') ? 'active' : ''); ?>">Ekologiya</a>
      <a href="/academy" class="<?php echo e(request()->is('academy*') ? 'active' : ''); ?>">Academy</a>
      <a href="/mentor" class="<?php echo e(request()->is('mentor*') ? 'active' : ''); ?>">Mentorlik</a>
      <a href="/farm" class="<?php echo e(request()->is('farm*') ? 'active' : ''); ?>">Qishloq</a>
      <a href="/news" class="<?php echo e(request()->is('news*') ? 'active' : ''); ?>">Yangiliklar</a>
    </nav>
    <div class="header-actions">
      <button class="theme-toggle-btn" onclick="toggleTheme()" title="Tema" aria-label="Tema">
        <svg class="theme-icon-dark" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"/></svg>
        <svg class="theme-icon-light" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display:none"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/></svg>
      </button>
      <div class="lang-switch">
        <button class="lang-btn active" data-lang="uz" onclick="setLang('uz')">UZ</button>
        <button class="lang-btn" data-lang="ru" onclick="setLang('ru')">RU</button>
        <button class="lang-btn" data-lang="en" onclick="setLang('en')">EN</button>
      </div>
      <?php if(auth()->guard()->check()): ?>
        <?php if(auth()->user()->isAdmin()): ?><a href="/admin" class="btn" style="color:var(--danger);font-size:12px;padding:8px 12px">Admin</a><?php endif; ?>
        <a href="/dashboard" class="btn btn-outline" style="padding:8px 16px;font-size:12px">Dashboard</a>
        <form action="/logout" method="POST" style="display:inline"><?php echo csrf_field(); ?><button type="submit" class="btn" style="color:var(--muted);font-size:12px">Chiqish</button></form>
      <?php else: ?>
        <a href="/login" class="btn btn-outline" style="padding:8px 16px;font-size:12px">Kirish</a>
        <a href="/register" class="btn btn-primary" style="padding:8px 16px;font-size:12px">Ro'yxatdan o'tish</a>
      <?php endif; ?>
      
      <button class="menu-btn" id="menuBtn" aria-label="Menyu">
        <span></span><span></span><span></span>
      </button>
    </div>
  </div></header>

  
  <div class="overlay" id="overlay" onclick="closeNav()"></div>

  
  <nav class="mobile-nav" id="mobileNav">
    <div class="mn-header">
      <a href="/" class="logo" onclick="closeNav()"><div class="logo-icon">A</div>AMBARELLA</a>
      <button class="mn-close" onclick="closeNav()" aria-label="Yopish">&times;</button>
    </div>
    <div class="mn-links">
      <div class="mn-section">Modullar</div>
      <a href="/" class="mn-link <?php echo e(request()->is('/') ? 'active' : ''); ?>" onclick="closeNav()">
        <svg viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>Bosh sahifa
      </a>
      <a href="/jobs" class="mn-link <?php echo e(request()->is('jobs*') ? 'active' : ''); ?>" onclick="closeNav()">
        <svg viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/></svg>Bandlik
      </a>
      <a href="/eco" class="mn-link <?php echo e(request()->is('eco*') ? 'active' : ''); ?>" onclick="closeNav()">
        <svg viewBox="0 0 24 24"><path d="M12 22c4-2.5 7-6 7-10a7 7 0 00-14 0c0 4 3 7.5 7 10z"/></svg>Ekologiya
      </a>
      <a href="/academy" class="mn-link <?php echo e(request()->is('academy*') ? 'active' : ''); ?>" onclick="closeNav()">
        <svg viewBox="0 0 24 24"><path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z"/><path d="M22 3h-6a4 4 0 00-4 4v14a3 3 0 013-3h7z"/></svg>Academy
      </a>
      <a href="/mentor" class="mn-link <?php echo e(request()->is('mentor*') ? 'active' : ''); ?>" onclick="closeNav()">
        <svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>Mentorlik
      </a>
      <a href="/farm" class="mn-link <?php echo e(request()->is('farm*') ? 'active' : ''); ?>" onclick="closeNav()">
        <svg viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/></svg>Qishloq
      </a>
      <a href="/startup" class="mn-link <?php echo e(request()->is('startup*') ? 'active' : ''); ?>" onclick="closeNav()">
        <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>Startup
      </a>
      <a href="/events" class="mn-link <?php echo e(request()->is('events*') ? 'active' : ''); ?>" onclick="closeNav()">
        <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>Tadbirlar
      </a>
      <a href="/challenges" class="mn-link <?php echo e(request()->is('challenges*') ? 'active' : ''); ?>" onclick="closeNav()">
        <svg viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>Musobaqalar
      </a>
      <a href="/news" class="mn-link <?php echo e(request()->is('news*') ? 'active' : ''); ?>" onclick="closeNav()">
        <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>Yangiliklar
      </a>
      <?php if(auth()->guard()->check()): ?>
      <div class="mn-divider"></div>
      <div class="mn-section">Mening sahifam</div>
      <a href="/dashboard" class="mn-link <?php echo e(request()->is('dashboard*') ? 'active' : ''); ?>" onclick="closeNav()">
        <svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>Dashboard
      </a>
      <a href="/greencoin" class="mn-link" onclick="closeNav()">
        <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 6v12M8 10h8"/></svg>GreenCoin
      </a>
      <a href="/daily-tasks" class="mn-link" onclick="closeNav()">
        <svg viewBox="0 0 24 24"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></svg>Kundalik vazifalar
      </a>
      <a href="/my-applications" class="mn-link" onclick="closeNav()">
        <svg viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/></svg>Arizalarim
      </a>
      <a href="/notifications" class="mn-link" onclick="closeNav()">
        <svg viewBox="0 0 24 24"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>Bildirishnomalar
      </a>
      <a href="/settings" class="mn-link" onclick="closeNav()">
        <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4"/></svg>Sozlamalar
      </a>
      <?php endif; ?>
    </div>
    <div class="mn-footer">
      <?php if(auth()->guard()->check()): ?>
        <div style="font-size:12px;color:var(--muted);margin-bottom:10px"><?php echo e(auth()->user()->name); ?></div>
        <form action="/logout" method="POST"><?php echo csrf_field(); ?><button type="submit" class="btn btn-outline" style="width:100%;justify-content:center;padding:10px;font-size:13px">Chiqish</button></form>
      <?php else: ?>
        <a href="/login" class="btn btn-outline" style="width:100%;justify-content:center;margin-bottom:8px">Kirish</a>
        <a href="/register" class="btn btn-primary" style="width:100%;justify-content:center">Ro'yxatdan o'tish</a>
      <?php endif; ?>
    </div>
  </nav>

  <?php if(session('success')): ?>
    <div class="container" style="margin-top:16px"><div class="alert alert-success"><?php echo e(session('success')); ?></div></div>
  <?php endif; ?>
  <?php if($errors->any()): ?>
    <div class="container" style="margin-top:16px"><div class="alert alert-error"><?php echo e($errors->first()); ?></div></div>
  <?php endif; ?>

  
  <?php try { $announcement = \App\Models\Announcement::where('is_active', true)->where(function($q){ $q->whereNull('starts_at')->orWhere('starts_at', '<=', now()); })->where(function($q){ $q->whereNull('ends_at')->orWhere('ends_at', '>=', now()); })->first(); } catch (\Exception $e) { $announcement = null; } ?>
  <?php if($announcement): ?>
  <div class="announcement-bar announcement-<?php echo e($announcement->type); ?>" id="announcementBar">
    <div class="container" style="display:flex;align-items:center;justify-content:center;gap:8px">
      <span><?php echo e($announcement->message); ?></span>
      <button onclick="document.getElementById('announcementBar').remove()" style="color:inherit;font-size:18px;opacity:.6">&times;</button>
    </div>
  </div>
  <?php endif; ?>

  <main id="main-content"><?php echo $__env->yieldContent('content'); ?></main>

  <footer class="footer"><div class="container">© 2026 SADAF DEV | AMBARELLA | Barcha huquqlar himoyalangan | +998 90 074 10 70</div></footer>

  <?php if ($__env->exists('components.cookie-consent')) echo $__env->make('components.cookie-consent', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  
  <nav class="mobile-bottom-nav" id="mobileBottomNav">
    <a href="/" class="<?php echo e(request()->is('/') ? 'active' : ''); ?>">
      <svg viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
      <span>Bosh</span>
    </a>
    <a href="/jobs" class="<?php echo e(request()->is('jobs*') ? 'active' : ''); ?>">
      <svg viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/></svg>
      <span>Ish</span>
    </a>
    <a href="/eco" class="<?php echo e(request()->is('eco*') ? 'active' : ''); ?>">
      <svg viewBox="0 0 24 24"><path d="M12 22c4-2.5 7-6 7-10a7 7 0 00-14 0c0 4 3 7.5 7 10z"/></svg>
      <span>Eco</span>
    </a>
    <?php if(auth()->guard()->check()): ?>
    <a href="/dashboard" class="<?php echo e(request()->is('dashboard*') ? 'active' : ''); ?>">
      <svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
      <span>Panel</span>
    </a>
    <?php else: ?>
    <a href="/login" class="<?php echo e(request()->is('login') ? 'active' : ''); ?>">
      <svg viewBox="0 0 24 24"><path d="M15 3h4a2 2 0 012 2v14a2 2 0 01-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/></svg>
      <span>Kirish</span>
    </a>
    <?php endif; ?>
    <button onclick="openNav()" class="<?php echo e(''); ?>" style="display:flex;flex-direction:column;align-items:center;gap:3px;padding:6px 12px;color:var(--muted);font-size:10px;font-weight:500;background:none;border:none;cursor:pointer">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
      <span>Menu</span>
    </button>
  </nav>

  
  <div class="ai-fab" id="aiFab" onclick="toggleAiChat()">
    <svg viewBox="0 0 24 24"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
  </div>

  
  <div class="ai-chat-box" id="aiChatBox">
    <div class="ai-chat-header">
      <div class="ai-chat-title"><svg viewBox="0 0 24 24" style="width:18px;height:18px;stroke:#60a5fa;fill:none;stroke-width:2"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg> AI Yordamchi</div>
      <button onclick="toggleAiChat()" style="background:none;border:none;color:var(--muted);font-size:20px;cursor:pointer">&times;</button>
    </div>
    <div class="ai-chat-body" id="aiChatBody">
      <div class="ai-msg ai-msg-bot">Salom! Men AMBARELLA AI yordamchisiman. Platforma haqida savollaringiz bo'lsa yozing. Javob topolmasam, menejerga yo'naltiraman.</div>
    </div>
    <div class="ai-chat-input">
      <input type="text" id="aiInput" placeholder="Savolingizni yozing..." onkeypress="if(event.key==='Enter')sendAiMsg()">
      <button onclick="sendAiMsg()"><svg viewBox="0 0 24 24" style="width:18px;height:18px;stroke:#fff;fill:none;stroke-width:2"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9"/></svg></button>
    </div>
  </div>

  <script>
  // Theme toggle
  function toggleTheme(){
    document.body.classList.toggle('light-mode');
    const isLight=document.body.classList.contains('light-mode');
    localStorage.setItem('ambarella_theme',isLight?'light':'dark');
    if(isLight){
      document.body.style.background='#f8fafc';
      document.body.style.color='#1e293b';
    }else{
      document.body.style.background='#0f172a';
      document.body.style.color='#e2e8f0';
    }
  }
  (function(){
    const saved=localStorage.getItem('ambarella_theme');
    if(saved==='light'){
      document.body.classList.add('light-mode');
      document.body.style.background='#f8fafc';
      document.body.style.color='#1e293b';
    }
  })();

  (function(){
    // Mobile nav drawer
    const menuBtn = document.getElementById('menuBtn');
    const mobileNav = document.getElementById('mobileNav');
    const overlay = document.getElementById('overlay');

    window.closeNav = function() {
      if (!mobileNav) return;
      mobileNav.classList.remove('open');
      if (overlay) overlay.classList.remove('open');
      if (menuBtn) menuBtn.classList.remove('open');
      document.body.style.overflow = '';
    };

    window.openNav = function() {
      if (!mobileNav) return;
      mobileNav.classList.add('open');
      if (overlay) overlay.classList.add('open');
      if (menuBtn) menuBtn.classList.add('open');
      document.body.style.overflow = 'hidden';
    };

    if (menuBtn) {
      menuBtn.addEventListener('click', function() {
        mobileNav && mobileNav.classList.contains('open') ? closeNav() : openNav();
      });
    }

    // Close on resize to desktop
    window.addEventListener('resize', function() {
      if (window.innerWidth > 768) closeNav();
    });

    // Scroll progress
    window.addEventListener('scroll', function() {
      const pct = (window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100;
      document.body.style.setProperty('--scroll-pct', pct + '%');
    });
  })();

  // AI Chat
  function toggleAiChat(){
    const box=document.getElementById('aiChatBox');
    const fab=document.getElementById('aiFab');
    box.classList.toggle('open');
    fab.classList.toggle('hidden');
  }

  const aiKnowledge={
    'ish':'Ish e\'lonlarini /jobs sahifasida topishingiz mumkin. Filtr orqali soha, joylashuv va maosh bo\'yicha qidiring.',
    'kurs':'Kurslarni /academy sahifasida ko\'ring. Bepul va pullik kurslar mavjud.',
    'eco':'Ekologiya moduli /eco sahifasida. Kundalik vazifalar bajaring va GreenCoin ishlang.',
    'mentor':'Mentorlarni /mentor sahifasida ko\'ring. So\'rov yuboring va 1:1 sessiya oling.',
    'greencoin':'GreenCoin — ekologik faoliyat uchun virtual mukofot. /eco sahifasida vazifalar bajaring.',
    'farm':'Qishloq mahsulotlari /farm sahifasida. Fermerlar o\'z mahsulotlarini sotishi mumkin.',
    'startup':'Startup inkubator /startup sahifasida. Biznes-reja, mentorlar, hackathonlar.',
    'ro\'yxat':'Ro\'yxatdan o\'tish uchun /register sahifasiga o\'ting. Email yoki Telegram orqali.',
    'login':'Tizimga kirish uchun /login sahifasiga o\'ting.',
    'profil':'Profil sozlamalari /profile sahifasida.',
    'telegram':'Telegram orqali kirish mumkin. Login sahifasida Telegram bo\'limini ko\'ring.',
    'parol':'Parolni tiklash uchun /forgot-password sahifasiga o\'ting.',
    'bepul':'Platformaning barcha asosiy xizmatlari bepul. Yashirin to\'lovlar yo\'q.',
    'aloqa':'Biz bilan bog\'lanish: +998 90 074 10 70, info@ambarella.uz, @AmbarellaBot',
  };

  function getAiReply(msg){
    const m=msg.toLowerCase();
    for(let key in aiKnowledge){
      if(m.includes(key))return aiKnowledge[key];
    }
    if(m.includes('salom')||m.includes('hello'))return'Salom! Qanday yordam bera olaman?';
    if(m.includes('rahmat'))return'Arzimaydi! Yana savol bo\'lsa yozing.';
    return null;
  }

  function sendAiMsg(){
    const input=document.getElementById('aiInput');
    const body=document.getElementById('aiChatBody');
    const msg=input.value.trim();
    if(!msg)return;
    body.innerHTML+=`<div class="ai-msg ai-msg-user">${msg}</div>`;
    input.value='';
    const reply=getAiReply(msg);
    setTimeout(()=>{
      if(reply){
        body.innerHTML+=`<div class="ai-msg ai-msg-bot">${reply}</div>`;
      }else{
        body.innerHTML+=`<div class="ai-msg ai-msg-bot">Bu savolga javob topolmadim. Menejer bilan bog'lanishingiz mumkin:<br><a href="https://t.me/AmbarellaBot" target="_blank" style="color:#60a5fa;font-weight:600">📱 Telegram: @AmbarellaBot</a><br><a href="tel:+998900741070" style="color:#4ade80;font-weight:600">📞 +998 90 074 10 70</a></div>`;
      }
      body.scrollTop=body.scrollHeight;
    },500);
    body.scrollTop=body.scrollHeight;
  }

  // Service Worker (PWA)
  if('serviceWorker' in navigator){
    window.addEventListener('load',()=>{
      navigator.serviceWorker.register('/service-worker.js')
        .then(reg=>{console.log('SW ok',reg.scope);initPush(reg)})
        .catch(e=>console.log('SW fail',e));
    });
  }

  // Push Notifications
  function initPush(reg){
    if(!('Notification' in window))return;
    // 30 soniyadan keyin ruxsat so'rash
    setTimeout(()=>{
      if(Notification.permission==='default'){
        Notification.requestPermission().then(p=>{
          if(p==='granted')console.log('Push notifications enabled');
        });
      }
    },30000);
  }

  // Language init
  document.addEventListener('DOMContentLoaded',()=>{
    const lang=localStorage.getItem('ambarella_lang')||'uz';
    document.querySelectorAll('.lang-btn').forEach(b=>{
      b.classList.toggle('active',b.dataset.lang===lang);
    });
    // Scroll progress
    window.addEventListener('scroll',()=>{
      const pct=(window.scrollY/(document.body.scrollHeight-window.innerHeight))*100;
      document.body.style.setProperty('--scroll-pct',pct+'%');
    });
    // Reveal on scroll (global)
    const revealObs=new IntersectionObserver(e=>{e.forEach(el=>{if(el.isIntersecting){el.target.style.opacity='1';el.target.style.transform='translateY(0)'}})},{threshold:.1,rootMargin:'0px 0px -40px 0px'});
    document.querySelectorAll('.stat-card,.panel,.mod-card,.course-card,.job-card,.mentor-card,.news-card,.task-card,.product-card,.eco-stat,.habit-card,.feature-card,.feat-card').forEach(el=>{
      el.style.opacity='0';el.style.transform='translateY(20px)';el.style.transition='opacity .6s ease, transform .6s ease';
      revealObs.observe(el);
    });

    // Lazy loading images
    document.querySelectorAll('img[data-src]').forEach(img=>{
      const io=new IntersectionObserver((entries,obs)=>{
        entries.forEach(e=>{if(e.isIntersecting){img.src=img.dataset.src;img.removeAttribute('data-src');obs.unobserve(img)}});
      });
      io.observe(img);
    });
  });
  </script>
</body>
</html>
<?php /**PATH /var/www/6a4e91db8a003/data/www/ambarella.uz/resources/views/layouts/app.blade.php ENDPATH**/ ?>