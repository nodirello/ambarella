
<?php $__env->startSection('title', 'Eslatmalar — Shaxsiy qaydlar | AMBARELLA'); ?>

<?php $__env->startSection('styles'); ?>
<style>
.notes-hero{padding:48px 0 32px;text-align:center}
.notes-hero h1{font-size:32px;font-weight:800;color:#fff;margin-bottom:8px}
.notes-hero p{color:var(--muted);font-size:15px}

.add-note-form{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:24px;margin-bottom:32px;max-width:600px;margin-left:auto;margin-right:auto}
.add-note-form h3{font-size:16px;font-weight:700;color:#fff;margin-bottom:16px;display:flex;align-items:center;gap:8px}
.add-note-form input,.add-note-form textarea{width:100%;padding:12px 16px;border-radius:12px;border:1px solid var(--border);background:rgba(255,255,255,.02);color:#fff;font-size:14px;font-family:inherit;margin-bottom:12px;transition:border-color .2s}
.add-note-form input:focus,.add-note-form textarea:focus{outline:none;border-color:var(--primary)}
.add-note-form textarea{min-height:100px;resize:vertical;line-height:1.6}
.add-note-form input::placeholder,.add-note-form textarea::placeholder{color:#475569}
.form-row{display:flex;gap:12px;align-items:center;flex-wrap:wrap}
.color-picker{display:flex;gap:8px}
.color-opt{width:28px;height:28px;border-radius:50%;cursor:pointer;border:2px solid transparent;transition:all .2s;position:relative}
.color-opt:hover{transform:scale(1.2)}
.color-opt.active{border-color:#fff;box-shadow:0 0 12px rgba(255,255,255,.3)}
.color-opt input{position:absolute;opacity:0;cursor:pointer}
.color-blue{background:#3b82f6}
.color-green{background:#22c55e}
.color-yellow{background:#eab308}
.color-purple{background:#a855f7}
.color-pink{background:#ec4899}

.notes-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:16px;margin-bottom:32px}
.note-card{border-radius:var(--radius);background:var(--surface);border:1px solid var(--border);overflow:hidden;transition:all .3s;position:relative}
.note-card:hover{transform:translateY(-3px);box-shadow:0 12px 32px rgba(0,0,0,.3)}
.note-strip{height:5px;width:100%}
.note-strip.blue{background:linear-gradient(90deg,#3b82f6,#60a5fa)}
.note-strip.green{background:linear-gradient(90deg,#22c55e,#4ade80)}
.note-strip.yellow{background:linear-gradient(90deg,#eab308,#facc15)}
.note-strip.purple{background:linear-gradient(90deg,#a855f7,#c084fc)}
.note-strip.pink{background:linear-gradient(90deg,#ec4899,#f472b6)}
.note-content{padding:16px 20px}
.note-title{font-size:15px;font-weight:700;color:#fff;margin-bottom:8px}
.note-text{font-size:13px;color:#94a3b8;line-height:1.6;word-wrap:break-word;max-height:120px;overflow:hidden}
.note-actions{display:flex;justify-content:space-between;align-items:center;padding:10px 20px;border-top:1px solid var(--border)}
.note-date{font-size:11px;color:var(--muted)}
.note-btns{display:flex;gap:8px}
.note-btn{width:30px;height:30px;border-radius:8px;display:flex;align-items:center;justify-content:center;border:1px solid var(--border);color:var(--muted);background:transparent;cursor:pointer;transition:all .2s}
.note-btn:hover{border-color:rgba(37,99,235,.3);color:#93c5fd}
.note-btn.pin-active{color:#fbbf24;border-color:rgba(245,158,11,.3)}
.note-btn.delete:hover{color:#f87171;border-color:rgba(220,38,38,.3)}
.pin-icon{position:absolute;top:12px;right:12px;color:#fbbf24;font-size:14px}
.empty-notes{text-align:center;padding:64px 24px;color:var(--muted)}
.empty-notes svg{width:64px;height:64px;margin-bottom:16px;opacity:.4}

@media(max-width:768px){
  .notes-grid{grid-template-columns:1fr}
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="notes-hero">
    <h1>📝 Eslatmalar</h1>
    <p>Shaxsiy qaydlaringiz — faqat siz ko'rasiz</p>
  </div>

  <div class="add-note-form">
    <h3>📌 Yangi eslatma</h3>
    <form action="<?php echo e(route('notes.store')); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <input type="text" name="title" placeholder="Sarlavha (ixtiyoriy)" value="<?php echo e(old('title')); ?>">
      <textarea name="content" placeholder="Eslatma matnini yozing..." required><?php echo e(old('content')); ?></textarea>
      <div class="form-row">
        <div class="color-picker">
          <label class="color-opt color-blue active" title="Moviy">
            <input type="radio" name="color" value="blue" checked>
          </label>
          <label class="color-opt color-green" title="Yashil">
            <input type="radio" name="color" value="green">
          </label>
          <label class="color-opt color-yellow" title="Sariq">
            <input type="radio" name="color" value="yellow">
          </label>
          <label class="color-opt color-purple" title="Binafsha">
            <input type="radio" name="color" value="purple">
          </label>
          <label class="color-opt color-pink" title="Pushti">
            <input type="radio" name="color" value="pink">
          </label>
        </div>
        <button type="submit" class="btn btn-primary" style="margin-left:auto">Saqlash</button>
      </div>
    </form>
  </div>

  <?php if($notes->count()): ?>
  <div class="notes-grid">
    <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="note-card">
      <div class="note-strip <?php echo e($note->color); ?>"></div>
      <?php if($note->is_pinned): ?>
        <span class="pin-icon">📌</span>
      <?php endif; ?>
      <div class="note-content">
        <?php if($note->title): ?>
          <div class="note-title"><?php echo e($note->title); ?></div>
        <?php endif; ?>
        <div class="note-text"><?php echo e($note->content); ?></div>
      </div>
      <div class="note-actions">
        <span class="note-date"><?php echo e($note->created_at->diffForHumans()); ?></span>
        <div class="note-btns">
          <form action="<?php echo e(route('notes.pin', $note)); ?>" method="POST" style="display:inline">
            <?php echo csrf_field(); ?>
            <button type="submit" class="note-btn <?php echo e($note->is_pinned ? 'pin-active' : ''); ?>" title="<?php echo e($note->is_pinned ? 'Qadalni olib tashlash' : 'Qadalgan qilish'); ?>">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="17" x2="12" y2="22"/><path d="M5 17h14v-1.76a2 2 0 00-1.11-1.79l-1.78-.9A2 2 0 0115 10.76V6h1a2 2 0 000-4H8a2 2 0 000 4h1v4.76a2 2 0 01-1.11 1.79l-1.78.9A2 2 0 005 15.24z"/></svg>
            </button>
          </form>
          <form action="<?php echo e(route('notes.destroy', $note)); ?>" method="POST" style="display:inline" onsubmit="return confirm('O\'chirilsinmi?')">
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            <button type="submit" class="note-btn delete" title="O'chirish">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2"/></svg>
            </button>
          </form>
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <?php else: ?>
  <div class="empty-notes">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
    <p>Hali eslatmalar yo'q. Yuqoridagi formadan yangi eslatma yarating!</p>
  </div>
  <?php endif; ?>
</div>

<script>
document.querySelectorAll('.color-opt').forEach(opt => {
  opt.addEventListener('click', function() {
    document.querySelectorAll('.color-opt').forEach(o => o.classList.remove('active'));
    this.classList.add('active');
  });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/6a4e91db8a003/data/www/ambarella.uz/resources/views/notes/index.blade.php ENDPATH**/ ?>