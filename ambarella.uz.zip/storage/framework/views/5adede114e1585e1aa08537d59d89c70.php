
<?php $__env->startSection('title', 'Yutuqlar & Darajalar | AMBARELLA'); ?>
<?php $__env->startSection('styles'); ?>
<style>
.ach-header{padding:32px 0;text-align:center}
.ach-header h1{font-size:28px;font-weight:800;color:#fff}
.ach-header p{color:var(--muted);font-size:14px;margin-top:6px}
.level-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:32px;margin-top:24px;text-align:center}
.level-badge{display:inline-flex;align-items:center;gap:8px;padding:8px 20px;border-radius:999px;font-size:16px;font-weight:800;margin-bottom:16px}
.level-info{color:var(--muted);font-size:13px;margin-bottom:16px}
.progress-bar{width:100%;max-width:400px;height:10px;background:rgba(255,255,255,.06);border-radius:99px;margin:0 auto;overflow:hidden}
.progress-fill{height:100%;border-radius:99px;transition:width .8s ease}
.progress-text{color:var(--muted);font-size:12px;margin-top:8px}
.badges-section{margin-top:32px}
.badges-section h3{font-size:18px;font-weight:700;color:#fff;margin-bottom:16px}
.badges-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:14px}
.badge-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:24px;text-align:center;transition:all .3s;position:relative;overflow:hidden}
.badge-card:hover{transform:translateY(-3px);border-color:rgba(37,99,235,.4)}
.badge-card.earned{border-color:rgba(74,222,128,.3)}
.badge-card.earned::after{content:'✓';position:absolute;top:10px;right:12px;background:#4ade80;color:#000;width:20px;height:20px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:800}
.badge-card.locked{opacity:.4;filter:grayscale(1)}
.badge-card.locked:hover{transform:none;border-color:var(--border)}
.badge-icon{font-size:36px;margin-bottom:10px;display:block}
.badge-card h4{font-size:14px;font-weight:700;color:#fff;margin-bottom:4px}
.badge-card p{font-size:12px;color:var(--muted)}
.level-list{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin-top:24px}
.level-item{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:14px;text-align:center;transition:all .3s}
.level-item.active{border-color:rgba(37,99,235,.5);background:rgba(37,99,235,.05)}
.level-item .name{font-size:13px;font-weight:700;color:#fff}
.level-item .range{font-size:11px;color:var(--muted);margin-top:2px}
@media(max-width:768px){.badges-grid{grid-template-columns:1fr 1fr}.level-list{grid-template-columns:1fr 1fr}}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="ach-header"><div class="container">
    <h1>🏆 Yutuqlar & Darajalar</h1>
    <p>O'z darajangizni oshiring va yangi yutuqlar qo'lga kiriting</p>
</div></section>

<div class="container">
    
    <div class="level-card">
        <div class="level-badge" style="background:<?php echo e($level['color']); ?>20;color:<?php echo e($level['color']); ?>">
            ⭐ <?php echo e($level['name']); ?> daraja
        </div>
        <div class="level-info">
            Sizning GreenCoin balansingiz: <strong style="color:#4ade80"><?php echo e(number_format($balance)); ?> GC</strong>
        </div>
        <div class="progress-bar">
            <div class="progress-fill" style="width:<?php echo e($progress); ?>%;background:<?php echo e($level['color']); ?>"></div>
        </div>
        <div class="progress-text">
            <?php if($level['name'] !== 'Lider'): ?>
                Keyingi daraja uchun <?php echo e(number_format($level['max'] - $balance)); ?> GC kerak
            <?php else: ?>
                Maksimal daraja erishildi! 🎉
            <?php endif; ?>
        </div>
    </div>

    
    <div class="level-list">
        <?php $levels = [['Yangi','0-99','#64748b'],['Faol','100-499','#10b981'],['Pro','500-1999','#3b82f6'],['Ekspert','2000-4999','#8b5cf6'],['Lider','5000+','#f59e0b']]; ?>
        <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="level-item <?php echo e($level['name'] === $l[0] ? 'active' : ''); ?>">
                <div class="name" style="color:<?php echo e($l[2]); ?>"><?php echo e($l[0]); ?></div>
                <div class="range"><?php echo e($l[1]); ?> GC</div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <div class="badges-section">
        <h3>🎖️ Yutuqlar (<?php echo e(count($earnedBadges)); ?>/<?php echo e(count($allBadges)); ?>)</h3>
        <div class="badges-grid">
            <?php $__currentLoopData = $allBadges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $badge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="badge-card <?php echo e(in_array($key, $earnedBadges) ? 'earned' : 'locked'); ?>">
                    <span class="badge-icon"><?php echo e($badge['icon']); ?></span>
                    <h4><?php echo e($badge['name']); ?></h4>
                    <p><?php echo e($badge['description']); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/6a4e91db8a003/data/www/ambarella.uz/resources/views/achievements/index.blade.php ENDPATH**/ ?>