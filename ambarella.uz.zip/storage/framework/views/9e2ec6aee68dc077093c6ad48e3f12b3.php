
<?php $__env->startSection('title', 'Mentorlar — 1:1 Konsultatsiya | AMBARELLA'); ?>
<?php $__env->startSection('description', 'IT, dizayn, biznes sohasidagi tajribali mentorlardan shaxsiy maslahat va yo\'l-yo\'riq oling.'); ?>
<?php $__env->startSection('styles'); ?>
<style>
.mentor-hero{padding:60px 0 48px;position:relative}
.mentor-hero::before{content:'';position:absolute;inset:0;background:radial-gradient(ellipse at 70% 30%,rgba(124,58,237,.07),transparent 60%)}
.mh-inner{display:grid;grid-template-columns:1fr 1fr;gap:48px;align-items:center}
.mentor-hero h1{font-size:clamp(28px,4vw,40px);font-weight:900;color:#fff;margin-bottom:12px}
.mentor-hero h1 span{background:linear-gradient(135deg,#a78bfa,#ec4899);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.mentor-hero p{font-size:15px;color:#94a3b8;line-height:1.7}
.mh-steps{margin-top:28px;display:flex;flex-direction:column;gap:12px}
.mhs{display:flex;align-items:flex-start;gap:12px}
.mhs-num{width:28px;height:28px;border-radius:50%;background:linear-gradient(135deg,#7c3aed,#a855f7);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:800;color:#fff;flex-shrink:0}
.mhs-text h4{font-size:13px;font-weight:700;color:#fff;margin-bottom:2px}
.mhs-text p{font-size:12px;color:var(--muted)}
/* Search/Filter */
.mentor-filters{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:20px}
.mf-row{display:flex;gap:8px;margin-bottom:10px}
.mf-row input{flex:1;padding:11px 14px;background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:10px;color:#fff;font-size:13px}
.mf-row input:focus{outline:none;border-color:#7c3aed}
.mf-row input::placeholder{color:#475569}
.mf-selects{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.mf-selects select{padding:9px 12px;background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:8px;color:#94a3b8;font-size:12px}
/* Stats */
.mentor-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin:40px 0 28px}
.ms-card{background:var(--surface);border:1px solid rgba(124,58,237,.12);border-radius:14px;padding:18px;text-align:center;transition:all .3s}
.ms-card:hover{border-color:rgba(124,58,237,.3);transform:translateY(-2px)}
.ms-card strong{display:block;font-size:22px;font-weight:800;color:#a78bfa}
.ms-card span{font-size:11px;color:var(--muted);margin-top:3px;display:block}
/* Mentors Grid */
.mentors-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:18px}
.mentor-card{background:var(--surface);border:1px solid var(--border);border-radius:18px;padding:26px;transition:all .35s cubic-bezier(.4,0,.2,1);display:flex;flex-direction:column;position:relative;overflow:hidden}
.mentor-card:hover{border-color:rgba(124,58,237,.3);transform:translateY(-4px);box-shadow:0 14px 36px rgba(124,58,237,.08)}
.mentor-card::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,#7c3aed,#a855f7,#ec4899);transform:scaleX(0);transition:transform .3s;transform-origin:left}
.mentor-card:hover::before{transform:scaleX(1)}
.mc-header{display:flex;align-items:center;gap:14px;margin-bottom:16px}
.mc-avatar{width:56px;height:56px;border-radius:50%;background:linear-gradient(135deg,rgba(124,58,237,.2),rgba(168,85,247,.15));display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:800;color:#a78bfa;border:2px solid rgba(124,58,237,.2);flex-shrink:0;position:relative}
.mc-available-dot{position:absolute;bottom:2px;right:2px;width:10px;height:10px;border-radius:50%;background:#4ade80;border:2px solid #0f172a}
.mc-name{font-size:16px;font-weight:700;color:#fff}
.mc-company{font-size:12px;color:var(--muted);margin-top:1px}
.mc-role{display:inline-flex;align-items:center;gap:5px;font-size:12px;font-weight:600;color:#a78bfa;background:rgba(124,58,237,.08);padding:4px 10px;border-radius:999px;border:1px solid rgba(124,58,237,.12);margin-bottom:10px}
.mc-role svg{width:12px;height:12px;stroke:currentColor;fill:none;stroke-width:2}
.mc-bio{font-size:13px;color:#94a3b8;line-height:1.5;margin-bottom:12px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.mc-skills{display:flex;gap:5px;flex-wrap:wrap;margin-bottom:14px}
.mc-skill{padding:3px 9px;border-radius:999px;font-size:10px;font-weight:600;background:rgba(124,58,237,.07);color:#a78bfa;border:1px solid rgba(124,58,237,.1)}
.mc-footer{display:flex;justify-content:space-between;align-items:center;margin-top:auto;padding-top:14px;border-top:1px solid var(--border)}
.mc-rating{display:flex;align-items:center;gap:4px;font-size:13px;font-weight:700;color:#fbbf24}
.mc-exp{font-size:11px;color:var(--muted);display:flex;align-items:center;gap:4px}
.mc-exp svg{width:11px;height:11px;stroke:currentColor;fill:none;stroke-width:2}
.mc-request-btn{margin-top:14px;width:100%;justify-content:center;padding:10px;font-size:13px;font-weight:600}
.unavailable-tag{font-size:11px;color:var(--muted);text-align:center;margin-top:12px}
.pagination-wrap{padding:32px 0;display:flex;justify-content:center}
@media(max-width:1024px){.mh-inner{grid-template-columns:1fr}.mentor-filters{display:none}}
@media(max-width:768px){.mentors-grid{grid-template-columns:1fr}.mentor-stats{grid-template-columns:1fr}}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<section class="mentor-hero">
  <div class="container">
    <div class="mh-inner">
      <div>
        <h1>Tajribali <span>mentorlar</span> bilan o'sing</h1>
        <p>IT, dizayn, marketing, biznes sohasidagi mutaxassislardan 1:1 konsultatsiya oling va karyerangizni tezlashtiring.</p>
        <div class="mh-steps">
          <div class="mhs"><div class="mhs-num">1</div><div class="mhs-text"><h4>Mentor tanlang</h4><p>Ko'nikmalar va tajriba bo'yicha filtrlang</p></div></div>
          <div class="mhs"><div class="mhs-num">2</div><div class="mhs-text"><h4>So'rov yuboring</h4><p>Maqsadlaringizni tushuntiring</p></div></div>
          <div class="mhs"><div class="mhs-num">3</div><div class="mhs-text"><h4>Sessiya o'tkazing</h4><p>Onlayn 1:1 yoki guruhlarda</p></div></div>
        </div>
      </div>
      <div class="mentor-filters">
        <form method="GET" action="/mentor">
          <div class="mf-row">
            <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Ism yoki soha bo'yicha qidirish...">
            <button type="submit" class="btn btn-primary" style="padding:11px 16px;background:#7c3aed">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
            </button>
          </div>
          <div class="mf-selects">
            <select name="available" onchange="this.form.submit()">
              <option value="">Barchasi</option>
              <option value="1" <?php echo e(request('available')=='1'?'selected':''); ?>>Faqat bo'sh</option>
            </select>
            <select name="sort" onchange="this.form.submit()">
              <option value="rating" <?php echo e(request('sort','rating')=='rating'?'selected':''); ?>>Reyting bo'yicha</option>
              <option value="sessions" <?php echo e(request('sort')=='sessions'?'selected':''); ?>>Sessiyalar bo'yicha</option>
            </select>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>

<div class="container" style="padding-bottom:64px">
  <div class="mentor-stats">
    <div class="ms-card"><strong><?php echo e($mentors->total()); ?></strong><span>Jami mentorlar</span></div>
    <div class="ms-card"><strong><?php echo e($mentors->where('is_available', true)->count()); ?></strong><span>Hozir bo'sh</span></div>
    <div class="ms-card"><strong>5+</strong><span>Soha yo'nalishlari</span></div>
  </div>

  <?php if(session('success')): ?>
    <div class="alert alert-success" style="margin-bottom:20px"><?php echo e(session('success')); ?></div>
  <?php endif; ?>
  <?php if($errors->any()): ?>
    <div class="alert alert-error" style="margin-bottom:20px"><?php echo e($errors->first()); ?></div>
  <?php endif; ?>

  <div class="mentors-grid">
    <?php $__empty_1 = true; $__currentLoopData = $mentors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mentor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="mentor-card">
      <div class="mc-header">
        <div class="mc-avatar">
          <?php echo e($mentor->initials); ?>

          <?php if($mentor->is_available): ?><span class="mc-available-dot"></span><?php endif; ?>
        </div>
        <div>
          <div class="mc-name"><?php echo e($mentor->name); ?></div>
          <?php if($mentor->company): ?><div class="mc-company"><?php echo e($mentor->company); ?></div><?php endif; ?>
        </div>
      </div>

      <span class="mc-role">
        <svg viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/></svg>
        <?php echo e($mentor->role); ?>

      </span>

      <?php if($mentor->bio): ?>
      <p class="mc-bio"><?php echo e($mentor->bio); ?></p>
      <?php endif; ?>

      <?php if(!empty($mentor->skills)): ?>
      <div class="mc-skills">
        <?php $__currentLoopData = array_slice($mentor->skills, 0, 4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <span class="mc-skill"><?php echo e($skill); ?></span>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(count($mentor->skills) > 4): ?>
        <span class="mc-skill">+<?php echo e(count($mentor->skills) - 4); ?></span>
        <?php endif; ?>
      </div>
      <?php endif; ?>

      <div class="mc-footer">
        <span class="mc-rating">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="#fbbf24" stroke="none"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
          <?php echo e($mentor->rating ?? '5.0'); ?>

        </span>
        <span class="mc-exp">
          <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
          <?php echo e($mentor->experience ?? '2+ yil'); ?>

        </span>
      </div>

      <?php if(auth()->guard()->check()): ?>
        <?php if($mentor->is_available): ?>
          <form action="/mentor/<?php echo e($mentor->id); ?>/request" method="POST">
            <?php echo csrf_field(); ?>
            <button class="btn mc-request-btn" style="background:#7c3aed;color:#fff;border:none">So'rov yuborish</button>
          </form>
        <?php else: ?>
          <p class="unavailable-tag">Hozirda band — tez orada bo'shaydi</p>
        <?php endif; ?>
      <?php else: ?>
        <a href="/login" class="btn btn-outline mc-request-btn">So'rov uchun kiring</a>
      <?php endif; ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div style="grid-column:1/-1;text-align:center;padding:80px 24px;color:var(--muted)">
      <p>Hozircha mentorlar yo'q.</p>
    </div>
    <?php endif; ?>
  </div>

  <?php if($mentors->hasPages()): ?>
  <div class="pagination-wrap"><?php echo e($mentors->links()); ?></div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/6a4e91db8a003/data/www/ambarella.uz/resources/views/mentor/index.blade.php ENDPATH**/ ?>