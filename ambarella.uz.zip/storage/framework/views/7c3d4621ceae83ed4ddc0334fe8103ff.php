
<?php $__env->startSection('title', 'Mening kurslarim | AMBARELLA'); ?>
<?php $__env->startSection('styles'); ?>
<style>
.page-hero{padding:48px 0 32px}
.page-hero h1{font-size:24px;font-weight:800;color:#fff;margin-bottom:6px}
.page-hero p{color:var(--muted);font-size:14px}
.courses-list{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px;padding:24px 0}
.course-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:22px;transition:all .2s}
.course-card:hover{border-color:rgba(245,158,11,.3);transform:translateY(-2px)}
.course-card h3{font-size:15px;font-weight:600;color:#fff;margin-bottom:6px}
.course-card .instructor{font-size:13px;color:var(--muted);margin-bottom:10px}
.course-card .badges{display:flex;gap:6px;flex-wrap:wrap}
.course-card .badge{padding:3px 10px;border-radius:999px;font-size:11px;font-weight:500}
.badge-level{background:rgba(37,99,235,.08);color:#93c5fd}
.badge-duration{background:rgba(124,58,237,.08);color:#a78bfa}
.empty-state{text-align:center;padding:64px 24px;color:var(--muted);font-size:14px}
@media(max-width:768px){.courses-list{grid-template-columns:1fr}}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="page-hero"><div class="container">
  <h1>Mening kurslarim</h1>
  <p>Siz yozilgan kurslar</p>
</div></section>
<div class="container">
  <div class="courses-list">
    <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <a href="/academy/<?php echo e($course->id); ?>" class="course-card">
      <h3><?php echo e($course->title); ?></h3>
      <p class="instructor"><?php echo e($course->instructor); ?></p>
      <div class="badges">
        <span class="badge badge-level"><?php echo e($course->level); ?></span>
        <span class="badge badge-duration"><?php echo e($course->duration); ?></span>
      </div>
    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="empty-state" style="grid-column:1/-1">
      <p>Hali kurslarga yozilmagansiz. <a href="/academy" style="color:var(--primary)">Kurslarni ko'ring</a></p>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/6a4e91db8a003/data/www/ambarella.uz/resources/views/my-courses/index.blade.php ENDPATH**/ ?>