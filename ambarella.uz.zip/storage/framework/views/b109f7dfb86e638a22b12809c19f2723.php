
<?php $__env->startSection('title', $news->title . ' | AMBARELLA'); ?>
<?php $__env->startSection('styles'); ?>
<style>
.news-detail{padding:48px 0}
.news-back{display:inline-flex;align-items:center;gap:6px;color:var(--muted);font-size:13px;margin-bottom:24px;transition:color .2s}
.news-back:hover{color:#fff}
.news-category{font-size:12px;font-weight:600;color:var(--primary);margin-bottom:8px;display:inline-block}
.news-detail h1{font-size:clamp(24px,4vw,36px);font-weight:800;color:#fff;margin-bottom:16px;line-height:1.3}
.news-meta-row{display:flex;gap:16px;color:var(--muted);font-size:13px;margin-bottom:32px}
.news-content{font-size:15px;line-height:1.9;color:#cbd5e1;white-space:pre-line}
.news-image{width:100%;max-height:400px;object-fit:cover;border-radius:var(--radius);margin-bottom:24px}
.related-section{margin-top:48px;padding-top:32px;border-top:1px solid var(--border)}
.related-section h3{font-size:18px;font-weight:700;color:#fff;margin-bottom:16px}
.related-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px}
.related-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:20px;transition:all .2s}
.related-card:hover{border-color:var(--primary);transform:translateY(-2px)}
.related-card h4{font-size:15px;font-weight:600;color:#fff;margin-bottom:6px}
.related-card p{font-size:13px;color:var(--muted)}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="news-detail">
    <a href="/news" class="news-back">← Yangiliklarga qaytish</a>
    <span class="news-category"><?php echo e($news->category); ?></span>
    <h1><?php echo e($news->title); ?></h1>
    <div class="news-meta-row">
      <span><?php echo e($news->author); ?></span>
      <span><?php echo e($news->created_at->format('d M Y')); ?></span>
    </div>
    <?php if($news->image): ?>
      <img src="<?php echo e($news->image); ?>" alt="<?php echo e($news->title); ?>" class="news-image">
    <?php endif; ?>
    <div class="news-content"><?php echo e($news->content); ?></div>

    <?php if($related->count() > 0): ?>
    <div class="related-section">
      <h3>O'xshash yangiliklar</h3>
      <div class="related-grid">
        <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="/news/<?php echo e($item->id); ?>" class="related-card">
          <h4><?php echo e($item->title); ?></h4>
          <p><?php echo e(Str::limit($item->content, 80)); ?></p>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/6a4e91db8a003/data/www/ambarella.uz/resources/views/news/show.blade.php ENDPATH**/ ?>