
<?php $__env->startSection('title', 'Profil | AMBARELLA'); ?>
<?php $__env->startSection('styles'); ?>
<style>
.profile-page{padding:48px 0;max-width:600px;margin:0 auto}
.profile-page h1{font-size:24px;font-weight:800;color:#fff;margin-bottom:8px}
.profile-page>p{color:var(--muted);font-size:14px;margin-bottom:32px}
.profile-form{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:28px;margin-bottom:20px}
.profile-form h3{font-size:15px;font-weight:700;color:#fff;margin-bottom:16px;display:flex;align-items:center;gap:8px}
.profile-form h3 svg{width:18px;height:18px;stroke:var(--primary);stroke-width:2;fill:none}
.form-group{margin-bottom:18px}
.form-group label{display:block;font-size:13px;font-weight:600;margin-bottom:6px;color:#94a3b8}
.form-group input{width:100%;padding:12px 16px;border:1px solid var(--border);border-radius:var(--radius);font-size:14px;background:rgba(255,255,255,.02);color:#fff;font-family:inherit;transition:border .2s}
.form-group input:focus{outline:none;border-color:var(--primary);box-shadow:0 0 0 3px rgba(37,99,235,.1)}
.form-group input::placeholder{color:#475569}
.form-group input[type="file"]{padding:10px;font-size:13px;color:#94a3b8}
.form-hint{font-size:11px;color:var(--muted);margin-top:4px}
@media(max-width:768px){.profile-page{padding:32px 0}}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="profile-page">
    <h1>Profil sozlamalari</h1>
    <p>Shaxsiy ma'lumotlaringizni yangilang</p>

    <form method="POST" action="/profile" enctype="multipart/form-data" class="profile-form">
      <?php echo csrf_field(); ?>
      <h3><svg viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg> Shaxsiy ma'lumotlar</h3>
      <div class="form-group"><label>Ism</label><input name="name" value="<?php echo e($user->name); ?>" required placeholder="To'liq ismingiz"></div>
      <div class="form-group"><label>Telefon</label><input name="phone" value="<?php echo e($user->phone); ?>" placeholder="+998 90 000 00 00"></div>
      <div class="form-group"><label>Avatar</label><input name="avatar" type="file" accept="image/jpeg,image/png,image/webp"><p class="form-hint">JPG, PNG yoki WebP. Max 2MB</p></div>
      <button type="submit" class="btn btn-primary" style="padding:12px 24px;font-size:13px">Saqlash</button>
    </form>

    <form method="POST" action="/profile/password" class="profile-form">
      <?php echo csrf_field(); ?>
      <h3><svg viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg> Parol o'zgartirish</h3>
      <div class="form-group"><label>Joriy parol</label><input name="current_password" type="password" required placeholder="Joriy parolingiz"></div>
      <div class="form-group"><label>Yangi parol</label><input name="password" type="password" required minlength="8" placeholder="Kamida 8 belgi"></div>
      <div class="form-group"><label>Yangi parolni tasdiqlang</label><input name="password_confirmation" type="password" required minlength="8" placeholder="Qayta kiriting"></div>
      <button type="submit" class="btn btn-primary" style="padding:12px 24px;font-size:13px">Parolni o'zgartirish</button>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/6a4e91db8a003/data/www/ambarella.uz/resources/views/profile/edit.blade.php ENDPATH**/ ?>