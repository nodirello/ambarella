
<?php $__env->startSection('title', 'Ish E\'lonlari — Bandlik | AMBARELLA'); ?>
<?php $__env->startSection('description', 'IT, marketing, dizayn va boshqa sohalarda ish o\'rinlari. Ariza topshiring va karyerangizni boshlang.'); ?>
<?php $__env->startSection('styles'); ?>
<style>
/* PAGE HERO */
.jobs-hero{padding:56px 0 0;position:relative}
.jobs-hero::before{content:'';position:absolute;inset:0;background:radial-gradient(ellipse at 20% 50%,rgba(37,99,235,.06),transparent 60%)}
.jobs-hero-inner{display:grid;grid-template-columns:1fr 360px;gap:40px;align-items:end}
.jobs-hero h1{font-size:clamp(28px,4vw,40px);font-weight:900;color:#fff;margin-bottom:10px}
.jobs-hero p{font-size:15px;color:var(--muted);margin-bottom:28px;max-width:480px}
.jobs-stats-mini{display:flex;gap:20px;flex-wrap:wrap}
.jsm{display:flex;align-items:center;gap:8px;font-size:13px;color:#94a3b8}
.jsm .jsm-dot{width:8px;height:8px;border-radius:50%}
.jsm strong{color:#fff;font-weight:700}

/* SEARCH BOX */
.search-box{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:20px;position:relative;z-index:2}
.search-row{display:grid;grid-template-columns:1fr auto;gap:10px;margin-bottom:12px}
.search-row input{padding:12px 16px;background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:10px;color:#fff;font-size:14px;width:100%;transition:border-color .2s}
.search-row input:focus{outline:none;border-color:var(--primary)}
.search-row input::placeholder{color:#475569}
.filter-row{display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px}
.filter-row select{padding:10px 12px;background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:8px;color:#94a3b8;font-size:13px;width:100%}
.filter-row select:focus{outline:none;border-color:var(--primary);color:#fff}

/* MAIN LAYOUT */
.jobs-layout{display:grid;grid-template-columns:1fr;gap:24px;padding:32px 0 64px}

/* TOOLBAR */
.jobs-toolbar{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;flex-wrap:wrap;gap:12px}
.jobs-toolbar .results-count{font-size:14px;color:var(--muted)}
.jobs-toolbar .results-count strong{color:#fff}
.sort-select{padding:8px 14px;background:var(--surface);border:1px solid var(--border);border-radius:8px;color:#94a3b8;font-size:13px}
.sort-select:focus{outline:none;border-color:var(--primary)}

/* JOB CARDS */
.jobs-list{display:flex;flex-direction:column;gap:12px}
.job-card{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:22px 26px;transition:all .35s cubic-bezier(.4,0,.2,1);display:grid;grid-template-columns:1fr auto;gap:20px;align-items:center;position:relative;overflow:hidden}
.job-card::before{content:'';position:absolute;left:0;top:0;bottom:0;width:3px;background:var(--jc-color,var(--primary));transform:scaleY(0);transform-origin:bottom;transition:transform .3s}
.job-card:hover{border-color:var(--jc-color,rgba(37,99,235,.3));transform:translateY(-3px);box-shadow:0 12px 32px rgba(0,0,0,.12)}
.job-card:hover::before{transform:scaleY(1)}
.job-card-logo{width:44px;height:44px;border-radius:10px;background:rgba(37,99,235,.1);display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:800;color:#60a5fa;flex-shrink:0;border:1px solid rgba(37,99,235,.15)}
.jc-top{display:flex;align-items:center;gap:12px;margin-bottom:10px}
.jc-title{font-size:16px;font-weight:700;color:#fff;transition:color .2s}
.job-card:hover .jc-title{color:#93c5fd}
.jc-meta{display:flex;align-items:center;gap:14px;flex-wrap:wrap;font-size:12px;color:var(--muted);margin-bottom:10px}
.jc-meta svg{width:13px;height:13px;stroke:currentColor;fill:none;stroke-width:2}
.jc-meta span{display:flex;align-items:center;gap:4px}
.jc-tags{display:flex;gap:6px;flex-wrap:wrap}
.jc-tag{padding:3px 10px;border-radius:999px;font-size:11px;font-weight:500;background:rgba(37,99,235,.06);color:#93c5fd;border:1px solid rgba(37,99,235,.1)}
.jc-right{text-align:right;display:flex;flex-direction:column;align-items:flex-end;gap:8px}
.jc-salary{font-size:17px;font-weight:800;color:#4ade80;white-space:nowrap}
.jc-salary small{font-size:11px;color:var(--muted);font-weight:400;display:block;margin-top:2px}
.jc-type{padding:4px 12px;border-radius:999px;font-size:11px;font-weight:700;white-space:nowrap}
.jc-new{font-size:10px;font-weight:700;background:rgba(239,68,68,.1);color:#f87171;padding:2px 8px;border-radius:999px;border:1px solid rgba(239,68,68,.15)}

/* EMPTY */
.empty-jobs{text-align:center;padding:80px 24px}
.empty-jobs svg{width:80px;height:80px;margin:0 auto 20px;stroke:rgba(255,255,255,.08);fill:none;stroke-width:1}
.empty-jobs p{color:var(--muted);font-size:15px}

/* PAGINATION */
.pagination-wrap{margin-top:32px;display:flex;justify-content:center}

@media(max-width:1024px){.jobs-hero-inner{grid-template-columns:1fr}}
@media(max-width:768px){.job-card{grid-template-columns:1fr}.jc-right{align-items:flex-start;text-align:left;flex-direction:row;flex-wrap:wrap;gap:8px}.filter-row{grid-template-columns:1fr 1fr}.search-row{grid-template-columns:1fr}}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<section class="jobs-hero">
  <div class="container">
    <div class="jobs-hero-inner">
      <div>
        <h1>Ish e'lonlari</h1>
        <p>O'zbekistonning eng yaxshi kompaniyalarida ish imkoniyatlarini toping</p>
        <div class="jobs-stats-mini">
          <span class="jsm"><span class="jsm-dot" style="background:#4ade80"></span><strong><?php echo e($stats['total']); ?></strong> faol vakansiya</span>
          <span class="jsm"><span class="jsm-dot" style="background:#22d3ee"></span><strong><?php echo e($stats['remote']); ?></strong> masofaviy</span>
          <span class="jsm"><span class="jsm-dot" style="background:#fbbf24"></span><strong><?php echo e($stats['new']); ?></strong> yangi (7 kunda)</span>
        </div>
      </div>
      <div class="search-box">
        <form method="GET" action="/jobs">
          <div class="search-row">
            <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Lavozim yoki kompaniya...">
            <button type="submit" class="btn btn-primary" style="padding:12px 20px;white-space:nowrap">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
            </button>
          </div>
          <div class="filter-row">
            <select name="type" onchange="this.form.submit()">
              <option value="">Ish turi</option>
              <option value="toliq" <?php echo e(request('type')=='toliq'?'selected':''); ?>>To'liq kunlik</option>
              <option value="yarim" <?php echo e(request('type')=='yarim'?'selected':''); ?>>Yarim kunlik</option>
              <option value="masofaviy" <?php echo e(request('type')=='masofaviy'?'selected':''); ?>>Masofaviy</option>
              <option value="freelance" <?php echo e(request('type')=='freelance'?'selected':''); ?>>Freelance</option>
            </select>
            <select name="location" onchange="this.form.submit()">
              <option value="">Joylashuv</option>
              <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($loc); ?>" <?php echo e(request('location')==$loc?'selected':''); ?>><?php echo e($loc); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <select name="sort" onchange="this.form.submit()">
              <option value="latest" <?php echo e(request('sort','latest')=='latest'?'selected':''); ?>>Yangi</option>
              <option value="salary_high" <?php echo e(request('sort')=='salary_high'?'selected':''); ?>>Yuqori maosh</option>
              <option value="popular" <?php echo e(request('sort')=='popular'?'selected':''); ?>>Mashhur</option>
            </select>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>


<div class="container">
  <div class="jobs-layout">
    <div>
      
      <?php if(request('search') || request('type') || request('location')): ?>
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:16px;flex-wrap:wrap">
        <span style="font-size:12px;color:var(--muted)">Filtrlar:</span>
        <?php if(request('search')): ?>
        <a href="<?php echo e(request()->except('search') ? '?'.http_build_query(request()->except('search')) : '/jobs'); ?>" style="display:inline-flex;align-items:center;gap:5px;padding:4px 10px;border-radius:999px;background:rgba(37,99,235,.1);color:#93c5fd;font-size:11px;font-weight:600">
          "<?php echo e(request('search')); ?>" &times;
        </a>
        <?php endif; ?>
        <?php if(request('type')): ?>
        <a href="<?php echo e('?'.http_build_query(request()->except('type'))); ?>" style="display:inline-flex;align-items:center;gap:5px;padding:4px 10px;border-radius:999px;background:rgba(124,58,237,.1);color:#c084fc;font-size:11px;font-weight:600">
          <?php echo e(request('type')); ?> &times;
        </a>
        <?php endif; ?>
        <?php if(request('location')): ?>
        <a href="<?php echo e('?'.http_build_query(request()->except('location'))); ?>" style="display:inline-flex;align-items:center;gap:5px;padding:4px 10px;border-radius:999px;background:rgba(245,158,11,.1);color:#fbbf24;font-size:11px;font-weight:600">
          <?php echo e(request('location')); ?> &times;
        </a>
        <?php endif; ?>
        <a href="/jobs" style="font-size:11px;color:var(--muted)">Barcha filtrlarni tozalash</a>
      </div>
      <?php endif; ?>

      
      <div class="jobs-toolbar">
        <p class="results-count"><strong><?php echo e($jobs->total()); ?></strong> ta vakansiya topildi</p>
      </div>

      
      <?php if(session('success')): ?>
        <div class="alert alert-success" style="margin-bottom:16px"><?php echo e(session('success')); ?></div>
      <?php endif; ?>
      <?php if($errors->any()): ?>
        <div class="alert alert-error" style="margin-bottom:16px"><?php echo e($errors->first()); ?></div>
      <?php endif; ?>

      <div class="jobs-list">
        <?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php
          $color = match($job->type ?? '') {
            'masofaviy' => '#22d3ee',
            'yarim' => '#fbbf24',
            'freelance' => '#a78bfa',
            default => '#4ade80',
          };
          $isNew = $job->created_at->gt(now()->subDays(3));
        ?>
        <a href="/jobs/<?php echo e($job->id); ?>" class="job-card" style="--jc-color:<?php echo e($color); ?>">
          <div>
            <div class="jc-top">
              <div class="job-card-logo"><?php echo e(strtoupper(substr($job->company ?? 'C', 0, 1))); ?></div>
              <div>
                <div class="jc-title"><?php echo e($job->title); ?></div>
                <div style="font-size:12px;color:var(--muted)"><?php echo e($job->company); ?></div>
              </div>
              <?php if($isNew): ?><span class="jc-new">YANGI</span><?php endif; ?>
            </div>
            <div class="jc-meta">
              <span><svg viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg><?php echo e($job->location ?? 'Noma\'lum'); ?></span>
              <span><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg><?php echo e($job->created_at->diffForHumans()); ?></span>
              <span><svg viewBox="0 0 24 24"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg><?php echo e($job->views_count ?? 0); ?> ko'rish</span>
            </div>
            <?php if(!empty($job->tags)): ?>
            <div class="jc-tags">
              <?php $__currentLoopData = array_slice($job->tags, 0, 3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <span class="jc-tag"><?php echo e($tag); ?></span>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
          </div>
          <div class="jc-right">
            <?php if($job->salary_min && $job->salary_max): ?>
            <div class="jc-salary">
              <?php echo e(number_format($job->salary_min/1000000,0)); ?>–<?php echo e(number_format($job->salary_max/1000000,0)); ?>M
              <small>so'm / oy</small>
            </div>
            <?php else: ?>
              <div class="jc-salary" style="font-size:13px;color:var(--muted)">Kelishiladi</div>
            <?php endif; ?>
            <span class="jc-type" style="background:color-mix(in srgb,<?php echo e($color); ?> 10%,transparent);color:<?php echo e($color); ?>;border:1px solid color-mix(in srgb,<?php echo e($color); ?> 20%,transparent)">
              <?php echo e($job->type ?? 'To\'liq'); ?>

            </span>
          </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="empty-jobs">
          <svg viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/></svg>
          <p>Hech qanday vakansiya topilmadi.<br>Boshqa parametrlar bilan qidiring yoki</p>
          <a href="/jobs" class="btn btn-outline" style="margin-top:16px">Filtrlarni tozalash</a>
        </div>
        <?php endif; ?>
      </div>

      
      <?php if($jobs->hasPages()): ?>
      <div class="pagination-wrap"><?php echo e($jobs->links()); ?></div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/6a4e91db8a003/data/www/ambarella.uz/resources/views/jobs/index.blade.php ENDPATH**/ ?>