
<?php $__env->startSection('title', 'Kirish | AMBARELLA'); ?>
<?php $__env->startSection('styles'); ?>
<style>
.auth-page{min-height:calc(100vh - 140px);display:flex;align-items:center;justify-content:center;padding:48px 24px}
.auth-card{width:100%;max-width:400px}
.auth-card h1{font-size:28px;font-weight:800;margin-bottom:8px}
.auth-card>p{color:var(--muted);margin-bottom:32px}
.form-group{margin-bottom:20px}.form-group label{display:block;font-size:14px;font-weight:500;margin-bottom:6px}
.form-group input{width:100%;padding:14px 16px;border:1.5px solid var(--border);border-radius:10px;font-size:15px;font-family:inherit}
.form-group input:focus{outline:none;border-color:var(--primary);box-shadow:0 0 0 3px rgba(37,99,235,.1)}
.auth-footer{margin-top:20px;text-align:center;font-size:14px;color:var(--muted)}.auth-footer a{color:var(--primary);font-weight:600}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="auth-page">
  <form class="auth-card" method="POST" action="/login">
    <?php echo csrf_field(); ?>
    <h1>Tizimga kirish</h1>
    <p>Email va parolingiz orqali kiring</p>
    <div class="form-group"><label>Email</label><input type="email" name="email" value="<?php echo e(old('email')); ?>" required placeholder="email@misol.uz"></div>
    <div class="form-group"><label>Parol</label><input type="password" name="password" required placeholder="Parolingiz" minlength="8"></div>
    <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:14px">Kirish</button>
    
    <div style="text-align:center;color:#94a3b8;font-size:13px;margin:24px 0;position:relative"><span style="background:#fff;padding:0 12px;position:relative;z-index:1">yoki</span><div style="position:absolute;top:50%;left:0;right:0;height:1px;background:var(--border)"></div></div>

    <!-- Variant A: Telegram Login Widget -->
    <div style="text-align:center;margin-bottom:16px">
      <script async src="https://telegram.org/js/telegram-widget.js?22" data-telegram-login="AmbarellaBot" data-size="large" data-radius="10" data-auth-url="<?php echo e(route('telegram.callback')); ?>" data-request-access="write"></script>
    </div>

    <!-- Variant B: Telegram kod orqali -->
    <div style="border:1px solid var(--border);border-radius:12px;padding:20px;margin-bottom:16px">
      <p style="font-size:13px;color:var(--muted);margin-bottom:12px;text-align:center">Telegram orqali kod bilan kirish</p>
      <div id="phoneStep">
        <div style="display:flex;gap:8px"><input type="tel" id="tgPhone" placeholder="+998 90 074 10 70" style="flex:1;padding:12px 14px;border:1px solid var(--border);border-radius:8px;font-size:14px"><button type="button" onclick="sendTgCode()" class="btn btn-primary" style="padding:12px 16px;font-size:13px;white-space:nowrap">Kod yuborish</button></div>
      </div>
      <div id="codeStep" style="display:none">
        <div style="display:flex;gap:8px"><input type="text" id="tgCode" placeholder="6 xonali kod" maxlength="6" style="flex:1;padding:12px 14px;border:1px solid var(--border);border-radius:8px;font-size:14px;text-align:center;letter-spacing:4px"><button type="button" onclick="verifyTgCode()" class="btn btn-primary" style="padding:12px 16px;font-size:13px">Tasdiqlash</button></div>
        <p style="font-size:12px;color:var(--muted);margin-top:8px;text-align:center">Kod Telegramga yuborildi</p>
      </div>
      <p id="tgMsg" style="font-size:12px;margin-top:8px;text-align:center"></p>
    </div>

    <p class="auth-footer">Hisobingiz yo'qmi? <a href="/register">Ro'yxatdan o'ting</a></p>
  </form>
</div>
<script>
let tgPhone='';
async function sendTgCode(){
  const phone=document.getElementById('tgPhone').value.trim();
  if(!phone){document.getElementById('tgMsg').textContent='Telefon raqam kiriting';return}
  tgPhone=phone;
  const res=await fetch('/auth/telegram/send-code',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-TOKEN':document.querySelector('meta[name=csrf-token]')?.content},body:JSON.stringify({phone})});
  const data=await res.json();
  if(data.success){document.getElementById('phoneStep').style.display='none';document.getElementById('codeStep').style.display='block';document.getElementById('tgMsg').textContent='';document.getElementById('tgMsg').style.color='#16a34a'}
  else{document.getElementById('tgMsg').textContent=data.message||'Xato';document.getElementById('tgMsg').style.color='#dc2626'}
}
async function verifyTgCode(){
  const code=document.getElementById('tgCode').value.trim();
  if(code.length!==6){document.getElementById('tgMsg').textContent='6 xonali kod kiriting';return}
  const res=await fetch('/auth/telegram/verify-code',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-TOKEN':document.querySelector('meta[name=csrf-token]')?.content},body:JSON.stringify({phone:tgPhone,code})});
  const data=await res.json();
  if(data.success){window.location.href=data.redirect}
  else{document.getElementById('tgMsg').textContent=data.message||'Kod noto\'g\'ri';document.getElementById('tgMsg').style.color='#dc2626'}
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/6a4e91db8a003/data/www/ambarella.uz/resources/views/auth/login.blade.php ENDPATH**/ ?>