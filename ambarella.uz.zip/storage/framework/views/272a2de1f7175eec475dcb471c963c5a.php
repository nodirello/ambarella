<!DOCTYPE html>
<html lang="uz">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Offline | AMBARELLA</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Inter',sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#0f172a;color:#e2e8f0;text-align:center;padding:24px}
.icon{width:80px;height:80px;margin:0 auto 24px;border-radius:20px;background:rgba(37,99,235,.1);display:flex;align-items:center;justify-content:center}
.icon svg{width:40px;height:40px;stroke:#60a5fa;stroke-width:1.5;fill:none}
h1{font-size:24px;font-weight:800;margin-bottom:8px}
p{color:#64748b;font-size:15px;margin-bottom:24px;max-width:400px}
.btn{display:inline-flex;padding:14px 28px;border-radius:12px;font-weight:600;font-size:15px;background:#2563eb;color:#fff;text-decoration:none;transition:all .2s}
.btn:hover{background:#1d4ed8}
</style>
</head>
<body>
<div>
  <div class="icon"><svg viewBox="0 0 24 24"><path d="M1 1l22 22M16.72 11.06A10.94 10.94 0 0119 12.55M5 12.55a10.94 10.94 0 015.17-2.39M10.71 5.05A16 16 0 0122.56 9M1.42 9a15.91 15.91 0 014.7-2.88M8.53 16.11a6 6 0 016.95 0M12 20h.01"/></svg></div>
  <h1>Internet yo'q</h1>
  <p>Hozirda internet aloqa mavjud emas. Iltimos, aloqani tekshirib qayta urinib ko'ring.</p>
  <a href="/" class="btn" onclick="location.reload();return false;">Qayta urinish</a>
</div>
</body>
</html>
<?php /**PATH /var/www/6a4e91db8a003/data/www/ambarella.uz/resources/views/offline.blade.php ENDPATH**/ ?>