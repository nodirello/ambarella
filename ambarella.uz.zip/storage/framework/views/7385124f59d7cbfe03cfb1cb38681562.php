
<?php $__env->startSection('title', $product->name . ' | AMBARELLA'); ?>
<?php $__env->startSection('styles'); ?>
<style>
.product-detail{padding:48px 0}
.back-link{display:inline-flex;align-items:center;gap:6px;color:var(--muted);font-size:13px;margin-bottom:24px;transition:color .2s}
.back-link:hover{color:#fff}
.product-main{display:grid;grid-template-columns:1fr 1fr;gap:40px;align-items:start}
.product-info h1{font-size:28px;font-weight:800;color:#fff;margin-bottom:12px}
.product-info .price{font-size:32px;font-weight:800;color:#4ade80;margin-bottom:16px}
.detail-row{display:flex;justify-content:space-between;padding:12px 0;border-bottom:1px solid var(--border);font-size:14px}
.detail-row span:first-child{color:var(--muted)}
.detail-row span:last-child{color:#fff;font-weight:500}
.seller-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:20px;margin-top:24px}
.seller-card h4{font-size:14px;font-weight:600;color:#fff;margin-bottom:8px}
.similar-section{margin-top:48px;padding-top:32px;border-top:1px solid var(--border)}
.similar-section h3{font-size:18px;font-weight:700;color:#fff;margin-bottom:16px}
.similar-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px}
.similar-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:18px;transition:all .2s}
.similar-card:hover{border-color:rgba(22,163,74,.3)}
@media(max-width:768px){.product-main{grid-template-columns:1fr}}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="product-detail">
    <a href="/farm" class="back-link">← Mahsulotlarga qaytish</a>
    <div class="product-main">
      <div class="product-info">
        <span style="font-size:12px;font-weight:600;color:var(--success);text-transform:uppercase"><?php echo e($product->category); ?></span>
        <h1><?php echo e($product->name); ?></h1>
        <div class="price"><?php echo e(number_format($product->price)); ?> so'm/<?php echo e($product->unit); ?></div>
        <?php if($product->description): ?>
          <p style="color:#94a3b8;font-size:15px;line-height:1.7;margin-bottom:24px"><?php echo e($product->description); ?></p>
        <?php endif; ?>
        <div class="detail-row"><span>Hudud</span><span><?php echo e($product->region); ?></span></div>
        <div class="detail-row"><span>Kategoriya</span><span><?php echo e($product->category); ?></span></div>
        <div class="detail-row"><span>O'lchov birligi</span><span><?php echo e($product->unit); ?></span></div>
        <div class="detail-row"><span>Joylangan sana</span><span><?php echo e($product->created_at->format('d M Y')); ?></span></div>
      </div>
      <div>
        <div class="seller-card">
          <h4>Sotuvchi</h4>
          <p style="color:#fff;font-size:15px;font-weight:600"><?php echo e($product->user->name ?? 'Fermer'); ?></p>
          <p style="color:var(--muted);font-size:13px;margin-top:4px">Ro'yxatga olingan: <?php echo e($product->user->created_at->format('M Y') ?? ''); ?></p>
        </div>
      </div>
    </div>

    <?php if($similar->count() > 0): ?>
    <div class="similar-section">
      <h3>O'xshash mahsulotlar</h3>
      <div class="similar-grid">
        <?php $__currentLoopData = $similar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="/farm/<?php echo e($item->id); ?>" class="similar-card">
          <span style="font-size:11px;color:var(--success)"><?php echo e($item->category); ?></span>
          <h4 style="font-size:14px;font-weight:600;color:#fff;margin:4px 0"><?php echo e($item->name); ?></h4>
          <span style="font-size:15px;font-weight:700;color:#4ade80"><?php echo e(number_format($item->price)); ?> so'm</span>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/6a4e91db8a003/data/www/ambarella.uz/resources/views/farm/show.blade.php ENDPATH**/ ?>