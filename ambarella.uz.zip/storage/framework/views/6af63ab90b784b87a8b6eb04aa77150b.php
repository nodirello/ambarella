
<?php $__env->startSection('title', 'Yangiliklar | AMBARELLA'); ?>
<?php $__env->startSection('styles'); ?>
<style>
.page-hero{padding:56px 0 40px;text-align:center;position:relative}
.page-hero h1{font-size:clamp(28px,4vw,38px);font-weight:800;color:#fff;margin-bottom:8px}
.page-hero p{color:var(--muted);font-size:15px}
.news-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:18px;padding:40px 0}
.news-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:26px;transition:all .3s;display:flex;flex-direction:column}
.news-card:hover{border-color:rgba(37,99,235,.4);transform:translateY(-3px);box-shadow:0 8px 32px rgba(37,99,235,.06)}
.news-card .category{font-size:12px;font-weight:600;color:#93c5fd;margin-bottom:8px;text-transform:uppercase;letter-spacing:.5px}
.news-card h3{font-size:17px;font-weight:700;color:#fff;margin-bottom:8px;line-height:1.4}
.news-card p{font-size:13px;color:var(--muted);line-height:1.6;flex:1}
.news-card-meta{display:flex;justify-content:space-between;align-items:center;font-size:12px;color:#475569;margin-top:14px;padding-top:14px;border-top:1px solid var(--border)}
.pagination-wrap{padding:24px 0;display:flex;justify-content:center}
@media(max-width:768px){.news-grid{grid-template-columns:1fr}}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="page-hero"><div class="container">
  <h1>Yangiliklar</h1>
  <p>Platforma va ekotizim yangiliklari</p>
</div></section>
<div class="container">
  <div class="news-grid">
    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="/news/<?php echo e($item->id); ?>" class="news-card">
      <span class="category"><?php echo e($item->category); ?></span>
      <h3><?php echo e($item->title); ?></h3>
      <p><?php echo e(Str::limit($item->content, 130)); ?></p>
      <div class="news-card-meta">
        <span><?php echo e($item->author); ?></span>
        <span><?php echo e($item->created_at->format('d M Y')); ?></span>
      </div>
    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <div class="pagination-wrap"><?php echo e($news->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/6a4e91db8a003/data/www/ambarella.uz/resources/views/news/index.blade.php ENDPATH**/ ?>