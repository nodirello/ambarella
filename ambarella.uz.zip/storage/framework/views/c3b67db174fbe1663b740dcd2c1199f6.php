
<?php $__env->startSection('title', 'Mening mahsulotlarim | AMBARELLA'); ?>
<?php $__env->startSection('styles'); ?>
<style>
.page-hero{padding:48px 0}
.page-hero h1{font-size:24px;font-weight:800;color:#fff;margin-bottom:8px}
.products-table{width:100%;border-collapse:collapse;margin-top:24px}
.products-table th{text-align:left;padding:12px 14px;font-size:12px;text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid var(--border)}
.products-table td{padding:14px;border-bottom:1px solid var(--border);font-size:14px}
.active-badge{padding:3px 8px;border-radius:999px;font-size:11px;font-weight:600}
.active-badge.yes{background:rgba(22,163,74,.1);color:#4ade80}
.active-badge.no{background:rgba(220,38,38,.1);color:#fca5a5}
.actions-cell{display:flex;gap:6px}
.empty-state{text-align:center;padding:48px;color:var(--muted);font-size:14px}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="page-hero"><div class="container">
  <div style="display:flex;justify-content:space-between;align-items:center">
    <h1>Mening mahsulotlarim</h1>
    <a href="/farm/create" class="btn btn-success">+ Yangi mahsulot</a>
  </div>
</div></section>
<div class="container">
  <?php if($products->count() > 0): ?>
  <table class="products-table">
    <thead><tr><th>Nomi</th><th>Kategoriya</th><th>Narxi</th><th>Hudud</th><th>Holat</th><th>Amallar</th></tr></thead>
    <tbody>
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td style="font-weight:600;color:#fff"><?php echo e($product->name); ?></td>
        <td><?php echo e($product->category); ?></td>
        <td style="color:#4ade80;font-weight:600"><?php echo e(number_format($product->price)); ?> so'm/<?php echo e($product->unit); ?></td>
        <td><?php echo e($product->region); ?></td>
        <td><span class="active-badge <?php echo e($product->is_active ? 'yes' : 'no'); ?>"><?php echo e($product->is_active ? 'Faol' : 'Nofaol'); ?></span></td>
        <td>
          <div class="actions-cell">
            <a href="/farm/<?php echo e($product->id); ?>/edit" class="btn btn-outline" style="padding:6px 10px;font-size:11px">Tahrirlash</a>
            <form action="/farm/<?php echo e($product->id); ?>/toggle" method="POST"><?php echo csrf_field(); ?><button class="btn btn-outline" style="padding:6px 10px;font-size:11px"><?php echo e($product->is_active ? 'O\'chirish' : 'Yoqish'); ?></button></form>
            <form action="/farm/<?php echo e($product->id); ?>" method="POST" onsubmit="return confirm('Rostan o\'chirmoqchimisiz?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="btn" style="padding:6px 10px;font-size:11px;color:var(--danger)">🗑️</button></form>
          </div>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <?php else: ?>
  <div class="empty-state">Hali mahsulot qo'shmagansiz. <a href="/farm/create" style="color:var(--primary)">Birinchi mahsulotingizni qo'shing!</a></div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/6a4e91db8a003/data/www/ambarella.uz/resources/views/farm/my-products.blade.php ENDPATH**/ ?>