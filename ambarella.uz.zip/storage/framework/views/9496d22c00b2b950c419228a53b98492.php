<div id="cookieConsent" class="cookie-consent" style="display:none">
  <div class="cookie-content">
    <p>Bu sayt sifatli xizmat ko&#39;rsatish uchun cookie (kukilar) ishlatadi.</p>
    <button onclick="acceptCookies()" class="cookie-accept-btn">Roziman</button>
  </div>
</div>
<style>
.cookie-consent{position:fixed;bottom:0;left:0;right:0;z-index:9998;padding:16px 24px;background:rgba(15,23,42,.95);backdrop-filter:blur(12px);border-top:1px solid var(--border);animation:slideUp .4s ease}
@keyframes slideUp{from{transform:translateY(100%)}to{transform:translateY(0)}}
.cookie-content{max-width:1100px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap}
.cookie-content p{font-size:14px;color:#94a3b8;margin:0}
.cookie-accept-btn{padding:10px 24px;background:#2563eb;color:#fff;border:none;border-radius:8px;font-weight:600;font-size:13px;cursor:pointer;transition:all .2s}
.cookie-accept-btn:hover{background:#1d4ed8;transform:translateY(-1px)}
@media(max-width:768px){.cookie-content{flex-direction:column;text-align:center}}
</style>
<script>
(function(){
  if(!localStorage.getItem('cookie_accepted')){
    document.getElementById('cookieConsent').style.display='block';
  }
})();
function acceptCookies(){
  localStorage.setItem('cookie_accepted','true');
  document.getElementById('cookieConsent').style.display='none';
}
</script>
<?php /**PATH /var/www/6a4e91db8a003/data/www/ambarella.uz/resources/views/components/cookie-consent.blade.php ENDPATH**/ ?>