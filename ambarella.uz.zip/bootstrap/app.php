<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->validateCsrfTokens(except: [
            '/webhook/telegram',
        ]);

        $middleware->append(\App\Http\Middleware\SecurityHeaders::class);
        $middleware->append(\App\Http\Middleware\SetLocale::class);

        $middleware->alias([
            'banned' => \App\Http\Middleware\CheckBanned::class,
            'profile.complete' => \App\Http\Middleware\CheckProfileComplete::class,
            'admin' => \App\Http\Middleware\IsAdmin::class,
            '2fa' => \App\Http\Middleware\TwoFactorAuth::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        // Production'da 500 xatolarni log qilish
        $exceptions->reportable(function (\Throwable $e) {
            if (config('app.env') === 'production') {
                \Illuminate\Support\Facades\Log::error('Exception: ' . $e->getMessage(), [
                    'file' => $e->getFile(),
                    'line' => $e->getLine(),
                    'url' => request()->fullUrl(),
                    'user_id' => auth()->id(),
                ]);
            }
        });
    })->create();
